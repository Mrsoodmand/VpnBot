export type ConfigIdentity = {name:string;flag:string};
type OrderLocation = {country_name?:string;flag?:string};

function decodeLabel(value:string):string {
  try { return decodeURIComponent(value); } catch { return value; }
}

function configName(link:string):string {
  const hash=link.indexOf('#');
  if(hash>=0) return decodeLabel(link.slice(hash+1));
  if(/^vmess:\/\//i.test(link)) {
    try {
      const encoded=link.slice(8).replace(/-/g,'+').replace(/_/g,'/');
      const bytes=Uint8Array.from(atob(encoded),char=>char.charCodeAt(0));
      const data=JSON.parse(new TextDecoder().decode(bytes));
      return typeof data.ps==='string'?data.ps:'';
    } catch { return ''; }
  }
  return '';
}

/** Read the display name only; never infer a location from credentials or hostnames. */
export function configIdentity(link:string,order:OrderLocation={}):ConfigIdentity {
  const name=configName(link).replace(/[\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/g,'').trim();
  const countryFlag=/[\u{1f1e6}-\u{1f1ff}]{2}/u;
  const ownFlag=name.match(countryFlag)?.[0];
  const fallbackFlag=order.flag?.match(countryFlag)?.[0];
  const flag=ownFlag||fallbackFlag||'🌐';
  const label=(ownFlag?name.replace(ownFlag,''):name).trim();
  let country='';
  if(ownFlag) {
    const code=Array.from(ownFlag).map(char=>String.fromCharCode(char.codePointAt(0)!-0x1f1e6+65)).join('');
    try { country=new Intl.DisplayNames(['fa'],{type:'region',fallback:'none'}).of(code)||''; } catch { /* Older browser */ }
  }
  return {name:label||country||order.country_name||'نام کانفیگ مشخص نیست',flag};
}

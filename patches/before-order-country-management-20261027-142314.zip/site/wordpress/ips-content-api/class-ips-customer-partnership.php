<?php
defined('ABSPATH') || exit;
/** First-party adapter for the existing reseller application and credential rules. */
final class IPS_Bridge_Customer_Partnership {
    private static function error($message,$status=400){return new WP_Error('ips_partnership',$message,['status'=>$status]);}
    public static function handle($r,$user,$db,$write=false){
        global $wpdb;
        if(!class_exists('IPSVP_Reseller_Store'))return self::error('سرویس نمایندگی فعال نیست.',503);
        if($write){$lock=IPSVP_Reseller_Store::lock($user->id);if(is_wp_error($lock))return $lock;}
        $a=IPSVP_Reseller_Store::account($user->id);$table=IPSVP_Reseller_Store::table('accounts');
        $message='';$secret=null;
        if($write){
            $action=$r->get_param('action');
            if($action==='apply'){
                if($a&&!in_array($a->status,['rejected','customer'],true))return self::error('درخواست قبلاً ثبت شده است یا حساب نیاز به بررسی مدیریت دارد.',409);
                $balance=IPSVP_Reseller_Store::balance($user,$db);if(is_wp_error($balance))return $balance;
                if($balance<IPSVP_Reseller_Store::MIN_BALANCE)return self::error('موجودی کیف پول برای درخواست نمایندگی کافی نیست.',402);
                foreach(['business_name','website','application_note'] as $f)if(!is_string($r->get_param($f)))return self::error('اطلاعات درخواست معتبر نیست.');
                $name=sanitize_text_field($r->get_param('business_name'));$website=esc_url_raw($r->get_param('website'),['https','http']);$note=sanitize_textarea_field($r->get_param('application_note'));
                if($name===''||strlen($name)>191||strlen($website)>255||strlen($note)>4000)return self::error('نام، آدرس یا توضیحات معتبر وارد کنید.');
                $data=['status'=>'pending','business_name'=>$name,'website'=>$website,'application_note'=>$note,'requested_at'=>$db->now(),'review_note'=>null,'reviewed_at'=>null,'reviewed_by'=>null];
                $ok=$a?$wpdb->update($table,$data,['user_id'=>(int)$user->id]):$wpdb->insert($table,array_merge($data,['user_id'=>(int)$user->id]));
                $message='درخواست ثبت شد و منتظر تأیید مدیریت است. مبلغی از کیف پول کسر نشد.';
            }else{
                if(!$a||$a->status!=='approved')return self::error('نمایندگی تأییدشده لازم است.',403);
                if($action==='rotate_key'){
                    if(!hash_equals((string)$a->key_hint,(string)$r->get_param('key_version')))return self::error('کلید تغییر کرده است؛ اطلاعات را به‌روز کنید.',409);
                    $days=$r->get_param('key_days');if(!in_array($days,[30,90,365],true))return self::error('مدت اعتبار نامعتبر است.');
                    $secret='ipsr_'.bin2hex(random_bytes(32));
                    $data=['key_hash'=>hash('sha256',$secret),'key_hint'=>substr($secret,-8),'key_created_at'=>gmdate('Y-m-d H:i:s'),'key_expires_at'=>gmdate('Y-m-d H:i:s',time()+$days*DAY_IN_SECONDS)];
                    $message='کلید جدید ساخته شد؛ کلید قبلی لغو شد. کلید جدید فقط همین بار نمایش داده می‌شود.';
                }elseif($action==='revoke_key'){$data=['key_hash'=>null,'key_hint'=>null,'key_expires_at'=>null];$message='کلید قبلی لغو شد.';
                }elseif($action==='settings'){
                    $raw=$r->get_param('allowed_ips');if(!is_string($raw)||strlen($raw)>1000)return self::error('فهرست IP معتبر نیست.');
                    $ips=preg_split('/[\s,]+/',trim($raw),-1,PREG_SPLIT_NO_EMPTY);if(count($ips)>20)return self::error('حداکثر ۲۰ IP مجاز است.');
                    foreach($ips as $ip)if(!filter_var($ip,FILTER_VALIDATE_IP))return self::error('IP نامعتبر است.');
                    $data=['allowed_ips'=>implode("\n",array_unique($ips))];$message='تنظیمات وب‌سرویس ذخیره شد.';
                }else return self::error('عملیات نامعتبر است.');
                $ok=$wpdb->update($table,$data,['user_id'=>(int)$user->id]);
            }
            if($ok===false)return self::error('ذخیره تغییرات ناموفق بود.',503);
            IPSVP_Reseller_Store::audit($db,$user,$message);$a=IPSVP_Reseller_Store::account($user->id);
        }
        $account=$a?array_intersect_key((array)$a,array_flip(['status','business_name','website','application_note','review_note','requested_at','reviewed_at','key_hint','key_expires_at','allowed_ips'])):null;
        return ['account'=>$account,'minimum_balance'=>IPSVP_Reseller_Store::MIN_BALANCE,'can_apply'=>!$a||in_array($a->status,['rejected','customer'],true),'message'=>$message,'secret'=>$secret];
    }
}

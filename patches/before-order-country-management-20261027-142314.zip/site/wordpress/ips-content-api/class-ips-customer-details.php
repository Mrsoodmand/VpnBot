<?php
defined('ABSPATH') || exit;
final class IPS_Bridge_Customer_Details {
    private static function error($message,$status=400) { return new WP_Error('ips_customer_detail',$message,['status'=>$status]); }
    public static function summary($o) {
        $out=['id'=>(int)$o->id,'order_code'=>(string)$o->order_code,'plan_title'=>(string)($o->plan_title??''),'country_name'=>(string)($o->country_name??''),'flag'=>(string)($o->flag??''),'service_type'=>(string)($o->service_type??'shared'),'price'=>(int)$o->price,'gb'=>(int)($o->gb??0),'days'=>(int)($o->days??0),'status'=>(string)$o->status,'payment_status'=>(string)$o->payment_status,'created_at'=>(string)$o->created_at];
        if (class_exists('IPSPLA_Orders')) {
            global $wpdb;
            $table=IPSPLA_Orders::table();
            $proxy=$wpdb->get_row($wpdb->prepare("SELECT id,phone,country_name FROM $table WHERE base_order_id=%d AND phone=%s LIMIT 1",$o->id,$o->phone));
            if ($proxy) { $out['proxy_id']=(int)$proxy->id; $out['service_type']='proxy'; $out['country_name']=$proxy->country_name; $out['plan_title']='پروکسی'; }
        }
        return $out;
    }
    public static function order($r,$user,$db,$transactions_only=false,$live_only=false) {
        $id=IPSVP_Reseller_Service::integer($r->get_param('id'));
        $o=$id===false?null:$db->get_order($id);
        if (!$o || (int)$o->user_id!==(int)$user->id) return self::error('سفارش پیدا نشد.',404);
        if($live_only) {
            $live=IPS_Bridge_Service_Live::snapshot($o,$db);
            if(!empty($live['busy'])) return self::error('دریافت اطلاعات سرویس در حال انجام است؛ دوباره تلاش کنید.',503);
            return ['order'=>IPS_Bridge_Service_Live::project(self::summary($o),$live,$db)];
        }
        $transactions=[];
        foreach ($db->get_order_receipts($id) as $receipt) {
            if ((int)$receipt->user_id!==(int)$user->id || (int)$receipt->order_id!==$id) continue;
            $payload=json_decode((string)($receipt->remote_payload??''),true);
            $transactions[]=['id'=>(int)$receipt->id,'order_id'=>$id,'type'=>(string)$receipt->type,'amount'=>(int)$receipt->amount,'status'=>(string)$receipt->status,'created_at'=>(string)$receipt->created_at,'plan_title'=>(string)($receipt->plan_title??''),'gb'=>isset($payload['gb'])?(int)$payload['gb']:null];
        }
        if ($transactions_only) return ['items'=>$transactions,'order_code'=>$o->order_code];
        $out=self::summary($o);
        $paid=in_array((string)$o->payment_status,['approved','wallet_paid','crypto_paid','paid','payment_paid'],true);
        $snapshot=[];
        if ($paid && (!empty($o->pg_username)||!empty($o->pg_user_id))) {
            $snapshot=IPS_Bridge_Service_Live::snapshot($o,$db,true);
            if(!empty($snapshot['busy'])) return self::error('دریافت اطلاعات سرویس در حال انجام است؛ دوباره تلاش کنید.',503);
            if (!is_array($snapshot)) $snapshot=[];
        }
        $o=$db->get_order($id);
        $out=self::summary($o);
        $links=json_decode((string)($o->pg_links??''),true);
        $links=!empty($snapshot['links'])?$snapshot['links']:(is_array($links)?$links:[]);
        $links=array_values(array_filter($links,function($link){return is_string($link)&&strlen($link)<=65536;}));
        $sub=(string)($snapshot['subscription_url']??'');
        if ($sub==='') $sub=(string)($o->pg_subscription_url??'');
        $content=(string)($snapshot['subscription_content']??'');
        $out['username']=$paid?(string)($o->pg_username??''):'';
        $out['subscription_url']=$paid?$sub:'';
        $out['links']=$paid?$links:[];
        $out['subscription_content']=$paid?$content:'';
        $out=IPS_Bridge_Service_Live::project($out,$snapshot,$db);
        $out['has_config']=$paid&&($sub!==''||count($links)>0||$content!=='');
        $out['can_renew']=$paid&&$db->order_can_renew($o);
        $out['can_extra_volume']=$out['can_renew']&&($out['usage']['limit']>0)&&(!empty($o->pg_user_id)||!empty($o->pg_username));
        // Identify the plugin's seven-day lifecycle cancellation, not an unpaid/manual cancellation.
        $ended=!empty($o->service_ended_at)?strtotime(get_gmt_from_date((string)$o->service_ended_at)):false;
        $cancelled=!empty($o->cancelled_at)?strtotime(get_gmt_from_date((string)$o->cancelled_at)):false;
        $out['renewal_grace_expired']=$paid&&$ended&&time()>($ended+7*DAY_IN_SECONDS)&&in_array((string)$o->status,['volume_finished','time_finished','cancelled'],true);
        $out['transactions']=$transactions;
        return ['order'=>$out];
    }
    public static function referral($r,$user) {
        if (!class_exists('IPSRA_Identity_Service')||!class_exists('IPSRA_User_Dashboard_Tab')) return self::error('سرویس دعوت دوستان فعال نیست.',503);
        $settings=IPSRA_Plugin::settings();
        if (($settings['enabled']??'0')!=='1') return self::error('سرویس دعوت دوستان غیرفعال است.',503);
        $identity=IPSRA_Identity_Service::upsert(['source'=>'site','site_user_id'=>(int)$user->id,'phone'=>$user->phone]);
        if (is_wp_error($identity)) return self::error('دریافت کد دعوت ناموفق بود.',409);
        if ((int)$identity->site_user_id!==(int)$user->id) return self::error('هویت دعوت معتبر نیست.',403);
        $links=IPSRA_Identity_Service::referral_links($identity);
        $data=IPSRA_User_Dashboard_Tab::user_referral_data($user->id,$identity->id);
        $items=[];
        foreach (array_slice($data['items'],0,100) as $item) $items[]=['id'=>(int)$item->id,'user'=>IPSRA_User_Dashboard_Tab::mask_phone($item->phone),'created_at'=>$item->created_at??null,'commission_amount'=>(int)($item->commission_amount??0),'commission_status'=>$item->commission_status??null];
        $paid=0;$pending=0;foreach($data['items'] as $row){if(($row->commission_status??'')==='paid')$paid++;if(($row->commission_status??'')==='pending')$pending+=(int)($row->commission_amount??0);}
        return ['commission_percent'=>(float)$settings['commission_percent'],'description'=>(string)$settings['panel_description'],'qualified_purchases'=>$paid,'pending_commission'=>$pending,'code'=>$identity->referral_code,'link'=>add_query_arg('ref',$identity->referral_code,home_url('/login/')),'total_referrals'=>(int)($data['summary']->total_referrals??0),'total_commission'=>(int)($data['summary']->total_commission??0),'items'=>$items];
    }
    public static function proxies($r,$user,$detail=false) {
        if (!class_exists('IPSPLA_Orders')) return self::error('سرویس پروکسی فعال نیست.',503);
        if (!$detail) {
            $rows=IPSPLA_Orders::user_orders($user->phone);
            $page=max(1,min(100000,(int)$r->get_param('page')));
            return ['items'=>array_map([__CLASS__,'proxy_summary'],array_slice($rows,($page-1)*20,20)),'total'=>count($rows),'page'=>$page];
        }
        $id=IPSVP_Reseller_Service::integer($r->get_param('id'));
        $o=$id===false?null:IPSPLA_Orders::user_order($id,$user->phone);
        if (!$o) return self::error('سفارش پروکسی پیدا نشد.',404);
        $out=self::proxy_summary($o);
        $paid=in_array((string)$o->payment_status,['approved','paid','wallet_paid','crypto_paid','payment_paid'],true);
        $out['can_renew']=$paid&&IPSPLA_Orders::can_submit_renewal($o);
        $out['links']=$paid?IPSPLA_Orders::proxy_lines($o,'raw'):[];
        $out['http']=$paid?implode("\n",IPSPLA_Orders::proxy_lines($o,'http')):'';
        $out['socks5']=$paid?implode("\n",IPSPLA_Orders::proxy_lines($o,'socks5')):'';
        $out['transactions']=array_map(function($row){return array_intersect_key((array)$row,array_flip(['id','type','title','amount','status','created_at','payment_method','label','date']));},IPSPLA_Orders::get_proxy_order_transactions($o));
        return ['order'=>$out];
    }
    public static function proxy_summary($o) {
        return ['id'=>(int)$o->id,'order_code'=>'PRX-'.$o->id,'country_name'=>(string)($o->country_name??$o->country_code??''),'service_type'=>'proxy','price'=>(int)$o->final_amount_irt,'status'=>$o->order_status,'payment_status'=>$o->payment_status,'created_at'=>$o->created_at,'expire'=>IPSPLA_Orders::proxy_order_expire_display($o),'base_order_id'=>(int)$o->base_order_id];
    }
}

(() => {
  'use strict';
  const config = window.ipsAdminOrderLive;
  if (!config) return;
  const states = new Set(['created','delivered','active','on_hold','disabled','time_finished','volume_finished','paid','approved']);
  const jobs = [];
  const seen = new Set();
  document.querySelectorAll('.ipsvp-table tbody tr').forEach(row => {
    const link = row.querySelector('a[href*="page=ipsvp-orders"][href*="view="]');
    const badge = row.querySelector('.ipsvp-badge');
    if (!link || !badge || ![...states].some(s => badge.classList.contains('ipsvp-' + s))) return;
    const id = new URL(link.href).searchParams.get('view');
    if (!/^\d+$/.test(id || '') || seen.has(id)) return;
    seen.add(id); jobs.push({id, badge});
  });
  const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
  async function refresh({id, badge}) {
    badge.title = 'در حال دریافت وضعیت از پنل سرویس';
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const response = await fetch(config.url, {method:'POST',credentials:'same-origin',cache:'no-store',
          body:new URLSearchParams({action:'ips_bridge_admin_order_live',nonce:config.nonce,id})});
        if (response.status === 503 && attempt < 2) {await pause(1800 + attempt * 1500); continue;}
        const result = await response.json();
        if (!response.ok || !result.success) throw new Error('unavailable');
        if (result.data.skip) {badge.title = ''; return;}
        const {status, label} = result.data;
        if (!/^[a-z_]+$/.test(status) || typeof label !== 'string') throw new Error('invalid');
        [...badge.classList].filter(c => c.startsWith('ipsvp-') && c !== 'ipsvp-badge').forEach(c => badge.classList.remove(c));
        badge.classList.add('ipsvp-' + status); badge.textContent = label;
        badge.title = 'وضعیت هنگام باز شدن این صفحه از پنل سرویس بررسی شد';
        return;
      } catch (_) {break;}
    }
    badge.title = 'دریافت وضعیت لحظه‌ای ناموفق بود؛ آخرین وضعیت ذخیره‌شده نمایش داده می‌شود';
    const note = document.createElement('small');
    note.textContent = ' · به‌روزرسانی نشد';
    badge.after(note);
  }
  async function worker() {while (jobs.length) await refresh(jobs.shift());}
  // Two requests per open page; server additionally enforces three globally.
  void Promise.all([worker(), worker()]);
})();

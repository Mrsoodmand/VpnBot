<?php
/** Administrative read model. No legacy bootstraps, mutations or provider calls. */
defined('ABSPATH') || exit;
final class IPS_Bridge_Admin_API {
    private static $application_user = 0;
    public static function init() {
        add_action('application_password_did_authenticate', function ($user) { self::$application_user = (int) $user->ID; }, 10, 1);
        add_action('rest_api_init', [__CLASS__, 'routes']);
        add_filter('rest_post_dispatch', function ($response, $server, $request) {
            if (strpos($request->get_route(), '/ips-bridge/v1/admin/') === 0) {
                $response->header('Cache-Control', 'private, no-store, max-age=0');
                $response->header('X-Robots-Tag', 'noindex, nofollow, noarchive');
                $response->header('Vary', 'Authorization, X-IPS-Admin-Authorization');
            }
            return $response;
        }, 20, 3);
    }
    public static function authorize($request) {
        if (!is_ssl()) { return new WP_Error('ips_https_required', 'HTTPS required.', ['status'=>403]); }
        // Another plugin may resolve current_user before REST_REQUEST is defined.
        // Re-run only WordPress's application-password verifier once inside REST.
        if ((!get_current_user_id() || self::$application_user !== (int) get_current_user_id()) && is_object($request) && method_exists($request, 'get_header')) {
            $header = $request->get_header('Authorization');
            if (!$header) { $header = $request->get_header('X-IPS-Admin-Authorization'); }
            if (!$header) { return new WP_Error('ips_admin_header_missing', 'Administrative authentication header not received.', ['status'=>401]); }
            if (is_string($header) && strlen($header) <= 1024 && preg_match('/^Basic ([A-Za-z0-9+\/=]+)$/i', $header, $match)) {
                $decoded = base64_decode($match[1], true);
                if (is_string($decoded) && strpos($decoded, ':') !== false && function_exists('wp_authenticate_application_password') && wp_is_application_passwords_available()) {
                    list($username, $password) = explode(':', $decoded, 2);
                    if ($username !== '' && strlen($username) <= 191 && strlen($password) <= 256) {
                        $authenticated = wp_authenticate_application_password(null, $username, $password);
                        if ($authenticated instanceof WP_User) {
                            wp_set_current_user($authenticated->ID);
                            self::$application_user = (int) $authenticated->ID;
                        }
                    }
                }
            }
        }
        if (!get_current_user_id() || self::$application_user !== (int) get_current_user_id()) {
            return new WP_Error('ips_admin_auth', 'An administrator application password is required.', ['status'=>401]);
        }
        if (!current_user_can('manage_options')) { return new WP_Error('ips_admin_forbidden', 'Administrator permission required.', ['status'=>403]); }
        return true;
    }
    public static function routes() {
        foreach (['me'=>'me', 'inventory'=>'inventory', 'settings'=>'settings', 'records/(?P<resource>[a-z-]+)(?:/(?P<id>[1-9][0-9]*))?'=>'records'] as $route=>$callback) {
            register_rest_route('ips-bridge/v1', '/admin/'.$route, [
                'methods'=>'GET', 'permission_callback'=>[__CLASS__, 'authorize'], 'callback'=>[__CLASS__, $callback],
            ]);
        }
    }
    public static function me() {
        $user = wp_get_current_user();
        return ['id'=>(int)$user->ID, 'name'=>$user->display_name, 'mode'=>'read-only', 'version'=>'2.5.0', 'can_disable_legacy'=>false];
    }
    public static function resources() {
        static $resources;
        if ($resources === null) { $resources = json_decode(file_get_contents(__DIR__.'/admin-resources.json'), true); }
        return is_array($resources) ? $resources : [];
    }
    private static function columns($table) {
        global $wpdb;
        // Identifiers only come from the static registry and the trusted WP prefix.
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table))) !== $table) { return null; }
        $columns = $wpdb->get_col("SHOW COLUMNS FROM `{$table}`", 0);
        return $wpdb->last_error ? null : $columns;
    }
    public static function inventory() {
        global $wpdb;
        $out = [];
        foreach (self::resources() as $name=>$spec) {
            $table = $wpdb->prefix.$spec['table'];
            $columns = self::columns($table);
            $ready = $columns !== null && in_array($spec['key'], $columns, true);
            $out[] = ['resource'=>$name, 'label'=>$spec['label'], 'available'=>$ready,
                'missing_fields'=>$columns === null ? [] : array_values(array_diff(explode(',', $spec['fields']), $columns)),
                'mode'=>'read-only'];
        }
        return ['resources'=>$out, 'can_disable_legacy'=>false, 'transactional_migration'=>'pending-staging-validation'];
    }
    public static function records($request) {
        global $wpdb;
        $registry = self::resources();
        $resource = (string)$request['resource'];
        if (!isset($registry[$resource])) { return new WP_Error('ips_unknown_resource', 'Unknown resource.', ['status'=>404]); }
        $spec = $registry[$resource]; $table = $wpdb->prefix.$spec['table'];
        $columns = self::columns($table);
        if ($columns === null || !in_array($spec['key'], $columns, true)) { return new WP_Error('ips_missing_schema', 'This module is unavailable in the connected database.', ['status'=>503]); }
        $fields = array_values(array_intersect(explode(',', $spec['fields']), $columns));
        $select = implode(',', array_map(function ($field) { return '`'.$field.'`'; }, $fields));
        $where = '1=1'; $args = [];
        if ($request['id']) { $where .= ' AND `'.$spec['key'].'`=%d'; $args[] = (int)$request['id']; }
        $q = $request->get_param('q');
        if ($q !== null && (!is_string($q) || strlen($q)>160)) { return new WP_Error('ips_invalid_search', 'Invalid search.', ['status'=>400]); }
        if (is_string($q) && trim($q) !== '') {
            $search = array_intersect(array_filter(explode(',', $spec['search'])), $columns);
            if (!$search) { return new WP_Error('ips_search_unavailable', 'Search is not supported for this resource.', ['status'=>400]); }
            $parts = [];
            foreach ($search as $field) { $parts[] = '`'.$field.'` LIKE %s'; $args[] = '%'.$wpdb->esc_like(trim($q)).'%'; }
            $where .= ' AND ('.implode(' OR ', $parts).')';
        }
        $page = $request->get_param('page') ?? '1';
        if (!is_scalar($page) || !preg_match('/^[1-9][0-9]{0,4}$/', (string)$page)) { return new WP_Error('ips_invalid_page', 'Invalid page.', ['status'=>400]); }
        $limit = 25; $offset = ((int)$page-1)*$limit;
        $base = "FROM `{$table}` WHERE {$where}";
        $sql = "SELECT {$select} {$base} ORDER BY `{$spec['key']}` DESC LIMIT %d OFFSET %d";
        $rows = $wpdb->get_results($wpdb->prepare($sql, array_merge($args, [$limit,$offset])), ARRAY_A);
        if ($wpdb->last_error) { return new WP_Error('ips_read_failed', 'Database read failed.', ['status'=>503]); }
        $count_sql = "SELECT COUNT(*) {$base}";
        $total = $wpdb->get_var($args ? $wpdb->prepare($count_sql, $args) : $count_sql);
        if ($wpdb->last_error) { return new WP_Error('ips_read_failed', 'Database read failed.', ['status'=>503]); }
        if ($request['id'] && !$rows) { return new WP_Error('ips_not_found', 'Record not found.', ['status'=>404]); }
        return ['resource'=>$resource, 'label'=>$spec['label'], 'fields'=>$fields, 'items'=>$rows ?: [], 'total'=>(int)$total, 'page'=>(int)$page, 'per_page'=>$limit, 'searchable'=>$spec['search'] !== '', 'mode'=>'read-only'];
    }
    public static function settings() {
        // Explicit allowlists. URLs, free-form log bodies and arbitrary option keys can contain credentials.
        $specs = [
            'sales'=>['ipsvp_settings','فروش و کانفیگ','brand_name,shared_sales_enabled,dedicated_sales_enabled,all_countries_enabled,all_countries_price_percent,extra_volume_price_per_gb,dedicated_extra_volume_price_per_gb,otp_login_enabled,otp_code_length,otp_expire_minutes,otp_resend_seconds,captcha_enabled,ssl_verify,sanaei_ssl_verify','panel_password,sanaei_panel_token,sanaei_panel_password,smsir_api_key,wp_sync_secret,telegram_bot_token'],
            'payments'=>['ipspm_settings','روش‌های پرداخت','payment_card_enabled,payment_wallet_enabled,payment_crypto_enabled,ramzino_to_currency,ramzino_invoice_lifetime','ramzino_secret'],
            'proxy'=>['ipspla_settings','پروکسی','sales_enabled,product_ipv4_dedicated,product_ipv4_shared,product_ipv6_dedicated,min_period,max_period,min_quantity,max_quantity,manual_rate,markup_percent,markup_fixed,rounding','api_key,rate_token'],
            'server'=>['ips_server_settings','سرور','enabled,sell_vps,sell_dedicated,fallback_usd_rate,markup_global,markup_vps,markup_dedicated,fixed_markup,minimum_order_amount,action_cooldown,confirm_sensitive_actions','api_key,ariapay_rate_token'],
            'referral'=>['ipsra_settings','همکاری در فروش','enabled,commission_percent,api_enabled',''],
            'support'=>['ipsgt_settings','گفتینو و اعلان‌ها','debug_log','telegram_token,goftino_key'],
            'crypto'=>['rcg_settings','درگاه رمزارزی','default_to_currency,lifetime,debug,use_callbacks','api_key,integration_secret,callback_secret'],
        ];
        $out = [];
        foreach ($specs as $name=>$spec) {
            $stored = get_option($spec[0], null); $values = is_array($stored) ? $stored : [];
            $safe = [];
            foreach (array_filter(explode(',', $spec[2])) as $field) { $safe[$field] = isset($values[$field]) && is_scalar($values[$field]) ? $values[$field] : null; }
            $secrets = [];
            foreach (array_filter(explode(',', $spec[3])) as $field) { $secrets[$field] = !empty($values[$field]); }
            $out[] = ['module'=>$name, 'label'=>$spec[1], 'configured'=>is_array($stored), 'stored_values'=>$safe, 'credentials_configured'=>$secrets, 'mode'=>'read-only'];
        }
        return ['modules'=>$out, 'note'=>'Stored values only; null means no explicit value. Legacy defaults may still apply.'];
    }
}
IPS_Bridge_Admin_API::init();

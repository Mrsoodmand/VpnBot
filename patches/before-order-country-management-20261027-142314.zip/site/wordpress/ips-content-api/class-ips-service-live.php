<?php
/** Fresh operational data; never use a purchase-time status as provider state. */
defined('ABSPATH') || exit;
final class IPS_Bridge_Service_Live {
    public static function eligible($o) {
        return $o && ($o->service_type??'')!=='proxy'
            && in_array((string)$o->payment_status,['approved','wallet_paid','crypto_paid','paid','payment_paid'],true)
            && in_array((string)$o->status,['created','delivered','active','on_hold','disabled','time_finished','volume_finished','paid','approved'],true)
            && (!empty($o->pg_username)||!empty($o->pg_user_id));
    }
    private static function pick($data,$keys) {
        foreach($keys as $key) if(isset($data[$key]) && is_scalar($data[$key])) return $data[$key];
        return null;
    }
    public static function normalize($live) {
        if(!is_array($live)||empty($live)) return [];
        $groups=[];
        foreach((array)($live['group_ids']??$live['groups']??[]) as $group) {
            $id=is_array($group)?($group['id']??$group['group_id']??0):$group;
            if(is_numeric($id)&&(int)$id>0) $groups[]=(int)$id;
        }
        if(!empty($live['group_id'])) $groups[]=(int)$live['group_id'];
        return ['live'=>$live,'status'=>self::pick($live,['status']),
            'used'=>self::pick($live,['used_traffic','used','data_usage','used_data','used_bytes']),
            'limit'=>self::pick($live,['data_limit','total','total_traffic','limit','total_bytes']),
            'expire'=>self::pick($live,['expire','expired_at','expiry_time','expire_at']),
            'group_ids'=>array_values(array_unique($groups))];
    }
    public static function status($s) {
        $map=['active'=>'active','on_hold'=>'on_hold','disabled'=>'disabled','deleted'=>'disabled','expired'=>'time_finished','limited'=>'volume_finished'];
        $state=strtolower(trim((string)($s['status']??'')));
        if(!isset($map[$state])) return null;
        $expire=$s['expire']??null;
        $time=is_numeric($expire)?((float)$expire>1e12?(float)$expire/1000:(float)$expire):(is_string($expire)?strtotime($expire):0);
        if($time>0 && $time<=time()) return 'time_finished';
        if(is_numeric($s['limit']??null)&&$s['limit']>0&&is_numeric($s['used']??null)&&$s['used']>=$s['limit']) return 'volume_finished';
        return $map[$state];
    }
    /** At most three provider calls across ALL PHP workers, not three per visitor. */
    public static function snapshot($o,$db,$connections=false) {
        if(!self::eligible($o)) return [];
        global $wpdb;
        $prefix='ips_live_'.substr(hash('sha256',DB_NAME),0,12).'_';
        $order_lock=$prefix.'order_'.(int)$o->id;
        if((int)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,0)',$order_lock))!==1) return ['busy'=>true];
        $slot=null;
        try {
            // Back off during provider failures; no successful usage/status response is cached.
            if(get_transient('ips_live_provider_backoff')) return ['busy'=>true];
            for($i=0;$i<3;$i++) {
                $name=$prefix.'slot_'.$i;
                if((int)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,0)',$name))===1){$slot=$name;break;}
            }
            if($slot===null) return ['busy'=>true];
            $api=new IPSVP_PasarGuard_API();
            if($connections || IPSVP_Sanaei_API::is_order($o)) {
                $s=$api->user_snapshot($o->pg_username,$o->pg_user_id,$o);
            } else {
                $live=!empty($o->pg_username)?$api->get_user($o->pg_username):$api->get_user_by_id($o->pg_user_id);
                if(is_wp_error($live)) $s=[]; else $s=self::normalize($live);
            }
            if(!is_array($s)||empty($s['live'])) {set_transient('ips_live_provider_backoff',1,5);return [];}
            self::persist($o,$s,$db);
            return $s;
        } finally {
            if($slot!==null) $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$slot));
            $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$order_lock));
        }
    }
    public static function lifecycle_fields($o,$s,$now=null) {
        $now=$now??time();
        $status=self::status($s);
        if(!$status) return [];
        $data=['status'=>$status];
        if(in_array($status,['volume_finished','time_finished'],true)) {
            $ended=!empty($o->service_ended_at)?strtotime(get_gmt_from_date($o->service_ended_at)):false;
            if(!$ended) {
                $expiry=$s['expire']??null;
                $expiry=is_numeric($expiry)?(int)$expiry:strtotime((string)$expiry);
                if($expiry>1000000000000)$expiry=(int)floor($expiry/1000);
                // A missing historical volume-exhaustion time cannot be inferred from creation.
                $ended=$status==='time_finished'&&$expiry>0&&$expiry<=$now?$expiry:$now;
                $data['service_ended_at']=get_date_from_gmt(gmdate('Y-m-d H:i:s',$ended));
            }
            if($now>$ended+7*DAY_IN_SECONDS) {
                $data['status']='cancelled';
                $data['cancelled_at']=get_date_from_gmt(gmdate('Y-m-d H:i:s',$now));
            }
        } elseif(in_array($status,['active','on_hold'],true)) {
            $data['service_ended_at']=null;$data['cancelled_at']=null;
        }
        return $data;
    }
    private static function persist($o,$s,$db) {
        global $wpdb;
        $status=self::status($s);
        if(!$status) return;
        $live=$s['live'];$old=json_decode((string)($o->pg_response??''),true);
        if(!empty($old['_all_countries'])) $live['_all_countries']=$old['_all_countries'];
        $data=array_merge(self::lifecycle_fields($o,$s),['pg_status'=>(string)$s['status'],'pg_response'=>wp_json_encode($live),'pg_synced_at'=>$db->now()]);
        // Compare-and-swap: a concurrent cancellation, payment or renewal wins over this read.
        $where=['id'=>(int)$o->id,'status'=>$o->status,'payment_status'=>$o->payment_status,'updated_at'=>$o->updated_at];
        return $wpdb->update($db->tables()['orders'],$data,$where)>0;
    }
    public static function project($out,$s,$db) {
        $out['live_available']=!empty($s['live']);
        $out['usage']=['used'=>isset($s['used'])&&is_numeric($s['used'])?(float)$s['used']:null,
            'limit'=>isset($s['limit'])&&is_numeric($s['limit'])?(float)$s['limit']:null,'expire'=>$s['expire']??null,'status'=>self::status($s)??($s['status']??null)];
        if(empty($s['live'])) return $out;
        $status=self::status($s);if($status && ($out['status']??'')!=='cancelled') $out['status']=$status;
        $groups=$s['group_ids']??[];
        $out['group_ids']=array_values(array_map('intval',$groups));
        if($groups && ($out['service_type']??'shared')==='shared') {
            $names=[];$flags=[];
            foreach($db->active_countries('shared') as $country) if(in_array((int)$country->pg_group_id,$groups,true)) {$names[]=$country->name;$flags[]=$country->flag;}
            if($db->all_countries_group_id()>0 && in_array((int)$db->all_countries_group_id(),$groups,true)) {$names=['همه کشورها'];$flags=['🌐'];}
            if($names){$out['country_name']=implode('، ',array_unique($names));$out['flag']=count($names)>1?'🌐':$flags[0];}
        }
        return $out;
    }
    public static function init() {
        add_action('init',[__CLASS__,'disable_background_sync'],30);
        add_action('admin_enqueue_scripts',[__CLASS__,'admin_assets']);
        add_action('wp_ajax_ips_bridge_admin_order_live',[__CLASS__,'admin_order_live']);
    }
    public static function admin_assets() {
        if(!current_user_can('manage_options') || ($_GET['page']??'')!=='ipsvp-orders' || !empty($_GET['view'])) return;
        wp_enqueue_script('ips-admin-order-live',plugin_dir_url(__FILE__).'admin-order-live.js',[],(string)filemtime(__DIR__.'/admin-order-live.js'),true);
        wp_localize_script('ips-admin-order-live','ipsAdminOrderLive',['url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('ips_admin_order_live')]);
    }
    public static function admin_order_live() {
        if(!current_user_can('manage_options')) wp_send_json_error(['message'=>'دسترسی مجاز نیست.'],403);
        check_ajax_referer('ips_admin_order_live','nonce');
        $id=isset($_POST['id'])?absint($_POST['id']):0;
        $db=new IPSVP_DB();$o=$id?$db->get_order($id):null;
        if(!$o) wp_send_json_error(['message'=>'سفارش پیدا نشد.'],404);
        if(!self::eligible($o)) wp_send_json_success(['skip'=>true]);
        $s=self::snapshot($o,$db);
        if(!empty($s['busy'])) wp_send_json_error(['message'=>'در حال دریافت'],503);
        if(empty($s['live']) || !self::status($s)) wp_send_json_error(['message'=>'اطلاعات لحظه‌ای در دسترس نیست.'],502);
        // Read back after CAS: never paint over a concurrent cancellation or payment change.
        $fresh=$db->get_order($id);
        if(!$fresh) wp_send_json_error(['message'=>'سفارش پیدا نشد.'],404);
        wp_send_json_success(['status'=>(string)$fresh->status,'label'=>$db->status_label($fresh->status)]);
    }
    public static function disable_background_sync() {
        if(class_exists('IPSabet_PasarGuard_Shop')) {
            remove_action('ipsvp_sync_order_lifecycle',[IPSabet_PasarGuard_Shop::instance(),'sync_order_lifecycle']);
        }
        // Operational data is refreshed only by authenticated customer requests.
        if(wp_next_scheduled('ipsvp_sync_order_lifecycle')) wp_clear_scheduled_hook('ipsvp_sync_order_lifecycle');
        if(wp_next_scheduled('ips_bridge_live_orders')) wp_clear_scheduled_hook('ips_bridge_live_orders');
    }
}

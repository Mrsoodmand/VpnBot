# Customer bridge 2.2.0

WordPress and its existing sales plugins remain authoritative. Do not disable existing plugins. This release is an initial customer/reseller integration, not the full transaction migration.

## Authentication
Server-to-server HTTPS requires the existing WordPress Application Password (manage_options), never the content key. Private customer calls additionally require X-IPS-Customer-Session, issued only after the sales account password and configured CAPTCHA are verified. The Next server keeps this token in an HttpOnly SameSite cookie. Sessions expire after 12 hours and are invalidated by logout, account blocking, or password changes. Customer IDs and roles are never trusted from the browser. Do not cache any customer API response.

## Routes under /wp-json/ips-bridge/v1/customer/
- GET challenge: CAPTCHA challenge and available authentication methods.
- POST login: phone, password, captcha_token, captcha_code.
- GET me; POST logout.
- GET orders, receipts, wallet: owned records and actual balance, bounded pages.
- GET catalog: active plan/country projections, no provider configuration.
- GET order?id=: ownership checked before returning subscription data.
- GET operations: approved reseller operation history only.
- POST quote: approved reseller price calculation.
- POST execute: approved reseller operation through IPSVP_Reseller_Service. Requires Idempotency-Key and max_amount. Existing journal, wallet lock, and uncertain-operation protections apply. No automatic retries with new keys.

## Frontend configuration
Use CUSTOMER_ORIGIN for the exact frontend origin. ADMIN_ORIGIN is a compatibility fallback for current local setup. WORDPRESS_URL, WORDPRESS_ADMIN_USERNAME and WORDPRESS_ADMIN_APP_PASSWORD stay server-only. Never prefix credentials with NEXT_PUBLIC_.

## Not completed in this release
OTP/registration, customer checkout/payment and receipt submission, crypto callbacks, profile edits, reseller application and API-key management, referral/proxy/dedicated-server transaction adapters. Old UI prototype components are retained as design references; they are not evidence of real payment processing. The current purchase checkout must not be presented as production-ready.

## Validation
Local PHP contract tests cover invalid credentials, CAPTCHA, normalized phone format, revoked/forged sessions, blocked accounts, password changes, rate limits, user-scoped pagination, receipt field filtering, reseller role restriction and required price ceiling. TypeScript/build checks are separate. Live customer testing requires uploading this version first; no live purchase or wallet debit was tested.


## Version 2.3.0
Service cards use the authenticated order list enriched with plan/country/flag. GET order?id includes private subscription/config strings and usage snapshot only for paid, owned orders; raw provider data is never forwarded. GET order-transactions?id is scoped to the owned order and customer. QR images are generated locally in the browser with qrcode; no external QR service receives connection data.

GET proxies/proxy?id integrates existing ProxyLine orders and connection formats; ownership uses the existing normalized-phone accessor. GET referral returns the customer's existing/generated referral code, site link, summary and masked invitees.

GET proxy-catalog, POST proxy-quote and multipart POST proxy-submit implement card/receipt proxy purchase and renewal through IPSPLA_Orders::create_payment. Prices and selection are held in a customer-bound expiring quote. Persistent request journals bind user + idempotency key + quote, returning completed results and refusing uncertain replays. Receipt files use the existing owner-bound uploader. Existing WordPress administrator review creates the proxy; submission is not an automatic approval.

POST service-quote and multipart POST service-submit create pending renewal/extra-volume receipts for ordinary customers. The original WordPress pricing helpers provide retail amounts; the authenticated customer's loyalty discount is explicitly applied because the old browser-session price hook skips REST. Receipt payloads follow the existing approval handler's schema. Existing WordPress review/provisioning handles final fulfillment. Shared approved resellers use the existing wallet quote/execute service instead.

Not included: ordinary-customer wallet/crypto payment adapters, proxy wallet/crypto checkout, registration/OTP and remaining profile/server management. Do not present these as complete. Production financial writes have not been exercised. Unit contracts and build validation do not replace staging/end-to-end receipt approval testing.


## Version 2.4.0: customer wallet renewal and volume
POST service-quote accepts method card or wallet and returns method availability. POST service-wallet requires an owned unexpired wallet quote plus Idempotency-Key. Uses the existing WordPress wallet lock and receipt approval engine; amount is recalculated server-side. Quote consumption is durable, including uncertain outcomes, and the same key cannot bind another quote. No live payments were performed in testing. Bot-linked wallets are not supported by this endpoint and are rejected, rather than debited locally. Ordinary site wallets and the existing reseller wallet path are supported.
Publish this plugin before enabling ordinary-customer wallet execution. Frontend prevents execution without the new capability response.

## Version 2.4.1: payment display settings
Authenticated GET `customer/payment-settings` returns only public payment-destination fields (`bank_card`, `bank_account_name`, `bank_iban`, `bank_note`) and `card_enabled`. It uses the existing customer session and bridge authentication. No wallet balance mutation or charge submission is introduced by this endpoint.


## Version 2.10.0: on-demand provider state
Authenticated `GET customer/order-live?id=N` verifies order ownership before contacting the provider. It returns fresh status, usage, limit, expiry and configured country/group labels without fetching subscription packages. `GET customer/order?id=N` refreshes connection data when the customer opens details. No successful operational response is cached. Purchase/payment states and proxy orders are excluded from the fixed-IP synchronization.

Provider calls from these endpoints are limited to three concurrent PHP workers using MySQL advisory locks; each order also has a lock. Busy reads return 503 and the frontend retries with bounded jitter. Provider failures trigger a five-second failure backoff, never a cached successful usage response. In-flight browser reads are shared and discarded on completion. State persistence compares the original status, payment status and updated timestamp so concurrent order mutations are not overwritten.

The old hourly PasarGuard lifecycle job and the bridge background refresh are disabled. No provider refresh or seven-day lifecycle cancellation runs on a schedule; order data updates when its owner visits the panel. Payment-expiration policy is separate and is not implemented by this change. Publish the bridge plugin together with the frontend (including the new endpoint allowlist). No production publication or financial operation is part of local validation.

## Version 2.10.1: receipt notification recovery
Pending local uploaded receipts are requeued in batches of at most five every five minutes, with a fifteen-minute per-receipt cooldown and the original persistent Telegram delivery marker and per-receipt lock. This job never approves/rejects payments or provisions services. Wallet provisioning failures preserve the receipt manager's authoritative order state and queue a separate admin alert without approval/rejection buttons. Run WordPress cron from the hosting account every minute; frontend traffic alone is not a reliable worker. The split-routing query allowlist must include `ipsvp_receipt_file` so signed receipt links reach the original WordPress nonce and ownership checks. Private receipt directories remain blocked.

<?php
/** Allowlisted commerce settings. All prices are computed by WordPress, never supplied by the browser. */
defined('ABSPATH') || exit;
final class IPS_Bridge_Customer_Commerce {
    private static function error($message,$status=400){return new WP_Error('ips_commerce',$message,['status'=>$status]);}
    public static function methods($user=null){
        $settings=IPSVP_Settings::get();$out=[];
        foreach(['card','wallet'] as $method)$out[$method]=class_exists('IPSPM_Payment_Manager')?IPSPM_Payment_Manager::method_enabled($method,'ip-sabet'):($settings['payment_'.$method.'_enabled']??'0')==='1';
        if($user&&!empty($user->bot_tel_id))$out['wallet']=false;
        return $out;
    }
    public static function bank(){
        $settings=class_exists('IPSPM_Payment_Manager')?IPSPM_Payment_Manager::card_details():IPSVP_Settings::get();
        return array_intersect_key((array)$settings,array_flip(['bank_card','bank_account_name','bank_iban','bank_note']));
    }
    public static function catalog($db,$user=null){
        $plans=[];$countries=[];$services=[];
        foreach(['shared','dedicated'] as $type){
            $enabled=$db->service_sales_enabled($type);
            $services[$type]=['enabled'=>(bool)$enabled,'extra_volume_price_per_gb'=>$db->extra_volume_unit_price($type)];
            if(!$enabled)continue;
            foreach($db->active_plans($type) as $p){$price=(int)$db->final_price($p,true);$original=(int)$p->price;$plans[]=['id'=>(int)$p->id,'title'=>$p->title,'service_type'=>$type,'gb'=>(int)$p->gb,'days'=>(int)$p->days,'retail_price'=>$price,'original_price'=>$original,'discount_percent'=>$original>0?round(max(0,$original-$price)*100/$original,2):0];}
            foreach($db->ready_countries($type) as $c)$countries[]=['id'=>(int)$c->id,'name'=>$c->name,'service_type'=>$type];
        }
        return ['plans'=>$plans,'countries'=>$countries,'services'=>$services,'methods'=>self::methods($user),'all_countries'=>['enabled'=>$db->service_sales_enabled('shared')&&$db->all_countries_enabled()&&$db->all_countries_group_ready(),'percent'=>$db->all_countries_price_percent_value()],'currency'=>'IRT'];
    }
    public static function price($db,$user,$input){
        if(($input['action']??'purchase')==='wallet-charge'){
            $amount=IPSVP_Reseller_Service::integer($input['amount']??null,1000,1000000000);
            return $amount===false?self::error('مبلغ شارژ معتبر نیست.'):['amount'=>$amount,'discount_percent'=>0,'action'=>'wallet-charge'];
        }
        $id=IPSVP_Reseller_Service::integer($input['plan_id']??null);
        $country_id=IPSVP_Reseller_Service::integer($input['country_id']??null,0);
        $plan=$id===false?null:$db->get_plan($id);
        if(!$plan||(int)$plan->status!==1||$country_id===false)return self::error('پلن و کشور معتبر انتخاب کنید.');
        $type=$db->normalize_service_type($plan->service_type);
        if(!$db->service_sales_enabled($type))return self::error('فروش این سرویس غیرفعال است.',409);
        if($type==='shared'&&IPSVP_Reseller_Store::approved($user->id))return self::error('خرید اشتراکی نمایندگی از پنل نمایندگی انجام می‌شود.',409);
        if($country_id===0){if($type!=='shared'||!$db->all_countries_enabled()||!$db->all_countries_group_ready())return self::error('گزینه همه کشورها فعال نیست.',409);}
        else {$ready=false;foreach($db->ready_countries($type) as $c)if((int)$c->id===$country_id)$ready=true;if(!$ready)return self::error('کشور برای این سرویس در دسترس نیست.',409);}
        $base=(int)$db->final_price($plan,true);
        if($country_id===0)$base=(int)ceil($base*(100+$db->all_countries_price_percent_value())/100);
        $profile=IPSVP_Loyalty::profile($user->id);$percent=$type==='shared'?(float)$profile['percent']:0;
        return ['action'=>'purchase','amount'=>IPSVP_Reseller_Store::discount($base,$percent),'retail_amount'=>$base,'discount_percent'=>$percent,'plan_id'=>$id,'country_id'=>$country_id,'service_type'=>$type];
    }
    public static function handle($r,$action,$user,$db){
        global $wpdb;
        $methods=self::methods($user);
        if($action==='commerce-quote'){
            $input=$r->get_json_params();if(!is_array($input))return self::error('درخواست معتبر نیست.');
            $input=array_intersect_key($input,array_flip(['action','plan_id','country_id','amount']));
            foreach($input as $v)if(!is_scalar($v)||strlen((string)$v)>100)return self::error('درخواست معتبر نیست.');
            if(!in_array($input['action']??'purchase',['purchase','wallet-charge'],true))return self::error('عملیات معتبر نیست.');
            $method=$r->get_param('method');if(!in_array($method,['card','wallet'],true)||empty($methods[$method])||(($input['action']??'')==='wallet-charge'&&$method!=='card'))return self::error('روش پرداخت در دسترس نیست.',409);
            $price=self::price($db,$user,$input);if(is_wp_error($price))return $price;
            $token=bin2hex(random_bytes(24));
            $ttl=$price['action']==='purchase'?86400:300;
            $expires=time()+$ttl;
            set_transient('ips_commerce_quote_'.hash('sha256',$token),['user_id'=>(int)$user->id,'input'=>$input,'method'=>$method,'price'=>$price,'expires'=>$expires],$ttl);
            return array_merge($price,['quote_id'=>$token,'expires_at'=>$expires,'methods'=>$methods,'bank'=>self::bank()]);
        }
        $method=$action==='commerce-wallet'?'wallet':'card';
        if(empty($methods[$method]))return self::error('روش پرداخت در دسترس نیست.',409);
        $token=$r->get_param('quote_id');$key=(string)$r->get_header('Idempotency-Key');
        if(!is_string($token)||!preg_match('/^[a-f0-9]{48}$/D',$token)||!preg_match('/^[A-Za-z0-9._:-]{16,100}$/D',$key))return self::error('شناسه درخواست معتبر نیست.');
        $lock=IPSVP_Reseller_Store::lock($user->id);if(is_wp_error($lock)||$lock!==true)return self::error('درخواست دیگری در حال انجام است.',409);
        $hash=hash('sha256',$user->id.'|'.$token);$journal='ips_commerce_'.$hash;$key_option='ips_commerce_key_'.hash('sha256',$user->id.'|'.$key);
        $prior_key=get_option($key_option);if($prior_key&&!hash_equals($prior_key,$hash))return self::error('شناسه درخواست برای سفارش دیگری استفاده شده است.',409);
        $prior=get_option($journal);if($prior)return $prior['result']??self::error('درخواست ثبت شده و نیاز به پیگیری پشتیبانی دارد.',409);
        $q=get_transient('ips_commerce_quote_'.hash('sha256',$token));
        if(!$q||(int)$q['user_id']!==(int)$user->id||$q['expires']<time()||$q['method']!==$method)return self::error('قیمت منقضی یا نامعتبر است. دوباره بررسی کنید.',409);
        $price=self::price($db,$user,$q['input']);if(is_wp_error($price))return $price;
        if($price!==$q['price'])return self::error('تعرفه تغییر کرده است. دوباره قیمت را دریافت کنید.',409);
        if($method==='wallet'&&($price['action']!=='purchase'||$db->get_local_wallet_balance($user->id)<$price['amount']))return self::error('موجودی کیف پول کافی نیست.',409);
        $upload=['attachment_id'=>0,'url'=>''];
        if($method==='card'){
            $file=$r->get_file_params()['receipt']??null;
            if(!is_array($file)||empty($file['size'])||$file['size']>min(8388608,IPSVP_Receipt_Uploader::max_upload_size()))return self::error('رسید معتبر با حداکثر حجم ۸ مگابایت انتخاب کنید.');
            $upload=IPSVP_Receipt_Uploader::upload($file,$user->id,$user->phone,$hash);if(is_wp_error($upload))return self::error('فایل رسید پذیرفته نشد.');
        }
        if(!add_option($key_option,$hash,'','no')&&!hash_equals((string)get_option($key_option),$hash))return self::error('شناسه درخواست تکراری است.',409);
        if(!add_option($journal,['state'=>'processing'],'','no'))return self::error('درخواست قبلاً ثبت شده است.',409);
        $tables=$db->tables();$order_id=0;$code='';
        // Keep wallet debits in the existing order ledger. Receipt approval and referral hooks remain WordPress-owned.
        $submission=($method==='wallet'?'wallet-pay-':'bridge-card-').substr($hash,0,48);
        if($price['action']==='purchase'){
            $settings=IPSVP_Settings::get();$code=strtoupper(sanitize_key($settings['order_prefix']??'IPS')).'-'.wp_date('Ymd').'-'.wp_generate_password(8,false,false);
            $ok=$wpdb->insert($tables['orders'],['order_code'=>$code,'submission_key'=>$submission,'service_type'=>$price['service_type'],'user_id'=>(int)$user->id,'phone'=>$user->phone,'plan_id'=>$price['plan_id'],'country_id'=>$price['country_id'],'price'=>$price['amount'],'status'=>'waiting_review','payment_status'=>$method==='wallet'?'wallet_paid':'waiting_review','wallet_effect'=>'local','created_at'=>$db->now(),'updated_at'=>$db->now()]);
            if(!$ok)return self::error('ثبت سفارش کامل نشد؛ با پشتیبانی پیگیری کنید.',503);
            $order_id=(int)$wpdb->insert_id;
        }
        $payload=array_merge($price,['payment_method'=>$method]);
        $ok=$wpdb->insert($tables['receipts'],['submission_key'=>'receipt-'.substr($hash,0,48),'order_id'=>$order_id,'user_id'=>(int)$user->id,'phone'=>$user->phone,'type'=>$price['action']==='wallet-charge'?'wallet':'new','plan_id'=>$price['plan_id']??null,'attachment_id'=>(int)$upload['attachment_id'],'file_url'=>$upload['url'],'amount'=>$price['amount'],'status'=>'pending','remote_payload'=>wp_json_encode($payload),'created_at'=>$db->now()]);
        if(!$ok)return self::error('ثبت رسید کامل نشد؛ با پشتیبانی پیگیری کنید.',503);
        $receipt_id=(int)$wpdb->insert_id;$status='pending';
        if($method==='wallet'){
            $approved=IPSVP_Receipt_Manager::approve($receipt_id,$db,new IPSVP_PasarGuard_API());
            $status=!empty($approved['ok'])?'approved':'pending_manual_review';
            // Provider failures must not silently release an already committed wallet debit.
            // Preserve the receipt manager's actual state (e.g. paid + provisioning failed).
            // Never turn an approved payment back into a payment-review request.
            if($status!=='approved') IPS_Bridge_Receipt_Notices::queue_manual_review($receipt_id);
        }else{IPSVP_Telegram_Service::queue_pending_payment_notice($receipt_id,$db);}
        $out=['order'=>['id'=>$order_id,'order_code'=>$code,'amount'=>$price['amount'],'status'=>$status],'receipt'=>['id'=>$receipt_id,'amount'=>$price['amount'],'status'=>$status],'message'=>$status==='approved'?'پرداخت تأیید شد. وضعیت سرویس را در سفارش‌ها ببینید.':($method==='wallet'?'پرداخت ثبت شد؛ آماده‌سازی سرویس نیاز به بررسی پشتیبانی دارد.':'رسید ثبت شد و پس از تأیید مدیریت اعمال می‌شود.')];
        update_option($journal,['state'=>'complete','result'=>$out],false);
        return $out;
    }
}

<?php
defined('ABSPATH') || exit;
final class IPS_Bridge_Customer_Proxy {
    private static function error($text,$status=400) { return new WP_Error('ips_proxy_bridge',$text,['status'=>$status]); }
    private static function method_enabled($method){return ($method!=='wallet'||(defined('IPSPLA_VERSION')&&version_compare(IPSPLA_VERSION,'1.1.2','>=')))&&IPSPLA_Settings::base_payment_enabled($method);}
    public static function handle($request,$action,$user) {
        global $wpdb;
        if (!class_exists('IPSPLA_Orders') || !class_exists('IPSPLA_Settings') || !class_exists('IPSVP_Receipt_Uploader')) return self::error('افزونه پروکسی آماده نیست.',503);
        $settings=IPSPLA_Settings::get();
        if (($settings['sales_enabled']??'0')!=='1') return self::error('فروش پروکسی موقتاً غیرفعال است.',409);
        if ($action==='proxy-catalog') {
            $raw=(new IPSPLA_ProxyLine_API())->countries();
            if (is_wp_error($raw)) return self::error('دریافت کشورها از ارائه‌دهنده ناموفق بود.',502);
            $countries=[];
            foreach (IPSPLA_Orders::flatten_countries($raw) as $c) {
                $code=(string)IPSPLA_Orders::array_find($c,['code','country','id','slug']);
                if (!$code || !IPSPLA_Settings::country_enabled($code,$settings)) continue;
                $cities=[];
                if (!empty($settings['city_enabled'])) foreach (IPSPLA_Orders::country_cities($c) as $city) $cities[]=['id'=>(string)IPSPLA_Orders::array_find($city,['id','code','slug','city']),'name'=>(string)IPSPLA_Orders::array_find($city,['name','title','label'])];
                $countries[]=['code'=>$code,'name'=>IPSPLA_Settings::country_display_name($code,IPSPLA_Orders::array_find($c,['name','title','country_name','label']),$settings),'cities'=>$cities];
            }
            $products=[];
            foreach ([['dedicated','4'],['shared','4'],['dedicated','6']] as $p) if (IPSPLA_Settings::product_enabled($p[0],$p[1],$settings)) $products[]=['type'=>$p[0],'ip_version'=>$p[1],'label'=>IPSPLA_Settings::public_product_label($p[0],$p[1])];
            return ['countries'=>$countries,'products'=>$products,'periods'=>array_values(array_filter($settings['active_periods'],function($p)use($settings){return $p>=$settings['min_period']&&$p<=$settings['max_period'];})),'wallet_enabled'=>self::method_enabled('wallet'),'card_enabled'=>IPSPLA_Settings::base_payment_enabled('card'),'max_upload_size'=>min(8388608,IPSVP_Receipt_Uploader::max_upload_size())];
        }
        $method=$action==='proxy-wallet'?'wallet':'card';
        if ($action==='proxy-quote') {
            $body=$request->get_json_params();
            if (!is_array($body)) return self::error('درخواست معتبر نیست.');
            $body=array_intersect_key($body,array_flip(['type','ip_version','country','city','period','coupon','order_id','method']));
            foreach ($body as $v) if (!is_scalar($v)||strlen((string)$v)>100) return self::error('ورودی معتبر نیست.');
            $method=$body['method']??'card';
            if (!in_array($method,['card','wallet'],true)||!self::method_enabled($method)) return self::error('روش پرداخت فعال نیست.',409);
            unset($body['method']);
            $renew_id=isset($body['order_id'])?IPSVP_Reseller_Service::integer($body['order_id']):0;
            if ($renew_id===false) return self::error('شناسه سفارش معتبر نیست.');
            if ($renew_id) {
                $owned=IPSPLA_Orders::user_order($renew_id,$user->phone);
                if (!$owned) return self::error('سفارش پیدا نشد.',404);
                if (!IPSPLA_Orders::can_submit_renewal($owned)) return self::error('این پروکسی اکنون قابل تمدید نیست.',409);
                $period=IPSVP_Reseller_Service::integer($body['period']??null,(int)$settings['min_period'],(int)$settings['max_period']);
                if ($period===false||!in_array($period,array_map('intval',$settings['active_periods']),true)) return self::error('مدت تمدید معتبر نیست.');
                $selection=['type'=>$owned->product_type,'ip_version'=>$owned->ip_version,'country'=>$owned->country_code,'city'=>$owned->city_id,'quantity'=>(int)$owned->quantity,'period'=>$period];
            } else { $selection=IPSPLA_Orders::validate_selection($body); }
            if (is_wp_error($selection)) return $selection;
            if (!$renew_id && !IPSPLA_Orders::country_city_valid($selection['country'],$selection['city'])) return self::error('کشور یا شهر معتبر نیست.');
            $price=IPSPLA_Pricing::calculate($selection);
            if (is_wp_error($price)) return self::error('دریافت قیمت پروکسی ناموفق بود.',502);
            $token=bin2hex(random_bytes(24));
            $quote=['method'=>$method,'user_id'=>(int)$user->id,'selection'=>$selection,'renew_order_id'=>$renew_id,'amount'=>(int)$price['final_amount_irt'],'expires'=>time()+300];
            set_transient('ips_proxy_quote_'.hash('sha256',$token),$quote,300);
            return ['methods'=>['card'=>IPSPLA_Settings::base_payment_enabled('card'),'wallet'=>self::method_enabled('wallet')],'method'=>$method,'quote_id'=>$token,'amount'=>$quote['amount'],'expires_at'=>$quote['expires'],'currency'=>'IRT','bank'=>class_exists('IPSPM_Payment_Manager')?IPSPM_Payment_Manager::card_details():array_intersect_key(IPSVP_Settings::get(),array_flip(['bank_card','bank_account_name','bank_iban','bank_note']))];
        }
        $key=(string)$request->get_header('Idempotency-Key');
        $token=$request->get_param('quote_id');
        if (!preg_match('/^[A-Za-z0-9._:-]{16,100}$/D',$key)||!is_string($token)||!preg_match('/^[a-f0-9]{48}$/D',$token)) return self::error('شناسه درخواست معتبر نیست.');
        $lock='ips_proxy_submit_'.(int)$user->id;
        if ((int)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 2)',$lock))!==1) return self::error('درخواست دیگری در حال ثبت است.',409);
        try {
            $journal='ips_proxy_request_'.hash('sha256',$user->id.'|'.$key);
            $previous=get_option($journal);
            if ($previous) {
                if (!hash_equals($previous['quote_hash'],hash('sha256',$token))) return self::error('شناسه درخواست قبلاً برای سفارش دیگری استفاده شده است.',409);
                if (!empty($previous['result'])) return $previous['result'];
                return self::error('وضعیت درخواست قبلی باید توسط پشتیبانی بررسی شود؛ درخواست تکراری ثبت نشد.',409);
            }
            $quote=get_transient('ips_proxy_quote_'.hash('sha256',$token));
            if (!$quote || (int)$quote['user_id']!==(int)$user->id || $quote['expires']<time()) return self::error('قیمت منقضی شده است؛ دوباره محاسبه کنید.',409);
            if (($quote['method']??'card')!==$method||!self::method_enabled($method)) return self::error('روش پرداخت معتبر یا فعال نیست.',409);
            $quote_journal='ips_proxy_consumed_'.hash('sha256',$user->id.'|'.$token);
            $consumed=get_option($quote_journal);
            if ($consumed) return !empty($consumed['result'])?$consumed['result']:self::error('این پیش‌فاکتور قبلاً ارسال شده و نیازمند بررسی است.',409);
            if ($method==='wallet') {
                if (!class_exists('IPSVP_Reseller_Store')) return self::error('قفل کیف پول آماده نیست.',503);
                $locked=IPSVP_Reseller_Store::lock($user->id);if(is_wp_error($locked))return $locked;
                $balance=IPSVP_Reseller_Store::balance($user,new IPSVP_DB());
                if(is_wp_error($balance)||$balance<(int)$quote['amount'])return self::error('موجودی کیف پول کافی یا قابل دریافت نیست.',409);
            }
            if (!empty($quote['renew_order_id'])) {
                $owned=IPSPLA_Orders::user_order($quote['renew_order_id'],$user->phone);
                if (!$owned||!IPSPLA_Orders::can_submit_renewal($owned)) return self::error('وضعیت تمدید تغییر کرده است.',409);
            }
            $price=IPSPLA_Pricing::calculate($quote['selection']);
            if (is_wp_error($price)||(int)$price['final_amount_irt']!==$quote['amount']) return self::error('قیمت تغییر کرده است؛ دوباره محاسبه کنید.',409);
            $upload_key=hash('sha256',$user->id.'|'.$token);
            $upload=null;
            if ($method==='card') {
            $files=$request->get_file_params();$file=$files['receipt']??null;
            if (!$file||!is_array($file)||!isset($file['size'])||$file['size']<1||$file['size']>min(8388608,IPSVP_Receipt_Uploader::max_upload_size())) return self::error('فایل رسید معتبر و حداکثر ۸ مگابایت لازم است.');
            $upload=IPSVP_Receipt_Uploader::upload($file,$user->id,$user->phone,$upload_key);
            if (is_wp_error($upload)) return self::error('فایل رسید پذیرفته نشد؛ فرمت یا حجم را بررسی کنید.');
            }
            if (!add_option($journal,['quote_hash'=>hash('sha256',$token),'state'=>'processing'],'','no')) return self::error('درخواست تکراری است.',409);
            if(!add_option($quote_journal,['state'=>'processing'],'','no'))return self::error('پیش‌فاکتور تکراری است.',409);
            // Only server-validated owned upload metadata is visible to the legacy adapter.
            $old=$_POST;$_POST=$upload?['receipt_attachment_id'=>$upload['attachment_id'],'receipt_file_url'=>$upload['url']]:[];
            try { $result=!empty($quote['renew_order_id'])?IPSPLA_Orders::create_renewal_payment($quote['renew_order_id'],$user->phone,$quote['selection']['period'],$method,null,'bridge-'.$upload_key):IPSPLA_Orders::create_payment($user->phone,$quote['selection'],$method,null,'bridge-'.$upload_key); }
            finally { $_POST=$old; }
            if (is_wp_error($result)||empty($result['order'])) {
                update_option($journal,['quote_hash'=>hash('sha256',$token),'state'=>'review_required'],false);
                return self::error('ثبت درخواست کامل نشد؛ برای جلوگیری از تکرار، نتیجه را با پشتیبانی بررسی کنید.',409);
            }
            $out=['order'=>IPS_Bridge_Customer_Details::proxy_summary($result['order']),'message'=>$method==='wallet'?($result['message']??'درخواست پرداخت ثبت شد.'):(!empty($quote['renew_order_id'])?'رسید تمدید ثبت شد؛ پس از تأیید مدیریت اعمال می‌شود.':'رسید ثبت شد؛ سفارش پس از تأیید مدیریت تحویل می‌شود.')];
            update_option($journal,['quote_hash'=>hash('sha256',$token),'state'=>'complete','result'=>$out],false);
            update_option($quote_journal,['state'=>'complete','result'=>$out],false);
            return $out;
        } finally {$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$lock));}
    }
}

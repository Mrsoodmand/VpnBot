<?php
defined('ABSPATH') || exit;
/** Customer quotes and payments through the existing WordPress receipt engine. */
final class IPS_Bridge_Customer_Renewal {
    private static function error($text,$status=400){return new WP_Error('ips_service_payment',$text,['status'=>$status]);}
    public static function price($user,$db,$input){
        $id=IPSVP_Reseller_Service::integer($input['order_id']??null);
        $order=$id===false?null:$db->get_order($id);
        if(!$order||(int)$order->user_id!==(int)$user->id)return self::error('سفارش پیدا نشد.',404);
        if(in_array((string)$order->status,['volume_finished','time_finished'],true)&&empty($order->service_ended_at)) {
            $snapshot=IPS_Bridge_Service_Live::snapshot($order,$db,true);
            if(empty($snapshot['live']))return self::error('بررسی وضعیت سرویس کامل نشد؛ دوباره تلاش کنید.',503);
            $order=$db->get_order($id);
        }
        $type=$db->order_service_type($order);
        if($type==='shared'&&IPSVP_Reseller_Store::approved($user->id))return self::error('عملیات نمایندگی باید از کیف پول انجام شود.',409);
        if(!$db->order_can_renew($order)||!in_array($order->payment_status,['approved','paid','wallet_paid','crypto_paid','payment_paid'],true)||(empty($order->pg_username)&&empty($order->pg_user_id)))return self::error('این سرویس قابل تمدید یا افزایش حجم نیست.',409);
        if(!$db->service_sales_enabled($type))return self::error('فروش این سرویس غیرفعال است.',409);
        $action=$input['action']??'';$plan=null;
        if($action==='renew'){
            $plan_id=IPSVP_Reseller_Service::integer($input['plan_id']??null);
            $plan=$plan_id===false?null:$db->get_plan($plan_id);
            if(!$plan||(int)$plan->status!==1||$db->normalize_service_type($plan->service_type)!==$type)return self::error('پلن فعال و سازگار انتخاب کنید.');
            $payload=$db->calculate_renewal_plan_price_info($plan,$order);
            $base=(int)$payload['renewal_final_price'];
            $payload=array_merge($payload,['purpose'=>'renewal','renewal_plan_volume_gb'=>(int)$plan->gb,'renewal_plan_days'=>(int)$plan->days]);
        }elseif($action==='extra-volume'){
            $gb=IPSVP_Reseller_Service::integer($input['gb']??null,1,10000);
            if($gb===false||(empty($order->pg_user_id)&&empty($order->pg_username)))return self::error('حجم یا سرویس انتخاب‌شده معتبر نیست.');
            $snapshot=(new IPSVP_PasarGuard_API())->user_snapshot($order->pg_username,$order->pg_user_id,$order);
            if(empty($snapshot['live'])||!isset($snapshot['limit'])||!is_numeric($snapshot['limit'])||(float)$snapshot['limit']<=0)return self::error('برای این سرویس حجم اضافه قابل محاسبه نیست.',409);
            $payload=$db->calculate_extra_volume_price($order,$gb,true);
            if(is_wp_error($payload))return $payload;
            $base=(int)$payload['total_amount'];
            $payload=array_merge($payload,['purpose'=>'extra_volume','gb'=>$gb,'extra_volume_applied'=>0,'telegram_report_sent'=>0]);
        }else{return self::error('عملیات معتبر نیست.');}
        $loyalty=IPSVP_Loyalty::profile($user->id);
        $percent=$type==='shared'?(float)$loyalty['percent']:0;
        $amount=IPSVP_Reseller_Store::discount($base,$percent);
        $payload=array_merge($payload,['order_id'=>$id,'user_id'=>(int)$user->id,'payment_method'=>'card','payment_status'=>'pending','amount'=>$amount,'discount_percent'=>$percent,'retail_amount'=>$base]);
        if($action==='renew'){$payload['renewal_final_price']=$amount;$payload['renewal_amount']=$amount;}
        else{$payload['total_amount']=$amount;$payload['final_unit_price']=IPSVP_Reseller_Store::discount($payload['final_unit_price'],$percent);$payload['unit_price']=$payload['final_unit_price'];}
        return ['amount'=>$amount,'discount_percent'=>$percent,'payload'=>$payload,'order_id'=>$id,'plan_id'=>$plan?(int)$plan->id:0,'type'=>$action==='renew'?'renewal':'extra_volume'];
    }
    public static function handle($r,$action,$user,$db){
        global $wpdb;
        $settings=IPSVP_Settings::get();
        if($action==='service-wallet')return self::wallet($r,$user,$db);
        $method=$action==='service-quote'?($r->get_param('method')?:'card'):'card';
        if(!in_array($method,['card','wallet'],true))return self::error('روش پرداخت معتبر نیست.');
        if($method==='wallet'&&!empty($user->bot_tel_id))return self::error('کیف پول این حساب نیاز به همگام‌سازی دارد.',409);
        $enabled=class_exists('IPSPM_Payment_Manager')?IPSPM_Payment_Manager::method_enabled($method,'ip-sabet'):($settings['payment_'.$method.'_enabled']??'0')==='1';
        if(!$enabled)return self::error('روش پرداخت انتخاب‌شده غیرفعال است.',409);
        if($action==='service-quote'){
            $input=$r->get_json_params();if(!is_array($input))return self::error('درخواست معتبر نیست.');
            $input=array_intersect_key($input,array_flip(['action','order_id','plan_id','gb']));
            foreach($input as $v)if(!is_scalar($v)||strlen((string)$v)>100)return self::error('درخواست معتبر نیست.');
            $price=self::price($user,$db,$input);if(is_wp_error($price))return $price;
            $token=bin2hex(random_bytes(24));
            set_transient('ips_service_quote_'.hash('sha256',$token),['user_id'=>(int)$user->id,'input'=>$input,'method'=>$method,'amount'=>$price['amount'],'expires'=>time()+300],300);
            return ['methods'=>['card'=>class_exists('IPSPM_Payment_Manager')?IPSPM_Payment_Manager::method_enabled('card','ip-sabet'):($settings['payment_card_enabled']??'0')==='1','wallet'=>empty($user->bot_tel_id)&&(class_exists('IPSPM_Payment_Manager')?IPSPM_Payment_Manager::method_enabled('wallet','ip-sabet'):($settings['payment_wallet_enabled']??'0')==='1')],'method'=>$method,'quote_id'=>$token,'unit_price'=>$price['payload']['unit_price']??null,'amount'=>$price['amount'],'discount_percent'=>$price['discount_percent'],'expires_at'=>time()+300,'bank'=>class_exists('IPSPM_Payment_Manager')?IPSPM_Payment_Manager::card_details():array_intersect_key($settings,array_flip(['bank_card','bank_account_name','bank_iban','bank_note']))];
        }
        $token=$r->get_param('quote_id');$key=(string)$r->get_header('Idempotency-Key');
        if(!is_string($token)||!preg_match('/^[a-f0-9]{48}$/D',$token)||!preg_match('/^[A-Za-z0-9._:-]{16,100}$/D',$key))return self::error('شناسه درخواست معتبر نیست.');
        $lock='ips_service_submit_'.(int)$user->id;
        if((int)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,2)',$lock))!==1)return self::error('درخواست دیگری در حال ثبت است.',409);
        try{
            $submission='bridge-service-'.hash('sha256',$user->id.'|'.$key);
            $key_journal='ips_service_request_'.hash('sha256',$submission);
            $journal='ips_service_card_quote_'.hash('sha256',$user->id.'|'.$token);
            $key_quote=get_option($key_journal);if($key_quote&&!hash_equals($key_quote,hash('sha256',$token)))return self::error('شناسه درخواست برای قیمت دیگری استفاده شده است.',409);
            $old=get_option($journal);
            if($old){if(!hash_equals($old['quote_hash'],hash('sha256',$token)))return self::error('شناسه درخواست تکراری است.',409);return $old['result']??self::error('درخواست قبلی نیاز به بررسی دارد؛ ثبت دوباره انجام نشد.',409);}
            $quote=get_transient('ips_service_quote_'.hash('sha256',$token));
            if(!$quote||(int)$quote['user_id']!==(int)$user->id||$quote['expires']<time())return self::error('قیمت منقضی شده است.',409);
            $price=self::price($user,$db,$quote['input']);if(is_wp_error($price))return $price;
            if(($quote['method']??'card')!=='card')return self::error('روش پرداخت با قیمت مطابقت ندارد.',409);
            if($price['amount']!==$quote['amount'])return self::error('قیمت تغییر کرده است؛ دوباره محاسبه کنید.',409);
            $files=$r->get_file_params();$file=$files['receipt']??null;
            if(!$file||!is_array($file)||!isset($file['size'])||$file['size']<1||$file['size']>min(8388608,IPSVP_Receipt_Uploader::max_upload_size()))return self::error('فایل رسید معتبر و حداکثر ۸ مگابایت لازم است.');
            $upload=IPSVP_Receipt_Uploader::upload($file,$user->id,$user->phone,hash('sha256',$submission));
            if(is_wp_error($upload))return self::error('فایل رسید پذیرفته نشد.');
            add_option($key_journal,hash('sha256',$token),'','no');
            if(!add_option($journal,['quote_hash'=>hash('sha256',$token)],'','no'))return self::error('درخواست تکراری است.',409);
            $tables=$db->tables();
            $ok=$wpdb->insert($tables['receipts'],['order_id'=>$price['order_id'],'submission_key'=>$submission,'user_id'=>(int)$user->id,'phone'=>$user->phone,'type'=>$price['type'],'plan_id'=>$price['plan_id'],'attachment_id'=>(int)$upload['attachment_id'],'file_url'=>$upload['url'],'amount'=>$price['amount'],'status'=>'pending','remote_payload'=>wp_json_encode($price['payload']),'created_at'=>$db->now()]);
            if(!$ok)return self::error('ثبت رسید کامل نشد؛ با پشتیبانی بررسی کنید.',503);
            $id=(int)$wpdb->insert_id;$out=['receipt'=>['id'=>$id,'order_id'=>$price['order_id'],'amount'=>$price['amount'],'status'=>'pending'],'message'=>'رسید ثبت شد؛ عملیات پس از تأیید مدیریت اعمال می‌شود.'];
            update_option($journal,['quote_hash'=>hash('sha256',$token),'result'=>$out],false);
            IPSVP_Telegram_Service::queue_pending_payment_notice($id,$db);
            return $out;
        }finally{$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$lock));}
    }
    private static function wallet($r,$user,$db){
        global $wpdb;
        $settings=IPSVP_Settings::get();
        if(!(class_exists('IPSPM_Payment_Manager')?IPSPM_Payment_Manager::method_enabled('wallet','ip-sabet'):($settings['payment_wallet_enabled']??'0')==='1'))return self::error('پرداخت کیف پول غیرفعال است.',409);
        if(!empty($user->bot_tel_id))return self::error('کیف پول این حساب نیاز به همگام‌سازی دارد.',409);
        $token=$r->get_param('quote_id');$key=(string)$r->get_header('Idempotency-Key');
        if(!is_string($token)||!preg_match('/^[a-f0-9]{48}$/D',$token)||!preg_match('/^[A-Za-z0-9._:-]{16,100}$/D',$key))return self::error('شناسه درخواست معتبر نیست.');
        $locked=IPSVP_Reseller_Store::lock($user->id);if(is_wp_error($locked))return $locked;
        $key_name='ips_service_wallet_key_'.hash('sha256',$user->id.'|'.$key);
        $token_hash=hash('sha256',$token);$bound=get_option($key_name);
        if($bound&&!hash_equals($bound,$token_hash))return self::error('شناسه درخواست قبلاً استفاده شده است.',409);
        $journal='ips_service_wallet_'.hash('sha256',$user->id.'|'.$token);
        $old=get_option($journal);
        if($old)return $old['result']??self::error('درخواست قبلی در حال بررسی است؛ دوباره پرداخت نکنید.',409);
        $quote=get_transient('ips_service_quote_'.$token_hash);
        if(!$quote||(int)$quote['user_id']!==(int)$user->id||$quote['expires']<time()||($quote['method']??'card')!=='wallet')return self::error('قیمت معتبر کیف پول لازم است.',409);
        $price=self::price($user,$db,$quote['input']);if(is_wp_error($price))return $price;
        if($price['amount']!==$quote['amount'])return self::error('قیمت تغییر کرده است؛ دوباره انتخاب کنید.',409);
        if($db->get_local_wallet_balance($user->id)<$price['amount'])return self::error('موجودی کیف پول کافی نیست.',409);
        if(!$bound&&!add_option($key_name,$token_hash,'','no'))return self::error('درخواست تکراری است.',409);
        if(!add_option($journal,['state'=>'processing'],'','no'))return self::error('درخواست در حال بررسی است.',409);
        $payload=array_merge($price['payload'],['payment_method'=>'wallet']);
        $tables=$db->tables();
        $ok=$wpdb->insert($tables['receipts'],['order_id'=>$price['order_id'],'submission_key'=>'bridge-wallet-'.$token_hash,'user_id'=>(int)$user->id,'phone'=>$user->phone,'type'=>'wallet_'.$price['type'],'plan_id'=>$price['plan_id'],'attachment_id'=>0,'file_url'=>'','amount'=>$price['amount'],'status'=>'pending','wallet_effect'=>'local','remote_payload'=>wp_json_encode($payload),'created_at'=>$db->now()]);
        if(!$ok)return self::error('ثبت درخواست کامل نشد؛ از پشتیبانی پیگیری کنید.',503);
        $receipt_id=(int)$wpdb->insert_id;
        update_option($journal,['state'=>'processing','receipt_id'=>$receipt_id],false);
        $approved=IPSVP_Receipt_Manager::approve($receipt_id,$db,new IPSVP_PasarGuard_API());
        $success=!empty($approved['ok']);
        if(!$success) IPS_Bridge_Receipt_Notices::queue_manual_review($receipt_id);
        $out=['receipt'=>['id'=>$receipt_id,'order_id'=>$price['order_id'],'amount'=>$price['amount'],'status'=>$success?'approved':'pending_manual_review'],'message'=>$success?'پرداخت و اعمال سرویس با موفقیت انجام شد.':'نتیجه عملیات نیاز به بررسی دارد؛ دوباره پرداخت نکنید و شناسه رسید را به پشتیبانی اعلام کنید.'];
        update_option($journal,['result'=>$out],false);
        return $out;
    }

}

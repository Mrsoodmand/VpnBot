<?php
/** Admin-triggered invalidation of public frontend data only. */
defined('ABSPATH') || exit;
final class IPS_Frontend_Cache {
    public static function init() {
        add_action('admin_menu', function () {
            add_options_page('کش فرانت آی‌پی ثابت', 'کش فرانت آی‌پی ثابت', 'manage_options', 'ips-frontend-cache', [__CLASS__, 'page']);
        });
        add_action('admin_post_ips_clear_frontend_cache', [__CLASS__, 'clear']);
    }
    public static function page() {
        if (!current_user_can('manage_options')) return;
        echo '<div class="wrap"><h1>کش فرانت آی‌پی ثابت</h1>';
        $status=isset($_GET['ips_cache'])?sanitize_key(wp_unslash($_GET['ips_cache'])):'';
        if ($status==='success') echo '<div class="notice notice-success"><p>کش سایت پاک شد. درخواست بعدی اطلاعات تازه را دریافت می‌کند.</p></div>';
        if ($status==='failed') echo '<div class="notice notice-error"><p>پاک‌کردن کش انجام نشد. اتصال فرانت و کلید وب‌سرویس را بررسی و دوباره تلاش کنید.</p></div>';
        echo '<p>فهرست عمومی پلن‌ها، کشورها و محتوای سایت حداکثر ۵ دقیقه کش می‌شوند. پس از تغییر تنظیمات فروش، از دکمه زیر استفاده کنید.</p><p>مصرف، سفارش‌ها، لینک اتصال، تراکنش‌ها، موجودی و قیمت نهایی پرداخت کش نمی‌شوند.</p>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="ips_clear_frontend_cache">';
        wp_nonce_field('ips_clear_frontend_cache');
        submit_button('پاک‌کردن کش سایت');
        echo '</form></div>';
    }
    public static function clear() {
        if (!current_user_can('manage_options')) wp_die('دسترسی مجاز نیست.', '', ['response'=>403]);
        check_admin_referer('ips_clear_frontend_cache');
        $ok=false;
        if (defined('IPS_CONTENT_KEY_SHA256') && preg_match('/^[a-f0-9]{64}$/D', IPS_CONTENT_KEY_SHA256)) {
            $timestamp=(string)time();
            // Same domain, fixed path; no user-supplied destination or credentials in the URL.
            $url=home_url('/api/cache/invalidate/', 'https');
            $result=wp_remote_post($url, ['timeout'=>20,'redirection'=>0,'sslverify'=>true,'headers'=>[
                'X-IPS-Timestamp'=>$timestamp,
                'X-IPS-Signature'=>hash_hmac('sha256','ips-cache:'.$timestamp,IPS_CONTENT_KEY_SHA256),
            ],'body'=>'']);
            if (!is_wp_error($result) && wp_remote_retrieve_response_code($result)===200) {
                $body=json_decode(wp_remote_retrieve_body($result),true);
                $ok=is_array($body)&&!empty($body['ok']);
            }
        }
        wp_safe_redirect(add_query_arg(['page'=>'ips-frontend-cache','ips_cache'=>$ok?'success':'failed'],admin_url('options-general.php')));
        exit;
    }
}
IPS_Frontend_Cache::init();

<?php
if (!defined('ABSPATH')) exit;
final class IPS_Comments_API {
    public static function rest() {
        foreach (['challenge'=>'GET','submit'=>'POST'] as $action=>$method) {
            register_rest_route('ips-bridge/v1', '/comments/'.$action, ['methods'=>$method,'permission_callback'=>['IPS_Content_API','authorize'],'callback'=>[__CLASS__,$action]]);
        }
    }
    private static function target($request) {
        $post=get_post(absint($request->get_param('post')));
        if (!$post || $post->post_status!=='publish' || $post->post_password || !in_array($post->post_type,['post','page'],true)) return new WP_Error('not_found','مطلب پیدا نشد.',['status'=>404]);
        if (!comments_open($post->ID)) return new WP_Error('closed','ثبت دیدگاه برای این مطلب بسته است.',['status'=>403]);
        if (!class_exists('IPSVP_Captcha_Service')) return new WP_Error('unavailable','سرویس کد امنیتی در دسترس نیست.',['status'=>503]);
        return $post;
    }
    public static function challenge($request) {
        $post=self::target($request); if(is_wp_error($post)) return $post;
        $captcha=IPSVP_Captcha_Service::create();
        set_transient('ips_comment_'.hash('sha256',$captcha['token']),$post->ID,10*MINUTE_IN_SECONDS);
        return ['captcha'=>$captcha];
    }
    public static function submit($request) {
        $post=self::target($request); if(is_wp_error($post)) return $post;
        if(get_option('comment_registration')) return new WP_Error('login_required','ثبت دیدگاه در تنظیمات سایت فقط برای اعضای واردشده فعال است.',['status'=>403]);
        $name=sanitize_text_field((string)$request->get_param('name'));$email=sanitize_email((string)$request->get_param('email'));$content=trim((string)$request->get_param('content'));
        if(!$name || strlen($name)>240 || !is_email($email) || strlen($email)>254 || strlen($content)<3 || strlen($content)>16000 || $request->get_param('website')) return new WP_Error('invalid','نام، ایمیل و متن دیدگاه را بررسی کنید.',['status'=>400]);
        $token=(string)$request->get_param('captcha_token');$binding='ips_comment_'.hash('sha256',$token);
        if((int)get_transient($binding)!==$post->ID) return new WP_Error('captcha_expired','کد امنیتی جدید دریافت کنید.',['status'=>400]);
        $valid=IPSVP_Captcha_Service::validate($token,(string)$request->get_param('captcha_code'));if(is_wp_error($valid)) return new WP_Error('captcha_invalid',$valid->get_error_message(),['status'=>400]);
        delete_transient($binding);
        $limit='ips_comment_rate_'.hash('sha256',strtolower($email));if(get_transient($limit)) return new WP_Error('rate_limit','برای ارسال دیدگاه بعدی کمی صبر کنید.',['status'=>429]);
        set_transient($limit,1,MINUTE_IN_SECONDS);
        $parent=absint($request->get_param('parent'));if($parent){$c=get_comment($parent);if(!$c || (int)$c->comment_post_ID!==$post->ID || $c->comment_approved!=='1') return new WP_Error('invalid_parent','دیدگاه مورد پاسخ معتبر نیست.',['status'=>400]);}
        // Use core validation, duplicate checks and spam hooks. Never publish automatically.
        $moderate=function($approved){return in_array($approved,['spam','trash'],true)?$approved:0;};
        add_filter('pre_comment_approved',$moderate,PHP_INT_MAX);
        try {$comment=wp_handle_comment_submission(['comment_post_ID'=>$post->ID,'author'=>$name,'email'=>$email,'comment'=>wp_strip_all_tags($content),'comment_parent'=>$parent]);}
        finally {remove_filter('pre_comment_approved',$moderate,PHP_INT_MAX);}
        if(is_wp_error($comment)) return new WP_Error('comment_rejected',$comment->get_error_message(),['status'=>400]);
        return new WP_REST_Response(['message'=>'دیدگاه شما ثبت شد و پس از تأیید نمایش داده می‌شود.'],201);
    }
}
add_action('rest_api_init',['IPS_Comments_API','rest']);

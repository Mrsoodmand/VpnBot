<?php
defined('ABSPATH') || exit;
/** Recover notification delivery only. Never approve, reject, debit or provision. */
final class IPS_Bridge_Receipt_Notices {
    const SWEEP='ips_bridge_recover_receipt_notices';
    const MANUAL='ips_bridge_manual_payment_notice';
    public static function init() {
        add_action('init',[__CLASS__,'schedule']);
        add_action(self::SWEEP,[__CLASS__,'recover']);
        add_action(self::MANUAL,[__CLASS__,'manual'],10,2);
    }
    public static function schedule() {
        if(!wp_next_scheduled(self::SWEEP)) wp_schedule_single_event(time()+300,self::SWEEP);
    }
    public static function recover() {
        if(!class_exists('IPSVP_Telegram_Service')||!class_exists('IPSVP_DB'))return;
        global $wpdb;$lock='ips_bridge_receipt_recovery';
        if((int)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,0)',$lock))!==1)return;
        try {
            $db=new IPSVP_DB();$table=$db->tables()['receipts'];
            // Only uploaded local receipts, not reseller journals or wallet debits.
            $rows=$wpdb->get_results("SELECT id,remote_payload FROM $table WHERE status='pending' AND file_url<>'' AND (remote_source IS NULL OR remote_source='') AND type IN ('new','renewal','extra_volume','wallet') ORDER BY id DESC LIMIT 100");
            $queued=0;
            foreach($rows as $r) {
                $payload=json_decode((string)$r->remote_payload,true)?:[];
                if(!empty($payload['telegram_pending_notice_sent']))continue;
                $key='ips_notice_recovery_'.(int)$r->id;
                if(get_transient($key))continue;
                if(IPSVP_Telegram_Service::queue_pending_payment_notice((int)$r->id,$db)) {
                    set_transient($key,1,900);$queued++;
                }
                if($queued>=5)break;
            }
        } finally {
            $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$lock));
            self::schedule();
        }
    }
    public static function queue_manual_review($id) {
        if(!wp_next_scheduled(self::MANUAL,[(int)$id,0])) wp_schedule_single_event(time()+1,self::MANUAL,[(int)$id,0]);
    }
    public static function manual($id,$attempt=0) {
        global $wpdb;$id=(int)$id;if($id<=0)return;
        $lock='ips_bridge_manual_notice_'.$id;
        if((int)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,0)',$lock))!==1)return;
        try {
            $key='ips_manual_notice_sent_'.$id;if(get_option($key))return;
            $db=new IPSVP_DB();$r=$db->get_receipt($id);if(!$r)return;
            $o=!empty($r->order_id)?$db->get_order($r->order_id):null;
            if($r->status==='approved' && $o && in_array($o->status,['active','on_hold','created','delivered','cancelled','rejected'],true))return;
            $s=IPSVP_Settings::get();if(($s['telegram_notifications']??'')!=='1'||empty($s['telegram_bot_token'])||empty($s['telegram_chat_id']))return;
            $text="⚠️ عملیات پرداخت نیاز به بررسی مدیریت دارد.\nشناسه رسید: ".$id;
            if($o)$text.="\nشناسه سفارش: ".$o->order_code;
            $text.="\nوضعیت رسید: ".($r->status==='approved'?'تأییدشده':'نیازمند بررسی')."\nتحویل یا اعمال سرویس کامل نشده است. پیش از هر اقدام، جزئیات تراکنش و وضعیت سرویس را در وردپرس بررسی کنید.";
            $res=wp_remote_post('https://api.telegram.org/bot'.trim($s['telegram_bot_token']).'/sendMessage',['timeout'=>20,'body'=>['chat_id'=>$s['telegram_chat_id'],'text'=>$text]]);
            $json=is_wp_error($res)?[]:json_decode(wp_remote_retrieve_body($res),true);
            if(!empty($json['ok'])&&!empty($json['result']['message_id'])) update_option($key,(int)$json['result']['message_id'],false);
            elseif($attempt<3) wp_schedule_single_event(time()+60*(2**$attempt),self::MANUAL,[$id,$attempt+1]);
            else $db->add_log('error','manual_notice_delivery','اعلان بررسی دستی پرداخت ارسال نشد.',['receipt_id'=>$id]);
        } finally {$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$lock));}
    }
}

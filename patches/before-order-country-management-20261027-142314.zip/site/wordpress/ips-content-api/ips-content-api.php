<?php
/**
 * Plugin Name: IP-Sabet Content API
 * Description: Content bridge and separately authenticated administrative read API.
 * Version: 2.10.1
 * Requires PHP: 7.4
 */
if (!defined('ABSPATH')) { exit; }
require_once __DIR__ . '/class-ips-frontend-cache.php';
require_once __DIR__ . '/class-ips-comments-api.php';
require_once __DIR__ . '/class-ips-admin-api.php';
require_once __DIR__ . '/class-ips-receipt-notices.php';
IPS_Bridge_Receipt_Notices::init();
require_once __DIR__ . '/class-ips-service-live.php';
IPS_Bridge_Service_Live::init();
require_once __DIR__ . '/class-ips-customer-details.php';
require_once __DIR__ . '/class-ips-customer-partnership.php';
require_once __DIR__ . '/class-ips-customer-proxy.php';
require_once __DIR__ . '/class-ips-customer-renewal.php';
require_once __DIR__ . '/class-ips-customer-commerce.php';
require_once __DIR__ . '/class-ips-customer-api.php';
final class IPS_Content_API {
    private static $bridge_depth = 0;
    public static function init() {
        add_filter('rest_pre_dispatch', [__CLASS__, 'protect_public_content'], 10, 3);
        add_filter('rest_post_dispatch', [__CLASS__, 'private_headers'], 10, 3);
        add_action('rest_api_init', [__CLASS__, 'rest']);
        add_filter('rank_math/sitemap/entry', [__CLASS__, 'sitemap_entry'], 10, 3);
        add_action('add_meta_boxes_page', [__CLASS__, 'box']);
        add_action('save_post_page', [__CLASS__, 'save']);
    }
    // Rank Math owns the sitemap; exclude private checkout/account routes and legacy redirects.
    public static function sitemap_entry($url, $type, $object) {
        if (!is_array($url) || empty($url['loc'])) { return $url; }
        $path = trim(rawurldecode((string) wp_parse_url($url['loc'], PHP_URL_PATH)), '/');
        $excluded = ['buy', 'dashboard', 'login', 'reseller', 'admin',
            'پلن-های-آی-پی-ثابت', 'پنل-کاربری-آی-پی-ثابت', 'خرید-کانفیگ-آی-پی-ثابت'];
        foreach ($excluded as $prefix) {
            if ($path === $prefix || strpos($path, $prefix . '/') === 0) { return false; }
        }
        return $url;
    }
    private static function seeds() {
        static $data = null;
        if ($data === null) { $data = json_decode(file_get_contents(__DIR__ . '/template-content.json'), true) ?: []; }
        return $data;
    }
    public static function rest() {
        register_rest_field(['post', 'page'], 'ips_content', [
            'get_callback' => [__CLASS__, 'content'],
            'schema' => ['description' => 'Published public editorial content and SEO', 'type' => 'object', 'context' => ['view'], 'readonly' => true],
        ]);
        register_rest_route('ips-bridge/v1', '/ip-location-config', [
            'methods' => 'GET', 'permission_callback' => [__CLASS__, 'authorize'],
            'callback' => function () {
                if (!class_exists('IPS_IP_Location_Widget')) {
                    return new WP_Error('ips_location_unavailable', 'IP location plugin is unavailable.', ['status' => 503]);
                }
                // The subsequent public AJAX lookup runs as a guest, without WP cookies.
                $previous_user = get_current_user_id();
                wp_set_current_user(0);
                $nonce = wp_create_nonce('ips_ip_location_nonce');
                wp_set_current_user($previous_user);
                $response = rest_ensure_response(['nonce' => $nonce]);
                $response->header('Cache-Control', 'private, no-store');
                return $response;
            },
        ]);
        register_rest_route('ips-bridge/v1', '/status', [
            'methods' => 'GET', 'permission_callback' => [__CLASS__, 'authorize'],
            'callback' => function () { return rest_ensure_response(['version' => '2.10.1', 'scope' => 'content:read', 'front_page' => (int) get_option('page_on_front'), 'menus' => 'frontend-managed']); },
        ]);
        register_rest_route('ips-bridge/v1', '/content/(?P<resource>posts|pages|categories|tags|comments)(?:/(?P<id>[1-9][0-9]*))?', [
            'methods' => 'GET', 'permission_callback' => [__CLASS__, 'authorize'],
            'callback' => [__CLASS__, 'read_content'],
        ]);
    }
    public static function authorize($request) {
        $hash = defined('IPS_CONTENT_KEY_SHA256') ? IPS_CONTENT_KEY_SHA256 : '';
        $key = $request->get_header('X-IPS-Content-Key');
        if (!is_ssl()) { return new WP_Error('ips_https_required', 'HTTPS required.', ['status' => 403]); }
        if (!is_string($hash) || !preg_match('/^[a-f0-9]{64}$/', $hash) || !is_string($key) || strlen($key) < 32 || strlen($key) > 512 || !hash_equals($hash, hash('sha256', $key))) {
            return new WP_Error('ips_unauthorized', 'Authentication required.', ['status' => 401]);
        }
        return true;
    }
    public static function protect_public_content($result, $server, $request) {
        if (self::$bridge_depth > 0 || current_user_can('edit_posts')) { return $result; }
        // Core routes, alternate ?rest_route= access and batch subrequests use this same gate.
        if (preg_match('#^/wp/v2/(posts|pages|categories|tags|comments|media|users|search)(/|$)#', $request->get_route()) || strpos($request->get_route(), '/rankmath/v1/getHead') === 0) {
            return new WP_Error('ips_private_content', 'Use the authenticated content bridge.', ['status' => 401]);
        }
        return $result;
    }
    public static function private_headers($response, $server, $request) {
        if (strpos($request->get_route(), '/ips-bridge/v1/') === 0 || preg_match('#^/wp/v2/(posts|pages|categories|tags|comments|media|users|search)(/|$)#', $request->get_route())) {
            $response->header('Cache-Control', 'private, no-store, max-age=0');
            $response->header('Vary', 'X-IPS-Content-Key, Authorization, Cookie');
        }
        return $response;
    }
    public static function read_content($request) {
        $resource = $request['resource'];
        $id = absint($request['id']);
        $inner = new WP_REST_Request('GET', '/wp/v2/' . $resource . ($id ? '/' . $id : ''));
        $allowed = ['page','per_page','search','slug','categories','tags','post','orderby','order','hide_empty'];
        foreach ($allowed as $name) {
            if ($request->has_param($name)) { $inner->set_param($name, $request->get_param($name)); }
        }
        $inner->set_param('per_page', min(100, max(1, (int) ($request->get_param('per_page') ?: 12))));
        $inner->set_param('context', 'view');
        if (in_array($resource, ['posts','pages'], true)) {
            $inner->set_param('status', 'publish');
            // Enforce absence of passwords even when another plugin changes a controller query.
            $filter = function ($args) { $args['has_password'] = false; $args['post_status'] = 'publish'; return $args; };
            $hook = $resource === 'posts' ? 'rest_post_query' : 'rest_page_query';
            add_filter($hook, $filter, PHP_INT_MAX);
            if ($id) {
                $post = get_post($id);
                if (!$post || $post->post_password || $post->post_status !== 'publish') { remove_filter($hook, $filter, PHP_INT_MAX); return new WP_Error('ips_not_found', 'Not found.', ['status' => 404]); }
            }
        }
        if ($resource === 'comments') { $inner->set_param('status', 'approve'); }
        if ($resource === 'comments') {
            $comment_filter = function ($args) { $args['status'] = 'approve'; $args['post_status'] = 'publish'; $args['post_password'] = ''; return $args; };
            add_filter('rest_comment_query', $comment_filter, PHP_INT_MAX);
            if ($id) {
                $comment = get_comment($id);
                $parent_post = $comment ? get_post($comment->comment_post_ID) : null;
                if (!$comment || $comment->comment_approved !== '1' || !$parent_post || $parent_post->post_status !== 'publish' || $parent_post->post_password) { remove_filter('rest_comment_query', $comment_filter, PHP_INT_MAX); return new WP_Error('ips_not_found', 'Not found.', ['status' => 404]); }
            }
        }
        self::$bridge_depth++;
        try {
            $response = rest_do_request($inner);
            if ($response->is_error()) { return $response; }
            $data = rest_get_server()->response_to_data($response, ['wp:featuredmedia','wp:term','author']);
            $data = $id ? self::project($data, $resource) : array_map(function ($item) use ($resource) { return self::project($item, $resource); }, $data);
            $out = new WP_REST_Response($data, 200);
            foreach ($response->get_headers() as $name => $value) {
                if (in_array(strtolower($name), ['x-wp-total','x-wp-totalpages'], true)) { $out->header($name, $value); }
            }
            return $out;
        } finally {
            self::$bridge_depth--;
            if (isset($comment_filter)) { remove_filter('rest_comment_query', $comment_filter, PHP_INT_MAX); }
            if (isset($hook)) { remove_filter($hook, $filter, PHP_INT_MAX); }
        }
    }
    private static function project($data, $resource) {
        // Explicit contract: never forward arbitrary fields registered by other plugins.
        $fields = ['id','slug','link','title','excerpt','date','date_gmt','modified','modified_gmt','template','comment_status','ips_content'];
        if (in_array($resource, ['categories','tags'], true)) { $fields = ['id','name','slug','link','count','taxonomy']; }
        if ($resource === 'comments') { $fields = ['id','parent','author_name','date_gmt','content']; }
        $out = array_intersect_key($data, array_flip($fields));
        if (in_array($resource, ['posts','pages'], true)) {
            $out['content'] = ['protected' => false, 'rendered' => $data['ips_content']['html'] ?? ''];
            $out['_embedded'] = ['author' => [], 'wp:featuredmedia' => [], 'wp:term' => []];
            foreach (($data['_embedded']['author'] ?? []) as $author) { $out['_embedded']['author'][] = ['name' => $author['name'] ?? '']; }
            foreach (($data['_embedded']['wp:featuredmedia'] ?? []) as $media) { $out['_embedded']['wp:featuredmedia'][] = array_intersect_key($media, array_flip(['source_url','alt_text'])); }
            foreach (($data['_embedded']['wp:term'] ?? []) as $terms) { $out['_embedded']['wp:term'][] = array_map(function ($term) { return array_intersect_key($term, array_flip(['id','name','slug','link','count','taxonomy'])); }, $terms); }
        }
        return $out;
    }
    public static function content($object) {
        if (self::$bridge_depth === 0) { return null; }
        $post = get_post((int) $object['id']);
        if (!$post || $post->post_status !== 'publish' || $post->post_password || !in_array($post->post_type, ['page','post'], true)) { return null; }
        // Never evaluate transactional/account shortcodes or read private metadata.
        if (in_array(get_page_template_slug($post->ID), ['dashboard.php','plans.php','buy-proxy.php','buy-vps.php'], true)) { return ['html' => '', 'source' => 'empty', 'faqs' => [], 'seo' => self::seo($post)]; }
        $override = get_post_meta($post->ID, '_ips_public_content', true);
        $seed = self::seeds()[$post->post_name] ?? [];
        $html = ''; $source = 'empty';
        if (trim($override) !== '') { $html = wpautop(wp_kses_post($override)); $source = 'editor'; }
        elseif (trim(strip_shortcodes($post->post_content)) !== '') { $html = apply_filters('the_content', strip_shortcodes($post->post_content)); $source = 'editor'; }
        elseif (!empty($seed['html'])) { $html = $seed['html']; $source = 'template'; }
        $raw_faqs = get_post_meta($post->ID, '_custom_faqs', true);
        if (!is_array($raw_faqs)) { $raw_faqs = $seed['faqs'] ?? []; }
        $faqs = [];
        foreach ($raw_faqs as $faq) {
            if (!is_array($faq)) { continue; }
            $question = sanitize_text_field($faq['question'] ?? '');
            $answer = wp_kses_post($faq['answer'] ?? '');
            if ($question && $answer) { $faqs[] = ['question' => $question, 'answer' => $answer]; }
        }
        return ['html' => wp_kses_post($html), 'source' => $source, 'faqs' => $faqs, 'seo' => self::seo($post)];
    }
    private static function seo($post) {
        $title = get_post_meta($post->ID, 'rank_math_title', true);
        $description = get_post_meta($post->ID, 'rank_math_description', true);
        if (class_exists('RankMath\\Helper')) {
            $title = \RankMath\Helper::replace_vars($title ?: '%title% %sep% %sitename%', $post);
            $description = \RankMath\Helper::replace_vars($description, $post);
        }
        $robots = get_post_meta($post->ID, 'rank_math_robots', true);
        $robots = is_array($robots) ? $robots : [];
        return [
            'title' => wp_strip_all_tags($title ?: get_the_title($post)),
            'description' => wp_strip_all_tags($description),
            'canonical' => esc_url_raw(get_post_meta($post->ID, 'rank_math_canonical_url', true)),
            'image' => esc_url_raw(get_post_meta($post->ID, 'rank_math_facebook_image', true)),
            'noindex' => in_array('noindex', $robots, true),
            'nofollow' => in_array('nofollow', $robots, true),
        ];
    }
    public static function box() {
        add_meta_box('ips-public-content', 'محتوای عمومی برای سایت جدید', [__CLASS__, 'render_box'], 'page', 'normal', 'default');
    }
    public static function render_box($post) {
        wp_nonce_field('ips_public_content_save', 'ips_public_content_nonce');
        echo '<p>این متن فقط برای وب‌سرویس محتوایی سایت جدید است. در صورت خالی بودن، متن برگه یا متن منتقل‌شده از قالب قبلی استفاده می‌شود. هیچ اطلاعات شخصی، کلید یا تنظیمات سرور در این بخش ننویسید.</p>';
        $stored = get_post_meta($post->ID, '_ips_public_content', true);
        $seed = self::seeds()[$post->post_name]['html'] ?? '';
        wp_editor($stored !== '' ? $stored : $seed, 'ips_public_content', ['textarea_name' => 'ips_public_content', 'textarea_rows' => 14, 'media_buttons' => true]);
    }
    public static function save($id) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) { return; }
        if (wp_is_post_revision($id) || !current_user_can('edit_post', $id)) { return; }
        if (!isset($_POST['ips_public_content_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['ips_public_content_nonce'])), 'ips_public_content_save')) { return; }
        if (isset($_POST['ips_public_content'])) { update_post_meta($id, '_ips_public_content', wp_kses_post(wp_unslash($_POST['ips_public_content']))); }
    }
}
IPS_Content_API::init();

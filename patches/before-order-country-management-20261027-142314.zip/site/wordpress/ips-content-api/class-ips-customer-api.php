<?php
/** First-party customer sessions. WordPress remains the source of truth. */
defined('ABSPATH') || exit;
final class IPS_Bridge_Customer_API {
    public static function init() {
        add_action('rest_api_init', function () {
            foreach (['challenge'=>'GET','login'=>'POST','otp-send'=>'POST','identify'=>'POST','me'=>'GET','profile-update'=>'POST','password-update'=>'POST','logout'=>'POST','orders'=>'GET','receipts'=>'GET','wallet'=>'GET','payment-settings'=>'GET','order-live'=>'GET','order-transactions'=>'GET','referral'=>'GET','reseller-account'=>'GET','reseller-update'=>'POST','proxies'=>'GET','proxy'=>'GET','proxy-catalog'=>'GET','proxy-quote'=>'POST','proxy-submit'=>'POST','proxy-wallet'=>'POST','service-quote'=>'POST','service-submit'=>'POST','service-wallet'=>'POST','commerce-catalog'=>'GET','commerce-quote'=>'POST','commerce-submit'=>'POST','commerce-wallet'=>'POST','catalog'=>'GET','order'=>'GET','operations'=>'GET','quote'=>'POST','execute'=>'POST'] as $action=>$method) {
                register_rest_route('ips-bridge/v1', '/customer/'.$action, ['methods'=>$method, 'permission_callback'=>['IPS_Bridge_Admin_API','authorize'], 'callback'=>function ($request) use ($action) { return self::dispatch($request, $action); }]);
            }
        });
        add_filter('rest_post_dispatch', function ($response, $server, $request) {
            if (strpos($request->get_route(), '/ips-bridge/v1/customer/') === 0) {
                $response->header('Cache-Control', 'private, no-store');
                $response->header('X-Robots-Tag', 'noindex, nofollow');
            }
            return $response;
        }, 20, 3);
    }
    private static function error($message, $status=400) { return new WP_Error('ips_customer_error', $message, ['status'=>$status]); }
    private static function key($token) { return 'ips_customer_'.hash('sha256', $token); }
    private static function profile($user) {
        $account = class_exists('IPSVP_Reseller_Store') ? IPSVP_Reseller_Store::approved($user->id) : null;
        $loyalty = class_exists('IPSVP_Loyalty') ? IPSVP_Loyalty::profile($user->id) : [];
        return ['name'=>(string)$user->name, 'phone'=>(string)$user->phone, 'role'=>$account?'reseller':'customer', 'loyalty'=>['stars'=>(int)($loyalty['stars']??0),'percent'=>(float)($loyalty['percent']??0),'source'=>$loyalty['source']??'automatic','expires_at'=>empty($loyalty['expires_at'])?null:gmdate('c',(int)$loyalty['expires_at']),'levels'=>class_exists('IPSVP_Loyalty')?IPSVP_Loyalty::settings()[$account?'reseller':'customer']:[], 'period_days'=>class_exists('IPSVP_Loyalty')?IPSVP_Loyalty::DAYS:30]];
    }
    private static function otp_ready() {
        $s=class_exists('IPSVP_Settings')?IPSVP_Settings::get():[];
        return ($s['otp_login_enabled']??'0')==='1' && !empty($s['smsir_api_key']) && !empty($s['smsir_template_id']) && class_exists('IPSVP_SMS_IR');
    }
    private static function otp($request,$db,$send) {
        global $wpdb;
        if(!self::otp_ready()) return self::error('ورود پیامکی در حال حاضر در دسترس نیست.',503);
        $phone=$db->normalize_phone((string)$request->get_param('phone'));
        if(!preg_match('/^\+989[0-9]{9}$/D',$phone))return self::error('شماره موبایل معتبر وارد کنید.');
        $key='ips_bridge_otp_'.hash('sha256',$phone);$lock='ips_otp_'.substr(hash('sha256',$phone),0,40);
        if((int)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 2)',$lock))!==1)return self::error('کمی بعد تلاش کنید.',429);
        try {
            $s=IPSVP_Settings::get();
            if($send){
                $grant=(string)$request->get_param('otp_grant');
                $authorized=preg_match('/^[a-f0-9]{64}$/D',$grant)&&get_transient('ips_otp_grant_'.hash('sha256',$grant))===$phone;
                if(!$authorized){
                    $valid=IPSVP_Captcha_Service::validate((string)$request->get_param('captcha_token'),(string)$request->get_param('captcha_code'));
                    if(is_wp_error($valid))return self::error('کد امنیتی معتبر نیست.');
                }
                $rate=get_transient($key.'_rate')?:['count'=>0,'until'=>time()+3600,'next'=>0];
                if($rate['count']>=5||$rate['next']>time())return self::error('برای ارسال مجدد کد کمی صبر کنید.',429);
                $wait=max(20,min(600,(int)($s['otp_resend_seconds']??60)));
                $rate['count']++;$rate['next']=time()+$wait;
                set_transient($key.'_rate',$rate,max(1,$rate['until']-time()));
                $length=max(4,min(8,(int)($s['otp_code_length']??6)));
                $code=(string)random_int(10**($length-1),10**$length-1);
                $sent=IPSVP_SMS_IR::send_verify_code($phone,$code);
                if(is_wp_error($sent))return self::error('ارسال پیامک انجام نشد؛ کمی بعد تلاش کنید.',503);
                $ttl=max(1,min(30,(int)($s['otp_expire_minutes']??5)))*60;
                set_transient($key,['hash'=>wp_hash_password($code),'attempts'=>0,'expires'=>time()+$ttl,'referral'=>$authorized?(get_transient('ips_ref_grant_'.hash('sha256',$grant))?:''):''],$ttl);
                if(!$authorized){$grant=bin2hex(random_bytes(32));set_transient('ips_otp_grant_'.hash('sha256',$grant),$phone,900);}
                return ['sent'=>true,'retry_after'=>$wait,'expires_in'=>$ttl,'otp_grant'=>$grant,'code_length'=>$length];
            }
            $record=get_transient($key);
            if(!$record||$record['expires']<=time()||$record['attempts']>=5){delete_transient($key);return self::error('کد منقضی شده است؛ کد جدید دریافت کنید.',401);}
            $record['attempts']++;
            $code=(string)$request->get_param('otp_code');
            if(!preg_match('/^[0-9]{4,8}$/D',$code)||!wp_check_password($code,$record['hash'])){
                if($record['attempts']>=5)delete_transient($key);else set_transient($key,$record,max(1,$record['expires']-time()));
                return self::error('کد واردشده صحیح نیست.',401);
            }
            delete_transient($key);
            $existing=$db->get_user_by_phone($phone);
            $user=$db->get_or_create_user($phone);
            if(!$existing&&$user&&!empty($record['referral'])&&class_exists('IPSRA_Referral_Relation_Service')){
                $attached=IPSRA_Referral_Relation_Service::attach_by_code($record['referral'],['source'=>'site','site_user_id'=>(int)$user->id,'phone'=>$user->phone],'site','referral_code');
                if(is_wp_error($attached))return self::error('حساب ساخته شد اما ثبت معرف ناموفق بود؛ با پشتیبانی تماس بگیرید.',503);
            }
            if(!$user||!empty($user->is_blocked))return self::error('ورود به این حساب امکان‌پذیر نیست.',403);
            $token=bin2hex(random_bytes(32));
            set_transient(self::key($token),['id'=>(int)$user->id,'version'=>hash('sha256',(string)$user->password_hash),'expires'=>time()+43200],43200);
            return ['token'=>$token,'account'=>self::profile($user)];
        } finally {$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$lock));}
    }
    public static function dispatch($request, $action) {
        global $wpdb;
        if (!class_exists('IPSVP_DB') || !class_exists('IPSVP_Captcha_Service')) return self::error('افزونه فروش فعال نیست.',503);
        $db = new IPSVP_DB();
        if ($action === 'challenge') {
            return ['captcha'=>IPSVP_Captcha_Service::create(), 'methods'=>self::otp_ready()?['password','otp']:['password']];
        }
        if($action==='identify'){
            $phone=$db->normalize_phone((string)$request->get_param('phone'));
            if(!preg_match('/^\+989[0-9]{9}$/D',$phone))return self::error('شماره موبایل معتبر وارد کنید.');
            $valid=IPSVP_Captcha_Service::validate((string)$request->get_param('captcha_token'),(string)$request->get_param('captcha_code'));
            if(is_wp_error($valid))return self::error('کد امنیتی معتبر نیست.');
            $user=$db->get_user_by_phone($phone);
            $methods=[];
            if($user&&!empty($user->password_hash))$methods[]='password';
            if(self::otp_ready())$methods[]='otp';
            if(!$methods)return self::error('ورود پیامکی فعلاً در دسترس نیست؛ با پشتیبانی تماس بگیرید.',503);
            $ref='';
            if(!$user&&$request->get_param('referral_code')){
                if(!class_exists('IPSRA_Plugin')||(IPSRA_Plugin::settings()['enabled']??'0')!=='1')return self::error('دعوت دوستان در حال حاضر فعال نیست.',503);
                $raw=$request->get_param('referral_code');if(!is_string($raw)||strlen($raw)>64)return self::error('کد معرف معتبر نیست.');
                $ref=IPSRA_Identity_Service::normalize_code($raw);$identity=IPSRA_Identity_Service::find_by_referral_code($ref);
                if(!$identity)return self::error('کد معرف معتبر نیست.');
                if($db->normalize_phone((string)$identity->phone)===$phone)return self::error('نمی‌توانید معرف خودتان باشید.');
            }
            $grant=bin2hex(random_bytes(32));
            if($ref!=='')set_transient('ips_ref_grant_'.hash('sha256',$grant),$ref,900);
            set_transient('ips_otp_grant_'.hash('sha256',$grant),$phone,900);
            return ['methods'=>$methods,'registration'=>!$user,'otp_grant'=>$grant];
        }
        if($action==='otp-send'||($action==='login'&&$request->get_param('method')==='otp'))return self::otp($request,$db,$action==='otp-send');
        if ($action === 'login') {
            $phone = $db->normalize_phone((string)$request->get_param('phone'));
            $password = (string)$request->get_param('password');
            if (!preg_match('/^\+989[0-9]{9}$/D',$phone) || strlen($password)>256 || $password==='') return self::error('شماره یا رمز معتبر نیست.');
            $lock = 'ips_login_'.substr(hash('sha256',$phone),0,40);
            if ((int)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 2)',$lock))!==1) return self::error('کمی بعد دوباره تلاش کنید.',429);
            try {
                $key = 'ips_login_rate_'.hash('sha256',$phone);
                $rate = get_transient($key) ?: ['count'=>0,'until'=>time()+900];
                if ($rate['count']>=5) return self::error('تعداد تلاش بیش از حد مجاز است؛ ۱۵ دقیقه بعد تلاش کنید.',429);
                $rate['count']++;
                set_transient($key,$rate,max(1,$rate['until']-time()));
                $grant=(string)$request->get_param('otp_grant');
                $authorized=preg_match('/^[a-f0-9]{64}$/D',$grant)&&get_transient('ips_otp_grant_'.hash('sha256',$grant))===$phone;
                if (!$authorized && IPSVP_Captcha_Service::is_required('panel','phone',false)) {
                    $valid = IPSVP_Captcha_Service::validate((string)$request->get_param('captcha_token'),(string)$request->get_param('captcha_code'));
                    if (is_wp_error($valid)) return self::error('کد امنیتی معتبر نیست.');
                }
                $user = $db->get_user_by_phone($phone);
                if (!$user || !empty($user->is_blocked) || empty($user->password_hash) || !wp_check_password($password,$user->password_hash)) return self::error('شماره یا رمز معتبر نیست.',401);
                delete_transient($key);
                $token = bin2hex(random_bytes(32));
                set_transient(self::key($token), ['id'=>(int)$user->id,'version'=>hash('sha256',$user->password_hash),'expires'=>time()+43200],43200);
                return ['token'=>$token,'account'=>self::profile($user)];
            } finally { $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$lock)); }
        }
        if ($action==='commerce-catalog') return IPS_Bridge_Customer_Commerce::catalog($db);
        if ($action==='proxy-catalog') return IPS_Bridge_Customer_Proxy::handle($request,$action,null);
        $token = (string)$request->get_header('X-IPS-Customer-Session');
        $session = preg_match('/^[a-f0-9]{64}$/',$token)?get_transient(self::key($token)):false;
        $user = $session?$db->get_user_by_id($session['id']):null;
        if (!$user || !empty($user->is_blocked) || $session['expires']<time() || !hash_equals($session['version'],hash('sha256',(string)$user->password_hash))) return self::error('ابتدا وارد حساب شوید.',401);
        if ($action==='profile-update') {
            $name=$request->get_param('name');
            if(!is_string($name)||trim($name)===''||strlen($name)>200)return self::error('نام معتبر وارد کنید.');
            $tables=$db->tables();$ok=$wpdb->update($tables['users'],['name'=>sanitize_text_field($name)],['id'=>(int)$user->id]);
            if($ok===false)return self::error('ذخیره نام انجام نشد.',503);
            return ['account'=>self::profile($db->get_user_by_id($user->id))];
        }
        if ($action==='password-update') {
            $locked=IPSVP_Reseller_Store::lock($user->id);if(is_wp_error($locked))return $locked;
            $current=$request->get_param('current');$new=$request->get_param('new');
            if(!is_string($current)||!is_string($new)||strlen($current)>256||strlen($new)<8||strlen($new)>256)return self::error('رمز جدید باید بین ۸ تا ۲۵۶ کاراکتر باشد.');
            $ratekey='ips_password_rate_'.(int)$user->id;$attempts=(int)get_transient($ratekey);
            if($attempts>=5)return self::error('تعداد تلاش بیش از حد مجاز است. ۱۵ دقیقه بعد تلاش کنید.',429);
            set_transient($ratekey,$attempts+1,900);
            if(!wp_check_password($current,$user->password_hash))return self::error('رمز فعلی معتبر نیست.',403);
            $hash=wp_hash_password($new);$tables=$db->tables();
            if($wpdb->update($tables['users'],['password_hash'=>$hash],['id'=>(int)$user->id,'password_hash'=>$user->password_hash])!==1)return self::error('ذخیره رمز انجام نشد. دوباره وارد حساب شوید.',409);
            delete_transient($ratekey);$session['version']=hash('sha256',$hash);
            set_transient(self::key($token),$session,max(1,$session['expires']-time()));
            return ['ok'=>true,'message'=>'رمز عبور تغییر کرد. نشست‌های قبلی حساب پایان یافتند.'];
        }
        if ($action==='logout') { delete_transient(self::key($token)); return ['ok'=>true]; }
        if (in_array($action,['commerce-quote','commerce-submit','commerce-wallet'],true)) return IPS_Bridge_Customer_Commerce::handle($request,$action,$user,$db);
        if ($action==='me') return ['account'=>self::profile($user)];
        if (in_array($action,['service-quote','service-submit','service-wallet'],true)) return IPS_Bridge_Customer_Renewal::handle($request,$action,$user,$db);
        if (in_array($action,['proxy-catalog','proxy-quote','proxy-submit','proxy-wallet'],true)) return IPS_Bridge_Customer_Proxy::handle($request,$action,$user);
        if ($action==='reseller-account'||$action==='reseller-update') return IPS_Bridge_Customer_Partnership::handle($request,$user,$db,$action==='reseller-update');
        if ($action==='referral') return IPS_Bridge_Customer_Details::referral($request,$user);
        if ($action==='proxies'||$action==='proxy') return IPS_Bridge_Customer_Details::proxies($request,$user,$action==='proxy');
        if (in_array($action,['order-transactions','order','order-live'],true)) return IPS_Bridge_Customer_Details::order($request,$user,$db,$action==='order-transactions',$action==='order-live');
        if (in_array($action,['catalog','order','operations','quote','execute'],true)) return self::services($request,$action,$user,$db);
        if ($action==='payment-settings') {
            if (!class_exists('IPSVP_Settings')) return self::error('تنظیمات پرداخت آماده نیست.',503);
            $settings=IPSVP_Settings::get();
            $bank=class_exists('IPSPM_Payment_Manager')?IPSPM_Payment_Manager::card_details():$settings;
            return ['methods'=>IPS_Bridge_Customer_Commerce::methods($user),'bank'=>array_intersect_key((array)$bank,array_flip(['bank_card','bank_account_name','bank_iban','bank_note'])), 'card_enabled'=>class_exists('IPSPM_Payment_Manager')?IPSPM_Payment_Manager::method_enabled('card','ip-sabet'):($settings['payment_card_enabled']??'0')==='1'];
        }
        if ($action==='wallet') {
            if (!class_exists('IPSVP_Reseller_Store')) return self::error('سرویس کیف پول آماده نیست.',503);
            $balance = IPSVP_Reseller_Store::balance($user,$db);
            if (is_wp_error($balance)) return self::error('دریافت موجودی ناموفق بود.',502);
            $items = array_map(function ($item) { return array_intersect_key((array)$item,array_flip(['kind','title','amount','status','date','ref'])); },$db->get_wallet_transactions($user->id,50));
            return ['balance'=>$balance,'currency'=>'تومان','items'=>$items];
        }
        $tables = $db->tables();
        $page = max(1,min(100000,(int)$request->get_param('page')));
        $fields = $action==='orders'?'id,order_code,plan_id,country_id,price,status,payment_status,created_at':'id,order_id,type,amount,status,created_at';
        $table = $tables[$action];
        $items = $wpdb->get_results($wpdb->prepare("SELECT $fields FROM $table WHERE user_id=%d ORDER BY id DESC LIMIT 20 OFFSET %d",$user->id,($page-1)*20),ARRAY_A);
        $total = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE user_id=%d",$user->id));
        if ($action==='orders') { $items=array_map(function($row) use ($db,$user) { $order=$db->get_order($row['id']); return $order&&(int)$order->user_id===(int)$user->id?IPS_Bridge_Customer_Details::summary($order):null; },$items); $items=array_values(array_filter($items)); }
        return ['items'=>$items,'total'=>$total,'page'=>$page,'per_page'=>20];
    }
    private static function services($request,$action,$user,$db) {
        global $wpdb;
        if (!class_exists('IPSVP_Reseller_Service') || !class_exists('IPSVP_PasarGuard_API')) return self::error('ماژول سرویس آماده نیست.',503);
        $service = new IPSVP_Reseller_Service($db,new IPSVP_PasarGuard_API());
        if ($action==='catalog') {
            return IPS_Bridge_Customer_Commerce::catalog($db,$user);
        }
        if ($action==='order') {
            $id=IPSVP_Reseller_Service::integer($request->get_param('id'));
            $order=$id===false?null:$db->get_order($id);
            if (!$order || (int)$order->user_id!==(int)$user->id) return self::error('سفارش پیدا نشد.',404);
            return ['order'=>$service->public_order($order,false)];
        }
        if (!IPSVP_Reseller_Store::approved($user->id)) return self::error('نمایندگی تأییدشده لازم است.',403);
        if ($action==='operations') {
            $table=IPSVP_Reseller_Store::table('operations');
            $page=max(1,min(100000,(int)$request->get_param('page')));
            $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE user_id=%d ORDER BY id DESC LIMIT 20 OFFSET %d",$user->id,($page-1)*20));
            $total=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE user_id=%d",$user->id));
            return ['items'=>array_map(['IPSVP_Reseller_Store','public_operation'],$rows),'total'=>$total,'page'=>$page];
        }
        $body=$request->get_json_params();
        if (!is_array($body)) return self::error('ساختار درخواست معتبر نیست.');
        $input=array_intersect_key($body,array_flip(['order_id','plan_id','country_id','gb','max_amount','customer_reference']));
        foreach ($input as $value) if (!is_scalar($value) || strlen((string)$value)>191) return self::error('ورودی معتبر نیست.');
        $operation=$body['action']??'';
        if (!is_string($operation)) return self::error('عملیات معتبر نیست.');
        if ($action==='quote') return $service->quote($user,$operation,$input);
        if (!isset($input['max_amount']) || IPSVP_Reseller_Service::integer($input['max_amount'],0,100000000000)===false) return self::error('سقف پرداخت معتبر لازم است.');
        $result=$service->execute($user,$operation,$input,(string)$request->get_header('Idempotency-Key'),'web');
        return is_wp_error($result)?$result:['operation'=>IPSVP_Reseller_Store::public_operation($result)];
    }
}
IPS_Bridge_Customer_API::init();

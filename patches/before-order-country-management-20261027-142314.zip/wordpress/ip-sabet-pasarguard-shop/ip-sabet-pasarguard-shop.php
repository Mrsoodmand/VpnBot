<?php
/**
 * Plugin Name: IP Sabet PasarGuard Shop
 * Description: فروش کانفیگ آی پی ثابت با اتصال به پنل PasarGuard، پرداخت کارت به کارت، تایید رسید، ساخت خودکار کاربر و پنل کاربری.
 * Version: 1.5.3
 * Author: IP Sabet Me
 * Text Domain: ip-sabet-pasarguard-shop
 *
 * @package IPSabet_PasarGuard_Shop
 */

defined('ABSPATH') || exit;

define('IPSVP_PLUGIN_FILE', __FILE__);
define('IPSVP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('IPSVP_PLUGIN_URL', plugin_dir_url(__FILE__));

require_once IPSVP_PLUGIN_DIR . 'includes/class-ipsvp-settings.php';
require_once IPSVP_PLUGIN_DIR . 'includes/class-ipsvp-db.php';
require_once IPSVP_PLUGIN_DIR . 'includes/class-ipsvp-session.php';
require_once IPSVP_PLUGIN_DIR . 'includes/class-ipsvp-receipt-uploader.php';
require_once IPSVP_PLUGIN_DIR . 'includes/class-ipsvp-captcha-service.php';
require_once IPSVP_PLUGIN_DIR . 'includes/class-ipsvp-auth-renderer.php';
require_once IPSVP_PLUGIN_DIR . 'includes/class-ipsvp-sms-ir.php';
require_once IPSVP_PLUGIN_DIR . 'includes/class-ipsvp-bot-api.php';
require_once IPSVP_PLUGIN_DIR . 'includes/class-ipsvp-pasarguard-api.php';
require_once IPSVP_PLUGIN_DIR . 'includes/class-ipsvp-sanaei-api.php';
require_once IPSVP_PLUGIN_DIR . 'includes/class-ipsvp-receipt-manager.php';
require_once IPSVP_PLUGIN_DIR . 'includes/class-ipsvp-telegram-service.php';
require_once IPSVP_PLUGIN_DIR . 'includes/class-ipsvp-loyalty.php';
require_once IPSVP_PLUGIN_DIR . 'includes/class-ipsvp-customer-loyalty-sync.php';
require_once IPSVP_PLUGIN_DIR . 'includes/class-ipsvp-reseller-store.php';
require_once IPSVP_PLUGIN_DIR . 'includes/class-ipsvp-reseller-service.php';
require_once IPSVP_PLUGIN_DIR . 'includes/class-ipsvp-reseller-api.php';
require_once IPSVP_PLUGIN_DIR . 'includes/class-ipsvp-reseller-docs.php';
require_once IPSVP_PLUGIN_DIR . 'includes/class-ipsvp-reseller-reports.php';
require_once IPSVP_PLUGIN_DIR . 'includes/class-ipsvp-reseller.php';
require_once IPSVP_PLUGIN_DIR . 'admin/class-ipsvp-admin.php';
require_once IPSVP_PLUGIN_DIR . 'public/class-ipsvp-frontend.php';
require_once IPSVP_PLUGIN_DIR . 'includes/class-ipsabet-pasarguard-shop.php';

register_activation_hook(IPSVP_PLUGIN_FILE, array('IPSabet_PasarGuard_Shop', 'activate'));
register_deactivation_hook(IPSVP_PLUGIN_FILE, array('IPSabet_PasarGuard_Shop', 'deactivate'));

IPSabet_PasarGuard_Shop::instance();

(function () {
    'use strict';

    function initAssignmentForms() {
        document.querySelectorAll('[data-ipsvp-assignment]').forEach(function (form) {
            var provider = form.querySelector('[data-ipsvp-provider]');
            var identifier = form.querySelector('[name="pg_identifier"]');
            var label = form.querySelector('[data-ipsvp-identifier-label]');
            if (!provider || !identifier || !label) { return; }

            function syncProvider() {
                var isSanaei = provider.value === 'sanaei';
                label.textContent = isSanaei ? 'نام کلاینت سنایی (Email)' : 'نام کاربری یا آیدی پاسارگارد';
                identifier.placeholder = isSanaei ? 'مثلاً client-123' : 'مثلاً ips-user-123 یا 4581';
                form.querySelectorAll('[data-ipsvp-provider-fields]').forEach(function (fields) {
                    var active = fields.dataset.ipsvpProviderFields === provider.value;
                    fields.hidden = !active;
                    fields.disabled = !active;
                });
                form.querySelectorAll('[data-ipsvp-provider-help]').forEach(function (help) {
                    help.hidden = help.dataset.ipsvpProviderHelp !== provider.value;
                });
            }

            provider.addEventListener('change', syncProvider);
            form.addEventListener('reset', function () { window.setTimeout(syncProvider, 0); });
            syncProvider();
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initAssignmentForms);
    } else {
        initAssignmentForms();
    }
}());

(function () {
  'use strict';
  function digits(value) { return value.replace(/[۰-۹٠-٩]/g, function (c) { return String(c.charCodeAt(0) - (c <= '٩' ? 1632 : 1776)); }); }
  function normalize(value) { return digits(value).replace(/ي/g, 'ی').replace(/ك/g, 'ک').toLowerCase().trim(); }
  // Capture before the authentication handlers and native pattern validation.
  document.addEventListener('input', function (event) {
    var input = event.target;
    if (!input.closest('.ipsvp') || !input.matches('input[type=tel],input[inputmode=numeric],input[data-ipsvp-otp-digit]')) { return; }
    var value = digits(input.value);
    if (value !== input.value) { var start = input.selectionStart; input.value = value; try { input.setSelectionRange(start, start); } catch (_) {} }
  }, true);
  function tables(root) {
    root.querySelectorAll('table:not(.form-table)').forEach(function (table) {
      if (table.closest('.ips-ui-table-scroll,.ipsvp-user-table-scroll,.ipsr-table-wrap,.ipspla-proxy-table-scroll')) { return; }
      var wrap = document.createElement('div'); wrap.className = 'ips-ui-table-scroll'; wrap.tabIndex = 0;
      wrap.setAttribute('role', 'region'); wrap.setAttribute('aria-label', 'جدول اطلاعات؛ برای مشاهده ستون‌ها پیمایش کنید');
      table.before(wrap); wrap.appendChild(table);
    });
  }
  function filterList(list, index) {
    if (list.dataset.ipsUiSearch || list.closest('.ipsr')) { return; }
    var rows = Array.from(list.children).filter(function (el) { return el.matches('.ipsvp-order-row'); });
    if (!rows.length) { return; }
    list.dataset.ipsUiSearch = 'true';
    var bar = document.createElement('div'); bar.className = 'ips-ui-list-search';
    var label = document.createElement('label'); label.textContent = 'جستجو در این فهرست';
    var input = document.createElement('input'); input.type = 'search'; input.id = 'ips-ui-search-' + index; input.placeholder = 'کد سفارش، سرویس یا کشور'; label.htmlFor = input.id; label.appendChild(input);
    var count = document.createElement('output'); count.setAttribute('aria-live', 'polite');
    bar.append(label, count); list.before(bar);
    var empty = document.createElement('p'); empty.className = 'ips-ui-empty'; empty.textContent = 'سفارشی با این عبارت پیدا نشد.'; empty.hidden = true; list.after(empty);
    function filter() {
      var query = normalize(input.value), visible = 0;
      rows.forEach(function (row) { row.hidden = normalize(row.textContent).indexOf(query) < 0; if (!row.hidden) { visible++; } });
      count.textContent = visible.toLocaleString('fa-IR') + ' سفارش'; empty.hidden = visible !== 0;
    }
    input.addEventListener('input', filter); filter();
  }
  function admin(root) {
    var heading = root.querySelector(':scope > .ips-ui-heading');
    if (!heading) {
      var title = root.querySelector(':scope > h1');
      if (!title) { return; }
      heading = document.createElement('header'); heading.className = 'ips-ui-heading';
      var copy = document.createElement('div'), eyebrow = document.createElement('span'); eyebrow.textContent = 'مدیریت آی پی ثابت من';
      title.before(heading); copy.append(eyebrow, title); heading.append(copy);
    }
    // WordPress can move notices next to the first h1 after DOM ready.
    // Keep plugin alerts outside the title/theme-control row in either load order.
    var alerts;
    function arrangeAlerts() {
      var notices = document.querySelectorAll('.ipsvp-dedicated-admin-notice,.ipsvp-dedicated-expiry-notice');
      if (!notices.length) return;
      if (!alerts) {alerts = document.createElement('div'); alerts.className = 'ipsvp-admin-alerts'; heading.after(alerts);}
      notices.forEach(function (notice) {if (notice.parentElement !== alerts) alerts.appendChild(notice);});
    }
    arrangeAlerts();
    new MutationObserver(arrangeAlerts).observe(heading, {childList:true, subtree:true});
    var toggle = document.createElement('button'); toggle.type = 'button'; toggle.className = 'button ips-ui-theme-toggle'; heading.append(toggle);
    var mode = 'light'; try { mode = localStorage.getItem('ips-admin-theme') || localStorage.getItem('theme') || 'light'; } catch (_) {}
    function theme(next) {
      mode = next === 'dark' ? 'dark' : 'light'; root.dataset.theme = mode;
      document.body.classList.toggle('ips-ui-admin-dark', mode === 'dark');
      toggle.textContent = mode === 'dark' ? 'حالت روشن' : 'حالت تیره';
      toggle.setAttribute('aria-label', toggle.textContent); toggle.setAttribute('aria-pressed', String(mode === 'dark'));
    }
    theme(mode); toggle.addEventListener('click', function () { theme(mode === 'dark' ? 'light' : 'dark'); try { localStorage.setItem('ips-admin-theme', mode); } catch (_) {} });
  }
  function boot() {
    document.querySelectorAll('.ipsvp-admin,.ips-server-admin').forEach(function (root) { admin(root); tables(root); });
    document.querySelectorAll('.ipsvp').forEach(tables);
    document.querySelectorAll('.ipsvp-order-list,[data-ips-ui-order-list]').forEach(filterList);
  }
  if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', boot); } else { boot(); }
})();

(function () {
  'use strict';

  function config() {
    return window.IPSVP_CAPTCHA || {};
  }

  function toEnglishDigits(value) {
    var map = {
      '۰': '0', '۱': '1', '۲': '2', '۳': '3', '۴': '4',
      '۵': '5', '۶': '6', '۷': '7', '۸': '8', '۹': '9',
      '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4',
      '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9'
    };
    return String(value || '').replace(/[۰-۹٠-٩]/g, function (digit) {
      return map[digit] || '';
    }).replace(/\D/g, '');
  }

  function rgbLightness(color) {
    var match = String(color || '').match(/rgba?\(\s*(\d+)\D+(\d+)\D+(\d+)/i);
    if (!match) {
      return null;
    }
    return (parseInt(match[1], 10) * 299 + parseInt(match[2], 10) * 587 + parseInt(match[3], 10) * 114) / 1000;
  }

  function resolvedTheme(box) {
    var mode = box.getAttribute('data-color-mode') || 'auto';
    if (mode === 'light' || mode === 'dark') {
      return mode;
    }
    if (box.closest('.light, [data-theme="light"], [data-color-scheme="light"]')) {
      return 'light';
    }
    if (box.closest('.dark, .dark-mode, [data-theme="dark"], [data-color-scheme="dark"]')) {
      return 'dark';
    }
    var authCard = box.closest('.ipsvp-auth-card');
    if (authCard && window.getComputedStyle) {
      var computed = window.getComputedStyle(authCard);
      var textLightness = rgbLightness(computed.color);
      if (textLightness !== null) {
        return textLightness > 165 ? 'dark' : 'light';
      }
    }
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }

  function setMessage(box, message) {
    var target = box.querySelector('[data-ipsvp-captcha-error]');
    if (!target) {
      return;
    }
    target.textContent = message || '';
    target.classList.toggle('is-visible', Boolean(message));
  }

  function themedUrl(url, box, bustCache) {
    try {
      var parsed = new URL(url, window.location.href);
      parsed.searchParams.set('theme', resolvedTheme(box));
      if (bustCache) {
        parsed.searchParams.set('_', String(Date.now()));
      }
      return parsed.toString();
    } catch (error) {
      return url;
    }
  }

  function applyTheme(box) {
    var image = box.querySelector('[data-ipsvp-captcha-image]');
    var theme = resolvedTheme(box);
    box.setAttribute('data-resolved-theme', theme);
    if (!image || !image.src) {
      return;
    }
    var next = themedUrl(image.src, box, false);
    if (next !== image.src) {
      image.src = next;
    }
  }

  function refresh(box) {
    var settings = config();
    var button = box.querySelector('[data-ipsvp-captcha-refresh]');
    if (!settings.ajax_url || !settings.nonce || box.classList.contains('is-refreshing')) {
      return Promise.resolve(false);
    }
    box.classList.add('is-refreshing');
    if (button) {
      button.disabled = true;
    }
    setMessage(box, '');

    var body = new URLSearchParams();
    body.set('action', 'ipsvp_captcha_refresh');
    body.set('nonce', settings.nonce);
    body.set('theme', resolvedTheme(box));

    return window.fetch(settings.ajax_url, {
      method: 'POST',
      credentials: 'same-origin',
      headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
      body: body.toString()
    }).then(function (response) {
      return response.json();
    }).then(function (response) {
      if (!response || !response.success || !response.data || !response.data.token || !response.data.image_url) {
        var message = response && response.data && response.data.message ? response.data.message : settings.refresh_error;
        throw new Error(message || 'دریافت کد امنیتی جدید ممکن نشد.');
      }
      var token = box.querySelector('[data-ipsvp-captcha-token]');
      var image = box.querySelector('[data-ipsvp-captcha-image]');
      var input = box.querySelector('[data-ipsvp-captcha-code]');
      if (token) {
        token.value = response.data.token;
      }
      if (image) {
        image.src = themedUrl(response.data.image_url, box, true);
      }
      if (input) {
        input.value = '';
        input.focus();
      }
      return true;
    }).catch(function (error) {
      setMessage(box, error && error.message ? error.message : settings.refresh_error);
      return false;
    }).finally(function () {
      box.classList.remove('is-refreshing');
      if (button) {
        button.disabled = false;
      }
    });
  }

  document.addEventListener('click', function (event) {
    var button = event.target.closest('[data-ipsvp-captcha-refresh]');
    if (!button) {
      return;
    }
    event.preventDefault();
    var box = button.closest('[data-ipsvp-captcha]');
    if (box) {
      refresh(box);
    }
  });

  document.addEventListener('input', function (event) {
    if (!event.target.matches('[data-ipsvp-captcha-code]')) {
      return;
    }
    var input = event.target;
    input.value = toEnglishDigits(input.value).slice(0, parseInt(input.maxLength, 10) || 5);
    var box = input.closest('[data-ipsvp-captcha]');
    if (box) {
      setMessage(box, '');
    }
  });

  document.addEventListener('submit', function (event) {
    var form = event.target;
    if (!form || !form.querySelector) {
      return;
    }
    var box = form.querySelector('[data-ipsvp-captcha]:not([data-captcha-test="1"])');
    if (!box) {
      return;
    }
    var input = box.querySelector('[data-ipsvp-captcha-code]');
    var token = box.querySelector('[data-ipsvp-captcha-token]');
    if (input && toEnglishDigits(input.value) && token && token.value) {
      input.value = toEnglishDigits(input.value);
      return;
    }
    event.preventDefault();
    event.stopImmediatePropagation();
    setMessage(box, config().empty_error || 'لطفاً کد امنیتی را وارد کنید.');
    if (input) {
      input.focus();
    } else if (!token || !token.value) {
      refresh(box);
    }
  }, true);

  function initialize(root) {
    var boxes = root.matches && root.matches('[data-ipsvp-captcha]') ? [root] : root.querySelectorAll('[data-ipsvp-captcha]');
    Array.prototype.forEach.call(boxes, applyTheme);
  }

  function ready() {
    initialize(document);
    if (window.MutationObserver) {
      new MutationObserver(function (records) {
        records.forEach(function (record) {
          Array.prototype.forEach.call(record.addedNodes, function (node) {
            if (node.nodeType === 1) {
              initialize(node);
            }
          });
        });
      }).observe(document.documentElement, {childList: true, subtree: true});
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', ready);
  } else {
    ready();
  }

  window.IPSVPCaptcha = {refresh: refresh};
}());

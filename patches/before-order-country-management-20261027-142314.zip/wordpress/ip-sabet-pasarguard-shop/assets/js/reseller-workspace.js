(() => {
    'use strict';
    document.querySelectorAll('[data-ipsr-chart]').forEach(chart => {
        chart.querySelectorAll('[data-chart-metric]').forEach(button => {
            button.addEventListener('click', () => {
                const metric = button.dataset.chartMetric === 'spent' ? 'spent' : 'sales';
                chart.querySelectorAll('[data-chart-metric]').forEach(item => item.setAttribute('aria-pressed', String(item === button)));
                chart.querySelectorAll('.ipsr-chart-column').forEach(column => {
                    const height = Number(column.dataset[metric === 'spent' ? 'heightSpent' : 'heightSales']);
                    column.style.setProperty('--bar-height', `${Number.isFinite(height) ? Math.max(0, Math.min(100, height)) : 0}%`);
                });
            });
        });
    });
    const format = value => new Intl.NumberFormat('fa-IR').format(value);
    document.querySelectorAll('[data-ipsr-create]').forEach(root => {
        const plan = root.querySelector('[data-ipsr-plan]');
        const country = root.querySelector('[data-ipsr-country]');
        const button = root.querySelector('[data-ipsr-buy]');
        const update = () => {
            const selected = plan.options[plan.selectedIndex];
            const raw = selected ? selected.dataset[country.value === '0' ? 'allAmount' : 'amount'] : '';
            const amount = raw === '' ? NaN : Number(raw);
            const balance = Number(root.dataset.balance);
            const valid = Number.isSafeInteger(amount) && amount >= 0 && country.value !== '';
            const insufficient = valid && balance < amount;
            root.querySelector('[data-ipsr-amount]').textContent = valid ? format(amount) : '—';
            root.querySelector('[data-ipsr-after]').textContent = valid ? format(balance - amount) : '—';
            root.querySelector('[data-ipsr-insufficient]').hidden = !insufficient;
            button.disabled = button.dataset.ready !== '1' || !valid || insufficient;
        };
        plan.addEventListener('change', update);
        country.addEventListener('change', update);
        update();
    });
})();

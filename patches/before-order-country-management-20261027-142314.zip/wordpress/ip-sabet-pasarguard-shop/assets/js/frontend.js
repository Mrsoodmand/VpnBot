jQuery(function($){
  $(document).on('click','[data-copy]',function(){
    var $box=$(this).closest('.ipsvp-copy');
    var text=$box.find('textarea').val() || '';
    if(navigator.clipboard){navigator.clipboard.writeText(text);}else{$box.find('textarea').trigger('select');document.execCommand('copy');}
    var old=$(this).text();
    $(this).text('کپی شد ✅');
    var btn=this; setTimeout(function(){$(btn).text(old);},1400);
  });
});

jQuery(function($){
  $(document).on('click','.ipsvp-price-card,.ipsvp-site-plan-card',function(e){
    if($(e.target).is('a,button,input,textarea,select,label,label *')){return;}
    var radio=$(this).find('input[type=radio]').first();
    if(radio.length){radio.prop('checked',true).trigger('change');}
  });
});

jQuery(function($){
  function syncSelected(scope){
    var $scope = scope ? $(scope) : $(document);
    $scope.find('.ipsvp-country,.ipsvp-plan,.ipsvp-site-plan-card,.ipsvp-renew-plan-option').each(function(){
      var checked = $(this).find('input[type=radio]').is(':checked');
      $(this).toggleClass('is-selected', !!checked);
    });
  }
  $(document).on('change','.ipsvp-country input[type=radio],.ipsvp-plan input[type=radio],.ipsvp-site-plan-card input[type=radio],.ipsvp-renew-plan-option input[type=radio]',function(){
    syncSelected($(this).closest('form'));
  });
  $(document).on('click','.ipsvp-country,.ipsvp-plan,.ipsvp-renew-plan-option',function(){
    var radio=$(this).find('input[type=radio]').first();
    if(radio.length && !radio.prop('disabled')){radio.prop('checked',true).trigger('change');}
  });
  syncSelected(document);
});


jQuery(function($){
  function bindHomePlanScroller(){
    $('.ipsvp-pricing-only .ipsvp-site-plans-grid, .ipsvp-plan-select-box .ipsvp-site-plans-grid').each(function(){
      var el = this;
      if (el.dataset.ipsvpMouseScrollBound === '1') { return; }
      el.dataset.ipsvpMouseScrollBound = '1';

      var isDown = false;
      var startX = 0;
      var startScrollLeft = 0;
      var moved = false;
      var lastDragAt = 0;
      var pendingScrollLeft = null;
      var rafId = null;

      function pageX(e){ return e.pageX || (e.clientX + window.pageXOffset); }
      function scheduleScroll(value){
        pendingScrollLeft = value;
        if (rafId) { return; }
        rafId = window.requestAnimationFrame(function(){
          if (pendingScrollLeft !== null) {
            el.scrollLeft = pendingScrollLeft;
          }
          pendingScrollLeft = null;
          rafId = null;
        });
      }
      function clearDrag(){
        if (!isDown) { return; }
        isDown = false;
        el.classList.remove('is-dragging');
        document.documentElement.classList.remove('ipsvp-no-select');
        if (moved) {
          lastDragAt = Date.now();
          setTimeout(function(){ moved = false; }, 80);
        }
      }

      el.addEventListener('mousedown', function(e){
        if (e.button !== 0) { return; }
        if ($(e.target).closest('input, textarea, select, button').length) { return; }
        isDown = true;
        moved = false;
        startX = pageX(e);
        startScrollLeft = el.scrollLeft;
        el.classList.add('is-dragging');
        document.documentElement.classList.add('ipsvp-no-select');
        e.preventDefault();
      });

      window.addEventListener('mousemove', function(e){
        if (!isDown) { return; }
        var dx = pageX(e) - startX;
        if (Math.abs(dx) > 4) { moved = true; }
        scheduleScroll(startScrollLeft - dx);
        e.preventDefault();
      }, {passive:false});

      window.addEventListener('mouseup', clearDrag);
      window.addEventListener('blur', clearDrag);

      el.addEventListener('click', function(e){
        if (moved || (Date.now() - lastDragAt) < 120) {
          e.preventDefault();
          e.stopPropagation();
          if (e.stopImmediatePropagation) { e.stopImmediatePropagation(); }
        }
      }, true);

      el.addEventListener('wheel', function(e){
        if (el.scrollWidth <= el.clientWidth) { return; }

        var absX = Math.abs(e.deltaX || 0);
        var absY = Math.abs(e.deltaY || 0);

        // اسکرول عمودی معمولی باید برای بالا و پایین رفتن صفحه آزاد باشد.
        // فقط وقتی کاربر با ترک پد افقی اسکرول می کند یا Shift را نگه می دارد،
        // اسکرول را به حرکت افقی پلن ها تبدیل می کنیم.
        if (!e.shiftKey && absX <= absY) { return; }

        var delta = e.shiftKey ? (e.deltaY || e.deltaX) : e.deltaX;
        if (!delta) { return; }

        var before = el.scrollLeft;
        el.scrollLeft = before + delta;
        if (el.scrollLeft === before) {
          el.scrollLeft = before - delta;
        }
        e.preventDefault();
      }, {passive:false});
    });
  }

  bindHomePlanScroller();
  $(document).on('ipsvp:refresh', bindHomePlanScroller);
});

jQuery(function($){
  if (typeof IPSVP_PANEL_LOGIN === 'undefined') { return; }
  if (!IPSVP_PANEL_LOGIN.ajax_url || !IPSVP_PANEL_LOGIN.nonce) { return; }

  var initialAuthHtml = '';
  var authTimer = null;
  function colorLightness(color){
    var match = String(color || '').match(/rgba?\(\s*(\d+)\D+(\d+)\D+(\d+)/i);
    if (!match) { return null; }
    return (parseInt(match[1], 10) * 299 + parseInt(match[2], 10) * 587 + parseInt(match[3], 10) * 114) / 1000;
  }
  function resolvedAuthTheme(card){
    if (!card) { return 'light'; }
    if (card.closest('.light, [data-theme="light"], [data-color-scheme="light"]')) { return 'light'; }
    if (card.closest('.dark, .dark-mode, [data-theme="dark"], [data-color-scheme="dark"]')) { return 'dark'; }
    if (window.getComputedStyle) {
      var lightness = colorLightness(window.getComputedStyle(card).color);
      if (lightness !== null) { return lightness > 165 ? 'dark' : 'light'; }
    }
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }
  function syncAuthTheme($root){
    if (!$root || !$root.length) { return; }
    $root.find('.ipsvp-auth-card').addBack('.ipsvp-auth-card').each(function(){
      this.setAttribute('data-ipsvp-resolved-theme', resolvedAuthTheme(this));
    });
  }
  function authRoot($el){
    var $root = $el && $el.closest ? $el.closest('[data-ipsvp-auth]') : $('[data-ipsvp-auth]').first();
    return $root.length ? $root : $();
  }
  function englishDigits(value){
    return String(value || '').replace(/[۰-۹٠-٩]/g, function(ch){
      return '۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩'.indexOf(ch) % 10;
    });
  }
  function localPhone(value){
    var digits = englishDigits(value).replace(/\D/g, '');
    if (digits.indexOf('0098') === 0) { digits = '0' + digits.slice(4); }
    if (digits.indexOf('98') === 0 && digits.length >= 12) { digits = '0' + digits.slice(2); }
    if (digits.indexOf('9') === 0 && digits.length === 10) { digits = '0' + digits; }
    return digits.slice(0, 11);
  }
  function formatSeconds(seconds){
    seconds = Math.max(0, parseInt(seconds, 10) || 0);
    var min = Math.floor(seconds / 60);
    var sec = seconds % 60;
    return min + ':' + (sec < 10 ? '0' : '') + sec;
  }
  function setBusy($form, busy){
    var $buttons = $form.find('button').not('[data-ipsvp-captcha-refresh]');
    if (busy) {
      $form.data('ipsvpBusy', 1);
      $buttons.each(function(){
        var $btn = $(this);
        if (!$btn.data('ipsvpOldText')) { $btn.data('ipsvpOldText', $btn.text()); }
        $btn.prop('disabled', true).text(IPSVP_PANEL_LOGIN.loading || 'لطفا صبر کنید...');
      });
    } else {
      $form.data('ipsvpBusy', 0);
      $buttons.each(function(){
        var $btn = $(this);
        if ($btn.data('ipsvpOldText')) { $btn.text($btn.data('ipsvpOldText')); }
        if ($btn.is('[data-ipsvp-resend-button]') && $btn.data('ipsvpTimerActive')) { return; }
        $btn.prop('disabled', false);
      });
    }
  }
  function syncOtp($form){
    var code = '';
    $form.find('[data-ipsvp-otp-digit]').each(function(){ code += englishDigits($(this).val()).replace(/\D/g, '').slice(0, 1); });
    $form.find('input[name="ipsvp_otp_code"]').val(code);
    return code;
  }
  function replaceAuth(html){
    if (!html) { return; }
    if (authTimer) {
      window.clearInterval(authTimer);
      authTimer = null;
    }
    var $current = $('[data-ipsvp-auth]').first();
    if ($current.length) {
      $current.replaceWith(html);
      initAuth();
      $(document).trigger('ipsvp:auth-refresh');
    }
  }
  function showMessage($root, msg){
    if (!$root.length) { return; }
    var $msg = $root.find('.ipsvp-auth-message').first();
    if (!$msg.length) {
      $msg = $('<div class="ipsvp-auth-message ipsvp-auth-error"></div>').insertAfter($root.find('.ipsvp-auth-head').first());
    }
    $msg.removeClass('ipsvp-auth-success').addClass('ipsvp-auth-error is-visible').text(msg || IPSVP_PANEL_LOGIN.network_error || 'ارتباط با سرور برقرار نشد.');
  }
  function initPhoneFields($root){
    $root.find('input[name="ipsvp_panel_phone"]').not('[type="hidden"]').each(function(){
      var $input = $(this);
      $input.val(localPhone($input.val()));
    });
  }
  function initOtpTimer($root){
    if (authTimer) {
      window.clearInterval(authTimer);
      authTimer = null;
    }
    var $timer = $root.find('[data-ipsvp-otp-timer]').first();
    if (!$timer.length) { return; }
    var seconds = parseInt($timer.attr('data-seconds'), 10) || 0;
    var $countdown = $timer.find('[data-ipsvp-otp-countdown]').first();
    var $button = $root.find('[data-ipsvp-resend-button]').first();
    function renderTimer(){
      $countdown.text(formatSeconds(seconds));
      if (seconds > 0) {
        $timer.addClass('is-active').removeClass('is-ready');
        $button.prop('disabled', true).data('ipsvpTimerActive', 1);
        seconds -= 1;
        return;
      }
      $timer.removeClass('is-active').addClass('is-ready');
      $button.prop('disabled', false).data('ipsvpTimerActive', 0);
      if (authTimer) {
        window.clearInterval(authTimer);
        authTimer = null;
      }
    }
    var shouldTick = seconds > 0;
    renderTimer();
    if (shouldTick) {
      authTimer = window.setInterval(renderTimer, 1000);
    }
  }
  function initAuth(){
    var $root = $('[data-ipsvp-auth]').first();
    if ($root.length && !initialAuthHtml) { initialAuthHtml = $root.prop('outerHTML'); }
    syncAuthTheme($root);
    initPhoneFields($root);
    initOtpTimer($root);
    $root.find('[data-ipsvp-otp-digit]').first().trigger('focus');
  }

  $(document).on('submit', '[data-ipsvp-auth-form]', function(e){
    e.preventDefault();
    var $form = $(this);
    if ($form.data('ipsvpBusy')) { return false; }
    var $root = authRoot($form);
    $form.find('input[name="ipsvp_panel_phone"]').not('[type="hidden"]').each(function(){
      $(this).val(localPhone($(this).val()));
    });
    if ($form.is('[data-ipsvp-otp-form]')) { syncOtp($form); }
    setBusy($form, true);
    $.post(IPSVP_PANEL_LOGIN.ajax_url, $form.serialize() + '&action=ipsvp_panel_login&nonce=' + encodeURIComponent(IPSVP_PANEL_LOGIN.nonce))
      .done(function(res){
        if (res && res.success && res.data && res.data.reload) {
          window.location.reload();
          return;
        }
        if (res && res.data && res.data.html) {
          replaceAuth(res.data.html);
          return;
        }
        showMessage($root, (res && res.data && res.data.message) ? res.data.message : '');
      })
      .fail(function(){
        showMessage($root, IPSVP_PANEL_LOGIN.network_error);
      })
      .always(function(){
        setBusy($form, false);
      });
    return false;
  });

  $(document).on('click', '[data-ipsvp-auth-back]', function(){
    if (initialAuthHtml) {
      replaceAuth(initialAuthHtml);
      var captchaBox = document.querySelector('[data-ipsvp-auth] [data-ipsvp-captcha]');
      if (captchaBox && window.IPSVPCaptcha && typeof window.IPSVPCaptcha.refresh === 'function') {
        window.IPSVPCaptcha.refresh(captchaBox);
      }
    }
  });

  function openSharedAuthModal(){
    var $modal = $('#ipspla-auth-modal');
    if($modal.length){
      window.location.hash = 'ipspla-auth-modal';
      setTimeout(function(){ $modal.find('input[name="ipsvp_panel_phone"]').not('[type="hidden"]').first().trigger('focus'); }, 80);
    }
  }
  $(document).on('click', '[data-ipsvp-open-auth]', function(){
    openSharedAuthModal();
  });
  $(document).on('submit', '[data-ipsvp-config-checkout][data-requires-login="1"]', function(e){
    e.preventDefault();
    var $form = $(this);
    $form.find('[data-ipsvp-config-guest-message]').prop('hidden', false).text('برای ثبت سفارش ابتدا وارد حساب کاربری شوید.');
    try {
      var state = {};
      $form.serializeArray().forEach(function(item){ state[item.name] = item.value; });
      window.sessionStorage.setItem('ipsvp_config_checkout_state', JSON.stringify(state));
    } catch(err) {}
    openSharedAuthModal();
    return false;
  });

  $(document).on('input', 'input[name="ipsvp_panel_phone"]', function(){
    var $input = $(this);
    if ($input.is('[type="hidden"]')) { return; }
    $input.val(localPhone($input.val()));
  });

  $(document).on('input', '[data-ipsvp-otp-digit]', function(){
    var $input = $(this);
    var value = englishDigits($input.val()).replace(/\D/g, '');
    if (value.length > 1) {
      var chars = value.split('');
      var $all = $input.closest('[data-ipsvp-otp-form]').find('[data-ipsvp-otp-digit]');
      var start = $all.index($input);
      for (var i = 0; i < chars.length && (start + i) < $all.length; i++) {
        $all.eq(start + i).val(chars[i]);
      }
      $all.eq(Math.min(start + chars.length, $all.length - 1)).trigger('focus');
    } else {
      $input.val(value.slice(0, 1));
      if (value && $input.next('[data-ipsvp-otp-digit]').length) {
        $input.next('[data-ipsvp-otp-digit]').trigger('focus');
      }
    }
    syncOtp($input.closest('[data-ipsvp-otp-form]'));
  });

  $(document).on('keydown', '[data-ipsvp-otp-digit]', function(e){
    var $input = $(this);
    if (e.key === 'Backspace' && !$input.val() && $input.prev('[data-ipsvp-otp-digit]').length) {
      $input.prev('[data-ipsvp-otp-digit]').trigger('focus');
    }
  });

  $(document).on('paste', '[data-ipsvp-otp-digit]', function(e){
    var text = (e.originalEvent.clipboardData || window.clipboardData).getData('text') || '';
    var digits = englishDigits(text).replace(/\D/g, '').split('');
    if (!digits.length) { return; }
    e.preventDefault();
    var $all = $(this).closest('[data-ipsvp-otp-form]').find('[data-ipsvp-otp-digit]');
    $all.each(function(i){ $(this).val(digits[i] || ''); });
    syncOtp($(this).closest('[data-ipsvp-otp-form]'));
    $all.eq(Math.min(digits.length, $all.length) - 1).trigger('focus');
  });

  if (window.MutationObserver) {
    var authThemeObserver = new MutationObserver(function(){ syncAuthTheme($('[data-ipsvp-auth]').first()); });
    authThemeObserver.observe(document.documentElement, {attributes:true, attributeFilter:['class','data-theme','data-color-scheme']});
    if (document.body) { authThemeObserver.observe(document.body, {attributes:true, attributeFilter:['class','data-theme','data-color-scheme']}); }
  }
  initAuth();
});

jQuery(function($){
  if (typeof IPSVP_PANEL_NOTIFICATIONS === 'undefined') { return; }
  if (!IPSVP_PANEL_NOTIFICATIONS.ajax_url || !IPSVP_PANEL_NOTIFICATIONS.nonce) { return; }
  var storageKey = 'ipsvp_last_popup_notification_id';
  var lastShown = parseInt(localStorage.getItem(storageKey) || '0', 10) || 0;
  var audioCtx = null;
  var audioReady = false;
  var suppressExistingOnLoad = !!parseInt(IPSVP_PANEL_NOTIFICATIONS.suppress_existing_on_load || 0, 10);
  var didInitialNotificationSync = false;
  function getAudioContext(){
    var Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) { return null; }
    if (!audioCtx) { audioCtx = new Ctx(); }
    return audioCtx;
  }
  function unlockAudio(){
    var ctx = getAudioContext();
    if (!ctx) { return; }
    if (ctx.state === 'suspended' && ctx.resume) {
      ctx.resume().then(function(){ audioReady = true; }).catch(function(){});
    } else {
      audioReady = true;
    }
  }
  $(document).one('pointerdown keydown touchstart click', unlockAudio);
  function playNotificationSound(){
    if (!IPSVP_PANEL_NOTIFICATIONS.sound) { return; }
    var ctx = getAudioContext();
    if (!ctx) { return; }
    function beep(freq, start, duration){
      var osc = ctx.createOscillator();
      var gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, ctx.currentTime + start);
      gain.gain.setValueAtTime(0.0001, ctx.currentTime + start);
      gain.gain.exponentialRampToValueAtTime(0.11, ctx.currentTime + start + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + start + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(ctx.currentTime + start);
      osc.stop(ctx.currentTime + start + duration + 0.02);
    }
    function run(){
      try {
        beep(740, 0, 0.12);
        beep(980, 0.13, 0.14);
      } catch(e) {}
    }
    try {
      if (ctx.state === 'suspended' && ctx.resume) {
        ctx.resume().then(function(){ audioReady = true; run(); }).catch(function(){});
      } else {
        audioReady = true;
        run();
      }
    } catch(e) {}
  }
  function stack(){
    var $s = $('.ipsvp-toast-stack');
    if (!$s.length) { $s = $('<div class="ipsvp-toast-stack" aria-live="polite" aria-atomic="true"></div>').appendTo('body'); }
    return $s;
  }
  function showToast(item){
    if (!item || !item.id || item.id <= lastShown) { return; }
    var minCreatedAt = parseInt(IPSVP_PANEL_NOTIFICATIONS.min_created_at || 0, 10) || 0;
    var itemCreatedAt = parseInt(item.created_at_epoch || 0, 10) || 0;
    // در صفحه ثبت موفق سفارش، نوتیفیکیشن های قدیمی را پخش نکن؛ فقط تغییراتی که بعد از باز شدن همین صفحه ایجاد می شوند نمایش داده شوند.
    if (minCreatedAt > 0 && itemCreatedAt > 0 && itemCreatedAt < minCreatedAt) {
      lastShown = parseInt(item.id, 10) || lastShown;
      localStorage.setItem(storageKey, String(lastShown));
      return;
    }
    lastShown = parseInt(item.id, 10) || lastShown;
    localStorage.setItem(storageKey, String(lastShown));
    var title = item.title || 'بروزرسانی سفارش';
    var msg = item.message || 'وضعیت یکی از موارد حساب شما تغییر کرد.';
    var btn = item.button || 'مشاهده سفارش';
    var url = item.action_url || '#';
    var $toast = $('<div class="ipsvp-toast"><h4></h4><p></p><div class="ipsvp-toast-actions"><a></a><button type="button">بستن</button></div></div>');
    $toast.find('h4').text(title);
    $toast.find('p').text(msg);
    $toast.find('a').attr('href', url).text(btn);
    $toast.find('button').on('click', function(){ $toast.remove(); });
    stack().append($toast);
    playNotificationSound();
    setTimeout(function(){ $toast.fadeOut(200, function(){ $(this).remove(); }); }, 14000);
  }
  function updateBell(counts){
    if (typeof counts !== 'object' || counts === null) {
      counts = {orders: counts};
    }
    $('.ipsvp-panel-nav a').find('.ipsvp-nav-bell').remove();
    Object.keys(counts).forEach(function(tab){
      var count = parseInt(counts[tab] || 0, 10) || 0;
      if (count <= 0) { return; }
      var $tab = $('.ipsvp-panel-nav a[href*="ipsvp_tab='+tab+'"]');
      if (!$tab.length) { return; }
      $tab.append('<span class="ipsvp-nav-bell" aria-label="اعلان جدید">🔔<em>'+count+'</em></span>');
    });
  }
  var pollTimer = null;
  var pollRequest = null;
  var pollInterval = parseInt(
    IPSVP_PANEL_NOTIFICATIONS.poll_interval || 30000,
    10
  );

  function schedulePoll(delay) {
    window.clearTimeout(pollTimer);
    pollTimer = window.setTimeout(poll, delay || pollInterval);
  }

  function poll(){
    if (document.hidden || poll.busy) {
      schedulePoll();
      return;
    }
    poll.busy = true;
    pollRequest = $.ajax({
      url: IPSVP_PANEL_NOTIFICATIONS.ajax_url,
      method: 'POST',
      timeout: 15000,
      data: {
        action: 'ipsvp_panel_notifications',
        nonce: IPSVP_PANEL_NOTIFICATIONS.nonce
      }
    }).done(function(res){
      if (!res || !res.success || !res.data) { return; }
      updateBell(res.data.counts || res.data.count || 0);
      var list = res.data.notifications || [];
      if (list.length) {
        list.sort(function(a,b){ return (parseInt(a.id,10)||0) - (parseInt(b.id,10)||0); });
        if (suppressExistingOnLoad && !didInitialNotificationSync) {
          var maxId = lastShown;
          list.forEach(function(item){
            var id = parseInt(item.id || 0, 10) || 0;
            if (id > maxId) { maxId = id; }
          });
          lastShown = maxId;
          localStorage.setItem(storageKey, String(lastShown));
        } else {
          list.forEach(showToast);
        }
      }
      didInitialNotificationSync = true;
    }).always(function(){
      poll.busy = false;
      pollRequest = null;
      schedulePoll();
    });
  }
  schedulePoll(600);

  document.addEventListener('visibilitychange', function () {
    if (document.hidden) {
      window.clearTimeout(pollTimer);

      if (pollRequest && pollRequest.readyState !== 4) {
        pollRequest.abort();
      }
    } else {
      schedulePoll(500);
    }
  });

  window.addEventListener('pagehide', function () {
    window.clearTimeout(pollTimer);

    if (pollRequest && pollRequest.readyState !== 4) {
      pollRequest.abort();
    }
  });
});

jQuery(function($){
  function todayKey(){
    var d = new Date();
    function pad2(n){ n = String(n); return n.length < 2 ? '0' + n : n; }
    return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
  }
  function storageGet(storage, key){
    try { return storage.getItem(key); } catch(e) { return null; }
  }
  function storageSet(storage, key, value){
    try { storage.setItem(key, value); } catch(e) {}
  }
  function shouldShowWarning(mode, key){
    if (mode === 'always') { return true; }
    var storage = mode === 'session' ? window.sessionStorage : window.localStorage;
    var stored = storageGet(storage, key);
    if (mode === 'daily') { return stored !== todayKey(); }
    return stored !== '1';
  }
  function markWarningSeen(mode, key){
    if (mode === 'always') { return; }
    var storage = mode === 'session' ? window.sessionStorage : window.localStorage;
    storageSet(storage, key, mode === 'daily' ? todayKey() : '1');
  }
  $('[data-service-warning-popup]').each(function(){
    var $popup = $(this);
    var mode = String($popup.data('repeat-mode') || 'daily');
    if (['session','daily','always'].indexOf(mode) === -1) { mode = 'daily'; }
    var onceAfterLogin = String($popup.data('once-after-login') || '0') === '1';
    var onceAfterLoginKey = 'ipsvp_service_warning_seen_after_login';
    if (onceAfterLogin && storageGet(window.sessionStorage, onceAfterLoginKey) === '1') {
      $popup.remove();
      return;
    }
    var visibleCount = 0;
    $popup.find('[data-warning-key]').each(function(){
      var $item = $(this);
      var key = 'ipsvp_service_warning_' + ($item.data('warning-key') || '');
      if (shouldShowWarning(mode, key)) {
        visibleCount += 1;
        markWarningSeen(mode, key);
      } else {
        $item.remove();
      }
    });
    if (!visibleCount) {
      $popup.remove();
      return;
    }
    if (onceAfterLogin) {
      storageSet(window.sessionStorage, onceAfterLoginKey, '1');
    }
    $popup.prop('hidden', false).addClass('is-open');
  });
  $(document).on('submit','form',function(){
    if ($(this).find('input[name="ipsvp_action"][value="panel_logout"]').length) {
      try { window.sessionStorage.removeItem('ipsvp_service_warning_seen_after_login'); } catch(e) {}
    }
  });
  $(document).on('click','[data-service-warning-close]',function(){
    $(this).closest('[data-service-warning-popup]').removeClass('is-open').prop('hidden', true);
  });
  try {
    var params = new URLSearchParams(window.location.search || '');
    var action = params.get('ips_action') || params.get('action') || '';
    var hash = '';
    if (action === 'renew') {
      hash = $('#ipsvp-renew-modal').length ? '#ipsvp-renew-modal' : ($('#ipsvp-bot-renew-modal').length ? '#ipsvp-bot-renew-modal' : '');
    } else if (action === 'extra_volume') {
      hash = $('#ipsvp-extra-volume-modal').length ? '#ipsvp-extra-volume-modal' : '';
    }
    if (hash && window.location.hash !== hash) {
      window.location.hash = hash;
    }
  } catch(e) {}
});

// Renewal flow: one plan picker, then payment methods
jQuery(function($){
  function formatToman(n){
    n = parseInt(n || 0, 10) || 0;
    try { return n.toLocaleString('fa-IR') + ' تومان'; } catch(e) { return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ',') + ' تومان'; }
  }
  function syncRenewFlow($flow){
    if(!$flow || !$flow.length){ return; }
    var $checked = $flow.find('[data-renew-plan-picker] input[type=radio]:checked').first();
    var planId = $checked.val() || '';
    var price = parseInt($checked.data('price') || $checked.closest('[data-plan-price]').data('plan-price') || 0, 10) || 0;
    $flow.find('.ipsvp-renew-plan-hidden').val(planId);
    $flow.find('.ipsvp-renew-choice').each(function(){
      var checked = $(this).find('input[type=radio]').is(':checked');
      $(this).toggleClass('is-selected', !!checked);
    });
    $flow.find('.ipsvp-renew-selected-price').text(price > 0 ? formatToman(price) : 'ابتدا پلن را انتخاب کنید');
    $flow.find('.ipsvp-renew-wallet-method').each(function(){
      var $box = $(this);
      var balance = parseInt($box.data('wallet-balance') || 0, 10) || 0;
      var insufficient = !!planId && price > balance;
      $box.toggleClass('is-insufficient', insufficient);
      $box.find('.ipsvp-renew-insufficient').toggle(insufficient);
      var hardDisabled = $box.find('.ipsvp-alert').not('.ipsvp-renew-insufficient').length > 0;
      $box.find('.ipsvp-renew-wallet-submit').prop('disabled', hardDisabled || !planId || insufficient);
    });
  }
  $(document).on('change','[data-renew-plan-picker] input[type=radio]',function(){
    syncRenewFlow($(this).closest('[data-renew-flow]'));
  });
  $(document).on('submit','.ipsvp-renew-payment-form',function(e){
    var $form = $(this);
    var $flow = $form.closest('[data-renew-flow]');
    syncRenewFlow($flow);
    if(!$form.find('.ipsvp-renew-plan-hidden').val()){
      e.preventDefault();
      alert('لطفا ابتدا پلن تمدید را انتخاب کنید.');
      return false;
    }
    if($form.hasClass('ipsvp-wallet-renew-form') && $form.closest('.ipsvp-renew-wallet-method').hasClass('is-insufficient')){
      e.preventDefault();
      alert('موجودی کیف پول برای این پلن کافی نیست. ابتدا کیف پول را شارژ کنید.');
      return false;
    }
  });
  $('[data-renew-flow]').each(function(){ syncRenewFlow($(this)); });
});

// Extra volume purchase flow
jQuery(function($){
  function toInt(v){
    v = String(v || '').replace(/[۰-۹]/g, function(d){ return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d); }).replace(/[٠-٩]/g, function(d){ return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); });
    return parseInt(v.replace(/\D+/g, ''), 10) || 0;
  }
  function formatToman(n){
    n = parseInt(n || 0, 10) || 0;
    try { return n.toLocaleString('fa-IR') + ' تومان'; } catch(e) { return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ',') + ' تومان'; }
  }
  function formatNumber(n){
    n = parseInt(n || 0, 10) || 0;
    try { return n.toLocaleString('fa-IR'); } catch(e) { return String(n); }
  }
  function syncExtraVolume($flow){
    if(!$flow || !$flow.length){ return; }
    var unit = parseInt($flow.data('unit-price') || 0, 10) || 0;
    var $input = $flow.find('[data-extra-volume-input]').first();
    var gb = Math.max(1, toInt($input.val()));
    $input.val(gb);
    var total = gb * unit;
    $flow.find('.ipsvp-extra-volume-gb-hidden').val(gb);
    $flow.find('.ipsvp-extra-volume-gb-label').text(formatNumber(gb));
    $flow.find('.ipsvp-extra-volume-total,.ipsvp-extra-volume-wallet-total').text(formatToman(total));
    $flow.find('.ipsvp-extra-volume-wallet-method').each(function(){
      var $box = $(this);
      var balance = parseInt($box.data('wallet-balance') || 0, 10) || 0;
      var insufficient = total > balance;
      var hardDisabled = $box.find('.ipsvp-alert').not('.ipsvp-extra-volume-insufficient').length > 0;
      $box.toggleClass('is-insufficient', insufficient);
      $box.find('.ipsvp-extra-volume-insufficient').toggle(insufficient);
      $box.find('.ipsvp-extra-volume-wallet-submit').prop('disabled', hardDisabled || insufficient);
    });
  }
  $(document).on('click','[data-extra-volume-plus]',function(){
    var $flow = $(this).closest('[data-extra-volume-flow]');
    var $input = $flow.find('[data-extra-volume-input]').first();
    $input.val(Math.max(1, toInt($input.val())) + 1);
    syncExtraVolume($flow);
  });
  $(document).on('click','[data-extra-volume-minus]',function(){
    var $flow = $(this).closest('[data-extra-volume-flow]');
    var $input = $flow.find('[data-extra-volume-input]').first();
    $input.val(Math.max(1, toInt($input.val()) - 1));
    syncExtraVolume($flow);
  });
  $(document).on('input change','[data-extra-volume-input]',function(){
    syncExtraVolume($(this).closest('[data-extra-volume-flow]'));
  });
  $(document).on('submit','.ipsvp-extra-volume-payment-form',function(e){
    var $form = $(this);
    var $flow = $form.closest('[data-extra-volume-flow]');
    syncExtraVolume($flow);
    if(toInt($form.find('.ipsvp-extra-volume-gb-hidden').val()) < 1){
      e.preventDefault();
      alert('مقدار حجم اضافه باید حداقل ۱ گیگ باشد.');
      return false;
    }
    if($form.hasClass('ipsvp-wallet-extra-volume-form') && $form.closest('.ipsvp-extra-volume-wallet-method').hasClass('is-insufficient')){
      e.preventDefault();
      alert('موجودی کیف پول برای این مقدار حجم کافی نیست.');
      return false;
    }
  });
  $('[data-extra-volume-flow]').each(function(){ syncExtraVolume($(this)); });
});



jQuery(function($){
  function bindCountryMarquee(){
    $('[data-ipsvp-country-marquee="1"]').each(function(){
      this.dataset.ipsvpCountryBound = '1';
    });
  }
  bindCountryMarquee();
  $(document).on('ipsvp:refresh', bindCountryMarquee);
});

// Shared receipt uploader: direct upload, server confirmation/recovery, native form fallback.
jQuery(function($){
  function cfg(){ return typeof IPSVP_RECEIPT_UPLOAD !== 'undefined' ? IPSVP_RECEIPT_UPLOAD : null; }
  function parseResponse(text){
    text = String(text || '').replace(/^\uFEFF/, '').trim();
    if(!text){ return null; }
    try { return JSON.parse(text); } catch(e) {}
    var start = text.indexOf('{'), end = text.lastIndexOf('}');
    if(start >= 0 && end > start){
      try { return JSON.parse(text.slice(start, end + 1)); } catch(e2) {}
    }
    return null;
  }
  function allowedExt(file){
    var c = cfg(), allowed = c && c.allowed ? c.allowed : ['jpg','jpeg','png','webp','pdf'];
    var name = file && file.name ? String(file.name) : '';
    var ext = name.indexOf('.') >= 0 ? name.split('.').pop().toLowerCase() : '';
    return allowed.indexOf(ext) !== -1;
  }
  function setMessage($uploader, msg, ok){
    $uploader.find('.ipsvp-receipt-message').text(msg || '').toggleClass('is-ok', !!ok);
  }
  function hasStoredFile($uploader){
    return !!($uploader.find('.ipsvp-receipt-attachment-id').val() || $uploader.find('.ipsvp-receipt-file-url').val());
  }
  function hasNativeFile($uploader){
    var input = $uploader.find('.ipsvp-receipt-native').get(0);
    return !!(input && input.files && input.files.length);
  }
  function showFileRow($uploader, name){
    $uploader.find('.ipsvp-receipt-file').prop('hidden', false).find('span').text(name || '');
  }
  function hideFileRow($uploader){
    $uploader.find('.ipsvp-receipt-file').prop('hidden', true).find('span').text('');
  }
  function syncRequiredSubmit($uploader){
    if($uploader.attr('data-required') !== '1'){ return; }
    var ready = hasStoredFile($uploader) || hasNativeFile($uploader);
    $uploader.closest('form').find('button[type=submit],input[type=submit]').each(function(){
      var $btn = $(this);
      if(!ready){
        if(!$btn.prop('disabled')){
          $btn.data('ipsvpReceiptRequiredDisabled', '1').prop('disabled', true);
        }
      } else if($btn.data('ipsvpReceiptRequiredDisabled') === '1'){
        $btn.prop('disabled', false).removeData('ipsvpReceiptRequiredDisabled');
      }
    });
  }
  function setProgress($uploader, pct, label){
    pct = Math.max(0, Math.min(100, parseInt(pct || 0, 10) || 0));
    var $bar = $uploader.find('.ipsvp-receipt-progress');
    $bar.prop('hidden', false).attr('aria-valuenow', pct).toggleClass('is-confirming', pct === 100 && !!label && label !== '100%');
    $bar.find('span').css('width', pct + '%');
    $bar.find('b').text(label || (pct + '%'));
  }
  function hideProgress($uploader){
    $uploader.find('.ipsvp-receipt-progress').prop('hidden', true).attr('aria-valuenow', 0).removeClass('is-confirming').find('span').css('width','0%');
    $uploader.find('.ipsvp-receipt-progress b').text('0%');
  }
  function setUploading($uploader, uploading){
    $uploader.toggleClass('is-uploading', !!uploading).attr('aria-busy', uploading ? 'true' : 'false');
    var $form = $uploader.closest('form');
    $form.find('button[type=submit],input[type=submit]').each(function(){
      var $btn = $(this);
      if(uploading){
        if(typeof $btn.data('ipsvpUploaderWasDisabled') === 'undefined'){
          $btn.data('ipsvpUploaderWasDisabled', $btn.prop('disabled') ? '1' : '0');
        }
        $btn.prop('disabled', true);
      } else {
        $btn.prop('disabled', $btn.data('ipsvpUploaderWasDisabled') === '1').removeData('ipsvpUploaderWasDisabled');
      }
    });
    if(!uploading){ syncRequiredSubmit($uploader); }
  }
  function stopOperation($uploader){
    var op = $uploader.data('ipsvpReceiptOperation');
    if(!op){ return false; }
    op.cancelled = true;
    if(op.retryTimer){ window.clearTimeout(op.retryTimer); }
    if(op.recoveryTimer){ window.clearTimeout(op.recoveryTimer); }
    if(op.responseTimer){ window.clearTimeout(op.responseTimer); }
    if(op.hardTimer){ window.clearTimeout(op.hardTimer); }
    try { if(op.xhr){ op.xhr.abort(); } } catch(ignore) {}
    try { if(op.statusXhr){ op.statusXhr.abort(); } } catch(ignore2) {}
    $uploader.removeData('ipsvpReceiptOperation');
    $uploader.find('.ipsvp-receipt-retry').prop('hidden', true);
    return true;
  }
  function clearUpload($uploader){
    if(stopOperation($uploader)){ setUploading($uploader, false); }
    var required = $uploader.attr('data-required') === '1';
    $uploader.find('.ipsvp-receipt-attachment-id,.ipsvp-receipt-file-url,.ipsvp-receipt-upload-key').val('');
    $uploader.find('.ipsvp-receipt-native').val('').prop('required', required);
    $uploader.find('.ipsvp-receipt-retry').prop('hidden', true);
    hideFileRow($uploader);
    hideProgress($uploader);
    setMessage($uploader, '', false);
    syncRequiredSubmit($uploader);
  }
  function createUploadKey(){
    if(window.crypto && window.crypto.getRandomValues){
      var bytes = new Uint8Array(20);
      window.crypto.getRandomValues(bytes);
      return Array.prototype.map.call(bytes, function(byte){ return ('0' + byte.toString(16)).slice(-2); }).join('');
    }
    return (Date.now().toString(16) + Math.random().toString(16).slice(2) + Math.random().toString(16).slice(2))
      .replace(/[^a-f0-9]/gi, '').slice(0, 40);
  }
  function isCurrent(op){
    return !op.cancelled && !op.finished && op.$uploader.data('ipsvpReceiptOperation') === op;
  }
  function finishOperation(op){
    op.finished = true;
    if(op.retryTimer){ window.clearTimeout(op.retryTimer); }
    if(op.recoveryTimer){ window.clearTimeout(op.recoveryTimer); }
    if(op.responseTimer){ window.clearTimeout(op.responseTimer); }
    if(op.hardTimer){ window.clearTimeout(op.hardTimer); }
    try { if(op.xhr){ op.xhr.abort(); } } catch(ignore) {}
    try { if(op.statusXhr){ op.statusXhr.abort(); } } catch(ignore2) {}
    op.xhr = null;
    op.statusXhr = null;
    op.$uploader.removeData('ipsvpReceiptOperation');
  }
  function uploadSucceeded(op, data, recovered){
    if(!isCurrent(op)){ return; }
    finishOperation(op);
    var $uploader = op.$uploader;
    $uploader.find('.ipsvp-receipt-attachment-id').val(data.attachment_id || '');
    $uploader.find('.ipsvp-receipt-file-url').val(data.url || '');
    $uploader.find('.ipsvp-receipt-native').val('').prop('required', false);
    showFileRow($uploader, data.name || op.file.name);
    setProgress($uploader, 100, '100%');
    setMessage($uploader, recovered ? 'رسید روی سرور پیدا و با موفقیت تایید شد.' : 'رسید با موفقیت آپلود شد.', true);
    setUploading($uploader, false);
  }
  function uploadFailed(op, message, allowFallback){
    if(!isCurrent(op)){ return; }
    finishOperation(op);
    var $uploader = op.$uploader;
    var required = $uploader.attr('data-required') === '1';
    setUploading($uploader, false);
    hideProgress($uploader);
    if(allowFallback && hasNativeFile($uploader)){
      $uploader.find('.ipsvp-receipt-attachment-id,.ipsvp-receipt-file-url').val('');
      $uploader.find('.ipsvp-receipt-native').prop('required', required);
      showFileRow($uploader, op.file.name);
      message = (message || op.c.upload_error || 'آپلود رسید ناموفق بود.') + ' ' + (op.c.fallback || 'فایل انتخاب‌شده حفظ شد و هنگام ثبت فرم دوباره ارسال می‌شود.');
    } else {
      $uploader.find('.ipsvp-receipt-attachment-id,.ipsvp-receipt-file-url').val('');
      $uploader.find('.ipsvp-receipt-native').val('').prop('required', required);
      hideFileRow($uploader);
    }
    $uploader.find('.ipsvp-receipt-retry').prop('hidden', !(allowFallback && hasNativeFile($uploader)));
    setMessage($uploader, message, false);
    syncRequiredSubmit($uploader);
  }
  function retryOrFail(op, message){
    if(!isCurrent(op)){ return; }
    if(op.attempt >= op.maxRetries){
      uploadFailed(op, message, true);
      return;
    }
    op.attempt++;
    setProgress(op.$uploader, 0, 'تلاش مجدد...');
    setMessage(op.$uploader, 'تایید سرور دریافت نشد؛ تلاش مجدد ' + op.attempt + ' از ' + op.maxRetries + ' در حال انجام است...', true);
    op.retryTimer = window.setTimeout(function(){ sendAttempt(op); }, 900 * op.attempt);
  }
  function recoverUpload(op, message){
    if(!isCurrent(op) || op.recovering){ return; }
    op.recovering = true;
    setProgress(op.$uploader, 100, 'در حال بررسی ثبت رسید...');
    op.statusPolls++;
    setMessage(op.$uploader, 'پاسخ نهایی نرسید؛ در حال بررسی مستقیم فایل روی سرور...', true);
    op.recoveryTimer = window.setTimeout(function(){
      if(!isCurrent(op)){ return; }
      var data = new FormData();
      data.append('action', 'ipsvp_receipt_upload_status');
      data.append('nonce', op.c.nonce);
      data.append('upload_key', op.uploadKey);
      var xhr = new XMLHttpRequest();
      op.statusXhr = xhr;
      var settled = false;
      function statusFinished(){
        if(settled){ return false; }
        settled = true;
        op.recovering = false;
        op.statusXhr = null;
        return isCurrent(op);
      }
      xhr.onload = function(){
        if(!statusFinished()){ return; }
        var res = parseResponse(xhr.responseText);
        if(xhr.status >= 200 && xhr.status < 300 && res && res.success && res.data && res.data.found){
          uploadSucceeded(op, res.data, true);
          return;
        }
        if(xhr.status === 401 || xhr.status === 403){
          var authMessage = res && res.data && res.data.message ? res.data.message : 'نشست ورود یا اعتبار صفحه منقضی شده است.';
          uploadFailed(op, authMessage, true);
          return;
        }
        continueRecovery();
      };
      function continueRecovery(){
        if(op.xhr || op.statusPolls < 3){ recoverUpload(op, message); }
        else { retryOrFail(op, message); }
      }
      xhr.onerror = xhr.ontimeout = function(){ if(statusFinished()){ continueRecovery(); } };
      xhr.onabort = function(){ statusFinished(); };
      xhr.open('POST', op.c.ajax_url, true);
      xhr.timeout = parseInt(op.c.status_timeout || 12000, 10) || 12000;
      xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
      try { xhr.send(data); } catch(error) { if(statusFinished()){ continueRecovery(); } }
    }, Number(op.c.status_interval) || 2000);
  }
  function sendAttempt(op){
    if(!isCurrent(op)){ return; }
    op.recovering = false;
    op.statusPolls = 0;
    var data = new FormData();
    data.append('action', 'ipsvp_receipt_upload');
    data.append('nonce', op.c.nonce);
    data.append('upload_key', op.uploadKey);
    data.append('receipt', op.file);
    var xhr = new XMLHttpRequest();
    op.xhr = xhr;
    var settled = false;
    function clearResponseTimer(){
      if(op.responseTimer){ window.clearTimeout(op.responseTimer); op.responseTimer = null; }
    }
    function requestFinished(){
      if(settled){ return false; }
      settled = true;
      clearResponseTimer();
      op.xhr = null;
      return isCurrent(op);
    }
    function startConfirmationWait(){
      if(!isCurrent(op) || settled || op.responseTimer){ return; }
      setProgress(op.$uploader, 100, 'در حال تایید سرور...');
      setMessage(op.$uploader, op.c.processing || 'فایل کامل ارسال شد؛ در حال ثبت روی سرور...', true);
      op.responseTimer = window.setTimeout(function(){
        if(!isCurrent(op) || settled){ return; }
        // Check completion without aborting a request the server is still finishing.
        recoverUpload(op, op.c.timeout_error || 'زمان پاسخ سرور برای آپلود به پایان رسید.');
      }, parseInt(op.c.response_timeout || 45000, 10) || 45000);
    }
    if(xhr.upload){
      xhr.upload.addEventListener('progress', function(e){
        if(!e.lengthComputable || settled || !isCurrent(op)){ return; }
        var sent = Math.min(100, Math.round((e.loaded / e.total) * 100));
        setProgress(op.$uploader, sent, sent >= 100 ? 'در حال تایید سرور...' : (sent + '%'));
      });
      xhr.upload.addEventListener('load', startConfirmationWait);
    }
    xhr.onload = function(){
      if(!requestFinished()){ return; }
      var res = parseResponse(xhr.responseText);
      if(xhr.status >= 200 && xhr.status < 300 && res && res.success && res.data && res.data.url){
        uploadSucceeded(op, res.data, false);
        return;
      }
      var message = res && res.data && res.data.message ? res.data.message : '';
      if(!message && xhr.status === 413){ message = 'حجم فایل از محدودیت وب‌سرور بیشتر است.'; }
      if(!message && (xhr.status === 401 || xhr.status === 403)){ message = 'نشست ورود یا اعتبار صفحه منقضی شده است؛ صفحه را تازه کنید.'; }
      if(!message){ message = (op.c.upload_error || 'آپلود رسید ناموفق بود.') + (xhr.status ? ' (HTTP ' + xhr.status + ')' : ''); }
      var mayHaveCompleted = (xhr.status >= 200 && xhr.status < 300 && !res) || xhr.status === 408 || xhr.status === 425 || xhr.status === 429 || (xhr.status === 409 && res && res.data && res.data.code === 'receipt_busy') || xhr.status >= 500;
      if(mayHaveCompleted){ recoverUpload(op, message); }
      else { uploadFailed(op, message, false); }
    };
    xhr.onerror = function(){ if(requestFinished()){ recoverUpload(op, op.c.network_error || 'ارتباط با سرور هنگام آپلود قطع شد.'); } };
    xhr.ontimeout = function(){ if(requestFinished()){ recoverUpload(op, op.c.timeout_error || 'زمان پاسخ سرور برای آپلود به پایان رسید.'); } };
    xhr.onabort = function(){ requestFinished(); };
    xhr.open('POST', op.c.ajax_url, true);
    xhr.timeout = op.requestTimeout;
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
    try { xhr.send(data); } catch(error) { if(requestFinished()){ recoverUpload(op, op.c.network_error); } }
  }
  function uploadFile($uploader, file, reuseKey){
    var c = cfg();
    if(stopOperation($uploader)){ setUploading($uploader, false); }
    if(!file){ return; }
    var existingKey = reuseKey ? $uploader.find('.ipsvp-receipt-upload-key').val() : '';
    // A replacement must never silently submit the previous receipt.
    $uploader.find('.ipsvp-receipt-native').prop('required', $uploader.attr('data-required') === '1');
    $uploader.find('.ipsvp-receipt-attachment-id,.ipsvp-receipt-file-url,.ipsvp-receipt-upload-key').val('');
    $uploader.find('.ipsvp-receipt-retry').prop('hidden', true);
    hideProgress($uploader);
    if(!allowedExt(file)){
      $uploader.find('.ipsvp-receipt-native').val('');
      if(!hasStoredFile($uploader)){ hideFileRow($uploader); }
      setMessage($uploader, c && c.invalid_type ? c.invalid_type : 'فرمت فایل مجاز نیست. فقط تصویر یا PDF قابل قبول است.', false);
      syncRequiredSubmit($uploader);
      return;
    }
    if(c && c.max_size && file.size > parseInt(c.max_size, 10)){
      $uploader.find('.ipsvp-receipt-native').val('');
      if(!hasStoredFile($uploader)){ hideFileRow($uploader); }
      setMessage($uploader, 'حجم فایل بیشتر از حد مجاز است.', false);
      syncRequiredSubmit($uploader);
      return;
    }
    if(!c || !c.ajax_url || !c.nonce || !window.FormData || !window.XMLHttpRequest){
      showFileRow($uploader, file.name);
      setMessage($uploader, 'فایل آماده است و همراه فرم ارسال می‌شود.', true);
      syncRequiredSubmit($uploader);
      return;
    }
    var op = {
      $uploader: $uploader,
      c: c,
      file: file,
      uploadKey: existingKey || createUploadKey(),
      requestTimeout: Number(c.timeout) || 180000,
      statusPolls: 0,
      maxRetries: Math.max(0, Math.min(2, parseInt(c.max_retries === undefined ? 1 : c.max_retries, 10) || 0)),
      attempt: 0,
      finished: false,
      cancelled: false,
      recovering: false
    };
    $uploader.data('ipsvpReceiptOperation', op);
    $uploader.find('.ipsvp-receipt-upload-key').val(op.uploadKey);
    showFileRow($uploader, file.name);
    setUploading($uploader, true);
    setMessage($uploader, 'در حال آپلود رسید...', true);
    setProgress($uploader, 0, '0%');
    op.hardTimer = window.setTimeout(function(){
      if(isCurrent(op)){ uploadFailed(op, c.timeout_error || 'آپلود بیش از حد طول کشید.', true); }
    }, Math.max(Number(c.hard_timeout) || 0, (op.maxRetries + 1) * (op.requestTimeout + 3 * ((Number(c.status_timeout) || 12000) + (Number(c.status_interval) || 2000))) + 10000));
    if(existingKey){ recoverUpload(op, c.network_error); } else { sendAttempt(op); }
  }
  $(document).on('click', '.ipsvp-receipt-retry', function(){
    var $uploader = $(this).closest('[data-ipsvp-receipt-uploader]');
    var input = $uploader.find('.ipsvp-receipt-native').get(0);
    if(input && input.files && input.files[0]){ uploadFile($uploader, input.files[0], true); }
  });
  $(document).on('click', '.ipsvp-receipt-select', function(e){
    e.preventDefault();
    $(this).closest('[data-ipsvp-receipt-uploader]').find('.ipsvp-receipt-native').trigger('click');
  });
  $(document).on('change', '.ipsvp-receipt-native', function(){
    var file = this.files && this.files[0] ? this.files[0] : null;
    uploadFile($(this).closest('[data-ipsvp-receipt-uploader]'), file);
  });
  $(document).on('dragover dragenter', '.ipsvp-receipt-drop', function(e){
    e.preventDefault();
    $(this).addClass('is-dragover');
  });
  $(document).on('dragleave dragend drop', '.ipsvp-receipt-drop', function(e){
    e.preventDefault();
    $(this).removeClass('is-dragover');
  });
  $(document).on('drop', '.ipsvp-receipt-drop', function(e){
    var files = e.originalEvent && e.originalEvent.dataTransfer ? e.originalEvent.dataTransfer.files : null;
    var file = files && files.length ? files[0] : null;
    var $uploader = $(this).closest('[data-ipsvp-receipt-uploader]');
    var input = $uploader.find('.ipsvp-receipt-native').get(0);
    if(input && files){
      try { input.files = files; } catch(ignore) {}
    }
    uploadFile($uploader, file);
  });
  $(document).on('click', '.ipsvp-receipt-remove', function(e){
    e.preventDefault();
    clearUpload($(this).closest('[data-ipsvp-receipt-uploader]'));
  });
  $(document).on('submit', 'form', function(e){
    var $form = $(this);
    if($form.find('[data-ipsvp-receipt-uploader].is-uploading').length){
      e.preventDefault();
      alert('لطفا تا پایان آپلود رسید صبر کنید.');
      return false;
    }
  });
  $('[data-ipsvp-receipt-uploader]').each(function(){ syncRequiredSubmit($(this)); });
});

/* Shared accessibility behaviour for hash modals and icon-only controls. */
jQuery(function($){
  var lastFocus = null;
  var focusable = 'a[href],button:not([disabled]),input:not([disabled]):not([type="hidden"]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';
  function modalFromHash(){
    var id = String(window.location.hash || '').replace(/^#/, '');
    if (!id) { return $(); }
    var $target = $('#' + id.replace(/([^a-zA-Z0-9_-])/g, '\\$1'));
    return $target.filter('.ipsvp-modal,.ipspla-auth-modal,.ipsvp-service-warning-popup');
  }
  function prepareModal($modal){
    if (!$modal.length) { return; }
    $modal.attr({'role':'dialog','aria-modal':'true','aria-hidden':'false'});
    var $heading = $modal.find('h1,h2,h3').first();
    if ($heading.length) {
      if (!$heading.attr('id')) { $heading.attr('id', 'ipsvp-modal-title-' + Math.random().toString(36).slice(2, 9)); }
      $modal.attr('aria-labelledby', $heading.attr('id'));
    } else if (!$modal.attr('aria-label')) {
      $modal.attr('aria-label', 'پنجره گفتگو');
    }
    setTimeout(function(){ $modal.find(focusable).first().trigger('focus'); }, 60);
  }
  function closeModal($modal){
    if (!$modal || !$modal.length) { return; }
    $modal.attr('aria-hidden','true');
    if (window.location.hash) { history.replaceState(null, document.title, window.location.pathname + window.location.search); }
    if (lastFocus && document.contains(lastFocus)) { $(lastFocus).trigger('focus'); }
  }
  $(document).on('click','a[href^="#ipsvp-"],a[href^="#ipspla-"]',function(){ lastFocus = this; });
  $(window).on('hashchange',function(){ prepareModal(modalFromHash()); });
  $(document).on('keydown',function(e){
    var $modal = modalFromHash();
    if (!$modal.length) { return; }
    if (e.key === 'Escape') { e.preventDefault(); closeModal($modal); return; }
    if (e.key !== 'Tab') { return; }
    var $items = $modal.find(focusable).filter(':visible');
    if (!$items.length) { e.preventDefault(); return; }
    var first = $items[0], last = $items[$items.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  });
  $('.ipsvp [data-copy]').each(function(){ if (!this.getAttribute('aria-label')) { this.setAttribute('aria-label','کپی در کلیپ‌بورد'); } });
  $('.ipsvp .ipsvp-receipt-remove').attr('aria-label','حذف فایل انتخاب‌شده');
  prepareModal(modalFromHash());
});

(() => {
    'use strict';
    document.querySelectorAll('.ipsvp-admin-user-tabs').forEach(root => {
        const nav = root.querySelector('.ipsvp-tab-nav');
        const tabs = [...nav.querySelectorAll('label')];
        nav.setAttribute('role', 'tablist');
        const activate = (tab, focus = false, remember = true) => {
            tabs.forEach(item => {
                const radio = document.getElementById(item.htmlFor);
                const panel = [...root.querySelectorAll('[data-user-panel]')].find(p => p.dataset.userPanel === radio.value);
                const selected = item === tab;
                radio.checked = selected;
                radio.tabIndex = -1;
                radio.setAttribute('aria-hidden', 'true');
                item.setAttribute('role', 'tab');
                item.setAttribute('aria-selected', String(selected));
                item.tabIndex = selected ? 0 : -1;
                if (panel) {
                    panel.id = `ipsvp_user_panel_${radio.value}`;
                    panel.setAttribute('role', 'tabpanel');
                    panel.setAttribute('aria-labelledby', item.id);
                    item.setAttribute('aria-controls', panel.id);
                }
            });
            if (focus) tab.focus();
            if (remember) {
                const url = new URL(location.href);
                url.searchParams.set('ipsvp_tab', document.getElementById(tab.htmlFor).value);
                history.replaceState(null, '', url);
            }
        };
        tabs.forEach((tab, index) => {
            tab.addEventListener('click', event => { event.preventDefault(); activate(tab); });
            tab.addEventListener('keydown', event => {
                const rtl = getComputedStyle(nav).direction === 'rtl';
                let next = index;
                if (event.key === 'ArrowRight') next += rtl ? -1 : 1;
                else if (event.key === 'ArrowLeft') next += rtl ? 1 : -1;
                else if (event.key === 'Home') next = 0;
                else if (event.key === 'End') next = tabs.length - 1;
                else if (event.key !== 'Enter' && event.key !== ' ') return;
                event.preventDefault();
                activate(tabs[(next + tabs.length) % tabs.length], true);
            });
        });
        const selected = tabs.find(tab => document.getElementById(tab.htmlFor).checked) || tabs[0];
        if (selected) activate(selected, false, false);
        root.querySelectorAll('.ipsvp-tab-panel table').forEach(table => {
            if (table.parentElement.classList.contains('ipsvp-user-table-scroll')) return;
            const wrap = document.createElement('div');
            wrap.className = 'ipsvp-user-table-scroll';
            wrap.tabIndex = 0;
            wrap.setAttribute('role', 'region');
            wrap.setAttribute('aria-label', 'جدول؛ برای مشاهده ستون‌ها پیمایش کنید');
            table.before(wrap);
            wrap.append(table);
        });
    });
})();

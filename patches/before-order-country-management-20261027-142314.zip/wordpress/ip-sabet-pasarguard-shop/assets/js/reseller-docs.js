/* Progressive enhancement only: documentation and anchors work without JavaScript. */
(function () {
  'use strict';
  function init() {
    if (document.querySelector('[data-ipsr-docs]')) { document.body.classList.add('ipsr-has-docs'); }
    document.querySelectorAll('[data-ipsr-docs]').forEach(function (root) {
      if (root.dataset.ipsrReady) { return; }
      root.dataset.ipsrReady = 'true';
      var search = root.querySelector('[data-ipsr-search]');
      var endpoints = Array.from(root.querySelectorAll('[data-ipsr-endpoint]'));
      var status = root.querySelector('[data-ipsr-search-status]');
      var empty = root.querySelector('[data-ipsr-empty]');
      var links = Array.from(root.querySelectorAll('.ipsr-docs-sidebar a'));
      var normalize = function (text) { return text.toLowerCase().replace(/ي/g, 'ی').replace(/ك/g, 'ک').replace(/\u200c/g, '').trim(); };
      function filter() {
        var words = normalize(search.value).split(/\s+/).filter(Boolean);
        var count = 0;
        endpoints.forEach(function (endpoint) {
          var haystack = normalize(endpoint.dataset.search + ' ' + endpoint.textContent);
          var match = words.every(function (word) { return haystack.indexOf(word) !== -1; });
          endpoint.hidden = !match;
          if (match) { count++; }
        });
        empty.hidden = count !== 0;
        status.textContent = count + ' مسیر از ' + endpoints.length + ' مسیر';
      }
      search.addEventListener('input', filter);
      var sidebar = root.querySelector('.ipsr-docs-sidebar');
      var activeId = '';
      function mark(id) {
        if (activeId === id) { return; }
        activeId = id;
        links.forEach(function (link) {
          if (link.hash === '#' + id) { link.setAttribute('aria-current', 'true'); }
          else { link.removeAttribute('aria-current'); }
        });
        var current = links.find(function (link) { return link.hash === '#' + id; });
        if (current && root.clientWidth > 850) {
          var item = current.getBoundingClientRect(), box = sidebar.getBoundingClientRect();
          if (item.top < box.top + 12 || item.bottom > box.bottom - 12) {
            sidebar.scrollTop += item.top - box.top - box.height / 2 + item.height / 2;
          }
        }
      }
      function revealHash() {
        var target = document.getElementById(window.location.hash.slice(1));
        if (!target || !root.contains(target)) { return; }
        if (target.hasAttribute('data-ipsr-endpoint')) { search.value = ''; filter(); target.open = true; }
        var ancestor = target.parentElement;
        while (ancestor) {
          if (ancestor.tagName === 'DETAILS') { ancestor.open = true; }
          ancestor = ancestor.parentElement;
        }
        if (root.clientWidth <= 850) { sidebar.open = false; }
        updateScroll();
        mark(target.id);
        // A details element may have been closed when native anchor scrolling ran.
        requestAnimationFrame(function () { target.scrollIntoView({ block: 'start' }); });
      }
      root.addEventListener('click', function (event) {
        var link = event.target.closest('a[href^="#"]');
        if (link && root.contains(link)) {
          var target = document.getElementById(link.hash.slice(1));
          if (target && target.hasAttribute('data-ipsr-endpoint')) {
            search.value = ''; filter(); target.open = true;
          }
          if (link.hash === window.location.hash) { revealHash(); }
        }
      });
      window.addEventListener('hashchange', revealHash);
      // Track document order, not the order of IntersectionObserver callbacks.
      var sections = links.map(function (link) { return document.getElementById(link.hash.slice(1)); }).filter(Boolean).sort(function (a, b) { return a === b ? 0 : (a.compareDocumentPosition(b) & 4 ? -1 : 1); });
      var scheduled = false;
      function updateScroll() {
        scheduled = false;
        var top = 16;
        document.querySelectorAll('#wpadminbar, .navbar').forEach(function (header) {
          var style = getComputedStyle(header), rect = header.getBoundingClientRect();
          if ((style.position === 'fixed' || style.position === 'sticky') && rect.top <= 80 && rect.bottom > 0 && rect.height < innerHeight / 2) {
            top = Math.max(top, rect.bottom + 16);
          }
        });
        root.style.setProperty('--ipsr-docs-top', top + 'px');
        var mobileHeight = root.clientWidth <= 850 ? sidebar.getBoundingClientRect().height : 0;
        root.style.setProperty('--ipsr-docs-anchor-top', (top + mobileHeight + 12) + 'px');
        var visible = sections.filter(function (section) { return !section.hidden && section.getClientRects().length; });
        var current = visible[0];
        visible.forEach(function (section) { if (section.getBoundingClientRect().top <= top + mobileHeight + 32) { current = section; } });
        if (current) { mark(current.id); }
      }
      function scheduleScroll() {
        if (!scheduled) { scheduled = true; requestAnimationFrame(updateScroll); }
      }
      window.addEventListener('scroll', scheduleScroll, { passive: true });
      window.addEventListener('resize', scheduleScroll);
      root.addEventListener('toggle', scheduleScroll, true);
      search.addEventListener('input', scheduleScroll);
      if ('ResizeObserver' in window) { new ResizeObserver(scheduleScroll).observe(root); }
      scheduleScroll();
      if (window.location.hash) { revealHash(); }
      var feedback = root.querySelector('.ipsr-copy-feedback');
      root.querySelectorAll('[data-ipsr-copy]').forEach(function (button) {
        button.hidden = false;
        button.addEventListener('click', async function () {
          var code = button.closest('.ipsr-code').querySelector('pre code');
          try {
            if (!navigator.clipboard || !window.isSecureContext) { throw new Error('clipboard unavailable'); }
            await navigator.clipboard.writeText(code.textContent);
            button.textContent = 'کپی شد ✓';
            feedback.textContent = 'کد کپی شد.';
          } catch (_) {
            var range = document.createRange();
            range.selectNodeContents(code);
            var selection = window.getSelection();
            selection.removeAllRanges(); selection.addRange(range);
            button.textContent = 'کد انتخاب شد';
            feedback.textContent = 'کپی خودکار در دسترس نیست؛ کد انتخاب شد. با Ctrl+C یا ⌘C کپی کنید.';
          }
          window.setTimeout(function () { button.textContent = 'کپی کد'; }, 2200);
        });
      });
      var desktop = window.matchMedia('(min-width: 851px)');
      if (root.clientWidth <= 850 && !window.location.hash) { root.querySelector('.ipsr-docs-sidebar').open = false; }
      desktop.addEventListener('change', function (event) {
        if (event.matches) { root.querySelector('.ipsr-docs-sidebar').open = true; }
      });
    });
  }
  if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', init); }
  else { init(); }
})();

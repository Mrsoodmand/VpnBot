<?php
/**
 * Signed customer-panel session cookie.
 *
 * @package IPSabet_PasarGuard_Shop
 */

defined('ABSPATH') || exit;

final class IPSVP_Session
{
    const LIFETIME = 2592000;

    public static function cookie_name()
    {
        return 'ipsvp_panel_phone_' . COOKIEHASH;
    }

    public static function set($phone, $db)
    {
        $phone = $db->normalize_phone($phone);
        if (!$phone) {
            return false;
        }

        $expires = time() + self::LIFETIME;
        $value = self::encode($phone, $expires);
        $_COOKIE[self::cookie_name()] = $value;
        self::send_cookie($value, $expires);

        return true;
    }

    public static function clear()
    {
        unset($_COOKIE[self::cookie_name()]);
        self::send_cookie('', time() - HOUR_IN_SECONDS);
    }

    public static function get_phone($db)
    {
        $name = self::cookie_name();
        if (empty($_COOKIE[$name])) {
            return '';
        }

        $parts = explode('|', (string) wp_unslash($_COOKIE[$name]));
        if (count($parts) !== 3) {
            return '';
        }

        list($phone, $expires, $signature) = $parts;
        $phone = $db->normalize_phone($phone);
        $expires = (int) $expires;
        if (!$phone || $expires < time() || !preg_match('/^[a-f0-9]{64}$/', $signature)) {
            return '';
        }

        $expected = self::signature($phone, $expires);
        return hash_equals($expected, $signature) ? $phone : '';
    }

    private static function encode($phone, $expires)
    {
        return $phone . '|' . $expires . '|' . self::signature($phone, $expires);
    }

    private static function signature($phone, $expires)
    {
        return hash_hmac('sha256', $phone . '|' . (int) $expires, wp_salt('auth'));
    }

    private static function send_cookie($value, $expires)
    {
        if (headers_sent()) {
            return;
        }

        $paths = array_unique(array_filter(array(
            defined('COOKIEPATH') && COOKIEPATH ? COOKIEPATH : '/',
            defined('SITECOOKIEPATH') && SITECOOKIEPATH ? SITECOOKIEPATH : '/',
        )));
        $domain = defined('COOKIE_DOMAIN') && COOKIE_DOMAIN ? COOKIE_DOMAIN : '';

        foreach ($paths as $path) {
            if (PHP_VERSION_ID >= 70300) {
                setcookie(self::cookie_name(), $value, array(
                    'expires' => $expires,
                    'path' => $path,
                    'domain' => $domain,
                    'secure' => is_ssl(),
                    'httponly' => true,
                    'samesite' => 'Lax',
                ));
            } else {
                setcookie(self::cookie_name(), $value, $expires, $path, $domain, is_ssl(), true);
            }
        }
    }
}

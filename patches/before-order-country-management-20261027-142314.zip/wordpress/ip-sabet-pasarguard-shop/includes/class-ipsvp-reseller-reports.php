<?php
/** Read-only, owner-scoped queries for the reseller workspace. */
defined('ABSPATH') || exit;

final class IPSVP_Reseller_Reports
{
    public static function filters(array $input)
    {
        $text = static function ($key) use ($input) {
            return isset($input[$key]) && is_string($input[$key]) ? sanitize_text_field(wp_unslash($input[$key])) : '';
        };
        $q = $text('rs_search');
        if (strlen($q) > 200) { $q = function_exists('mb_strcut') ? mb_strcut($q, 0, 200, 'UTF-8') : ''; }
        $status = $text('rs_status');
        if (!in_array($status, self::statuses(), true)) { $status = ''; }
        $source = $text('rs_source');
        if (!in_array($source, array('api', 'panel', 'site'), true)) { $source = ''; }
        $page = IPSVP_Reseller_Service::integer($input['rs_page'] ?? 1, 1, 1000000);
        return array('search' => $q, 'status' => $status, 'source' => $source, 'page' => $page === false ? 1 : $page);
    }

    public static function statuses()
    {
        return array('active', 'on_hold', 'created', 'disabled', 'volume_finished', 'time_finished', 'waiting_review', 'pending_receipt', 'reseller_processing', 'failed', 'cancelled');
    }

    public static function orders($db, $user_id, array $filters)
    {
        global $wpdb;
        $t = $db->tables();
        $ops = IPSVP_Reseller_Store::table('operations');
        $where = 'o.user_id=%d';
        $params = array((int) $user_id);
        if ($filters['search'] !== '') {
            $like = '%' . $wpdb->esc_like($filters['search']) . '%';
            $where .= " AND (o.order_code LIKE %s OR o.pg_username LIKE %s OR p.title LIKE %s OR c.name LIKE %s OR o.id=%d OR EXISTS (SELECT 1 FROM $ops sx WHERE sx.user_id=o.user_id AND sx.order_id=o.id AND sx.customer_reference LIKE %s))";
            array_push($params, $like, $like, $like, $like, ctype_digit($filters['search']) ? (int) $filters['search'] : 0, $like);
        }
        if ($filters['status'] !== '') { $where .= ' AND o.status=%s'; $params[] = $filters['status']; }
        if ($filters['source'] !== '') {
            if ($filters['source'] === 'site') {
                $where .= " AND NOT EXISTS (SELECT 1 FROM $ops sx WHERE sx.user_id=o.user_id AND sx.order_id=o.id AND sx.action='purchase')";
            } else {
                $where .= " AND EXISTS (SELECT 1 FROM $ops sx WHERE sx.user_id=o.user_id AND sx.order_id=o.id AND sx.action='purchase' AND sx.channel=%s)";
                $params[] = $filters['source'];
            }
        }
        $join = "FROM {$t['orders']} o LEFT JOIN {$t['plans']} p ON p.id=o.plan_id LEFT JOIN {$t['countries']} c ON c.id=o.country_id WHERE $where";
        $total = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) $join", ...$params));
        $pages = max(1, (int) ceil($total / 20));
        $page = min($filters['page'], $pages);
        $rows = $wpdb->get_results($wpdb->prepare("SELECT o.*, p.title plan_title, p.gb, p.days,
            CASE WHEN o.country_id=0 THEN 'همه کشورها' ELSE c.name END country_name,
            CASE WHEN o.country_id=0 THEN '🌍' ELSE c.flag END flag,
            (SELECT sx.channel FROM $ops sx WHERE sx.order_id=o.id AND sx.user_id=o.user_id AND sx.action='purchase' ORDER BY sx.id ASC LIMIT 1) reseller_channel,
            (SELECT sx.customer_reference FROM $ops sx WHERE sx.order_id=o.id AND sx.user_id=o.user_id AND sx.customer_reference<>'' ORDER BY sx.id DESC LIMIT 1) reseller_reference
            $join ORDER BY o.id DESC LIMIT 20 OFFSET %d", ...array_merge($params, array(($page - 1) * 20))));
        return array('items' => $rows ?: array(), 'total' => $total, 'pages' => $pages, 'page' => $page, 'filters' => $filters);
    }

    public static function summary($db, $user_id, $period = 30)
    {
        global $wpdb;
        $period = in_array((int) $period, array(7, 30, 90), true) ? (int) $period : 30;
        $today = new DateTimeImmutable(substr($db->now(), 0, 10));
        $start = $today->modify('-' . ($period - 1) . ' days')->format('Y-m-d');
        $end = $today->modify('+1 day')->format('Y-m-d');
        $table = IPSVP_Reseller_Store::table('operations');
        $summary = $wpdb->get_row($wpdb->prepare("SELECT COUNT(*) operations, COALESCE(SUM(action='purchase'),0) sales,
            COALESCE(SUM(action='renew'),0) renewals, COALESCE(SUM(amount),0) spent,
            COALESCE(SUM(base_amount-amount),0) savings, COALESCE(SUM(channel='api'),0) api_count,
            COALESCE(SUM(channel='panel'),0) panel_count FROM $table
            WHERE user_id=%d AND state='succeeded' AND created_at>=%s AND created_at<%s", $user_id, $start, $end));
        $daily = $wpdb->get_results($wpdb->prepare("SELECT DATE(created_at) day, COALESCE(SUM(action='purchase'),0) sales, COALESCE(SUM(amount),0) spent
            FROM $table WHERE user_id=%d AND state='succeeded' AND created_at>=%s AND created_at<%s GROUP BY DATE(created_at) ORDER BY day", $user_id, $start, $end));
        $indexed = array();
        foreach ($daily ?: array() as $row) { $indexed[$row->day] = $row; }
        $days = array();
        for ($i = $period - 1; $i >= 0; $i--) {
            $day = $today->modify('-' . $i . ' days')->format('Y-m-d');
            $days[] = array('day' => $day, 'sales' => (int) ($indexed[$day]->sales ?? 0), 'spent' => (int) ($indexed[$day]->spent ?? 0));
        }
        $orders = $db->tables()['orders'];
        $active = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $orders WHERE user_id=%d AND status IN ('active','on_hold','created')", $user_id));
        $unresolved = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE user_id=%d AND state IN ('reserved','processing','manual_review','refund_review')", $user_id));
        return array('period' => $period, 'totals' => (array) $summary, 'days' => $days, 'active' => $active, 'unresolved' => $unresolved);
    }

    public static function operations($user_id, $page = 1, $size = 20)
    {
        global $wpdb;
        $table = IPSVP_Reseller_Store::table('operations');
        $size = max(1, min(20, (int) $size));
        $total = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE user_id=%d", $user_id));
        $pages = max(1, (int) ceil($total / $size));
        $page = max(1, min((int) $page, $pages));
        $items = $wpdb->get_results($wpdb->prepare("SELECT id,action,channel,state,order_id,customer_reference,base_amount,discount_percent,amount,created_at FROM $table WHERE user_id=%d ORDER BY id DESC LIMIT %d OFFSET %d", $user_id, $size, ($page - 1) * $size));
        return array('items' => $items ?: array(), 'total' => $total, 'page' => $page, 'pages' => $pages);
    }
}

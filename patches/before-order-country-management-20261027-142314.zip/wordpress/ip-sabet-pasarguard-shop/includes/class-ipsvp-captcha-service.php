<?php
/**
 * Captcha generation and validation service.
 *
 * @package IPSabet_PasarGuard_Shop
 */

defined('ABSPATH') || exit;

final class IPSVP_Captcha_Service
{
    const TRANSIENT_PREFIX = 'ipsvp_captcha_';
    const PASS_TRANSIENT_PREFIX = 'ipsvp_captcha_pass_';
    const REFRESH_ACTION = 'ipsvp_captcha_refresh';
    const IMAGE_ACTION = 'ipsvp_captcha_image';

    private static $initialized = false;
    private static $assets_localized = false;

    public static function init()
    {
        if (self::$initialized) {
            return;
        }
        self::$initialized = true;
        add_action('admin_post_' . self::IMAGE_ACTION, array(__CLASS__, 'render_image_request'));
        add_action('admin_post_nopriv_' . self::IMAGE_ACTION, array(__CLASS__, 'render_image_request'));
        add_action('wp_ajax_' . self::REFRESH_ACTION, array(__CLASS__, 'ajax_refresh'));
        add_action('wp_ajax_nopriv_' . self::REFRESH_ACTION, array(__CLASS__, 'ajax_refresh'));
    }

    public static function register_assets()
    {
        $base = IPSVP_PLUGIN_URL . 'assets/';
        wp_register_style('ipsvp-captcha', $base . 'css/captcha.css', array(), IPSabet_PasarGuard_Shop::VERSION);
        wp_register_script('ipsvp-captcha', $base . 'js/captcha.js', array(), IPSabet_PasarGuard_Shop::VERSION, true);
    }

    public static function enqueue_assets()
    {
        if (!wp_style_is('ipsvp-captcha', 'registered') || !wp_script_is('ipsvp-captcha', 'registered')) {
            self::register_assets();
        }
        wp_enqueue_style('ipsvp-captcha');
        wp_enqueue_script('ipsvp-captcha');
        if (!self::$assets_localized) {
            wp_localize_script('ipsvp-captcha', 'IPSVP_CAPTCHA', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('ipsvp_captcha_refresh'),
                'empty_error' => 'لطفاً کد امنیتی را وارد کنید.',
                'refresh_error' => 'دریافت کد امنیتی جدید ممکن نشد. دوباره تلاش کنید.',
            ));
            self::$assets_localized = true;
        }
    }

    public static function settings()
    {
        $settings = IPSVP_Settings::get();
        return array(
            'enabled' => !empty($settings['captcha_enabled']) && (string) $settings['captcha_enabled'] === '1',
            'length' => isset($settings['captcha_length']) && (int) $settings['captcha_length'] === 5 ? 5 : 4,
            'ttl' => max(1, min(60, isset($settings['captcha_ttl_minutes']) ? (int) $settings['captcha_ttl_minutes'] : 10)) * MINUTE_IN_SECONDS,
            'max_attempts' => max(1, min(10, isset($settings['captcha_max_attempts']) ? (int) $settings['captcha_max_attempts'] : 3)),
            'color_mode' => isset($settings['captcha_color_mode']) && in_array($settings['captcha_color_mode'], array('auto', 'light', 'dark'), true) ? $settings['captcha_color_mode'] : 'auto',
            'show_panel' => !empty($settings['captcha_show_panel']) && (string) $settings['captcha_show_panel'] === '1',
            'show_config' => !empty($settings['captcha_show_config']) && (string) $settings['captcha_show_config'] === '1',
            'show_proxy' => !empty($settings['captcha_show_proxy']) && (string) $settings['captcha_show_proxy'] === '1',
            'show_otp' => !empty($settings['captcha_show_otp']) && (string) $settings['captcha_show_otp'] === '1',
        );
    }

    public static function normalize_context($context)
    {
        $context = sanitize_key((string) $context);
        return in_array($context, array('panel', 'config', 'proxy'), true) ? $context : 'panel';
    }

    public static function is_required($context = 'panel', $step = 'phone', $otp_possible = false)
    {
        $settings = self::settings();
        if (!$settings['enabled']) {
            return false;
        }
        $context = self::normalize_context($context);
        $context_enabled = !empty($settings['show_' . $context]);
        $step = sanitize_key((string) $step);
        if ($step !== 'phone') {
            return false;
        }
        return $context_enabled || ($otp_possible && $settings['show_otp']);
    }

    public static function generate_token()
    {
        try {
            return bin2hex(random_bytes(24));
        } catch (Exception $e) {
            return hash('sha256', wp_generate_password(64, true, true) . microtime(true) . wp_rand());
        }
    }

    public static function generate_code($token = '', $length = null)
    {
        $token = self::sanitize_token($token);
        if ($token === '') {
            $token = self::generate_token();
        }
        $length = (int) $length === 5 ? 5 : ((int) $length === 4 ? 4 : self::settings()['length']);
        $digest = hash_hmac('sha256', 'ipsvp-captcha|' . $token, wp_salt('auth'));
        $max = (int) pow(10, $length);
        return str_pad((string) (hexdec(substr($digest, 0, 8)) % $max), $length, '0', STR_PAD_LEFT);
    }

    private static function code_hash($code)
    {
        return hash_hmac('sha256', (string) $code, wp_salt('secure_auth'));
    }

    public static function store_code($token, $code)
    {
        $token = self::sanitize_token($token);
        if ($token === '') {
            return false;
        }
        $ttl = self::settings()['ttl'];
        $record = array(
            'hash' => self::code_hash($code),
            'expires' => time() + $ttl,
            'attempts' => 0,
            'length' => strlen((string) $code),
        );
        return set_transient(self::TRANSIENT_PREFIX . $token, $record, $ttl + (5 * MINUTE_IN_SECONDS));
    }

    public static function create()
    {
        $token = self::generate_token();
        self::store_code($token, self::generate_code($token));
        return array(
            'token' => $token,
            'image_url' => self::image_url($token),
        );
    }

    public static function image_url($token, $theme = 'auto')
    {
        $theme = in_array($theme, array('auto', 'light', 'dark'), true) ? $theme : 'auto';
        return add_query_arg(array(
            'action' => self::IMAGE_ACTION,
            'token' => self::sanitize_token($token),
            'theme' => $theme,
        ), admin_url('admin-post.php'));
    }

    public static function render_captcha_field($context = 'panel', $step = 'phone', $otp_possible = false)
    {
        $context = self::normalize_context($context);
        if (!self::is_required($context, $step, $otp_possible)) {
            return '';
        }
        self::enqueue_assets();
        $captcha = self::create();
        $settings = self::settings();
        $id = 'ipsvp-captcha-' . substr($captcha['token'], 0, 10);
        ob_start();
        ?>
        <div class="ips-captcha-box" data-ipsvp-captcha data-captcha-context="<?php echo esc_attr($context); ?>" data-color-mode="<?php echo esc_attr($settings['color_mode']); ?>">
            <input type="hidden" name="captcha_token" value="<?php echo esc_attr($captcha['token']); ?>" data-ipsvp-captcha-token>
            <input type="hidden" name="ipsvp_captcha_context" value="<?php echo esc_attr($context); ?>">
            <div class="ips-captcha-image-wrap">
                <button type="button" class="ips-captcha-refresh" aria-label="دریافت کد امنیتی جدید" title="کد جدید" data-ipsvp-captcha-refresh><span aria-hidden="true">↻</span><span class="ips-captcha-refresh-text">کد جدید</span></button>
                <img src="<?php echo esc_url($captcha['image_url']); ?>" alt="کد امنیتی" class="ips-captcha-image" width="152" height="54" draggable="false" data-ipsvp-captcha-image>
            </div>
            <label class="ips-captcha-input-wrap" for="<?php echo esc_attr($id); ?>">
                <span>کد امنیتی</span>
                <input id="<?php echo esc_attr($id); ?>" type="text" name="captcha_code" inputmode="numeric" pattern="[0-9۰-۹٠-٩]*" autocomplete="off" maxlength="<?php echo esc_attr($settings['length']); ?>" placeholder="کد امنیتی را وارد کنید" data-ipsvp-captcha-code>
            </label>
            <div class="ips-captcha-error" role="alert" aria-live="polite" data-ipsvp-captcha-error></div>
        </div>
        <?php
        return trim(ob_get_clean());
    }

    public static function validate($token, $input)
    {
        $token = self::sanitize_token($token);
        $input = self::normalize_digits($input);
        if ($token === '') {
            return new WP_Error('captcha_expired', 'کد امنیتی منقضی شده است. لطفاً کد جدید دریافت کنید.');
        }
        $record = get_transient(self::TRANSIENT_PREFIX . $token);
        if (!is_array($record) || empty($record['hash']) || empty($record['expires'])) {
            return new WP_Error('captcha_expired', 'کد امنیتی منقضی شده است. لطفاً کد جدید دریافت کنید.');
        }
        if ((int) $record['expires'] < time()) {
            delete_transient(self::TRANSIENT_PREFIX . $token);
            return new WP_Error('captcha_expired', 'کد امنیتی منقضی شده است. لطفاً کد جدید دریافت کنید.');
        }
        $settings = self::settings();
        $length = isset($record['length']) && (int) $record['length'] === 5 ? 5 : 4;
        $expected = self::generate_code($token, $length);
        $valid = strlen($input) === $length
            && hash_equals((string) $record['hash'], self::code_hash($input))
            && hash_equals($expected, $input);
        if ($valid) {
            delete_transient(self::TRANSIENT_PREFIX . $token);
            return true;
        }
        $record['attempts'] = isset($record['attempts']) ? (int) $record['attempts'] + 1 : 1;
        if ($record['attempts'] >= $settings['max_attempts']) {
            delete_transient(self::TRANSIENT_PREFIX . $token);
            return new WP_Error('captcha_refresh_required', 'کد امنیتی اشتباه است. لطفاً کد جدید دریافت کنید.');
        }
        set_transient(self::TRANSIENT_PREFIX . $token, $record, max(MINUTE_IN_SECONDS, ((int) $record['expires'] - time()) + (5 * MINUTE_IN_SECONDS)));
        return new WP_Error('captcha_invalid', 'کد امنیتی اشتباه است. لطفاً دوباره تلاش کنید.');
    }

    public static function validate_request($context, $step, $otp_possible = false)
    {
        if (!self::is_required($context, $step, $otp_possible)) {
            return true;
        }
        $token = isset($_POST['captcha_token']) ? wp_unslash($_POST['captcha_token']) : '';
        $code = isset($_POST['captcha_code']) ? wp_unslash($_POST['captcha_code']) : '';
        return self::validate($token, $code);
    }

    public static function create_pass($phone, $context = 'panel')
    {
        $phone = trim((string) $phone);
        if ($phone === '') {
            return '';
        }
        $context = self::normalize_context($context);
        $token = self::generate_token();
        $ttl = self::settings()['ttl'];
        set_transient(self::PASS_TRANSIENT_PREFIX . $token, array(
            'phone_hash' => hash_hmac('sha256', $phone, wp_salt('logged_in')),
            'context' => $context,
            'expires' => time() + $ttl,
        ), $ttl);
        return $token;
    }

    public static function validate_pass($token, $phone, $context = 'panel')
    {
        $token = self::sanitize_token($token);
        $phone = trim((string) $phone);
        $context = self::normalize_context($context);
        $record = $token !== '' ? get_transient(self::PASS_TRANSIENT_PREFIX . $token) : false;
        if (!is_array($record) || empty($record['phone_hash']) || empty($record['expires'])) {
            return new WP_Error('captcha_pass_expired', 'اعتبار مرحله امنیتی منقضی شده است. لطفاً دوباره از مرحله اول ادامه دهید.');
        }
        $phone_hash = hash_hmac('sha256', $phone, wp_salt('logged_in'));
        if ((int) $record['expires'] < time()
            || !hash_equals((string) $record['phone_hash'], $phone_hash)
            || !hash_equals((string) $record['context'], $context)) {
            delete_transient(self::PASS_TRANSIENT_PREFIX . $token);
            return new WP_Error('captcha_pass_invalid', 'اعتبار مرحله امنیتی منقضی شده است. لطفاً دوباره از مرحله اول ادامه دهید.');
        }
        return true;
    }

    public static function delete_pass($token)
    {
        $token = self::sanitize_token($token);
        if ($token !== '') {
            delete_transient(self::PASS_TRANSIENT_PREFIX . $token);
        }
    }

    public static function refresh($theme = 'auto')
    {
        $captcha = self::create();
        $captcha['image_url'] = self::image_url($captcha['token'], $theme);
        return $captcha;
    }

    public static function ajax_refresh()
    {
        if (check_ajax_referer('ipsvp_captcha_refresh', 'nonce', false) === false) {
            wp_send_json_error(array('message' => 'اعتبار درخواست منقضی شده است. صفحه را تازه کنید.'), 403);
        }
        if (!self::allow_refresh()) {
            wp_send_json_error(array('message' => 'تعداد درخواست کد جدید زیاد است. کمی بعد دوباره تلاش کنید.'), 429);
        }
        $theme = isset($_POST['theme']) ? sanitize_key(wp_unslash($_POST['theme'])) : 'auto';
        wp_send_json_success(self::refresh($theme));
    }

    private static function allow_refresh()
    {
        $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : 'unknown';
        $key = 'ipsvp_captcha_rate_' . substr(hash_hmac('sha256', $ip, wp_salt('nonce')), 0, 24);
        $count = (int) get_transient($key);
        if ($count >= 20) {
            return false;
        }
        set_transient($key, $count + 1, MINUTE_IN_SECONDS);
        return true;
    }

    public static function render_image_request()
    {
        $token = isset($_GET['token']) ? self::sanitize_token(wp_unslash($_GET['token'])) : '';
        $theme = isset($_GET['theme']) ? sanitize_key(wp_unslash($_GET['theme'])) : 'auto';
        self::render_image($token, $theme);
    }

    public static function render_image($token, $theme = 'auto')
    {
        nocache_headers();
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('X-Content-Type-Options: nosniff');
        $token = self::sanitize_token($token);
        $record = $token !== '' ? get_transient(self::TRANSIENT_PREFIX . $token) : false;
        if (!is_array($record) || empty($record['expires']) || (int) $record['expires'] < time()) {
            self::output_error_svg();
        }
        $mode = self::settings()['color_mode'];
        if ($mode !== 'auto') {
            $theme = $mode;
        }
        $theme = $theme === 'dark' ? 'dark' : 'light';
        $code = self::generate_code($token, isset($record['length']) ? (int) $record['length'] : null);
        if (function_exists('imagecreatetruecolor') && function_exists('imagepng')) {
            self::output_gd($code, $theme);
        }
        self::output_svg($code, $theme);
    }

    private static function output_gd($code, $theme)
    {
        $width = 152;
        $height = 54;
        $image = imagecreatetruecolor($width, $height);
        $dark = $theme === 'dark';
        $background = imagecolorallocate($image, $dark ? 31 : 244, $dark ? 36 : 246, $dark ? 48 : 249);
        $ink = imagecolorallocate($image, $dark ? 229 : 48, $dark ? 232 : 52, $dark ? 240 : 63);
        $line = imagecolorallocatealpha($image, $dark ? 139 : 91, $dark ? 146 : 96, $dark ? 168 : 112, 48);
        $noise = imagecolorallocatealpha($image, $dark ? 170 : 105, $dark ? 176 : 112, $dark ? 193 : 128, 72);
        imagefill($image, 0, 0, $background);
        for ($i = 0; $i < 75; $i++) {
            imagesetpixel($image, wp_rand(2, $width - 3), wp_rand(2, $height - 3), $noise);
        }
        for ($wave = 0; $wave < 3; $wave++) {
            $phase = wp_rand(0, 30) / 10;
            $amplitude = wp_rand(3, 7);
            $baseline = wp_rand(13, 42);
            $last_x = 0;
            $last_y = $baseline;
            for ($x = 4; $x < $width; $x += 4) {
                $y = $baseline + sin(($x / 12) + $phase) * $amplitude;
                imageline($image, $last_x, (int) $last_y, $x, (int) $y, $line);
                $last_x = $x;
                $last_y = $y;
            }
        }
        $length = strlen($code);
        $spacing = (int) floor(118 / max(1, $length));
        $start = 17;
        for ($i = 0; $i < $length; $i++) {
            $glyph = imagecreatetruecolor(26, 36);
            imagealphablending($glyph, false);
            imagesavealpha($glyph, true);
            $transparent = imagecolorallocatealpha($glyph, 0, 0, 0, 127);
            imagefill($glyph, 0, 0, $transparent);
            $glyph_ink = imagecolorallocate($glyph, $dark ? 229 : 48, $dark ? 232 : 52, $dark ? 240 : 63);
            imagestring($glyph, 5, 7, 10, $code[$i], $glyph_ink);
            $rotated = function_exists('imagerotate') ? imagerotate($glyph, wp_rand(-14, 14), $transparent) : $glyph;
            imagecopy($image, $rotated, $start + ($i * $spacing) + wp_rand(-2, 2), wp_rand(7, 11), 0, 0, imagesx($rotated), imagesy($rotated));
            if ($rotated !== $glyph) {
                imagedestroy($rotated);
            }
            imagedestroy($glyph);
        }
        header('Content-Type: image/png');
        imagepng($image, null, 7);
        imagedestroy($image);
        exit;
    }

    private static function output_svg($code, $theme)
    {
        $dark = $theme === 'dark';
        $background = $dark ? '#1f2430' : '#f4f6f9';
        $ink = $dark ? '#e5e8f0' : '#30343f';
        $line = $dark ? '#8b92a8' : '#5b6070';
        $length = strlen($code);
        $step = 118 / max(1, $length);
        $text = '';
        for ($i = 0; $i < $length; $i++) {
            $x = 18 + ($i * $step) + wp_rand(-2, 2);
            $y = 36 + wp_rand(-3, 3);
            $rotation = wp_rand(-12, 12);
            $text .= '<text x="' . esc_attr($x) . '" y="' . esc_attr($y) . '" transform="rotate(' . esc_attr($rotation) . ' ' . esc_attr($x) . ' ' . esc_attr($y) . ')">' . esc_html($code[$i]) . '</text>';
        }
        $dots = '';
        for ($i = 0; $i < 45; $i++) {
            $dots .= '<circle cx="' . esc_attr(wp_rand(3, 149)) . '" cy="' . esc_attr(wp_rand(3, 51)) . '" r="' . esc_attr(wp_rand(3, 8) / 10) . '"/>';
        }
        header('Content-Type: image/svg+xml; charset=utf-8');
        echo '<svg xmlns="http://www.w3.org/2000/svg" width="152" height="54" viewBox="0 0 152 54" role="img" aria-label="کد امنیتی"><rect width="152" height="54" rx="10" fill="' . esc_attr($background) . '"/><g fill="' . esc_attr($line) . '" opacity=".35">' . $dots . '</g><g fill="none" stroke="' . esc_attr($line) . '" stroke-width="1.2" opacity=".5"><path d="M0 18 Q25 5 50 20 T102 18 T152 22"/><path d="M0 40 Q28 25 55 39 T110 36 T152 34"/></g><g fill="' . esc_attr($ink) . '" font-family="Arial,sans-serif" font-size="27" font-weight="700" letter-spacing="3">' . $text . '</g></svg>';
        exit;
    }

    private static function output_error_svg()
    {
        header('Content-Type: image/svg+xml; charset=utf-8');
        echo '<svg xmlns="http://www.w3.org/2000/svg" width="152" height="54" viewBox="0 0 152 54"><rect width="152" height="54" rx="10" fill="#f4f6f9"/><text x="76" y="32" text-anchor="middle" font-family="Arial,sans-serif" font-size="12" fill="#6b7280">کد منقضی شده</text></svg>';
        exit;
    }

    private static function sanitize_token($token)
    {
        $token = strtolower(trim((string) $token));
        return preg_match('/^[a-f0-9]{48,64}$/', $token) ? $token : '';
    }

    private static function normalize_digits($value)
    {
        $value = strtr((string) $value, array(
            '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
            '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
            '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
        ));
        return preg_replace('/\D+/', '', $value);
    }

    public static function cleanup()
    {
        // WordPress removes expired transients; this method is intentionally
        // reusable for scheduled/manual cleanup without introducing sessions.
        return true;
    }
}

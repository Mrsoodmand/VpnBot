<?php
/**
 * Companion bot API client.
 *
 * @package IPSabet_PasarGuard_Shop
 */

defined('ABSPATH') || exit;

final class IPSVP_Bot_API
{
    private static function settings()
    {
        return IPSVP_Settings::get();
    }

    private static function base_url()
    {
        $s = self::settings();
        $url = isset($s['bot_api_url']) ? trim((string) $s['bot_api_url']) : '';
        return untrailingslashit($url);
    }

    private static function secret()
    {
        $s = self::settings();
        return isset($s['wp_sync_secret']) ? (string) $s['wp_sync_secret'] : '';
    }

    public static function request($method, $path, $body = array())
    {
        $base = self::base_url();
        $secret = self::secret();
        if (!$base || !$secret) {
            return new WP_Error('bot_sync_missing_settings', 'آدرس API ربات یا کلید امنیتی اتصال تنظیم نشده است.');
        }
        $url = $base . '/' . ltrim($path, '/');
        $args = array(
            'method' => strtoupper($method),
            'timeout' => 25,
            'headers' => array(
                'Accept' => 'application/json',
                'Content-Type' => 'application/json; charset=utf-8',
                'X-IPSABET-API-KEY' => $secret,
            ),
            'body' => !empty($body) ? wp_json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null,
        );
        $res = wp_remote_request($url, $args);
        if (is_wp_error($res)) {
            return $res;
        }
        $code = (int) wp_remote_retrieve_response_code($res);
        $raw = (string) wp_remote_retrieve_body($res);
        $data = json_decode($raw, true);
        if ($code < 200 || $code >= 300) {
            return new WP_Error('bot_sync_http_' . $code, 'خطای API ربات: HTTP ' . $code . ' - ' . ($raw ? $raw : 'بدون پاسخ'));
        }
        return is_array($data) ? $data : array('raw' => $raw);
    }

    public static function ping()
    {
        return self::request('GET', '/api/wp-sync/ping');
    }

    private static function normalize_balance_value($value)
    {
        if (is_int($value) || is_float($value)) {
            return max(0, (int) $value);
        }
        if (!is_scalar($value)) {
            return null;
        }
        $value = strtr((string) $value, array(
            '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
            '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
            '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
        ));
        $value = preg_replace('/[^0-9\-]/', '', $value);
        return $value === '' ? null : max(0, (int) $value);
    }

    private static function normalize_wallet_response($res)
    {
        if (!is_array($res)) {
            return $res;
        }
        if (!empty($res['data']) && is_array($res['data'])) {
            foreach ($res['data'] as $key => $value) {
                if (!array_key_exists($key, $res)) {
                    $res[$key] = $value;
                }
            }
        }
        if (!empty($res['wallet']) && is_array($res['wallet'])) {
            foreach ($res['wallet'] as $key => $value) {
                if (!array_key_exists($key, $res)) {
                    $res[$key] = $value;
                }
            }
        }
        if (!isset($res['ok']) && isset($res['success'])) {
            $res['ok'] = (bool) $res['success'];
        }
        $candidates = array(
            $res['balance'] ?? null,
            $res['wallet_balance'] ?? null,
            $res['new_balance'] ?? null,
            $res['remaining_balance'] ?? null,
            isset($res['wallet']['balance']) ? $res['wallet']['balance'] : null,
            isset($res['data']['balance']) ? $res['data']['balance'] : null,
            isset($res['data']['wallet']['balance']) ? $res['data']['wallet']['balance'] : null,
        );
        foreach ($candidates as $candidate) {
            $balance = self::normalize_balance_value($candidate);
            if ($balance !== null) {
                $res['balance'] = $balance;
                break;
            }
        }
        if (!isset($res['ok']) && isset($res['balance'])) {
            $res['ok'] = true;
        }
        return $res;
    }

    public static function wallet($tel_id)
    {
        $res = self::request('POST', '/api/wp-sync/wallet/balance', array('tel_id' => (string) $tel_id));
        if (is_wp_error($res) || !is_array($res)) {
            return $res;
        }
        return self::normalize_wallet_response($res);
    }

    public static function unified_wallet($user, $db, $sync_local = true)
    {
        if (!$user || empty($user->id) || empty($user->bot_tel_id)) {
            return new WP_Error('wallet_not_linked', 'حساب کاربری به ربات تلگرام متصل نیست.');
        }
        $locked = IPSVP_Reseller_Store::lock($user->id);
        if (is_wp_error($locked)) { return $locked; }
        $remote = self::wallet($user->bot_tel_id);
        if (is_wp_error($remote)) {
            return $remote;
        }
        if (empty($remote['ok']) || !isset($remote['balance'])) {
            $message = !empty($remote['message']) ? (string) $remote['message'] : 'پاسخ موجودی کیف پول ربات معتبر نیست.';
            return new WP_Error('bot_wallet_invalid_response', $message, array('response' => $remote));
        }

        $local_balance = $db->get_local_wallet_balance((int) $user->id);
        if (!$sync_local || $local_balance <= 0) {
            $remote['local_balance_before_sync'] = $local_balance;
            $remote['synced_amount'] = 0;
            return $remote;
        }

        $sync_receipt = $db->prepare_wallet_sync_debit($user, $user->bot_tel_id);
        if (is_wp_error($sync_receipt)) {
            return $sync_receipt;
        }
        if (!$sync_receipt) {
            $remote['local_balance_before_sync'] = $local_balance;
            $remote['synced_amount'] = 0;
            return $remote;
        }
        if ((string) $sync_receipt->status !== 'approved') {
            $credited = self::credit_wallet(
                $user->bot_tel_id,
                (int) $sync_receipt->amount,
                (int) $sync_receipt->id,
                (string) $user->phone
            );
            if (is_wp_error($credited) || empty($credited['ok'])) {
                $message = is_wp_error($credited) ? $credited->get_error_message() : (!empty($credited['message']) ? (string) $credited['message'] : 'انتقال موجودی سایت به ربات ناموفق بود.');
                $db->add_log('error', 'wallet_sync_to_bot', $message, array(
                    'user_id' => (int) $user->id,
                    'receipt_id' => (int) $sync_receipt->id,
                    'amount' => (int) $sync_receipt->amount,
                    'bot_response' => is_wp_error($credited) ? array() : $credited,
                ), (string) $user->phone, 0, (int) $sync_receipt->id, (int) $user->id);
                return new WP_Error('wallet_sync_failed', $message, array(
                    'local_balance' => $local_balance,
                    'remote_balance' => (int) $remote['balance'],
                ));
            }
            if ($db->complete_wallet_sync_debit((int) $sync_receipt->id, $credited) === false) {
                return new WP_Error('wallet_sync_finalize_failed', 'موجودی به ربات منتقل شد اما ثبت نهایی همگام سازی در سایت ناموفق بود؛ لطفا دوباره تلاش کنید.');
            }
            $remote = $credited;
            if (!isset($remote['balance'])) {
                $remote = self::wallet($user->bot_tel_id);
            }
            if (is_wp_error($remote) || empty($remote['ok']) || !isset($remote['balance'])) {
                return is_wp_error($remote) ? $remote : new WP_Error('wallet_sync_balance_failed', 'موجودی منتقل شد اما دریافت مانده جدید از ربات ناموفق بود.');
            }
            $db->add_log('info', 'wallet_sync_to_bot', 'موجودی محلی سایت با کیف پول ربات ادغام شد.', array(
                'user_id' => (int) $user->id,
                'receipt_id' => (int) $sync_receipt->id,
                'amount' => (int) $sync_receipt->amount,
                'balance' => (int) $remote['balance'],
            ), (string) $user->phone, 0, (int) $sync_receipt->id, (int) $user->id);
        }
        $remote['local_balance_before_sync'] = $local_balance;
        $remote['synced_amount'] = (int) $sync_receipt->amount;
        return $remote;
    }

    public static function wallet_transactions($tel_id, $page = 1, $per_page = 30)
    {
        return self::request('POST', '/api/wp-sync/wallet/transactions', array(
            'tel_id' => (string) $tel_id,
            'page' => max(1, (int) $page),
            'per_page' => max(1, min(100, (int) $per_page)),
        ));
    }

    public static function bot_orders($tel_id, $page = 1, $per_page = 100)
    {
        $res = self::request('POST', '/api/wp-sync/orders/list', array(
            'tel_id' => (string) $tel_id,
            'page' => max(1, (int) $page),
            'per_page' => max(1, min(200, (int) $per_page)),
        ));
        if (is_wp_error($res) || !is_array($res)) {
            return $res;
        }
        // New API uses items; older builds used orders.
        if (empty($res['orders']) && !empty($res['items']) && is_array($res['items'])) {
            $res['orders'] = $res['items'];
        }
        return $res;
    }

    public static function find_bot_order($tel_id, $bot_order_id)
    {
        $direct = self::request('POST', '/api/wp-sync/orders/show', array(
            'tel_id' => (string) $tel_id,
            'order_id' => (int) $bot_order_id,
        ));
        if (!is_wp_error($direct) && !empty($direct['ok']) && !empty($direct['order']) && is_array($direct['order'])) {
            return $direct['order'];
        }
        $list = self::bot_orders($tel_id, 1, 200);
        if (is_wp_error($list) || empty($list['ok']) || empty($list['orders']) || !is_array($list['orders'])) {
            return is_wp_error($list) ? $list : null;
        }
        foreach ($list['orders'] as $order) {
            if ((int) ($order['id'] ?? 0) === (int) $bot_order_id) {
                return $order;
            }
        }
        return null;
    }

    public static function sync_user_full($tel_id = '', $phone = '')
    {
        return self::request('POST', '/api/wp-sync/sync/user-full', array(
            'tel_id' => (string) $tel_id,
            'phone' => (string) $phone,
        ));
    }

    public static function update_bot_order($tel_id, $bot_order_id, $payload = array())
    {
        return self::request('POST', '/api/wp-sync/orders/update-bot', array(
            'tel_id' => (string) $tel_id,
            'bot_order_id' => (int) $bot_order_id,
            'order' => is_array($payload) ? $payload : array(),
        ));
    }

    public static function credit_wallet($tel_id, $amount, $receipt_id, $phone = '', $source = 'wordpress_wallet_receipt')
    {
        $res = self::request('POST', '/api/wp-sync/wallet/credit', array(
            'tel_id' => (string) $tel_id,
            'phone' => (string) $phone,
            'amount' => (int) $amount,
            'source' => sanitize_key((string) $source),
            'receipt_id' => (int) $receipt_id,
        ));
        return is_wp_error($res) ? $res : self::normalize_wallet_response($res);
    }

    public static function debit_wallet($tel_id, $amount, $order_code, $phone = '')
    {
        $res = self::request('POST', '/api/wp-sync/wallet/debit', array(
            'tel_id' => (string) $tel_id,
            'phone' => (string) $phone,
            'amount' => (int) $amount,
            'source' => 'wordpress_order_payment',
            'order_code' => (string) $order_code,
        ));
        return is_wp_error($res) ? $res : self::normalize_wallet_response($res);
    }

    public static function import_site_order($order)
    {
        if (IPSVP_Sanaei_API::is_order($order)) {
            return array('ok' => true, 'skipped' => 'sanaei_site_managed');
        }
        if (!$order || empty($order->phone)) {
            return new WP_Error('bad_site_order', 'اطلاعات سفارش سایت برای ارسال به ربات کامل نیست.');
        }
        $payload = (new IPSVP_DB())->order_payload_for_bot($order);
        if (!$payload) {
            return array('ok' => true, 'skipped' => 'site_managed_order');
        }
        return self::request('POST', '/api/wp-sync/orders/import-site', array('order' => $payload));
    }

    public static function disconnect_link($tel_id = '', $phone = '')
    {
        return self::request('POST', '/api/wp-sync/link/disconnect', array(
            'tel_id' => (string) $tel_id,
            'phone' => (string) $phone,
        ));
    }

    public static function admin_stats($range, $month, $start, $end, $group)
    {
        $res = self::request('POST', '/api/wp-sync/admin/stats', array(
            'range' => (string) $range,
            'month' => (string) $month,
            'start' => (string) $start,
            'end' => (string) $end,
            'group' => (string) $group,
        ));
        if (is_wp_error($res) || !is_array($res) || empty($res['series']) || !is_array($res['series'])) {
            return $res;
        }
        foreach ($res['series'] as $period => $row) {
            if (!is_array($row)) {
                continue;
            }
            if (!isset($row['sales']) && isset($row['revenue'])) {
                $row['sales'] = (int) $row['revenue'];
            }
            if (!isset($row['payments']) && isset($row['orders'])) {
                $row['payments'] = (int) $row['orders'];
            }
            $res['series'][$period] = $row;
        }
        return $res;
    }

    public static function admin_list($type, $page = 1, $search = '')
    {
        return self::request('POST', '/api/wp-sync/admin/list', array(
            'type' => (string) $type,
            'page' => max(1, (int) $page),
            'search' => (string) $search,
        ));
    }


    public static function handle_confirm_link_request($request, $db)
    {
        $s = self::settings();
        $secret = isset($s['wp_sync_secret']) ? (string) $s['wp_sync_secret'] : '';
        $header = (string) $request->get_header('x-ipsabet-api-key');
        if (!$secret || !hash_equals($secret, $header)) {
            return new WP_REST_Response(array('ok' => false, 'message' => 'unauthorized'), 403);
        }
        $params = $request->get_json_params();
        if (!is_array($params)) {
            $params = array();
        }
        $code = isset($params['code']) ? $params['code'] : '';
        $tel_id = isset($params['tel_id']) ? $params['tel_id'] : '';
        $telegram = isset($params['telegram']) && is_array($params['telegram']) ? $params['telegram'] : array();
        $user = $db->confirm_bot_link_code($code, $tel_id, $telegram);
        if (is_wp_error($user)) {
            return new WP_REST_Response(array('ok' => false, 'message' => $user->get_error_message()), 422);
        }
        $wallet = self::unified_wallet($user, $db, true);
        $wallet_payload = array(
            'ok' => !is_wp_error($wallet) && !empty($wallet['ok']),
            'balance' => !is_wp_error($wallet) && isset($wallet['balance']) ? (int) $wallet['balance'] : $db->get_local_wallet_balance((int) $user->id),
            'synced_amount' => !is_wp_error($wallet) && isset($wallet['synced_amount']) ? (int) $wallet['synced_amount'] : 0,
        );
        if (is_wp_error($wallet)) {
            $wallet_payload['message'] = $wallet->get_error_message();
            $db->add_log('warning', 'confirm_link_wallet_sync', $wallet->get_error_message(), array(
                'user_id' => (int) $user->id,
                'tel_id' => (string) $tel_id,
            ), (string) $user->phone, 0, 0, (int) $user->id);
        }
        return array(
            'ok' => true,
            'phone' => $user->phone,
            'site_user_id' => (int) $user->id,
            'wallet' => $wallet_payload,
            'wallet_balance' => (int) $wallet_payload['balance'],
            'orders' => $db->get_site_orders_for_sync($user->phone),
        );
    }
}

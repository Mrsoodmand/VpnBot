<?php
/** 3x-ui adapter. Never creates clients or resets their traffic. */
defined('ABSPATH') || exit;

final class IPSVP_Sanaei_API
{
    public static function is_order($order)
    {
        return is_object($order) && ($order->service_type ?? '') === 'dedicated' && ($order->panel_provider ?? '') === 'sanaei';
    }

    public static function normalize_url($url)
    {
        $url = trim((string) $url);
        if ($url === '') { return ''; }
        if (!preg_match('#^https?://#i', $url)) { $url = 'https://' . $url; }
        $url = rtrim(preg_replace('/[?#].*$/', '', $url), '/');
        // Preserve 3x-ui's secret webBasePath.
        return rtrim(preg_replace('#/(panel(?:/.*)?|login|openapi\.json)$#i', '', $url), '/');
    }

    private function request($method, $path, $payload = null, $retry = true)
    {
        $s = IPSVP_Settings::get();
        $base = self::normalize_url($s['sanaei_panel_url'] ?? '');
        if (!$base) { return new WP_Error('sanaei_settings', 'آدرس پنل سنایی تنظیم نشده است.'); }
        $args = array('method' => $method, 'timeout' => 30, 'redirection' => 0, 'sslverify' => !empty($s['sanaei_ssl_verify']), 'headers' => array('Accept' => 'application/json'));
        $key = 'ipsvp_sanaei_session_' . md5($base . '|' . ($s['sanaei_username'] ?? '') . '|' . ($s['sanaei_password'] ?? ''));
        if (!empty($s['sanaei_token'])) {
            $args['headers']['Authorization'] = 'Bearer ' . $s['sanaei_token'];
        } else {
            $cookies = get_transient($key);
            if (!$cookies) {
                if (empty($s['sanaei_username']) || empty($s['sanaei_password'])) {
                    return new WP_Error('sanaei_credentials', 'توکن API یا نام کاربری و رمز عبور سنایی را در تنظیمات وارد کنید.');
                }
                $login = wp_remote_post($base . '/login', array('timeout' => 30, 'redirection' => 0, 'sslverify' => $args['sslverify'], 'body' => array('username' => $s['sanaei_username'], 'password' => $s['sanaei_password'])));
                if (is_wp_error($login)) { return $login; }
                $body = json_decode(wp_remote_retrieve_body($login), true);
                $cookies = wp_remote_retrieve_cookies($login);
                if ((int) wp_remote_retrieve_response_code($login) !== 200 || !is_array($body) || ($body['success'] ?? false) !== true || !$cookies) {
                    return new WP_Error('sanaei_login', 'ورود به سنایی ناموفق بود؛ اطلاعات ورود را بررسی کنید. برای پنل دارای ورود دومرحله‌ای از توکن API استفاده کنید.');
                }
                set_transient($key, $cookies, 20 * MINUTE_IN_SECONDS);
            }
            $args['cookies'] = $cookies;
        }
        if ($method !== 'GET' && empty($s['sanaei_token'])) {
            $csrf = $this->request('GET', '/csrf-token');
            if (is_wp_error($csrf) && !$this->missing_route($csrf)) { return $csrf; }
            if (is_string($csrf) && $csrf !== '') { $args['headers']['X-CSRF-Token'] = $csrf; }
            // The CSRF read may have refreshed the session.
            $args['cookies'] = get_transient($key) ?: $args['cookies'];
        }
        if ($payload !== null) {
            $args['headers']['Content-Type'] = 'application/json';
            $args['body'] = wp_json_encode($payload);
        }
        $response = wp_remote_request($base . $path, $args);
        if (is_wp_error($response)) { return $response; }
        $code = (int) wp_remote_retrieve_response_code($response);
        if ($code === 401 && $retry && empty($s['sanaei_token'])) {
            delete_transient($key);
            return $this->request($method, $path, $payload, false);
        }
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($code < 200 || $code >= 300 || !is_array($body) || ($body['success'] ?? false) !== true) {
            $detail = $this->safe_error_message(is_array($body) ? ($body['msg'] ?? '') : '', $payload, $s);
            $route = preg_replace('#/(get|traffic|update|updateClient|getClientTraffics)/[^/]+$#', '/$1/{client}', $path);
            $message = 'درخواست سنایی ناموفق بود (HTTP ' . $code . '، ' . $method . ' ' . $route . ').';
            $message .= $detail !== '' ? ' علت پنل: ' . $detail : ' پاسخ معتبر از پنل دریافت نشد.';
            return new WP_Error('sanaei_api', $message, array('http_status' => $code));
        }
        return $body['obj'] ?? array();
    }

    private function safe_error_message($message, $payload, $settings)
    {
        if (!is_string($message)) { return ''; }
        $secrets = array();
        $collect = static function ($values) use (&$collect, &$secrets) {
            foreach ((array) $values as $key => $value) {
                if (is_array($value)) { $collect($value); }
                elseif (is_scalar($value) && preg_match('/password|token|secret|uuid|subid|email|username|privatekey|publickey|^id$|^auth$/i', (string) $key) && strlen((string) $value) >= 4) { $secrets[] = (string) $value; }
                elseif ($key === 'settings' && is_string($value)) { $collect(json_decode($value, true)); }
            }
        };
        $collect($payload);
        $collect($settings);
        usort($secrets, static function ($a, $b) { return strlen($b) - strlen($a); });
        if ($secrets) { $message = str_replace($secrets, '[redacted]', $message); }
        $message = preg_replace('#(?:https?|vless|vmess|trojan|ss)://[^\s<>]+#i', '[redacted]', $message);
        $message = preg_replace('/[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}/i', '[redacted]', $message);
        return function_exists('mb_substr') ? mb_substr(sanitize_text_field($message), 0, 400) : substr(sanitize_text_field($message), 0, 400);
    }

    private function normalize_modern_client($client)
    {
        // ClientRecord (read) differs from Client (write) in 3x-ui's Go models.
        if (array_key_exists('uuid', $client)) { $client['id'] = (string) $client['uuid']; }
        unset($client['uuid'], $client['inboundIds'], $client['traffic']);
        foreach (array('createdAt' => 'created_at', 'updatedAt' => 'updated_at') as $from => $to) {
            if (isset($client[$from])) { $client[$to] = (int) $client[$from]; unset($client[$from]); }
        }
        if (isset($client['allowedIPs']) && is_string($client['allowedIPs'])) {
            $client['allowedIPs'] = array_values(array_filter(array_map('trim', explode(',', $client['allowedIPs'])), 'strlen'));
        }
        if (array_key_exists('reverse', $client)) {
            if (is_string($client['reverse'])) {
                $reverse = trim($client['reverse']);
                $client['reverse'] = $reverse === '' ? null : json_decode($reverse);
                if ($reverse !== '' && !is_object($client['reverse'])) { return new WP_Error('sanaei_reverse', 'ساختار reverse کلاینت سنایی معتبر نیست؛ اطلاعات اتصال تغییر نکرد.'); }
            } elseif (is_array($client['reverse'])) {
                $client['reverse'] = (object) $client['reverse'];
            }
        }
        return $client;
    }

    private function missing_route($result)
    {
        return is_wp_error($result) && in_array((int) ($result->get_error_data()['http_status'] ?? 0), array(404, 405), true);
    }

    public function test_connection()
    {
        return $this->request('GET', '/panel/api/inbounds/list');
    }

    private function client($order)
    {
        $email = trim((string) ($order->pg_username ?? ''));
        $inbound_id = (int) ($order->panel_inbound_id ?? 0);
        if ($email === '' || $inbound_id <= 0) {
            return new WP_Error('sanaei_identity', 'نام کلاینت (Email) و آیدی اینباند سنایی الزامی است.');
        }
        $inbound = $this->request('GET', '/panel/api/inbounds/get/' . $inbound_id);
        if (is_wp_error($inbound)) { return $inbound; }
        if (!is_array($inbound) || (int) ($inbound['id'] ?? 0) !== $inbound_id) {
            return new WP_Error('sanaei_inbound', 'اینباند انتخاب‌شده در سنایی پیدا نشد.');
        }
        $detail = $this->request('GET', '/panel/api/clients/get/' . rawurlencode($email));
        if ($this->missing_route($detail)) {
            $mode = 'legacy';
            $settings = is_array($inbound['settings'] ?? null) ? $inbound['settings'] : json_decode((string) ($inbound['settings'] ?? ''), true);
            if (!is_array($settings) || !is_array($settings['clients'] ?? null)) { return new WP_Error('sanaei_settings_response', 'ساختار تنظیمات اینباند سنایی معتبر نیست.'); }
            $matches = array_values(array_filter($settings['clients'], static function ($row) use ($email) { return is_array($row) && ($row['email'] ?? '') === $email; }));
            if (count($matches) !== 1) { return new WP_Error('sanaei_client', 'کلاینت با این Email در اینباند انتخاب‌شده یکتا نیست یا پیدا نشد.'); }
            $client = $matches[0];
            $traffic = $this->request('GET', '/panel/api/inbounds/getClientTraffics/' . rawurlencode($email));
        } else {
            if (is_wp_error($detail)) { return $detail; }
            if (!is_array($detail)) { return new WP_Error('sanaei_client_response', 'ساختار پاسخ کلاینت سنایی معتبر نیست.'); }
            $mode = 'modern';
            $client = $detail['client'] ?? $detail;
            if (!is_array($client)) { return new WP_Error('sanaei_client_response', 'ساختار پاسخ کلاینت سنایی معتبر نیست.'); }
            $ids = $detail['inboundIds'] ?? ($client['inboundIds'] ?? array());
            // Modern updates affect the client's attached inbounds; require one dedicated inbound.
            if (!is_array($ids) || array_values(array_unique(array_map('intval', $ids))) !== array($inbound_id)) {
                return new WP_Error('sanaei_shared_client', 'این کلاینت باید فقط به اینباند اختصاصی انتخاب‌شده متصل باشد؛ اتصال چنداینباندی برای جلوگیری از تغییر سرویس‌های دیگر پذیرفته نیست.');
            }
            $client = $this->normalize_modern_client($client);
            if (is_wp_error($client)) { return $client; }
            $traffic = $this->request('GET', '/panel/api/clients/traffic/' . rawurlencode($email));
        }
        if (is_wp_error($traffic)) { return $traffic; }
        if (!is_array($client) || ($client['email'] ?? '') !== $email || !is_array($traffic) || ($traffic['email'] ?? '') !== $email || !isset($traffic['up'], $traffic['down'], $client['totalGB'], $client['expiryTime'], $client['enable'])) {
            return new WP_Error('sanaei_response', 'اطلاعات کلاینت یا مصرف سنایی کامل نیست؛ اطلاعات قبلی سفارش حفظ شد.');
        }
        if (!is_numeric($traffic['up']) || !is_numeric($traffic['down']) || !is_numeric($client['totalGB']) || !is_numeric($client['expiryTime']) || (float) $traffic['up'] < 0 || (float) $traffic['down'] < 0 || (float) $client['totalGB'] < 0) {
            return new WP_Error('sanaei_traffic_values', 'مقادیر مصرف یا محدودیت سنایی معتبر نیست.');
        }
        if ($mode === 'legacy' && (int) ($traffic['inboundId'] ?? 0) !== $inbound_id) {
            return new WP_Error('sanaei_traffic_identity', 'اینباند آمار مصرف با اینباند سفارش یکسان نیست.');
        }
        $protocol = (string) ($inbound['protocol'] ?? '');
        $id_key = array('vless' => 'id', 'vmess' => 'id', 'trojan' => 'password', 'shadowsocks' => 'email', 'hysteria' => 'auth');
        $id = isset($id_key[$protocol]) ? (string) ($client[$id_key[$protocol]] ?? '') : '';
        if ($id === '' || strlen($id) > 64 || (!empty($order->pg_user_id) && !hash_equals((string) $order->pg_user_id, $id))) {
            return new WP_Error('sanaei_client_changed', 'شناسهٔ کلاینت سنایی تغییر کرده یا پروتکل پشتیبانی نمی‌شود؛ برای حفظ کانفیگ عملیات متوقف شد.');
        }
        // The traffic table carries first-connection expiry updates in older panels.
        if (isset($traffic['expiryTime'])) { $client['expiryTime'] = (int) $traffic['expiryTime']; }
        return array('mode' => $mode, 'client' => $client, 'traffic' => $traffic, 'inbound' => $inbound, 'id' => $id);
    }

    private function snapshot($record, $order)
    {
        $client = $record['client'];
        $used = (int) $record['traffic']['up'] + (int) $record['traffic']['down'];
        $limit = (int) $client['totalGB']; // Despite its name, totalGB is measured in bytes.
        $expiry = (int) $client['expiryTime'];
        $expire = $expiry > 0 ? (int) floor($expiry / 1000) : 0;
        $status = !$client['enable'] || empty($record['inbound']['enable']) ? 'disabled' : ($expire > 0 && $expire <= time() ? 'expired' : ($limit > 0 && $used >= $limit ? 'limited' : ($expiry < 0 ? 'on_hold' : 'active')));
        $links = json_decode((string) ($order->pg_links ?? ''), true);
        $links = is_array($links) ? $links : array();
        $live = array('username' => (string) $client['email'], 'status' => $status, 'used_traffic' => $used, 'data_limit' => $limit, 'expire' => $expire, 'on_hold_expire_duration' => $expiry < 0 ? (int) floor(abs($expiry) / 1000) : 0);
        return array('live' => $live, 'error' => '', 'username' => (string) $client['email'], 'user_id' => $record['id'], 'status' => $status, 'used' => $used, 'limit' => $limit, 'expire' => $expire, 'group_ids' => array(), 'subscription_url' => (string) ($order->pg_subscription_url ?? ''), 'links' => $links, 'subscription_content' => implode("\n", $links), 'subscription_type' => 'links', 'subscription_error' => '');
    }

    public function user_snapshot($order)
    {
        $record = $this->client($order);
        if (is_wp_error($record)) { return array('live' => array(), 'error' => $record->get_error_message()); }
        $snapshot = $this->snapshot($record, $order);
        if (!$snapshot['links'] && $record['mode'] === 'modern' && !empty($record['client']['subId'])) {
            $links = $this->request('GET', '/panel/api/clients/subLinks/' . rawurlencode($record['client']['subId']));
            if (!is_wp_error($links) && is_array($links)) {
                $snapshot['links'] = (new IPSVP_PasarGuard_API())->extract_config_links($links);
                $snapshot['subscription_content'] = implode("\n", $snapshot['links']);
            }
        }
        return $snapshot;
    }

    private function update($record, $order, $changes)
    {
        // Send the full existing client; 3x-ui update endpoints replace fields, not patch them.
        $client = array_merge($record['client'], $changes);
        if ($record['mode'] === 'modern') {
            $result = $this->request('POST', '/panel/api/clients/update/' . rawurlencode($client['email']), $client);
        } else {
            $result = $this->request('POST', '/panel/api/inbounds/updateClient/' . rawurlencode($record['id']), array('id' => (int) $order->panel_inbound_id, 'settings' => wp_json_encode(array('clients' => array($client)))));
        }
        if (is_wp_error($result)) { return $result; }
        // No mutation retry on timeouts or application errors; they may have already applied.
        $record['client'] = $client;
        return $this->snapshot($record, $order);
    }

    public function update_user_status_for_order($order, $status)
    {
        $record = $this->client($order);
        if (is_wp_error($record)) { return $record; }
        $status = sanitize_key($status);
        if (!in_array($status, array('created', 'active', 'on_hold', 'disabled', 'cancelled', 'volume_finished', 'time_finished'), true)) {
            return new WP_Error('sanaei_status', 'وضعیت انتخاب‌شده پشتیبانی نمی‌شود.');
        }
        if (in_array($status, array('volume_finished', 'time_finished'), true)) {
            return new WP_Error('sanaei_derived_status', 'اتمام حجم و زمان در سنایی از مصرف و تاریخ انقضا تشخیص داده می‌شود؛ برای توقف دستی، معلق را انتخاب کنید.');
        }
        $enable = in_array($status, array('created', 'active', 'on_hold'), true);
        $changes = array('enable' => $enable);
        $expiry = (int) $record['client']['expiryTime'];
        $now_ms = time() * 1000;
        if ($enable && empty($record['inbound']['enable'])) {
            return new WP_Error('sanaei_inbound_disabled', 'اینباند این سرویس در سنایی غیرفعال است؛ ابتدا اینباند را در پنل فعال کنید.');
        }
        if ($status === 'on_hold' && $expiry >= 0) {
            $remaining = $expiry > 0 ? $expiry - $now_ms : (int) ($order->days ?? 0) * DAY_IN_SECONDS * 1000;
            if ($remaining <= 0) { return new WP_Error('sanaei_on_hold_duration', 'زمانی برای انتظار اتصال باقی نمانده است؛ ابتدا مدت سرویس را تمدید کنید.'); }
            $changes['expiryTime'] = -$remaining;
        } elseif (in_array($status, array('created', 'active'), true) && $expiry < 0) {
            $changes['expiryTime'] = $now_ms + abs($expiry);
        }
        $result = $this->update($record, $order, $changes);
        if (is_wp_error($result)) { return $result; }
        return array('user_id' => $record['id'], 'username' => $record['client']['email'], 'local_status' => $status, 'pg_status' => $result['status'], 'raw' => $result['live']);
    }

    public function extend_user_for_order($order, $plan)
    {
        if (!$plan || (int) $plan->days <= 0 || (int) $plan->gb < 0) { return new WP_Error('sanaei_plan', 'پلن تمدید معتبر نیست.'); }
        $record = $this->client($order);
        if (is_wp_error($record)) { return $record; }
        $expiry = (int) $record['client']['expiryTime'];
        $days_ms = (int) $plan->days * DAY_IN_SECONDS * 1000;
        $new_expiry = $expiry < 0 ? $expiry - $days_ms : max($expiry, time() * 1000) + $days_ms;
        $limit = (int) $record['client']['totalGB'];
        $new_limit = $limit > 0 ? $limit + (int) $plan->gb * 1073741824 : 0;
        $result = $this->update($record, $order, array('enable' => true, 'expiryTime' => $new_expiry, 'totalGB' => $new_limit));
        if (is_wp_error($result)) { return $result; }
        return array('user_id' => $record['id'], 'status' => $result['status'], 'subscription_url' => $result['subscription_url'], 'links' => $result['links'], 'expire_at' => $result['expire'], 'new_limit' => $new_limit, 'raw' => array('after' => $result['live']));
    }

    public function add_extra_volume_for_order($order, $gb)
    {
        if ((int) $gb <= 0) { return new WP_Error('sanaei_volume', 'حجم اضافه معتبر نیست.'); }
        $record = $this->client($order);
        if (is_wp_error($record)) { return $record; }
        $old = (int) $record['client']['totalGB'];
        if ($old <= 0) { return new WP_Error('extra_volume_unlimited', 'این سرویس نامحدود است و نیازی به خرید حجم اضافه ندارد.'); }
        $added = (int) $gb * 1073741824;
        $result = $this->update($record, $order, array('totalGB' => $old + $added, 'enable' => true));
        if (is_wp_error($result)) { return $result; }
        return array('user_id' => $record['id'], 'gb' => (int) $gb, 'added_bytes' => $added, 'old_limit' => $old, 'new_limit' => $old + $added, 'status' => $result['status'], 'subscription_url' => $result['subscription_url'], 'links' => $result['links'], 'raw' => $result['live']);
    }
}

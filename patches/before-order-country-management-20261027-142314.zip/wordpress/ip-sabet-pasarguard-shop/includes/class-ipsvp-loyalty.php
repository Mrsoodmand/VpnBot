<?php
/** Server-side account levels, derived from approved external payments and wallet credits. */
defined('ABSPATH') || exit;

final class IPSVP_Loyalty
{
    const OPTION = 'ipsvp_loyalty_settings';
    const DAYS = 30;
    private static $db;
    private static $ledger = array();
    private static $notice = '';

    public static function init($db)
    {
        self::$db = $db;
        add_action('admin_init', array(__CLASS__, 'handle_override'));
        add_filter('ipsvp_panel_hero', array(__CLASS__, 'hero'), 20, 4);
        add_action('admin_menu', array(__CLASS__, 'menu'), 25);
        add_filter('ipsvp_admin_user_detail_tabs', array(__CLASS__, 'tabs'));
        add_action('ipsvp_admin_user_detail_extra_panels', array(__CLASS__, 'admin_user'), 20, 3);
    }

    public static function defaults()
    {
        return array(
            'reseller' => array(
                array('min' => 0, 'strict' => 0, 'percent' => 5),
                array('min' => 5000000, 'strict' => 0, 'percent' => 10),
                array('min' => 10000000, 'strict' => 0, 'percent' => 20),
                array('min' => 10000000, 'strict' => 1, 'percent' => 30),
            ),
            'customer' => array(
                array('min' => 0, 'strict' => 0, 'percent' => 0),
                array('min' => 2000000, 'strict' => 0, 'percent' => 5),
                array('min' => 5000000, 'strict' => 0, 'percent' => 10),
                array('min' => 10000000, 'strict' => 0, 'percent' => 20),
            ),
        );
    }

    public static function migrate_settings()
    {
        $saved = get_option(self::OPTION, null);
        $legacy = self::defaults()['customer'];
        $legacy[1]['strict'] = 1; $legacy[3]['strict'] = 1;
        // Only migrate the original customer schedule; preserve administrator customization.
        if (is_array($saved) && isset($saved['customer']) && $saved['customer'] == $legacy) {
            $saved['customer'] = self::defaults()['customer'];
            update_option(self::OPTION, $saved, false);
        }
    }

    public static function settings()
    {
        $saved = get_option(self::OPTION, null);
        if ($saved === null || $saved === false) { return self::defaults(); }
        $checked = self::validate_settings($saved);
        return is_wp_error($checked) ? self::defaults() : $checked;
    }

    public static function validate_settings($input)
    {
        $out = array();
        foreach (array('reseller', 'customer') as $group) {
            if (!is_array($input) || !isset($input[$group]) || !is_array($input[$group]) || count($input[$group]) !== 4) {
                return new WP_Error('loyalty_settings', 'هر گروه باید چهار سطح داشته باشد.');
            }
            $last_min = -1; $last_percent = -1;
            foreach (array_values($input[$group]) as $index => $row) {
                if (!is_array($row)) { return new WP_Error('loyalty_settings', 'ساختار سطح معتبر نیست.'); }
                $min = $row['min'] ?? null; $percent = $row['percent'] ?? null; $strict = $row['strict'] ?? null;
                if ((!is_string($min) && !is_int($min)) || !preg_match('/^(0|[1-9][0-9]{0,11})$/D', (string) $min)
                    || !is_scalar($percent) || !preg_match('/^(?:100(?:\.0{1,2})?|[0-9]{1,2}(?:\.[0-9]{1,2})?)$/D', (string) $percent)
                    || !in_array($strict, array(0, 1, '0', '1'), true)) {
                    return new WP_Error('loyalty_settings', 'مبلغ صحیح و درصد صفر تا صد با حداکثر دو رقم اعشار وارد کنید.');
                }
                $floor = (int) $min + (int) $strict;
                if (($index === 0 && $floor !== 0) || $floor <= $last_min || (float) $percent < $last_percent) {
                    return new WP_Error('loyalty_settings', 'سطح پایه باید از صفر شروع شود؛ آستانه‌ها صعودی و درصدها غیرکاهشی باشند.');
                }
                $out[$group][] = array('min' => (int) $min, 'strict' => (int) $strict, 'percent' => (float) $percent);
                $last_min = $floor; $last_percent = (float) $percent;
            }
        }
        return $out;
    }

    public static function clear_cache() { self::$ledger = array(); }

    private static function timestamp($value)
    {
        if (!is_string($value) || !preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/D', $value) || strpos($value, '0000-') === 0) { return 0; }
        try { return (new DateTimeImmutable($value, wp_timezone()))->getTimestamp(); } catch (Exception $e) { return 0; }
    }

    private static function qualifies($row, $reseller)
    {
        if (($row->status ?? '') !== 'approved' || strpos((string) ($row->submission_key ?? ''), 'referral-') === 0) { return false; }
        $source = (string) ($row->remote_source ?? '');
        if (in_array($row->type ?? '', array('new', 'renewal', 'bot_renewal', 'extra_volume'), true)) {
            if ($reseller || !in_array($source, array('', 'bot'), true)) { return false; }
            $payload = json_decode((string) ($row->remote_payload ?? ''), true);
            $method = is_array($payload) ? ($payload['payment_method'] ?? '') : '';
            if ($method !== '' && !in_array($method, array('card','bank_card','card_to_card'), true)) { return false; }
            return $method !== '' || !empty($row->attachment_id) || !empty($row->file_url);
        }
        if ($source === 'admin_wallet_adjustment') { return true; }
        if (!in_array($source, array('', 'bot_wallet_mirror'), true)) { return false; }
        // Older add-ons used the administrative adjustment method for purchases/refunds.
        $note = (string) ($row->admin_note ?? '');
        foreach (array('خرید سرور ', 'پرداخت سفارش پروکسی #', 'تمدید سفارش پروکسی #', 'بازگشت وجه سفارش پروکسی #') as $prefix) {
            if (strpos($note, $prefix) === 0) { return false; }
        }
        return true;
    }

    private static function tier($amount, array $tiers)
    {
        $level = 0;
        foreach ($tiers as $i => $row) {
            if ($amount >= $row['min'] + $row['strict']) { $level = $i; }
        }
        return $level;
    }

    /** Pure deterministic calculation; no writes, scheduling or user-provided prices. */
    public static function calculate(array $rows, $reseller, $manual, $first_purchase, array $settings, $now)
    {
        $cutoff = $now - self::DAYS * 86400;
        $events = array();
        foreach ($rows as $row) {
            $row = (object) $row;
            $at = self::timestamp($row->reviewed_at ?? '');
            if ($reseller && !$at) { $at = self::timestamp($row->created_at ?? ''); }
            if (!self::qualifies($row, $reseller) || $at <= 0 || $at > $now || (int) ($row->amount ?? 0) <= 0) { continue; }
            if (!in_array($row->type ?? '', array('wallet', 'wallet_admin_credit', 'wallet_admin_debit', 'new', 'renewal', 'bot_renewal', 'extra_volume'), true)) { continue; }
            $events[] = array('id' => (int) $row->id, 'at' => $at, 'amount' => (int) $row->amount, 'debit' => $row->type === 'wallet_admin_debit', 'origin' => strpos((string) ($row->submission_key ?? ''), 'bot:') === 0 ? 1 : 0, 'correctable' => in_array($row->type, array('wallet','wallet_admin_credit'), true));
        }
        usort($events, static function ($a, $b) { return ($a['at'] <=> $b['at']) ?: ($a['origin'] <=> $b['origin']) ?: ($a['id'] <=> $b['id']); });
        $credits = array();
        foreach ($events as $event) {
            if (!$event['debit']) { $credits[] = $event; continue; }
            // Corrections reduce the latest preceding eligible deposit first. Excess is
            // discarded, never applied to a later deposit or an ordinary purchase debit.
            $remaining = $event['amount'];
            for ($i = count($credits) - 1; $i >= 0 && $remaining > 0; $i--) {
                if (!$credits[$i]['correctable'] || $credits[$i]['at'] <= $event['at'] - self::DAYS * 86400) { continue; }
                $used = min($remaining, $credits[$i]['amount']);
                $credits[$i]['amount'] -= $used; $remaining -= $used;
            }
        }
        $credits = array_values(array_filter($credits, static function ($credit) use ($cutoff) { return $credit['at'] > $cutoff; }));
        $tiers = $settings[$reseller ? 'reseller' : 'customer'];
        $total = 0; $largest = 0; $level = 0; $expires = null; $source_id = null;
        foreach ($credits as $credit) {
            $total += $credit['amount']; $largest = max($largest, $credit['amount']);
            if ($reseller) {
                $candidate = self::tier($credit['amount'], $tiers);
                $until = $credit['at'] + self::DAYS * 86400;
                if ($candidate > $level || ($candidate === $level && $candidate > 0 && $until > (int) $expires)) {
                    $level = $candidate; $expires = $candidate > 0 ? $until : null; $source_id = $candidate > 0 ? $credit['id'] : null;
                }
            }
        }
        if (!$reseller) {
            $level = self::tier($total, $tiers);
            // Find when expiring deposits first drop the customer below the current tier.
            if ($level > 0) {
                $remaining = $total;
                foreach ($credits as $credit) {
                    $remaining -= $credit['amount'];
                    if (self::tier($remaining, $tiers) < $level) { $expires = $credit['at'] + self::DAYS * 86400; break; }
                }
            }
        }
        $automatic = (float) $tiers[$level]['percent'];
        $has_manual = $manual !== null && $manual !== '';
        $effective = $has_manual ? (float) max(0, min(100, (float) $manual)) : $automatic;
        $stars = $reseller || $level > 0 ? $level + 1 : ($first_purchase ? 1 : 0);
        if ($has_manual) {
            $stars = $reseller || $first_purchase || $effective > 0 ? 1 : 0;
            foreach ($tiers as $i => $tier) {
                if ($i > 0 && (!$reseller || $effective > 0) && $effective >= (float) $tier['percent']) { $stars = $i + 1; }
            }
        }
        return array('kind' => $reseller ? 'reseller' : 'customer', 'level' => $level,
            'stars' => $stars,
            'percent' => $effective,
            'automatic_percent' => $automatic, 'source' => $has_manual ? 'manual' : 'automatic',
            'expires_at' => $has_manual ? null : $expires, 'level_expires_at' => $expires,
            'source_receipt_id' => $source_id, 'total' => $total, 'largest' => $largest);
    }

    public static function profile($user_id, $account = null)
    {
        global $wpdb;
        $db = self::$db ?: new IPSVP_DB(); $tables = $db->tables();
        if ($account === null) { $account = IPSVP_Reseller_Store::account($user_id); }
        if (!isset(self::$ledger[$user_id])) {
            $rows = $wpdb->get_results($wpdb->prepare("SELECT id,type,amount,status,remote_source,submission_key,admin_note,created_at,reviewed_at,remote_payload,attachment_id,file_url FROM {$tables['receipts']} WHERE user_id=%d AND status='approved' AND type IN ('wallet','wallet_admin_credit','wallet_admin_debit','new','renewal','bot_renewal','extra_volume') ORDER BY id ASC", (int) $user_id));
            $first = (bool) $wpdb->get_var($wpdb->prepare("SELECT id FROM {$tables['orders']} WHERE user_id=%d AND status IN ('created','active','on_hold','disabled','volume_finished','time_finished','delivered','completed','awaiting_assignment','cancelled') AND payment_status IN ('approved','paid','wallet_paid','crypto_paid','payment_paid') LIMIT 1", (int) $user_id));
            if (!$first && function_exists('ips_server_tables')) {
                $server = ips_server_tables();
                $first = (bool) $wpdb->get_var($wpdb->prepare("SELECT id FROM {$server['orders']} WHERE user_id=%d AND order_status IN ('invoice_paid','active','delivered') AND payment_status='payment_paid' LIMIT 1", (int) $user_id));
            }
            if (function_exists('ips_server_tables')) {
                $server = ips_server_tables();
                $payments = $wpdb->get_results($wpdb->prepare("SELECT id,amount_irt AS amount,status,created_at,approved_at AS reviewed_at,receipt_attachment_id AS attachment_id,receipt_file_url AS file_url FROM {$server['payments']} WHERE user_id=%d AND status='approved' AND method='card' ORDER BY id ASC", (int) $user_id));
                foreach ($payments ?: array() as $payment) {
                    $payment->type = 'new';
                    $payment->remote_source = '';
                    $payment->remote_payload = '{"payment_method":"card"}';
                    $rows[] = $payment;
                }
            }
            self::$ledger[$user_id] = array($rows ?: array(), $first);
        }
        list($rows, $first) = self::$ledger[$user_id];
        $reseller = $account && $account->status === 'approved';
        $user = $reseller ? null : $db->get_user_by_id((int) $user_id);
        if (!$reseller && class_exists('IPSVP_Customer_Loyalty_Sync')) {
            list($rows, $first) = IPSVP_Customer_Loyalty_Sync::merge($user, $rows, $first);
        }
        $manual = $reseller ? (property_exists($account, 'manual_discount_percent') ? $account->manual_discount_percent : $account->discount_percent) : ($user->manual_discount_percent ?? null);
        return self::calculate($rows, $reseller, $manual, $first, self::settings(), time());
    }

    public static function decorate($account)
    {
        if (!$account || $account->status !== 'approved') { return $account; }
        $copy = clone $account;
        $copy->manual_discount_percent = $account->discount_percent;
        $copy->loyalty = self::profile($account->user_id, $account);
        $copy->discount_percent = $copy->loyalty['percent'];
        return $copy;
    }

    public static function badge(array $profile)
    {
        $stars = max(0, min(4, (int) $profile['stars']));
        $html = '<div class="ipsvp-level" data-account-level="' . $stars . '"><span class="ipsvp-level-stars" role="img" aria-label="' . esc_attr($stars . ' ستاره از ۴') . '">';
        for ($i = 1; $i <= 4; $i++) { $html .= '<span aria-hidden="true" class="' . ($i <= $stars ? 'is-earned' : '') . '">★</span>'; }
        $html .= '</span><strong>' . esc_html(number_format_i18n($profile['percent'], $profile['percent'] == (int) $profile['percent'] ? 0 : 2)) . '٪ تخفیف</strong>';
        if ($profile['source'] === 'manual') { $html .= '<small>تخفیف اختصاصی</small>'; }
        elseif ($profile['expires_at']) { $html .= '<small>اعتبار سطح تا <bdi dir="ltr">' . esc_html(wp_date('Y/m/d H:i', $profile['expires_at'], wp_timezone())) . '</bdi></small>'; }
        else { $html .= '<small>سطح پایه</small>'; }
        return $html . '</div>';
    }

    public static function hero($html, $phone, $balance, $wallet_label)
    {
        $user = self::$db->get_user_by_phone($phone);
        if (!$user || !empty($user->is_blocked)) { return $html; }
        return preg_replace_callback('~</h2>~', static function () use ($user) { return '</h2>' . self::badge(self::profile($user->id)); }, $html, 1);
    }

    public static function menu()
    {
        add_submenu_page('ipsvp', 'سطح حساب و تخفیف', 'سطح حساب و تخفیف', 'manage_options', 'ipsvp-loyalty', array(__CLASS__, 'settings_page'));
    }
    public static function tabs($tabs) { $tabs['loyalty'] = 'سطح و تخفیف'; return $tabs; }

    public static function save_override($user_id, $value)
    {
        global $wpdb;
        if (!is_string($value) || ($value !== '' && !preg_match('/^(?:100(?:\.0{1,2})?|[0-9]{1,2}(?:\.[0-9]{1,2})?)$/D', $value))) {
            return new WP_Error('invalid_discount', 'درصد بین صفر تا صد وارد کنید یا فیلد را خالی بگذارید.');
        }
        $user = self::$db->get_user_by_id((int) $user_id);
        if (!$user) { return new WP_Error('missing_user', 'کاربر پیدا نشد.'); }
        $lock = IPSVP_Reseller_Store::lock($user->id);
        if (is_wp_error($lock)) { return $lock; }
        $account = IPSVP_Reseller_Store::account($user->id);
        $reseller = $account && $account->status === 'approved';
        $tables = self::$db->tables();
        $table = $reseller ? IPSVP_Reseller_Store::table('accounts') : $tables['users'];
        $field = $reseller ? 'discount_percent' : 'manual_discount_percent';
        $where = $reseller ? array('user_id' => $user->id) : array('id' => $user->id);
        $old = $reseller ? $account->discount_percent : ($user->manual_discount_percent ?? null);
        $value = $value === '' ? null : $value;
        if ($wpdb->update($table, array($field => $value), $where) === false) { return new WP_Error('discount_save_failed', 'تخفیف ذخیره نشد.'); }
        self::clear_cache();
        IPSVP_Reseller_Store::audit(self::$db, $user, 'تغییر تخفیف ثابت حساب', array('old_discount' => $old, 'discount' => $value));
        return true;
    }

    public static function handle_override()
    {
        if (!isset($_POST['ipsvp_save_user_discount'])) { return; }
        if (!current_user_can('manage_options')) { wp_die('دسترسی کافی نیست.', '', array('response' => 403)); }
        check_admin_referer('ipsvp_user_discount');
        $id = $_POST['user_id'] ?? '';
        $result = is_scalar($id) && ctype_digit((string) $id) ? self::save_override((int) $id, wp_unslash($_POST['manual_discount_percent'] ?? '')) : new WP_Error('missing_user', 'کاربر معتبر نیست.');
        self::$notice = '<div class="notice ' . (is_wp_error($result) ? 'notice-error' : 'notice-success') . '"><p>' . esc_html(is_wp_error($result) ? $result->get_error_message() : 'تخفیف حساب ذخیره شد.') . '</p></div>';
    }

    public static function admin_user($user, $unused = null, $unused2 = null)
    {
        $p = self::profile($user->id);
        $account = IPSVP_Reseller_Store::account($user->id);
        $manual = $account && $account->status === 'approved' ? $account->discount_percent : ($user->manual_discount_percent ?? null);
        echo '<div class="ipsvp-tab-panel" data-user-panel="loyalty"><h3>سطح حساب و تخفیف</h3>' . self::$notice . self::badge($p);
        $url = add_query_arg(array('page' => 'ipsvp-users', 'view' => $user->id, 'ipsvp_tab' => 'loyalty'), admin_url('admin.php'));
        echo '<form class="ipsvp-admin-form" method="post" action="' . esc_url($url) . '">';
        wp_nonce_field('ipsvp_user_discount');
        echo '<input type="hidden" name="user_id" value="' . (int) $user->id . '"><label>تخفیف ثابت حساب (درصد)<input type="number" name="manual_discount_percent" min="0" max="100" step="0.01" placeholder="خالی = پلکانی" value="' . esc_attr($manual) . '"></label><p>خالی: محاسبه پلکانی؛ صفر: بدون تخفیف. درصد ثابت برای خریدهای بعدی اعمال می‌شود.</p><button class="button button-primary" name="ipsvp_save_user_discount" value="1">ذخیره تخفیف حساب</button></form>';
        echo '<div class="ipsvp-admin-detail-grid"><p><strong>تراکنش معتبر ۳۰ روز اخیر</strong><br>' . esc_html(number_format_i18n($p['total'])) . ' تومان</p><p><strong>بزرگ‌ترین تراکنش معتبر</strong><br>' . esc_html(number_format_i18n($p['largest'])) . ' تومان</p><p><strong>تخفیف خودکار سطح</strong><br>' . esc_html(number_format_i18n($p['automatic_percent'], 2)) . '٪</p></div>';
        echo '<p>در حالت دستی، ستاره‌ها بر اساس درصد تخفیف فعال و پلکان همان گروه نمایش داده می‌شوند.</p><a class="button" href="' . esc_url(admin_url('admin.php?page=ipsvp-loyalty')) . '">تنظیم پلکان‌ها</a></div>';
    }

    public static function settings_page()
    {
        if (!current_user_can('manage_options')) { wp_die('دسترسی کافی نیست.'); }
        wp_enqueue_style('ipsvp-admin'); $notice = '';
        if (isset($_POST['ipsvp_loyalty_save'])) {
            check_admin_referer('ipsvp_loyalty_save');
            $data = self::validate_settings(wp_unslash($_POST['loyalty'] ?? null));
            if (is_wp_error($data)) { $notice = '<div class="notice notice-error"><p>' . esc_html($data->get_error_message()) . '</p></div>'; }
            else {
                update_option(self::OPTION, $data, false); self::clear_cache();
                $notice = '<div class="notice notice-success"><p>پلکان‌ها ذخیره شدند.</p></div>';
            }
        }
        $settings = self::settings();
        echo '<div class="wrap ipsvp-admin" dir="rtl"><h1>سطح حساب و تخفیف</h1>' . $notice . '<form method="post" class="ipsvp-admin-form">';
        wp_nonce_field('ipsvp_loyalty_save');
        foreach (array('reseller' => 'همکار فروش — هر شارژ به‌صورت مستقل', 'customer' => 'کاربر عادی — مجموع پرداخت‌های تأییدشده') as $group => $label) {
            echo '<section class="ipsvp-detail"><h2>' . esc_html($label) . '</h2><table class="widefat"><thead><tr><th>سطح</th><th>مبلغ (تومان)</th><th>مرز مبلغ</th><th>تخفیف (درصد)</th></tr></thead><tbody>';
            foreach ($settings[$group] as $i => $row) {
                $prefix = 'loyalty[' . $group . '][' . $i . ']';
                echo '<tr><td>' . ($i + 1) . ' ستاره' . ($i === 0 && $group === 'customer' ? ' پس از اولین خرید' : '') . '</td><td><input aria-label="مبلغ سطح ' . ($i + 1) . '" type="number" min="0" max="999999999999" step="1" required name="' . esc_attr($prefix . '[min]') . '" value="' . esc_attr($row['min']) . '"' . ($i === 0 ? ' readonly' : '') . '></td><td><select aria-label="مرز مبلغ سطح ' . ($i + 1) . '" name="' . esc_attr($prefix . '[strict]') . '"><option value="0" ' . selected($row['strict'], 0, false) . '>از این مبلغ</option><option value="1" ' . selected($row['strict'], 1, false) . '>بیشتر از این مبلغ</option></select></td><td><input aria-label="درصد سطح ' . ($i + 1) . '" type="number" min="0" max="100" step="0.01" required name="' . esc_attr($prefix . '[percent]') . '" value="' . esc_attr($row['percent']) . '"></td></tr>';
            }
            echo '</tbody></table></section>';
        }
        echo '<div class="ipsvp-detail"><p>برای کاربر عادی، شارژ کیف پول و رسیدهای تأییدشده خرید، تمدید و حجم اضافه در ۳۰ روز اخیر جمع می‌شوند. پرداخت از کیف پول دوباره شمرده نمی‌شود. همکار همچنان بر اساس هر شارژ مستقل محاسبه می‌شود. کسر اصلاحی مدیریت فقط از شارژ کیف پول کم می‌شود.</p><p>تخفیف روی خرید، تمدید و حجم اضافه کانفیگ اشتراکی اعمال می‌شود. فیلد خالی تخفیف حساب یعنی خودکار؛ صفر یعنی تخفیف دستی صفر درصد. تغییر پلکان‌ها از همین لحظه روی قیمت‌گذاری جدید اعمال می‌شود.</p><button type="submit" class="button button-primary" name="ipsvp_loyalty_save" value="1">ذخیره پلکان‌ها</button></div></form></div>';
    }
}

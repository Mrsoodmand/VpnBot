<?php
/**
 * Shared authentication UI renderer.
 *
 * @package IPSabet_PasarGuard_Shop
 */

defined('ABSPATH') || exit;

final class IPSVP_Auth_Renderer
{
    public static function customer_box($phone, $user = null)
    {
        $phone = trim((string) $phone);
        if ($phone === '') {
            return '';
        }

        if (!$user && class_exists('IPSVP_DB')) {
            $db = new IPSVP_DB();
            $phone = $db->normalize_phone($phone);
            $user = $phone ? $db->get_user_by_phone($phone) : null;
        }

        $display_phone = self::display_phone($phone);
        $name = '';
        if ($user) {
            $name = !empty($user->name) ? (string) $user->name : (!empty($user->bot_first_name) ? (string) $user->bot_first_name : '');
        }

        $html = '<div class="ipspla-login-required ipsvp-auth-required-box ipsvp-customer-info-box">';
        $html .= '<div><h3>اطلاعات خریدار</h3><p>سفارش با حساب کاربری زیر ثبت می‌شود.</p></div>';
        $html .= '<div class="ipsvp-customer-info-values">';
        if ($name !== '') {
            $html .= '<div><span>نام کاربری</span><strong>' . esc_html($name) . '</strong></div>';
        }
        $html .= '<div><span>شماره تماس کاربری</span><strong dir="ltr">' . esc_html($display_phone) . '</strong></div>';
        $html .= '</div></div>';
        return $html;
    }

    public static function required_box($args = array())
    {
        $args = wp_parse_args(is_array($args) ? $args : array(), array(
            'title' => 'برای تکمیل خرید وارد حساب کاربری شوید',
            'description' => 'می‌توانید انتخاب‌های موردنظر را انجام دهید. برای ثبت سفارش و پرداخت، ابتدا وارد حساب کاربری شوید.',
            'button' => 'ورود به حساب کاربری',
            'modal_id' => 'ipspla-auth-modal',
        ));
        return '<div class="ipspla-login-required ipsvp-auth-required-box"><div><h3>' . esc_html($args['title']) . '</h3><p>' . esc_html($args['description']) . '</p></div><a href="#' . esc_attr($args['modal_id']) . '" class="ipsvp-btn ipspla-auth-open" data-ipspla-open-auth data-ipsvp-open-auth>' . esc_html($args['button']) . '</a></div>';
    }

    public static function modal($args = array())
    {
        $args = wp_parse_args(is_array($args) ? $args : array(), array(
            'modal_id' => 'ipspla-auth-modal',
            'title' => 'ورود به حساب کاربری',
            'button' => 'ادامه',
            'context' => 'config',
        ));
        $context = IPSVP_Captcha_Service::normalize_context($args['context']);
        ob_start();
        echo '<div class="ipsvp ipsvp-auth-modal-scope"><div class="ipsvp-modal ipspla-auth-modal" id="' . esc_attr($args['modal_id']) . '">';
        echo '<a class="ipsvp-modal-bg" href="#"></a><div class="ipsvp-modal-card ipspla-auth-modal-card"><a class="ipsvp-modal-close ipspla-auth-modal-close proxy-auth-modal-close" href="#" aria-label="بستن">×</a>';
        echo '<div class="ipsvp-auth-shell" data-ipsvp-auth><div class="ipsvp-auth-card">';
        echo '<div class="ipsvp-auth-head"><div class="ipsvp-auth-mark">IP</div><div><h3>' . esc_html($args['title']) . '</h3></div></div>';
        echo '<form method="post" class="ipsvp-auth-form" data-ipsvp-auth-form>';
        wp_nonce_field('ipsvp_panel_login');
        echo '<input type="hidden" name="ipsvp_action" value="panel_login"><input type="hidden" name="ipsvp_login_method" value="phone"><input type="hidden" name="step" value="phone"><input type="hidden" name="ipsvp_captcha_context" value="' . esc_attr($context) . '">';
        echo '<label class="ipsvp-auth-field"><span>شماره موبایل</span><input required name="ipsvp_panel_phone" type="tel" value="" placeholder="09123456789" autocomplete="tel" inputmode="numeric" pattern="09[0-9]{9}" maxlength="11"></label>';
        echo IPSVP_Captcha_Service::render_captcha_field($context, 'phone', self::otp_possible());
        echo '<button class="ipsvp-auth-primary" type="submit">' . esc_html($args['button']) . '</button>';
        echo '</form></div></div></div></div></div>';
        return ob_get_clean();
    }

    private static function otp_possible()
    {
        $settings = IPSVP_Settings::get();
        return !empty($settings['otp_login_enabled'])
            && (string) $settings['otp_login_enabled'] === '1'
            && !empty($settings['smsir_api_key'])
            && !empty($settings['smsir_template_id']);
    }

    private static function display_phone($phone)
    {
        $phone = trim((string) $phone);
        if (strpos($phone, '+98') === 0) {
            return '0' . substr($phone, 3);
        }
        if (strpos($phone, '0098') === 0) {
            return '0' . substr($phone, 4);
        }
        return $phone;
    }
}

<?php
/** Dashboard, application review, API credentials and legacy checkout integration. */
defined('ABSPATH') || exit;

final class IPSVP_Reseller
{
    private static $instance;
    private $db;
    private $api;
    private $service;
    private $rest;
    private $notice = '';
    private $secret = '';
    private $last_operation;

    public function __construct($db, $api)
    {
        self::$instance = $this;
        $this->db = $db;
        $this->api = $api;
        $this->service = new IPSVP_Reseller_Service($db, $api);
        $this->rest = new IPSVP_Reseller_API($db, $this->service);
        add_filter('ipsvp_panel_nav_items', array($this, 'navigation'), 100, 3);
        add_filter('ipsvp_panel_current_tab', array($this, 'current_tab'), 100, 2);
        add_filter('ipsvp_panel_hero', array($this, 'hero'), 10, 4);
        add_filter('ipsvp_panel_allowed_tabs', array($this, 'allowed_tabs'), 100, 2);
        add_filter('ipsvp_panel_render_tab', array($this, 'panel'), 10, 3);
        add_filter('ipsvp_panel_notification_counts', array($this, 'notification_counts'), 10, 3);
        add_action('ipsvp_panel_mark_notifications_seen', array($this, 'mark_seen'), 10, 3);
        add_filter('ipsvp_admin_user_detail_tabs', array($this, 'tabs'));
        add_action('ipsvp_admin_user_detail_extra_panels', array($this, 'admin_user'), 10, 3);
        add_action('template_redirect', array($this, 'handle_front'));
        // Register after the parent menu so WordPress derives the correct page hook.
        add_action('admin_menu', array($this, 'menu'), 20);
        add_action('admin_init', array($this, 'handle_admin'));
        add_action('wp_enqueue_scripts', array($this, 'assets'));
        add_shortcode('ips_reseller_api_docs', array('IPSVP_Reseller_Docs', 'shortcode'));
        if (!empty($_COOKIE[IPSVP_Session::cookie_name()]) && !defined('DONOTCACHEPAGE')) { define('DONOTCACHEPAGE', true); }
    }

    public function assets()
    {
        wp_enqueue_style('ipsvp-palette', IPSVP_PLUGIN_URL . 'assets/css/palette.css', array(), IPSabet_PasarGuard_Shop::VERSION);
        wp_enqueue_style('ipsvp-reseller', IPSVP_PLUGIN_URL . 'assets/css/reseller.css', array('ipsvp-palette'), IPSabet_PasarGuard_Shop::VERSION);
        wp_enqueue_script('ipsvp-reseller-workspace', IPSVP_PLUGIN_URL . 'assets/js/reseller-workspace.js', array(), IPSabet_PasarGuard_Shop::VERSION, true);
        wp_enqueue_script('ipsvp-reseller-docs', IPSVP_PLUGIN_URL . 'assets/js/reseller-docs.js', array(), IPSabet_PasarGuard_Shop::VERSION, true);
    }

    public static function current_user()
    {
        if (!self::$instance) { return null; }
        $db = self::$instance->db;
        $phone = IPSVP_Session::get_phone($db);
        return $phone ? $db->get_user_by_phone($phone) : null;
    }

    public static function current_account()
    {
        $user = self::current_user();
        return $user && empty($user->is_blocked) ? IPSVP_Reseller_Store::approved($user->id) : false;
    }

    public static function price($amount, $service_type = 'shared')
    {
        if ($service_type !== 'shared' || (is_admin() && !(function_exists('wp_doing_ajax') && wp_doing_ajax())) || (defined('REST_REQUEST') && REST_REQUEST)) { return (int) $amount; }
        $account = self::current_account();
        if ($account) { return IPSVP_Reseller_Store::discount($amount, $account->discount_percent); }
        $user = self::current_user();
        if (!$user || !empty($user->is_blocked) || !class_exists('IPSVP_Loyalty')) { return (int) $amount; }
        $profile = IPSVP_Loyalty::profile($user->id);
        return IPSVP_Reseller_Store::discount($amount, $profile['percent']);
    }

    public static function shop_panel($service_type)
    {
        if ($service_type !== 'shared' || !self::current_account()) { return ''; }
        return self::$instance->panel('', 'reseller-create', self::current_user()->phone);
    }

    /** Legacy wallet forms also use the same journal and pricing as the API. */
    public static function legacy_wallet($action, $phone, $nonce_action, array $input)
    {
        if (!self::current_account()) { return null; }
        $self = self::$instance;
        $user = self::current_user();
        if (!$user || $user->phone !== $phone || !empty($user->is_blocked)) { return '<div class="ipsvp-alert">نشست معتبر لازم است.</div>'; }
        $plan = !empty($input['plan_id']) ? $self->db->get_plan($input['plan_id']) : null;
        $order = !empty($input['order_id']) ? $self->db->get_order($input['order_id']) : null;
        if (($plan && $self->db->normalize_service_type($plan->service_type) !== 'shared') || ($order && $self->db->order_service_type($order) !== 'shared')) { return null; }
        if (!isset($_POST['_wpnonce']) || !is_string($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], $nonce_action)) { return '<div class="ipsvp-alert">درخواست نامعتبر است.</div>'; }
        $key = isset($_POST['ipsvp_submission_key']) && is_string($_POST['ipsvp_submission_key']) ? wp_unslash($_POST['ipsvp_submission_key']) : '';
        $result = $self->service->execute($user, $action, $input, $key, 'panel');
        return $self->result_notice($result);
    }

    public static function wallet_only_notice($plan_id = 0, $order_id = 0)
    {
        if (!self::current_account()) { return ''; }
        $db = self::$instance->db;
        $plan = $plan_id ? $db->get_plan($plan_id) : null;
        $order = $order_id ? $db->get_order($order_id) : null;
        if (($plan && $db->normalize_service_type($plan->service_type) === 'shared') || ($order && $db->order_service_type($order) === 'shared')) {
            return '<div class="ipsvp-alert">خرید و تمدید نمایندگی از کیف پول انجام می‌شود. روش کیف پول یا تب نمایندگی را انتخاب کنید.</div>';
        }
        return '';
    }

    public static function account_for_phone($phone)
    {
        if (!self::$instance || !$phone) { return false; }
        $user = self::$instance->db->get_user_by_phone($phone);
        return $user && empty($user->is_blocked) ? IPSVP_Reseller_Store::approved($user->id) : false;
    }

    public function tabs($tabs) { $tabs['reseller'] = 'نمایندگی و وب‌سرویس'; return $tabs; }

    public function navigation($tabs, $active = '', $phone = '')
    {
        if (!self::account_for_phone($phone)) { return $this->tabs($tabs); }
        $items = array('dashboard' => 'داشبورد', 'reseller-create' => 'ساخت سریع کانفیگ', 'orders' => 'سفارشات',
            'wallet' => 'کیف پول', 'reseller-operations' => 'گردش عملیات', 'reseller-api' => 'تنظیمات وب‌سرویس',
            'reseller-docs' => 'مستندات', 'profile' => 'حساب من');
        // Keep access to existing add-on services, but referral is not part of the reseller workspace.
        foreach ($tabs as $key => $label) {
            if (!isset($items[$key]) && !in_array($key, array('reseller', 'referral'), true)) { $items[$key] = $label; }
        }
        return $items;
    }

    public function allowed_tabs($tabs, $phone = '')
    {
        $tabs[] = 'reseller';
        if (self::account_for_phone($phone)) {
            $tabs = array_merge(array_diff($tabs, array('referral')), array('reseller-create', 'reseller-api', 'reseller-docs', 'reseller-operations'));
        }
        return array_values(array_unique($tabs));
    }

    public function current_tab($tab, $phone)
    {
        return $tab === 'reseller' && self::account_for_phone($phone) ? 'dashboard' : $tab;
    }

    public function hero($html, $phone, $balance, $wallet_label)
    {
        $account = self::account_for_phone($phone);
        if (!$account) { return $html; }
        ob_start();
        include IPSVP_PLUGIN_DIR . 'templates/reseller-hero.php';
        return ob_get_clean();
    }

    public function notification_counts($counts, $phone, $db)
    {
        $counts[self::account_for_phone($phone) ? 'reseller-operations' : 'reseller'] = $db->count_unread_notifications($phone, 'reseller');
        return $counts;
    }

    public function mark_seen($tab, $phone, $db)
    {
        if (in_array($tab, array('reseller', 'reseller-operations'), true)) { $db->mark_notifications_seen($phone, 'reseller'); }
    }

    public static function dashboard_url($tab = 'reseller')
    {
        $settings = IPSVP_Settings::get();
        return add_query_arg('ipsvp_tab', $tab, !empty($settings['dashboard_url']) ? $settings['dashboard_url'] : home_url('/dashboard/'));
    }

    private function nonce_action($user)
    {
        return 'ipsr_panel_' . $user->id . '_' . hash('sha256', (string) ($_COOKIE[IPSVP_Session::cookie_name()] ?? ''));
    }

    private function form_start($user, $action, $tab = '')
    {
        if (!$tab) { $tab = $action === 'apply' ? 'reseller' : ($action === 'operation' ? 'reseller-create' : 'reseller-api'); }
        echo '<form method="post" class="ipsr-form" action="' . esc_url(self::dashboard_url($tab)) . '">';
        wp_nonce_field($this->nonce_action($user), 'ipsr_nonce');
        echo '<input type="hidden" name="ipsr_action" value="' . esc_attr($action) . '">';
    }

    private function result_notice($result)
    {
        if (is_wp_error($result)) { return '<div class="ipsvp-alert" role="alert">' . esc_html($result->get_error_message()) . '</div>'; }
        if (!$result) { return '<div class="ipsvp-alert">نتیجه نامشخص است؛ با پشتیبانی تماس بگیرید.</div>'; }
        $message = $result->state === 'succeeded' ? 'عملیات با موفقیت انجام شد.' : 'این عملیات ثبت شده است؛ وضعیت آن را در جدول تراکنش‌ها پیگیری کنید. درخواست تازه ثبت نکنید.';
        return '<div class="ipsvp-success" role="status">' . esc_html($message . ' شماره پیگیری: ' . $result->id) . '</div>';
    }

    public function handle_front()
    {
        $user = self::current_user();
        if ($user) { nocache_headers(); }
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || empty($_POST['ipsr_action'])) { return; }
        if (!is_string($_POST['ipsr_action']) || !isset($_POST['ipsr_nonce']) || !is_string($_POST['ipsr_nonce']) || !$user || !empty($user->is_blocked) || !wp_verify_nonce($_POST['ipsr_nonce'], $this->nonce_action($user))) {
            $this->notice = '<div class="ipsvp-alert">نشست یا اعتبار فرم منقضی شده است؛ دوباره وارد شوید.</div>'; return;
        }
        foreach (array('business_name','website','application_note','key_version','key_days','allowed_ips','operation','plan_id','country_id','order_id','gb','customer_reference','max_amount','idempotency_key') as $field) {
            if (isset($_POST[$field]) && !is_string($_POST[$field])) { $this->notice = '<div class="ipsvp-alert">ساختار فرم نامعتبر است.</div>'; return; }
        }
        $locked = IPSVP_Reseller_Store::lock($user->id);
        if (is_wp_error($locked)) { $this->notice = $this->result_notice($locked); return; }
        $action = sanitize_key(wp_unslash($_POST['ipsr_action']));
        try {
            $result = $this->front_action($user, $action);
            $this->notice = is_wp_error($result) ? $this->result_notice($result) : '<div class="ipsvp-success" role="status">' . esc_html((string) $result) . '</div>';
        } catch (Throwable $e) { $this->notice = '<div class="ipsvp-alert">ثبت تغییرات ناموفق بود؛ وضعیت حساب را بررسی کنید.</div>'; }
    }

    private function front_action($user, $action)
    {
        global $wpdb;
        $table = IPSVP_Reseller_Store::table('accounts');
        $user = $this->db->get_user_by_id($user->id);
        if (!$user || !empty($user->is_blocked)) { return IPSVP_Reseller_Store::error('forbidden', 'حساب در دسترس نیست.', 403); }
        $account = IPSVP_Reseller_Store::account($user->id);
        if ($action === 'apply') {
            if ($account && !in_array($account->status, array('rejected', 'customer'), true)) { return IPSVP_Reseller_Store::error('already_applied', 'درخواست قبلاً ثبت شده است یا حساب نیاز به بررسی مدیریت دارد.', 409); }
            $balance = IPSVP_Reseller_Store::balance($user, $this->db);
            if (is_wp_error($balance)) { return $balance; }
            if ($balance < IPSVP_Reseller_Store::MIN_BALANCE) { return IPSVP_Reseller_Store::error('balance_low', 'برای ثبت درخواست حداقل ۲ میلیون تومان موجودی لازم است.', 402); }
            $name = sanitize_text_field(wp_unslash($_POST['business_name'] ?? ''));
            if ($name === '' || strlen($name) > 191) { return IPSVP_Reseller_Store::error('business_name', 'نام کسب‌وکار را وارد کنید (حداکثر ۱۹۱ بایت).'); }
            $data = array('status' => 'pending', 'business_name' => $name,
                'website' => esc_url_raw(wp_unslash($_POST['website'] ?? ''), array('https', 'http')),
                'application_note' => sanitize_textarea_field(wp_unslash($_POST['application_note'] ?? '')),
                'requested_at' => $this->db->now(), 'review_note' => null, 'reviewed_at' => null, 'reviewed_by' => null);
            if (strlen($data['website']) > 255 || strlen($data['application_note']) > 4000) { return IPSVP_Reseller_Store::error('too_long', 'آدرس یا توضیحات بیش از حد طولانی است.'); }
            $ok = $account ? $wpdb->update($table, $data, array('user_id' => $user->id)) : $wpdb->insert($table, array_merge($data, array('user_id' => $user->id)));
            if ($ok === false) { return IPSVP_Reseller_Store::error('save_failed', 'درخواست ثبت نشد.', 503); }
            IPSVP_Reseller_Store::audit($this->db, $user, 'درخواست نمایندگی ثبت شد.');
            return 'درخواست ثبت شد و منتظر تأیید مدیریت است. مبلغی از کیف پول کسر نشد.';
        }
        if (!$account || $account->status !== 'approved') { return IPSVP_Reseller_Store::error('not_approved', 'نمایندگی شما فعال نیست.', 403); }
        if ($action === 'rotate_key') {
            if (!is_ssl()) { return IPSVP_Reseller_Store::error('https_required', 'ساخت کلید فقط روی HTTPS مجاز است.', 403); }
            if (!hash_equals((string) $account->key_hint, (string) ($_POST['key_version'] ?? ''))) { return 'کلید قبلاً تغییر کرده است. صفحه را تازه کنید.'; }
            $days = (int) ($_POST['key_days'] ?? 90);
            if (!in_array($days, array(30, 90, 365), true)) { return IPSVP_Reseller_Store::error('invalid_expiry', 'مدت اعتبار نامعتبر است.'); }
            $secret = 'ipsr_' . bin2hex(random_bytes(32));
            $ok = $wpdb->update($table, array('key_hash' => hash('sha256', $secret), 'key_hint' => substr($secret, -8),
                'key_created_at' => gmdate('Y-m-d H:i:s'), 'key_expires_at' => gmdate('Y-m-d H:i:s', time() + $days * DAY_IN_SECONDS)), array('user_id' => $user->id));
            if ($ok === false) { return IPSVP_Reseller_Store::error('save_failed', 'کلید ساخته نشد.', 503); }
            $this->secret = $secret;
            IPSVP_Reseller_Store::audit($this->db, $user, 'کلید وب‌سرویس تعویض شد.');
            return 'کلید جدید ساخته و کلید قبلی فوراً لغو شد. کلید جدید فقط همین بار نمایش داده می‌شود.';
        }
        if ($action === 'revoke_key') {
            $ok = $wpdb->update($table, array('key_hash' => null, 'key_hint' => null, 'key_expires_at' => null), array('user_id' => $user->id));
            if ($ok === false) { return IPSVP_Reseller_Store::error('save_failed', 'لغو کلید انجام نشد.', 503); }
            IPSVP_Reseller_Store::audit($this->db, $user, 'کلید وب‌سرویس لغو شد.');
            return 'دسترسی کلید قبلی لغو شد.';
        }
        if ($action === 'settings') {
            $ips = preg_split('/[\s,]+/', trim(wp_unslash($_POST['allowed_ips'] ?? '')), -1, PREG_SPLIT_NO_EMPTY);
            if (count($ips) > 20) { return IPSVP_Reseller_Store::error('invalid_ips', 'حداکثر ۲۰ IP مجاز است.'); }
            foreach ($ips as $ip) { if (!filter_var($ip, FILTER_VALIDATE_IP)) { return IPSVP_Reseller_Store::error('invalid_ips', 'IP نامعتبر است؛ هر IPv4 یا IPv6 را در یک خط بنویسید.'); } }
            if (false === $wpdb->update($table, array('allowed_ips' => implode("\n", array_unique($ips))), array('user_id' => $user->id))) { return IPSVP_Reseller_Store::error('save_failed', 'تنظیمات ذخیره نشد.', 503); }
            IPSVP_Reseller_Store::audit($this->db, $user, 'فهرست IP مجاز تغییر کرد.');
            return 'تنظیمات وب‌سرویس ذخیره شد.';
        }
        if ($action === 'operation') {
            $operation = sanitize_key(wp_unslash($_POST['operation'] ?? ''));
            $input = array();
            foreach (array('plan_id', 'country_id', 'order_id', 'gb', 'customer_reference', 'max_amount') as $field) {
                if (isset($_POST[$field]) && $_POST[$field] !== '') { $input[$field] = wp_unslash($_POST[$field]); }
            }
            $result = $this->service->execute($user, $operation, $input, wp_unslash($_POST['idempotency_key'] ?? ''), 'panel');
            if (is_wp_error($result)) { return $result; }
            $this->last_operation = $result;
            return $result && $result->state === 'succeeded' ? 'عملیات موفق بود؛ شماره پیگیری: ' . $result->id : 'عملیات نیاز به بررسی دارد؛ شماره پیگیری: ' . ($result->id ?? 'نامشخص') . '. درخواست تازه ثبت نکنید.';
        }
        return IPSVP_Reseller_Store::error('invalid_action', 'عملیات نامعتبر است.');
    }

    public function panel($html, $tab, $phone)
    {
        $routes = array('dashboard', 'reseller', 'reseller-create', 'reseller-api', 'reseller-docs', 'reseller-operations');
        if (!in_array($tab, $routes, true)) { return $html; }
        $user = $this->db->get_user_by_phone($phone);
        if (!$user || !empty($user->is_blocked)) { return $html; }
        $account = IPSVP_Reseller_Store::account($user->id);
        $approved = $account && $account->status === 'approved';
        if ($approved) { $account = IPSVP_Reseller_Store::approved($user->id); }
        if (!$approved && $tab !== 'reseller') { return $html; }
        if ($approved && $tab === 'reseller') { $tab = 'dashboard'; }
        $balance = in_array($tab, array('reseller', 'reseller-create'), true) ? IPSVP_Reseller_Store::balance($user, $this->db) : null;
        ob_start();
        if (!$approved) {
            include IPSVP_PLUGIN_DIR . 'templates/reseller-panel.php';
        } else {
            echo '<section class="ipsr ipsr-workspace" dir="rtl" data-ipsr-workspace>';
            echo wp_kses_post($this->notice);
            if ($tab === 'dashboard') {
                $period = isset($_GET['rs_period']) && is_string($_GET['rs_period']) ? (int) $_GET['rs_period'] : 30;
                $report = IPSVP_Reseller_Reports::summary($this->db, $user->id, $period);
                $operations = IPSVP_Reseller_Reports::operations($user->id, 1, 5);
                include IPSVP_PLUGIN_DIR . 'templates/reseller-dashboard.php';
            } elseif ($tab === 'reseller-create') {
                $plans = $this->rest->plans($user);
                $countries = $this->rest->countries();
                global $wpdb;
                $unresolved = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . IPSVP_Reseller_Store::table('operations') . " WHERE user_id=%d AND state IN ('reserved','processing','manual_review','refund_review')", $user->id));
                include IPSVP_PLUGIN_DIR . 'templates/reseller-create.php';
            } elseif ($tab === 'reseller-api') {
                include IPSVP_PLUGIN_DIR . 'templates/reseller-api-settings.php';
            } elseif ($tab === 'reseller-docs') {
                echo IPSVP_Reseller_Docs::shortcode();
            } else {
                $page = IPSVP_Reseller_Service::integer($_GET['rs_page'] ?? 1, 1, 1000000);
                $operations = IPSVP_Reseller_Reports::operations($user->id, $page ?: 1);
                include IPSVP_PLUGIN_DIR . 'templates/reseller-operations.php';
            }
            echo '</section>';
        }
        return ob_get_clean();
    }

    public static function label($state)
    {
        $labels = array('customer' => 'کاربر عادی', 'pending' => 'در انتظار بررسی', 'approved' => 'تأییدشده', 'rejected' => 'ردشده', 'suspended' => 'تعلیق‌شده',
            'reserved' => 'ثبت و رزرو مبلغ', 'processing' => 'در حال پردازش', 'manual_review' => 'نیازمند بررسی مدیریت',
            'refund_review' => 'بررسی بازپرداخت', 'succeeded' => 'موفق', 'failed' => 'ناموفق / بدون کسر', 'refunded' => 'بازپرداخت‌شده',
            'purchase' => 'خرید', 'renew' => 'تمدید', 'extra-volume' => 'حجم اضافه', 'disable' => 'توقف', 'enable' => 'فعال‌سازی');
        return $labels[$state] ?? $state;
    }

    public function menu()
    {
        add_submenu_page('ipsvp', 'نمایندگان و وب‌سرویس', 'نمایندگان و وب‌سرویس', 'manage_options', 'ipsvp-resellers', array($this, 'admin_page'));
    }

    public function admin_user($user, $active, $db)
    {
        if (!current_user_can('manage_options')) { return; }
        echo '<div class="ipsvp-tab-panel" data-user-panel="reseller">';
        echo wp_kses_post($this->notice);
        $this->admin_account_form($user);
        echo '</div>';
    }

    private function admin_account_form($user)
    {
        $a = IPSVP_Reseller_Store::account($user->id);
        echo '<h3>نمایندگی و وب‌سرویس</h3>';
        if (!$a) { echo '<p>این کاربر هنوز درخواست نمایندگی ثبت نکرده است. حداقل موجودی درخواست: ۲ میلیون تومان.</p>'; return; }
        echo '<div class="ipsvp-reseller-request"><strong>' . esc_html($a->business_name) . '</strong><span class="ipsvp-badge">' . esc_html(self::label($a->status)) . '</span><p>' . esc_html($a->application_note) . '</p></div>';
        $action_url = add_query_arg(array('page' => 'ipsvp-users', 'view' => $user->id, 'ipsvp_tab' => 'reseller'), admin_url('admin.php'));
        echo '<p>وب‌سایت: ' . esc_html($a->website ?: '—') . '</p><form class="ipsvp-admin-form ipsvp-reseller-review-form" method="post" action="' . esc_url($action_url) . '">';
        wp_nonce_field('ipsr_admin', 'ipsr_admin_nonce');
        echo '<input type="hidden" name="ipsr_admin_action" value="review"><input type="hidden" name="user_id" value="' . (int) $user->id . '">';
        echo '<p><label>وضعیت <select name="status">';
        foreach (array('pending', 'approved', 'customer', 'rejected', 'suspended') as $status) { echo '<option value="' . esc_attr($status) . '" ' . selected($a->status, $status, false) . '>' . esc_html(self::label($status)) . '</option>'; }
        echo '</select></label></p><p><label>تخفیف نمایندگی (درصد) <input type="number" name="discount_percent" min="0" max="100" step="0.01" placeholder="خودکار از تنظیمات" value="' . esc_attr($a->discount_percent) . '"></label></p>';
        echo '<p>خالی: پلکان خودکار؛ صفر: بدون تخفیف دستی. خرید، تمدید و حجم اشتراکی؛ تخفیف ۱۰۰٪ یعنی رایگان.</p>';
        if (class_exists('IPSVP_Loyalty')) { echo IPSVP_Loyalty::badge(IPSVP_Loyalty::profile($user->id, $a)); }
        echo '<p><label>توضیح تصمیم (قابل مشاهده برای کاربر)<br><textarea name="review_note" rows="3" cols="60" maxlength="2000">' . esc_textarea($a->review_note ?? '') . '</textarea></label></p>';
        echo '<p><label><input type="checkbox" name="revoke_key" value="1"> لغو کلید فعلی</label></p><button class="button button-primary">ذخیره تصمیم و تخفیف</button></form>';
    }

    public function handle_admin()
    {
        if (empty($_POST['ipsr_admin_action'])) { return; }
        if (!current_user_can('manage_options')) { wp_die('دسترسی کافی نیست.', '', array('response' => 403)); }
        check_admin_referer('ipsr_admin', 'ipsr_admin_nonce');
        $user = $this->db->get_user_by_id((int) ($_POST['user_id'] ?? 0));
        if (!$user) { $this->notice = '<div class="notice notice-error"><p>کاربر پیدا نشد.</p></div>'; return; }
        $locked = IPSVP_Reseller_Store::lock($user->id);
        try {
            $result = is_wp_error($locked) ? $locked : $this->admin_action($user, sanitize_key(wp_unslash($_POST['ipsr_admin_action'])));
        } catch (Throwable $e) { $result = IPSVP_Reseller_Store::error('storage_failed', 'ذخیره ناموفق بود؛ وضعیت تراکنش را بررسی کنید.', 503); }
        $this->notice = '<div class="notice ' . (is_wp_error($result) ? 'notice-error' : 'notice-success') . '"><p>' . esc_html(is_wp_error($result) ? $result->get_error_message() : $result) . '</p></div>';
    }

    private function admin_action($user, $action)
    {
        global $wpdb;
        if ($action === 'resolve') { return $this->resolve($user); }
        if ($action !== 'review') { return IPSVP_Reseller_Store::error('invalid_action', 'عملیات نامعتبر است.'); }
        $account = IPSVP_Reseller_Store::account($user->id);
        $status = sanitize_key(wp_unslash($_POST['status'] ?? ''));
        $percent = wp_unslash($_POST['discount_percent'] ?? '');
        $note = sanitize_textarea_field(wp_unslash($_POST['review_note'] ?? ''));
        if (!$account || !in_array($status, array('pending', 'approved', 'customer', 'rejected', 'suspended'), true) || !is_string($percent) || ($percent !== '' && !preg_match('/^(?:100(?:\.0{1,2})?|[0-9]{1,2}(?:\.[0-9]{1,2})?)$/D', $percent))) {
            return IPSVP_Reseller_Store::error('invalid_review', 'وضعیت یا درصد تخفیف معتبر نیست (۰ تا ۱۰۰ با دو رقم اعشار).');
        }
        if (in_array($status, array('rejected', 'suspended'), true) && $note === '') { return IPSVP_Reseller_Store::error('note_required', 'دلیل رد یا تعلیق را بنویسید.'); }
        if ($status === 'approved' && !empty($user->is_blocked)) { return IPSVP_Reseller_Store::error('blocked', 'ابتدا مسدودی کاربر را رفع کنید.', 409); }
        if ($status === 'approved' && $account->status !== 'approved' && empty($account->approved_at)) {
            $balance = IPSVP_Reseller_Store::balance($user, $this->db);
            if (is_wp_error($balance)) { return $balance; }
            if ($balance < IPSVP_Reseller_Store::MIN_BALANCE) { return IPSVP_Reseller_Store::error('balance_low', 'موجودی کاربر برای تأیید نمایندگی کمتر از ۲ میلیون تومان است.', 409); }
        }
        $data = array('status' => $status, 'discount_percent' => $percent === '' ? null : $percent, 'review_note' => $note,
            'reviewed_at' => $this->db->now(), 'reviewed_by' => get_current_user_id());
        if ($status === 'approved' && empty($account->approved_at)) { $data['approved_at'] = $this->db->now(); }
        if ($status !== 'approved' || !empty($_POST['revoke_key'])) { $data += array('key_hash' => null, 'key_hint' => null, 'key_expires_at' => null); }
        if (false === $wpdb->update(IPSVP_Reseller_Store::table('accounts'), $data, array('user_id' => $user->id))) { return IPSVP_Reseller_Store::error('save_failed', 'تغییرات ذخیره نشد.', 503); }
        IPSVP_Reseller_Store::audit($this->db, $user, 'تصمیم مدیریت درباره نمایندگی', array('old_status' => $account->status, 'status' => $status, 'old_discount' => $account->discount_percent, 'discount' => $percent, 'note' => $note));
        $this->db->create_user_notification($user->id, $user->phone, 'وضعیت نمایندگی', ($status === 'customer' ? 'حساب شما به پنل کاربر عادی تغییر کرد و دسترسی وب‌سرویس نمایندگی غیرفعال شد.' : self::label($status) . '؛ تخفیف: ' . ($percent === '' ? 'خودکار طبق سطح حساب' : $percent . '٪')) . '. ' . $note, 'reseller', 0, 0, self::dashboard_url());
        return 'وضعیت و درصد تخفیف ذخیره شد.';
    }

    private function resolve($user)
    {
        global $wpdb;
        $op = IPSVP_Reseller_Store::operation((int) ($_POST['operation_id'] ?? 0), $user->id);
        $note = sanitize_textarea_field(wp_unslash($_POST['resolution_note'] ?? ''));
        if (!$op || !in_array($op->state, array('reserved', 'processing', 'manual_review', 'refund_review'), true)) { return IPSVP_Reseller_Store::error('resolved', 'عملیات قبلاً تعیین تکلیف شده یا پیدا نشد.', 409); }
        if (empty($_POST['verified']) || $note === '') { return IPSVP_Reseller_Store::error('verification_required', 'نتیجه پنل و کیف پول را بررسی و شرح بررسی را ثبت کنید.'); }
        $outcome = sanitize_key(wp_unslash($_POST['outcome'] ?? ''));
        if ($outcome === 'complete') {
            if ($op->state === 'refund_review') { return IPSVP_Reseller_Store::error('refund_unresolved', 'ابتدا وضعیت بازپرداخت نامشخص را تعیین تکلیف کنید.', 409); }
            if (empty($op->provider_result)) {
                $order = $this->db->get_order($op->order_id);
                $username = $order->pg_username;
                if (!$username && $op->action === 'purchase') {
                    $suffix = (int) $order->country_id === 0 ? '_all' : '_' . substr(md5((string) $order->pg_group_id), 0, 4);
                    $username = substr('ips' . $order->id . $suffix . '_' . substr(md5($order->phone . $order->order_code), 0, 6), 0, 32);
                }
                $snapshot = $this->api->user_snapshot($username, $order->pg_user_id, $order);
                if (empty($snapshot['live'])) { return IPSVP_Reseller_Store::error('upstream_unavailable', 'سرویس در پنل پیدا نشد؛ تأیید انجام نشد.', 409); }
                $result = array('username' => $snapshot['username'], 'user_id' => $snapshot['user_id'], 'status' => $snapshot['status'],
                    'subscription_url' => $snapshot['subscription_url'], 'links' => $snapshot['links'], 'raw' => $snapshot['live']);
                IPSVP_Reseller_Store::update_operation($op->id, array('provider_result' => wp_json_encode($result)));
            }
            // Admin verified the debit in the remote wallet as well as delivery in the provider.
            if ($op->receipt_id && $op->wallet_source === 'remote') {
                if (false === $wpdb->update($this->db->tables()['receipts'], array('status' => 'approved', 'reviewed_at' => $this->db->now()), array('id' => $op->receipt_id))) { return IPSVP_Reseller_Store::error('save_failed', 'ثبت کسر کیف پول ناموفق بود.', 503); }
            }
            $done = $this->service->complete(IPSVP_Reseller_Store::operation($op->id));
            if (is_wp_error($done)) { return $done; }
        } elseif (in_array($outcome, array('refund', 'no_debit', 'refund_confirmed'), true)) {
            if ($outcome === 'refund_confirmed' && $op->state !== 'refund_review') {
                return IPSVP_Reseller_Store::error('invalid_resolution', 'بازپرداخت در انتظار تأیید نیست.', 409);
            }
            if ($op->wallet_source === 'remote' && (int) $op->amount > 0) {
                if ($outcome === 'refund') {
                    if ($op->state === 'refund_review') { return IPSVP_Reseller_Store::error('refund_unresolved', 'بازپرداخت قبلاً ارسال شده است؛ نتیجه را از کیف پول بررسی و تأیید دستی کنید.', 409); }
                    IPSVP_Reseller_Store::update_operation($op->id, array('state' => 'refund_review', 'stage' => 'refund_pending'));
                    $credited = IPSVP_Bot_API::credit_wallet($op->bot_tel_id, $op->amount, $op->id, $user->phone, 'reseller_refund');
                    if (is_wp_error($credited) || empty($credited['ok'])) { return IPSVP_Reseller_Store::error('refund_uncertain', 'نتیجه بازپرداخت نامشخص است؛ ارسال مجدد خودکار مسدود شد. مرجع reseller_refund را در کیف پول بررسی کنید.', 409); }
                } elseif ($outcome === 'refund_confirmed' && $op->state !== 'refund_review') {
                    return IPSVP_Reseller_Store::error('invalid_resolution', 'بازپرداخت در انتظار تأیید نیست.', 409);
                } elseif ($outcome === 'no_debit' && !in_array($op->stage, array('reserved', 'debit_pending'), true)) {
                    return IPSVP_Reseller_Store::error('debit_confirmed', 'کسر قبلاً تأیید شده است؛ از بازپرداخت استفاده کنید.', 409);
                }
            }
            $tables = $this->db->tables();
            $storage = IPSVP_Reseller_Store::transactional_storage($this->db);
            if (is_wp_error($storage)) { return $storage; }
            if ($wpdb->query('START TRANSACTION') === false) { throw new RuntimeException('Refund transaction failed'); }
            try {
                // Release the original reservation once, atomically with the terminal state.
                if ($op->receipt_id && false === $wpdb->update($tables['receipts'], array('status' => 'rejected', 'reviewed_at' => $this->db->now()), array('id' => $op->receipt_id))) { throw new RuntimeException('Refund receipt failed'); }
                if ($op->action === 'purchase' && false === $this->db->update_order($op->order_id, array('status' => 'failed', 'payment_status' => 'reseller_refunded'))) { throw new RuntimeException('Refund order failed'); }
                IPSVP_Reseller_Store::update_operation($op->id, array('state' => $outcome === 'no_debit' ? 'failed' : 'refunded', 'stage' => 'resolved', 'error_code' => null));
                if ($wpdb->query('COMMIT') === false) { throw new RuntimeException('Refund commit failed'); }
            } catch (Throwable $e) { $wpdb->query('ROLLBACK'); throw $e; }
        } else { return IPSVP_Reseller_Store::error('invalid_resolution', 'روش تعیین تکلیف نامعتبر است.'); }
        IPSVP_Reseller_Store::audit($this->db, $user, 'تعیین تکلیف عملیات نمایندگی', array('operation_id' => $op->id, 'outcome' => $outcome, 'note' => $note));
        return 'عملیات تعیین تکلیف شد.';
    }

    public function admin_page()
    {
        if (!current_user_can('manage_options')) { return; }
        global $wpdb;
        $table = IPSVP_Reseller_Store::table('accounts');
        $users = $this->db->tables()['users'];
        $page = max(1, (int) ($_GET['paged'] ?? 1));
        $filter = sanitize_key($_GET['status'] ?? 'pending');
        if (!in_array($filter, array('all', 'pending', 'approved', 'customer', 'rejected', 'suspended'), true)) { $filter = 'pending'; }
        $where = $filter === 'all' ? '1=1' : $wpdb->prepare('a.status=%s', $filter);
        $search = sanitize_text_field(wp_unslash($_GET['s'] ?? ''));
        if ($search !== '') { $like = '%' . $wpdb->esc_like($search) . '%'; $where .= $wpdb->prepare(' AND (u.phone LIKE %s OR a.business_name LIKE %s)', $like, $like); }
        $accounts = $wpdb->get_results($wpdb->prepare("SELECT a.*, u.phone FROM $table a JOIN $users u ON u.id=a.user_id WHERE $where ORDER BY a.requested_at DESC LIMIT 30 OFFSET %d", ($page - 1) * 30));
        $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table a JOIN $users u ON u.id=a.user_id WHERE $where");
        echo '<div class="wrap" dir="rtl"><h1>نمایندگان و وب‌سرویس</h1>' . wp_kses_post($this->notice);
        echo '<p>حداقل موجودی درخواست و تأیید: ۲٬۰۰۰٬۰۰۰ تومان. شورت‌کد راهنما: <code>[ips_reseller_api_docs]</code></p>';
        echo '<form method="get"><input type="hidden" name="page" value="ipsvp-resellers"><select name="status">';
        foreach (array('all', 'pending', 'approved', 'customer', 'rejected', 'suspended') as $s) { echo '<option value="' . esc_attr($s) . '" ' . selected($filter, $s, false) . '>' . esc_html($s === 'all' ? 'همه' : self::label($s)) . '</option>'; }
        echo '</select> <input name="s" value="' . esc_attr($search) . '" placeholder="شماره یا کسب‌وکار"> <button class="button">جستجو</button></form><table class="widefat striped"><thead><tr><th>کاربر</th><th>کسب‌وکار</th><th>وضعیت</th><th>تخفیف</th><th>درخواست</th><th>مدیریت</th></tr></thead><tbody>';
        foreach ($accounts as $a) {
            $url = add_query_arg(array('page' => 'ipsvp-users', 'view' => $a->user_id, 'ipsvp_tab' => 'reseller'), admin_url('admin.php'));
            $display_discount = $a->discount_percent === null ? 'خودکار' : $a->discount_percent . '٪';
            echo '<tr><td>' . esc_html($a->phone) . '</td><td>' . esc_html($a->business_name) . '</td><td>' . esc_html(self::label($a->status)) . '</td><td>' . esc_html($display_discount) . '</td><td>' . esc_html($a->requested_at) . '</td><td><a href="' . esc_url($url) . '">بررسی و تعیین تخفیف</a></td></tr>';
        }
        if (!$accounts) { echo '<tr><td colspan="6">موردی پیدا نشد.</td></tr>'; }
        echo '</tbody></table>';
        echo wp_kses_post(paginate_links(array('base' => add_query_arg('paged', '%#%'), 'format' => '', 'current' => $page, 'total' => (int) ceil($total / 30))));
        $ops = IPSVP_Reseller_Store::table('operations');
        $review_page = max(1, (int) ($_GET['review_page'] ?? 1));
        $pending = $wpdb->get_results($wpdb->prepare("SELECT * FROM $ops WHERE state IN ('reserved','processing','manual_review','refund_review') ORDER BY id ASC LIMIT 20 OFFSET %d", ($review_page - 1) * 20));
        $pending_total = (int) $wpdb->get_var("SELECT COUNT(*) FROM $ops WHERE state IN ('reserved','processing','manual_review','refund_review')");
        echo '<h2>عملیات نیازمند بررسی (' . (int) $pending_total . ')</h2><p>قبل از تعیین تکلیف، نتیجه واقعی پنل و کسر/بازپرداخت کیف پول را بررسی کنید. فعال‌سازی حساب، به‌تنهایی اثبات تمدید یا افزایش حجم نیست. عملیات در حال اجرا پس از پایان درخواست قابل بررسی است.</p>';
        foreach ($pending as $op) {
            echo '<details style="background:#fff;padding:16px;margin:12px 0"><summary>' . esc_html('#' . $op->id . ' / کاربر ' . $op->user_id . ' / ' . self::label($op->action) . ' / ' . self::label($op->state) . ' / ' . number_format_i18n($op->amount) . ' تومان') . '</summary>';
            echo '<p>' . esc_html('سفارش: ' . $op->order_id . '؛ مرحله: ' . $op->stage . '؛ منبع کیف پول: ' . $op->wallet_source . '؛ مرجع کسر: RS-OP-' . $op->id . '؛ خطا: ' . $op->error_code) . '</p><pre dir="ltr">' . esc_html($op->request_json) . '</pre><form method="post">';
            wp_nonce_field('ipsr_admin', 'ipsr_admin_nonce');
            echo '<input type="hidden" name="ipsr_admin_action" value="resolve"><input type="hidden" name="user_id" value="' . (int) $op->user_id . '"><input type="hidden" name="operation_id" value="' . (int) $op->id . '">';
            echo '<p><select name="outcome"><option value="complete">تحویل و کسر وجه را تأیید می‌کنم</option><option value="refund">عدم تحویل را تأیید و مبلغ کسرشده را بازپرداخت کن</option><option value="no_debit">عدم تحویل و عدم کسر وجه را تأیید می‌کنم</option><option value="refund_confirmed">بازپرداخت نامشخص قبلی در ربات انجام شده است</option></select></p>';
            echo '<p><textarea name="resolution_note" required rows="2" cols="70" placeholder="شرح بررسی و مرجع نتیجه واقعی"></textarea></p><p><label><input type="checkbox" name="verified" value="1" required> نتیجه پنل و کیف پول را مستقلاً بررسی کرده‌ام؛ در بازپرداخت، سرویس تحویل‌نشده یا لغوشده است.</label></p><button class="button button-primary">ثبت نتیجه بررسی</button></form></details>';
        }
        echo wp_kses_post(paginate_links(array('base' => add_query_arg('review_page', '%#%'), 'format' => '', 'current' => $review_page, 'total' => (int) ceil($pending_total / 20))));
        echo '</div>';
    }
}

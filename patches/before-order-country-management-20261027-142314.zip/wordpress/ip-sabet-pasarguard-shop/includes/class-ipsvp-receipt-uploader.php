<?php
/**
 * Private receipt upload and cleanup service.
 *
 * @package IPSabet_PasarGuard_Shop
 */

defined('ABSPATH') || exit;

final class IPSVP_Receipt_Uploader
{
    const CLEANUP_HOOK = 'ipsvp_cleanup_receipt_files';
    const REVIEWED_RETENTION_DAYS = 10;
    const HARD_RETENTION_DAYS = 15;

    private static $initialized = false;

    public static function init()
    {
        if (self::$initialized) {
            return;
        }
        self::$initialized = true;
        add_action('init', array(__CLASS__, 'maybe_serve_download'), 0);
        add_action(self::CLEANUP_HOOK, array(__CLASS__, 'cleanup_old_files'));
    }

    public static function schedule_cleanup()
    {
        if (!wp_next_scheduled(self::CLEANUP_HOOK)) {
            wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', self::CLEANUP_HOOK);
        }
    }

    public static function clear_cleanup_schedule()
    {
        wp_clear_scheduled_hook(self::CLEANUP_HOOK);
    }

    public static function max_upload_size()
    {
        return (int) apply_filters('ipsvp_receipt_max_upload_size', wp_max_upload_size());
    }

    public static function allowed_extensions()
    {
        return array('jpg', 'jpeg', 'png', 'webp', 'pdf');
    }

    public static function allowed_mimes()
    {
        return array(
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png' => 'image/png',
            'webp' => 'image/webp',
            'pdf' => 'application/pdf',
        );
    }

    public static function render_field($input_name, $label = 'رسید پرداخت', $required = true)
    {
        $input_name = sanitize_key($input_name);
        $max = self::max_upload_size();
        $max_label = size_format($max);
        $required_attr = $required ? ' required' : '';
        $html = '<div class="ipsvp-receipt-uploader" data-ipsvp-receipt-uploader data-input-name="' . esc_attr($input_name) . '" data-max-size="' . esc_attr($max) . '" data-required="' . esc_attr($required ? '1' : '0') . '">';
        $html .= '<label class="ipsvp-receipt-drop" tabindex="0">';
        $html .= '<input class="ipsvp-receipt-native" name="' . esc_attr($input_name) . '" type="file" accept=".jpg,.jpeg,.png,.webp,.pdf,image/jpeg,image/png,image/webp,application/pdf"' . $required_attr . '>';
        $html .= '<span class="ipsvp-receipt-icon" aria-hidden="true">⬆</span>';
        $html .= '<strong>' . esc_html($label) . '</strong>';
        $html .= '<span>تصویر رسید یا فایل PDF را انتخاب کنید.</span>';
        $html .= '<em>فرمت‌های مجاز: jpg, jpeg, png, webp, pdf · حداکثر حجم: ' . esc_html($max_label) . '</em>';
        $html .= '<button type="button" class="ipsvp-secondary ipsvp-receipt-select">انتخاب فایل رسید</button>';
        $html .= '</label>';
        $html .= '<div class="ipsvp-receipt-progress" role="progressbar" aria-label="پیشرفت آپلود رسید" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0" hidden><span style="width:0%"></span><b>0%</b></div>';
        $html .= '<div class="ipsvp-receipt-file" hidden><span></span><button type="button" class="ipsvp-receipt-remove">حذف فایل</button></div>';
        $html .= '<div class="ipsvp-receipt-message" role="alert" aria-live="polite"></div>';
        $html .= '<button type="button" class="ipsvp-secondary ipsvp-receipt-retry" hidden>تلاش دوباره</button>';
        $html .= '<input type="hidden" name="' . esc_attr($input_name) . '_attachment_id" class="ipsvp-receipt-attachment-id" value="">';
        $html .= '<input type="hidden" name="' . esc_attr($input_name) . '_file_url" class="ipsvp-receipt-file-url" value="">';
        $html .= '<input type="hidden" name="' . esc_attr($input_name) . '_upload_key" class="ipsvp-receipt-upload-key" value="">';
        $html .= '</div>';
        return $html;
    }

    public static function request_upload_key($input_name)
    {
        $field = sanitize_key($input_name) . '_upload_key';
        return isset($_POST[$field]) && is_string($_POST[$field]) ? self::normalize_upload_key(wp_unslash($_POST[$field])) : '';
    }

    private static function normalize_upload_key($upload_key)
    {
        return is_string($upload_key) && preg_match('/^[a-z0-9]{16,64}$/iD', $upload_key) ? strtolower($upload_key) : '';
    }

    private static function upload_token($owner_user_id, $owner_phone, $upload_key)
    {
        $upload_key = self::normalize_upload_key($upload_key);
        if ($upload_key === '' || (!(int) $owner_user_id && (string) $owner_phone === '')) {
            return '';
        }
        $owner_identity = (int) $owner_user_id
            ? 'user:' . (int) $owner_user_id
            : 'phone:' . sanitize_text_field($owner_phone);
        return substr(hash_hmac('sha256', $owner_identity . '|' . $upload_key, wp_salt('auth')), 0, 40);
    }

    /**
     * Find an upload which may have completed after the browser lost its AJAX response.
     * The same upload key always resolves to the same private file for this owner.
     */
    public static function find_existing_upload($owner_user_id, $owner_phone, $upload_key)
    {
        $token = self::upload_token($owner_user_id, $owner_phone, $upload_key);
        if ($token === '') {
            return null;
        }
        // Check yesterday too, so an upload started just before midnight remains recoverable.
        foreach (array(time(), time() - DAY_IN_SECONDS) as $timestamp) {
            $key = wp_date('Y/m/d', $timestamp) . '/' . $token;
            $metadata = self::local_metadata($key);
            $url = self::persistent_url($key);
            if (!$metadata || self::local_path_from_url($url) === '') {
                continue;
            }
            $existing_owner = isset($metadata['owner_user_id']) ? (int) $metadata['owner_user_id'] : 0;
            $existing_phone = isset($metadata['owner_phone']) ? sanitize_text_field($metadata['owner_phone']) : '';
            if ((int) $owner_user_id > 0 && $existing_owner !== (int) $owner_user_id) {
                continue;
            }
            if (!(int) $owner_user_id && (string) $owner_phone !== '' && $existing_phone !== sanitize_text_field($owner_phone)) {
                continue;
            }
            return array(
                'attachment_id' => 0,
                'url' => $url,
                'name' => isset($metadata['original_name']) ? sanitize_file_name($metadata['original_name']) : '',
            );
        }
        return null;
    }

    public static function upload($file, $owner_user_id = 0, $owner_phone = '', $upload_key = '')
    {
        $token = self::upload_token($owner_user_id, $owner_phone, $upload_key);
        $lock = null;
        if ($token !== '') {
            // One writer per owner/key, even when a timed-out browser retries concurrently.
            $directory = trailingslashit(self::storage_directory()) . wp_date('Y/m/d');
            $prepared = self::prepare_storage_directory($directory);
            if (is_wp_error($prepared)) { return $prepared; }
            $lock = @fopen($directory . '/' . $token . '.lock', 'c');
            if (!$lock || !flock($lock, LOCK_EX | LOCK_NB)) {
                if (is_resource($lock)) { fclose($lock); }
                return new WP_Error('receipt_busy', 'فایل رسید در حال ثبت است؛ کمی بعد دوباره بررسی کنید.');
            }
        }
        try {
            $existing = self::find_existing_upload($owner_user_id, $owner_phone, $upload_key);
            if ($existing) { return $existing; }
            if (!is_array($file) || (isset($file['name']) && !is_string($file['name'])) || (isset($file['tmp_name']) && !is_string($file['tmp_name'])) || (isset($file['error']) && !is_scalar($file['error'])) || (isset($file['size']) && !is_scalar($file['size']))) {
                return new WP_Error('receipt_upload_invalid', 'ساختار فایل رسید معتبر نیست.');
            }
            return self::store_upload($file, $owner_user_id, $owner_phone, $upload_key);
        } finally {
            if (is_resource($lock)) { flock($lock, LOCK_UN); fclose($lock); }
        }
    }

    private static function store_upload($file, $owner_user_id, $owner_phone, $upload_key)
    {
        if (empty($file) || empty($file['name'])) {
            return new WP_Error('receipt_required', 'فایل رسید پرداخت الزامی است.');
        }
        if (!empty($file['error'])) {
            return new WP_Error('receipt_upload_error', self::upload_error_message((int) $file['error']));
        }
        if (!empty($file['size']) && (int) $file['size'] > self::max_upload_size()) {
            return new WP_Error('receipt_file_too_large', 'حجم فایل بیشتر از حد مجاز است.');
        }
        if (isset($file['size']) && (int) $file['size'] <= 0) {
            return new WP_Error('receipt_file_empty', 'فایل رسید خالی یا ناقص است.');
        }
        if (empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            return new WP_Error('receipt_upload_invalid', 'فایل آپلودشده معتبر نیست.');
        }
        $actual_size = @filesize($file['tmp_name']);
        if ($actual_size === false || $actual_size <= 0 || $actual_size > self::max_upload_size()) {
            return new WP_Error('receipt_file_size_invalid', 'حجم واقعی فایل رسید معتبر نیست یا بیشتر از حد مجاز است.');
        }

        $mimes = self::allowed_mimes();
        $ext = strtolower((string) pathinfo($file['name'], PATHINFO_EXTENSION));
        $actual_mime = self::validate_file_type($file['tmp_name'], $ext);
        if (is_wp_error($actual_mime)) {
            return $actual_mime;
        }
        if (!in_array($ext, self::allowed_extensions(), true) || !in_array($actual_mime, $mimes, true)) {
            return new WP_Error('bad_file_type', 'فرمت فایل مجاز نیست. فقط تصویر یا PDF قابل قبول است.');
        }
        $date_path = wp_date('Y/m/d');
        $directory = trailingslashit(self::storage_directory()) . $date_path;
        $prepared = self::prepare_storage_directory($directory);
        if (is_wp_error($prepared)) {
            return $prepared;
        }

        $upload_key = self::normalize_upload_key($upload_key);
        $token = self::upload_token($owner_user_id, $owner_phone, $upload_key);
        $has_upload_key = $token !== '';
        if ($has_upload_key) {
            $existing = self::find_existing_upload($owner_user_id, $owner_phone, $upload_key);
            if ($existing) {
                return $existing;
            }
        } else {
            try {
                $token = bin2hex(random_bytes(20));
            } catch (Exception $e) {
                $token = wp_generate_password(40, false, false);
            }
        }
        $token = strtolower(preg_replace('/[^a-z0-9]/i', '', $token));
        $key = $date_path . '/' . $token;

        $destination = trailingslashit($directory) . $token . '.' . $ext;
        if (!@move_uploaded_file($file['tmp_name'], $destination)) {
            return new WP_Error('receipt_store_failed', 'ذخیره فایل رسید روی سرور ناموفق بود.');
        }
        @chmod($destination, 0640);

        $metadata = array(
            'owner_user_id' => (int) $owner_user_id,
            'owner_phone' => sanitize_text_field($owner_phone),
            'mime' => $actual_mime,
            'extension' => $ext,
            'original_name' => sanitize_file_name($file['name']),
            'created_at' => time(),
        );
        // Publish metadata only after the entire file and JSON have been persisted.
        $json = wp_json_encode($metadata);
        $temporary_metadata = self::metadata_path($key) . '.tmp';
        if (!is_string($json) || @file_put_contents($temporary_metadata, $json, LOCK_EX) !== strlen($json) || !@rename($temporary_metadata, self::metadata_path($key))) {
            wp_delete_file($temporary_metadata);
            wp_delete_file($destination);
            return new WP_Error('receipt_metadata_failed', 'ثبت اطلاعات فایل رسید ناموفق بود.');
        }
        @chmod(self::metadata_path($key), 0640);

        return array('attachment_id' => 0, 'url' => self::persistent_url($key));
    }

    private static function storage_directory()
    {
        return untrailingslashit((string) apply_filters('ipsvp_receipt_storage_directory', WP_CONTENT_DIR . '/ipsvp-private-receipts'));
    }

    private static function prepare_storage_directory($directory)
    {
        if (!wp_mkdir_p($directory)) {
            return new WP_Error('receipt_directory_failed', 'پوشه امن رسیدها قابل ایجاد نیست.');
        }
        $root = self::storage_directory();
        if (!file_exists($root . '/index.php')) {
            @file_put_contents($root . '/index.php', "<?php\n// Silence is golden.\n", LOCK_EX);
        }
        if (!file_exists($root . '/.htaccess')) {
            $deny_rules = "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n";
            @file_put_contents($root . '/.htaccess', $deny_rules, LOCK_EX);
        }
        return true;
    }

    private static function sanitize_local_key($key)
    {
        $key = trim((string) $key, '/');
        return preg_match('#\A\d{4}/\d{2}/\d{2}/[a-z0-9]{32,64}\z#', $key) ? $key : '';
    }

    private static function persistent_url($key)
    {
        return esc_url_raw(add_query_arg('ipsvp_receipt_file', self::sanitize_local_key($key), home_url('/')));
    }

    private static function key_from_url($url)
    {
        $query = (string) parse_url((string) $url, PHP_URL_QUERY);
        if ($query === '') {
            return '';
        }
        parse_str($query, $args);
        return self::sanitize_local_key(isset($args['ipsvp_receipt_file']) ? $args['ipsvp_receipt_file'] : '');
    }

    private static function metadata_path($key)
    {
        $key = self::sanitize_local_key($key);
        return $key !== '' ? trailingslashit(self::storage_directory()) . $key . '.json' : '';
    }

    private static function local_metadata($key)
    {
        $path = self::metadata_path($key);
        if ($path === '' || !is_readable($path)) {
            return array();
        }
        $metadata = json_decode((string) file_get_contents($path), true);
        return is_array($metadata) ? $metadata : array();
    }

    public static function local_path_from_url($url)
    {
        $key = self::key_from_url($url);
        $metadata = self::local_metadata($key);
        if ($key === '' || empty($metadata['extension'])) {
            return '';
        }
        $ext = strtolower((string) $metadata['extension']);
        if (!in_array($ext, self::allowed_extensions(), true)) {
            return '';
        }
        $path = trailingslashit(self::storage_directory()) . $key . '.' . $ext;
        return is_readable($path) && is_file($path) ? $path : '';
    }

    private static function validate_file_type($tmp_name, $ext)
    {
        $tmp_name = (string) $tmp_name;
        $ext = strtolower((string) $ext);
        $mimes = self::allowed_mimes();
        if ($tmp_name === '' || !is_readable($tmp_name) || !isset($mimes[$ext])) {
            return new WP_Error('bad_file_type', 'فرمت فایل مجاز نیست. فقط تصویر یا PDF قابل قبول است.');
        }
        if ($ext === 'pdf') {
            $handle = fopen($tmp_name, 'rb');
            $signature = $handle ? fread($handle, 5) : '';
            if ($handle) {
                fclose($handle);
            }
            return $signature === '%PDF-' ? 'application/pdf' : new WP_Error('bad_pdf_file', 'فایل انتخاب‌شده یک PDF معتبر نیست.');
        }

        $actual = function_exists('wp_get_image_mime') ? wp_get_image_mime($tmp_name) : false;
        if (!$actual && function_exists('getimagesize')) {
            $info = @getimagesize($tmp_name);
            $actual = is_array($info) && !empty($info['mime']) ? (string) $info['mime'] : false;
        }
        $expected = $mimes[$ext];
        if (!$actual || !in_array($actual, array('image/jpeg', 'image/png', 'image/webp'), true) || $actual !== $expected) {
            return new WP_Error('bad_image_file', 'محتوای فایل تصویر با پسوند آن مطابقت ندارد یا تصویر معتبر نیست.');
        }
        return $actual;
    }

    public static function uploaded_from_request($input_name, $owner_user_id = 0)
    {
        $input_name = sanitize_key($input_name);
        $attachment_id = isset($_POST[$input_name . '_attachment_id']) && is_scalar($_POST[$input_name . '_attachment_id']) ? (int) $_POST[$input_name . '_attachment_id'] : 0;
        if (!$attachment_id) {
            $file_url = isset($_POST[$input_name . '_file_url']) && is_string($_POST[$input_name . '_file_url']) ? esc_url_raw(wp_unslash($_POST[$input_name . '_file_url'])) : '';
            $key = self::key_from_url($file_url);
            if ($key === '') {
                // The AJAX response can be lost even though its file was committed.
                return $owner_user_id > 0 ? self::find_existing_upload($owner_user_id, '', self::request_upload_key($input_name)) : null;
            }
            $metadata = self::local_metadata($key);
            if (!$metadata || self::local_path_from_url($file_url) === '') {
                return new WP_Error('receipt_missing', 'فایل رسید آپلودشده پیدا نشد.');
            }
            $owner = isset($metadata['owner_user_id']) ? (int) $metadata['owner_user_id'] : 0;
            if ($owner_user_id && (!$owner || $owner !== (int) $owner_user_id) && !current_user_can('manage_options')) {
                return new WP_Error('receipt_owner_mismatch', 'دسترسی به فایل رسید مجاز نیست.');
            }
            return array('attachment_id' => 0, 'url' => self::persistent_url($key));
        }
        $owner = (int) get_post_meta($attachment_id, '_ipsvp_receipt_owner_user_id', true);
        if ($owner_user_id && (!$owner || $owner !== (int) $owner_user_id) && !current_user_can('manage_options')) {
            return new WP_Error('receipt_owner_mismatch', 'دسترسی به فایل رسید مجاز نیست.');
        }
        $url = wp_get_attachment_url($attachment_id);
        if (!$url) {
            return new WP_Error('receipt_missing', 'فایل رسید آپلودشده پیدا نشد.');
        }
        return array('attachment_id' => $attachment_id, 'url' => esc_url_raw($url));
    }

    public static function view_url($attachment_id, $fallback_url = '')
    {
        $attachment_id = (int) $attachment_id;
        if ($attachment_id > 0) {
            return add_query_arg(array(
                'ipsvp_receipt_file' => $attachment_id,
                '_wpnonce' => wp_create_nonce('ipsvp_receipt_file_' . $attachment_id),
            ), home_url('/'));
        }
        $key = self::key_from_url($fallback_url);
        if ($key !== '') {
            return add_query_arg(array(
                'ipsvp_receipt_file' => $key,
                '_wpnonce' => wp_create_nonce('ipsvp_receipt_file_' . $key),
            ), home_url('/'));
        }
        return $fallback_url !== '' ? esc_url_raw($fallback_url) : '';
    }

    public static function link_html($attachment_id, $file_url = '', $label = 'مشاهده رسید', $class = '')
    {
        $url = self::view_url($attachment_id, $file_url);
        if ($url === '') {
            return '';
        }
        $class_attr = $class !== '' ? ' class="' . esc_attr($class) . '"' : '';
        return '<a' . $class_attr . ' target="_blank" rel="noopener" href="' . esc_url($url) . '">' . esc_html($label) . '</a>';
    }

    public static function maybe_serve_download()
    {
        $requested = isset($_GET['ipsvp_receipt_file']) ? sanitize_text_field(wp_unslash($_GET['ipsvp_receipt_file'])) : '';
        if ($requested === '') {
            return;
        }
        $key = self::sanitize_local_key($requested);
        $attachment_id = $key === '' ? (int) $requested : 0;
        $nonce_target = $key !== '' ? $key : $attachment_id;
        if (!$nonce_target || !isset($_GET['_wpnonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'])), 'ipsvp_receipt_file_' . $nonce_target)) {
            wp_die('دسترسی به فایل رسید مجاز نیست.', '', array('response' => 403));
        }
        if ($key !== '') {
            $metadata = self::local_metadata($key);
            if (!self::current_user_can_view_owner(isset($metadata['owner_user_id']) ? (int) $metadata['owner_user_id'] : 0)) {
                wp_die('دسترسی به فایل رسید مجاز نیست.', '', array('response' => 403));
            }
            $file = self::local_path_from_url(self::persistent_url($key));
            $mime = !empty($metadata['mime']) ? (string) $metadata['mime'] : '';
        } else {
            if (!self::current_user_can_view($attachment_id)) {
                wp_die('دسترسی به فایل رسید مجاز نیست.', '', array('response' => 403));
            }
            $file = get_attached_file($attachment_id);
            $mime = get_post_mime_type($attachment_id);
        }
        if (!$file || !is_readable($file)) {
            wp_die('فایل رسید پیدا نشد.', '', array('response' => 404));
        }
        if (!in_array($mime, self::allowed_mimes(), true)) {
            wp_die('نوع فایل مجاز نیست.', '', array('response' => 403));
        }
        nocache_headers();
        header('X-Content-Type-Options: nosniff');
        header('Content-Type: ' . $mime);
        header('Content-Length: ' . filesize($file));
        header('Content-Disposition: inline; filename="' . basename($file) . '"');
        readfile($file);
        exit;
    }

    private static function current_user_can_view_owner($owner)
    {
        if (current_user_can('manage_options')) {
            return true;
        }
        $owner = (int) $owner;
        if ($owner <= 0 || !class_exists('IPSVP_DB')) {
            return false;
        }
        $db = new IPSVP_DB();
        $phone = IPSVP_Session::get_phone($db);
        $user = $phone ? $db->get_user_by_phone($phone) : null;
        return $user && (int) $user->id === $owner;
    }

    private static function current_user_can_view($attachment_id)
    {
        $owner = (int) get_post_meta((int) $attachment_id, '_ipsvp_receipt_owner_user_id', true);
        return self::current_user_can_view_owner($owner);
    }

    public static function cleanup_old_files()
    {
        global $wpdb;
        if (!class_exists('IPSVP_DB')) {
            return;
        }
        $db = new IPSVP_DB();
        $table = $db->tables()['receipts'];
        $reviewed_cutoff = wp_date('Y-m-d H:i:s', time() - (self::REVIEWED_RETENTION_DAYS * DAY_IN_SECONDS));
        $hard_cutoff = wp_date('Y-m-d H:i:s', time() - (self::HARD_RETENTION_DAYS * DAY_IN_SECONDS));
        $terminal = "'approved','rejected','cancelled','canceled','failed','completed','confirmed','paid'";
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT id,attachment_id,file_url FROM {$table}
             WHERE (COALESCE(attachment_id,0)>0 OR COALESCE(file_url,'')<>'')
               AND ((status IN ({$terminal}) AND COALESCE(reviewed_at,created_at)<%s) OR created_at<%s)
             ORDER BY id ASC LIMIT 100",
            $reviewed_cutoff,
            $hard_cutoff
        ));
        foreach ((array) $rows as $row) {
            self::delete_stored_file((int) $row->attachment_id, (string) $row->file_url);
            $wpdb->update($table, array('attachment_id' => 0, 'file_url' => ''), array('id' => (int) $row->id), array('%d', '%s'), array('%d'));
        }
        self::cleanup_expired_date_directories();
        if (count((array) $rows) === 100) {
            wp_schedule_single_event(time() + (15 * MINUTE_IN_SECONDS), self::CLEANUP_HOOK);
        }
    }

    private static function delete_stored_file($attachment_id, $file_url)
    {
        if ($attachment_id > 0) {
            wp_delete_attachment($attachment_id, true);
        }
        $key = self::key_from_url($file_url);
        if ($key === '') {
            return;
        }
        $path = self::local_path_from_url($file_url);
        if ($path !== '') {
            wp_delete_file($path);
        }
        $metadata = self::metadata_path($key);
        if ($metadata !== '' && is_file($metadata)) {
            wp_delete_file($metadata);
        }
    }

    private static function cleanup_expired_date_directories()
    {
        $root = self::storage_directory();
        if (!is_dir($root)) {
            return;
        }
        $cutoff = strtotime(wp_date('Y-m-d', time() - (self::HARD_RETENTION_DAYS * DAY_IN_SECONDS)) . ' 00:00:00');
        $deleted = 0;
        foreach ((array) glob($root . '/[0-9][0-9][0-9][0-9]/[0-9][0-9]/[0-9][0-9]', GLOB_ONLYDIR) as $directory) {
            $relative = substr($directory, strlen($root) + 1);
            $directory_date = strtotime(str_replace('/', '-', $relative) . ' 00:00:00');
            if (!$directory_date || $directory_date >= $cutoff) {
                continue;
            }
            foreach ((array) glob($directory . '/*') as $file) {
                if (is_file($file)) {
                    wp_delete_file($file);
                    $deleted++;
                    if ($deleted >= 100) {
                        wp_schedule_single_event(time() + (15 * MINUTE_IN_SECONDS), self::CLEANUP_HOOK);
                        return;
                    }
                }
            }
            @rmdir($directory);
        }
    }

    public static function upload_error_message($code)
    {
        $map = array(
            UPLOAD_ERR_INI_SIZE => 'حجم فایل بیشتر از حد مجاز سرور است.',
            UPLOAD_ERR_FORM_SIZE => 'حجم فایل بیشتر از حد مجاز فرم است.',
            UPLOAD_ERR_PARTIAL => 'آپلود فایل کامل نشد.',
            UPLOAD_ERR_NO_FILE => 'فایلی انتخاب نشده است.',
        );
        return isset($map[$code]) ? $map[$code] : 'آپلود فایل ناموفق بود.';
    }
}

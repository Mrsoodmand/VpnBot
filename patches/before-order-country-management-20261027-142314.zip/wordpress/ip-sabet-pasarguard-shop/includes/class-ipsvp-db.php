<?php
/**
 * Database schema and data access layer.
 *
 * @package IPSabet_PasarGuard_Shop
 */

defined('ABSPATH') || exit;

final class IPSVP_DB
{
    public function tables()
    {
        global $wpdb;
        return array(
            'users' => $wpdb->prefix . 'ipsvp_users',
            'plans' => $wpdb->prefix . 'ipsvp_plans',
            'countries' => $wpdb->prefix . 'ipsvp_countries',
            'orders' => $wpdb->prefix . 'ipsvp_orders',
            'receipts' => $wpdb->prefix . 'ipsvp_receipts',
            'logs' => $wpdb->prefix . 'ipsvp_logs',
            'notifications' => $wpdb->prefix . 'ipsvp_notifications',
        );
    }

    public function install()
    {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $t = $this->tables();

        dbDelta("CREATE TABLE {$t['users']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            phone VARCHAR(32) NOT NULL,
            name VARCHAR(191) NULL,
            password_hash VARCHAR(255) NULL,
            is_blocked TINYINT(1) NOT NULL DEFAULT 0,
            blocked_at DATETIME NULL,
            blocked_note TEXT NULL,
            wallet_balance BIGINT UNSIGNED NOT NULL DEFAULT 0,
            manual_discount_percent DECIMAL(5,2) NULL DEFAULT NULL,
            bot_tel_id VARCHAR(64) NULL,
            bot_username VARCHAR(191) NULL,
            bot_first_name VARCHAR(191) NULL,
            bot_link_code VARCHAR(24) NULL,
            bot_link_expires_at DATETIME NULL,
            bot_linked_at DATETIME NULL,
            created_at DATETIME NOT NULL,
            last_seen_at DATETIME NULL,
            PRIMARY KEY (id),
            UNIQUE KEY phone (phone),
            KEY bot_tel_id (bot_tel_id),
            KEY bot_link_code (bot_link_code)
        ) $charset;");

        dbDelta("CREATE TABLE {$t['plans']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            service_type VARCHAR(20) NOT NULL DEFAULT 'shared',
            title VARCHAR(191) NOT NULL,
            gb INT UNSIGNED NOT NULL DEFAULT 0,
            days INT UNSIGNED NOT NULL DEFAULT 0,
            price BIGINT UNSIGNED NOT NULL DEFAULT 0,
            sale_price BIGINT UNSIGNED NULL,
            discount_label VARCHAR(80) NULL,
            card_icon VARCHAR(255) NULL,
            features LONGTEXT NULL,
            status TINYINT(1) NOT NULL DEFAULT 1,
            sort_order INT NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY service_type (service_type),
            KEY status (status)
        ) $charset;");

        dbDelta("CREATE TABLE {$t['countries']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            service_type VARCHAR(20) NOT NULL DEFAULT 'shared',
            name VARCHAR(191) NOT NULL,
            flag VARCHAR(32) NULL,
            pg_group_id BIGINT UNSIGNED NULL,
            pg_group_name VARCHAR(191) NULL,
            status TINYINT(1) NOT NULL DEFAULT 1,
            sort_order INT NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY service_type (service_type),
            KEY status (status),
            KEY pg_group_id (pg_group_id)
        ) $charset;");

        dbDelta("CREATE TABLE {$t['orders']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            order_code VARCHAR(64) NOT NULL,
            service_type VARCHAR(20) NOT NULL DEFAULT 'shared',
            panel_provider VARCHAR(20) NOT NULL DEFAULT 'pasarguard',
            panel_inbound_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            submission_key VARCHAR(80) NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            phone VARCHAR(32) NOT NULL,
            plan_id BIGINT UNSIGNED NOT NULL,
            country_id BIGINT UNSIGNED NOT NULL,
            price BIGINT UNSIGNED NOT NULL DEFAULT 0,
            status VARCHAR(40) NOT NULL DEFAULT 'pending_receipt',
            payment_status VARCHAR(40) NOT NULL DEFAULT 'waiting_review',
            wallet_effect VARCHAR(20) NULL,
            pg_username VARCHAR(64) NULL,
            pg_user_id VARCHAR(64) NULL,
            pg_status VARCHAR(64) NULL,
            pg_subscription_url TEXT NULL,
            pg_links LONGTEXT NULL,
            pg_response LONGTEXT NULL,
            pg_synced_at DATETIME NULL,
            admin_note TEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            approved_at DATETIME NULL,
            service_ended_at DATETIME NULL,
            cancelled_at DATETIME NULL,
            PRIMARY KEY (id),
            UNIQUE KEY order_code (order_code),
            UNIQUE KEY submission_key (submission_key),
            KEY phone (phone),
            KEY user_id (user_id),
            KEY service_type (service_type),
            KEY status (status),
            KEY pg_synced_at (pg_synced_at)
        ) $charset;");

        dbDelta("CREATE TABLE {$t['receipts']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            order_id BIGINT UNSIGNED NOT NULL,
            submission_key VARCHAR(80) NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            phone VARCHAR(32) NOT NULL,
            type VARCHAR(30) NOT NULL DEFAULT 'new',
            plan_id BIGINT UNSIGNED NULL,
            attachment_id BIGINT UNSIGNED NULL,
            file_url TEXT NULL,
            amount BIGINT UNSIGNED NOT NULL DEFAULT 0,
            status VARCHAR(40) NOT NULL DEFAULT 'pending',
            wallet_effect VARCHAR(20) NULL,
            admin_note TEXT NULL,
            remote_source VARCHAR(30) NULL,
            remote_order_id VARCHAR(64) NULL,
            remote_payload LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            reviewed_at DATETIME NULL,
            PRIMARY KEY (id),
            UNIQUE KEY submission_key (submission_key),
            KEY order_id (order_id),
            KEY status (status),
            KEY status_reviewed_at (status,reviewed_at),
            KEY user_status_type (user_id,status,type),
            KEY created_at (created_at),
            KEY type (type),
            KEY plan_id (plan_id),
            KEY remote_order_id (remote_order_id)
        ) $charset;");

        dbDelta("CREATE TABLE {$t['logs']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NULL,
            phone VARCHAR(32) NULL,
            order_id BIGINT UNSIGNED NULL,
            receipt_id BIGINT UNSIGNED NULL,
            level VARCHAR(20) NOT NULL DEFAULT 'error',
            source VARCHAR(80) NULL,
            message TEXT NOT NULL,
            context LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY phone (phone),
            KEY order_id (order_id),
            KEY receipt_id (receipt_id),
            KEY level (level),
            KEY created_at (created_at)
        ) $charset;");

        dbDelta("CREATE TABLE {$t['notifications']} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NULL,
            phone VARCHAR(32) NOT NULL,
            order_id BIGINT UNSIGNED NULL,
            receipt_id BIGINT UNSIGNED NULL,
            type VARCHAR(40) NOT NULL DEFAULT 'order',
            status VARCHAR(40) NOT NULL DEFAULT 'unread',
            title VARCHAR(191) NOT NULL,
            message TEXT NOT NULL,
            action_url TEXT NULL,
            created_at DATETIME NOT NULL,
            seen_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY phone_status (phone,status),
            KEY user_id (user_id),
            KEY order_id (order_id),
            KEY receipt_id (receipt_id),
            KEY created_at (created_at)
        ) $charset;");

        $this->migrate_legacy_wallet_effects();
        IPSVP_Reseller_Store::install();
    }

    private function migrate_legacy_wallet_effects()
    {
        global $wpdb;
        $t = $this->tables();

        // Before wallet_effect existed, successful operations performed while a bot
        // link was active were written to the site audit ledger as well as the bot.
        // Mark those historical rows as remote so only pre-link site credit is merged.
        $wpdb->query("UPDATE {$t['receipts']} r
            INNER JOIN {$t['users']} u ON u.id=r.user_id
            SET r.wallet_effect='remote'
            WHERE (r.wallet_effect IS NULL OR r.wallet_effect='')
              AND u.bot_tel_id IS NOT NULL AND u.bot_tel_id<>''
              AND u.bot_linked_at IS NOT NULL
              AND r.status='approved'
              AND r.type IN ('wallet','wallet_admin_credit','wallet_admin_debit','wallet_renewal','wallet_bot_renewal','wallet_extra_volume')
              AND COALESCE(r.reviewed_at,r.created_at) >= u.bot_linked_at
              AND (r.remote_source IS NULL OR r.remote_source<>'bot_wallet_sync')");

        $wpdb->query("UPDATE {$t['orders']} o
            INNER JOIN {$t['users']} u ON u.id=o.user_id
            SET o.wallet_effect='remote'
            WHERE (o.wallet_effect IS NULL OR o.wallet_effect='')
              AND u.bot_tel_id IS NOT NULL AND u.bot_tel_id<>''
              AND u.bot_linked_at IS NOT NULL
              AND o.submission_key LIKE 'wallet-pay-%'
              AND o.payment_status IN ('wallet_paid','approved')
              AND o.status NOT IN ('failed','rejected')
              AND COALESCE(o.approved_at,o.created_at) >= u.bot_linked_at");
    }

    public function now()
    {
        return current_time('mysql');
    }

    public function normalize_phone($phone)
    {
        $phone = trim((string) $phone);
        $phone = strtr($phone, array(
            '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
            '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
            '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
        ));
        $phone = preg_replace('/[^0-9+]/', '', $phone);
        if (strpos($phone, '0098') === 0) {
            $phone = '+98' . substr($phone, 4);
        }
        if (strpos($phone, '98') === 0 && strlen($phone) >= 12) {
            $phone = '+98' . substr($phone, 2);
        }
        if (strpos($phone, '09') === 0) {
            $phone = '+98' . substr($phone, 1);
        }
        return $phone;
    }

    public function sanitize_submission_key($key)
    {
        $key = trim((string) $key);
        $key = preg_replace('/[^a-zA-Z0-9_\-]/', '', $key);
        return substr($key, 0, 80);
    }

    public function get_user_by_id($id)
    {
        global $wpdb;
        $t = $this->tables();
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['users']} WHERE id=%d", (int) $id));
    }

    public function is_user_blocked($phone)
    {
        $user = $this->get_user_by_phone($phone);
        return $user && !empty($user->is_blocked);
    }

    public function set_user_blocked($user_id, $blocked = 1, $note = '')
    {
        global $wpdb;
        $t = $this->tables();
        return $wpdb->update($t['users'], array(
            'is_blocked' => $blocked ? 1 : 0,
            'blocked_at' => $blocked ? $this->now() : null,
            'blocked_note' => sanitize_textarea_field($note),
        ), array('id' => (int) $user_id));
    }

    public function admin_set_user_password_by_id($user_id, $password)
    {
        global $wpdb;
        $t = $this->tables();
        $password = (string) $password;
        if (trim($password) === '') {
            return false;
        }
        return $wpdb->update($t['users'], array(
            'password_hash' => wp_hash_password($password),
            'last_seen_at' => $this->now(),
        ), array('id' => (int) $user_id));
    }

    public function clear_user_password_by_id($user_id)
    {
        global $wpdb;
        $t = $this->tables();
        return $wpdb->update($t['users'], array('password_hash' => null), array('id' => (int) $user_id));
    }

    public function get_or_create_user($phone, $name = '')
    {
        global $wpdb;
        $t = $this->tables();
        $phone = $this->normalize_phone($phone);
        if (!$phone) {
            return false;
        }
        $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['users']} WHERE phone=%s", $phone));
        if ($user) {
            $wpdb->update($t['users'], array('last_seen_at' => $this->now()), array('id' => $user->id));
            return $user;
        }
        $wpdb->insert($t['users'], array(
            'phone' => $phone,
            'name' => sanitize_text_field($name),
            'created_at' => $this->now(),
            'last_seen_at' => $this->now(),
        ));
        $created_user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['users']} WHERE id=%d", $wpdb->insert_id));
        // Extension point for independent add-ons, e.g. referral attribution on first registration.
        do_action('ipsvp_user_created', $created_user, $phone, $name);
        return $created_user;
    }




    public function get_local_wallet_balance($user_id)
    {
        global $wpdb;
        $t = $this->tables();
        $user_id = (int) $user_id;
        if ($user_id <= 0) {
            return 0;
        }
        // Display-only reads need not wait for long provider calls. Mutation callers
        // hold the same account lock before checking funds; legacy POST flows acquire it here.
        if (!in_array($_SERVER['REQUEST_METHOD'] ?? 'POST', array('GET', 'HEAD'), true)) {
            IPSVP_Reseller_Store::require_lock($user_id);
        }
        $local_effect = "(wallet_effect IS NULL OR wallet_effect='' OR wallet_effect='local')";
        $credits = (int) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM {$t['receipts']} WHERE user_id=%d AND status='approved' AND type IN ('wallet','wallet_admin_credit') AND {$local_effect}", $user_id));
        $manual_debits = (int) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM {$t['receipts']} WHERE user_id=%d AND status='approved' AND type IN ('wallet_admin_debit','wallet_renewal','wallet_bot_renewal','wallet_extra_volume') AND {$local_effect}", $user_id));
        $order_debits = (int) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(price),0) FROM {$t['orders']} WHERE user_id=%d AND submission_key LIKE %s AND payment_status IN ('wallet_paid','approved') AND status NOT IN ('failed','rejected') AND {$local_effect}", $user_id, 'wallet-pay-%'));
        $balance = $credits - $manual_debits - $order_debits;
        return max(0, (int) $balance);
    }

    public function set_receipt_wallet_effect($receipt_id, $effect)
    {
        global $wpdb;
        $t = $this->tables();
        $effect = $effect === 'remote' ? 'remote' : 'local';
        return $wpdb->update($t['receipts'], array('wallet_effect' => $effect), array('id' => (int) $receipt_id));
    }

    public function set_order_wallet_effect($order_id, $effect)
    {
        global $wpdb;
        $t = $this->tables();
        $effect = $effect === 'remote' ? 'remote' : 'local';
        return $wpdb->update($t['orders'], array('wallet_effect' => $effect), array('id' => (int) $order_id));
    }

    public function prepare_wallet_sync_debit($user, $tel_id)
    {
        global $wpdb;
        $t = $this->tables();
        if (!$user || empty($user->id) || trim((string) $tel_id) === '') {
            return new WP_Error('invalid_wallet_sync_user', 'اطلاعات کاربر برای همگام سازی کیف پول کامل نیست.');
        }
        $user_id = (int) $user->id;
        $amount = $this->get_local_wallet_balance($user_id);
        if ($amount <= 0) {
            return null;
        }

        // The fingerprint makes concurrent/retried sync attempts resolve to one receipt.
        // Only approved local-effect rows participate, so the key remains stable while
        // a transfer is pending and changes after a genuinely new local transaction.
        $receipt_state = (string) $wpdb->get_var($wpdb->prepare(
            "SELECT CONCAT(COALESCE(MAX(id),0),':',COALESCE(SUM(amount),0)) FROM {$t['receipts']} WHERE user_id=%d AND status='approved' AND type IN ('wallet','wallet_admin_credit','wallet_admin_debit','wallet_renewal','wallet_bot_renewal','wallet_extra_volume') AND (wallet_effect IS NULL OR wallet_effect='' OR wallet_effect='local')",
            $user_id
        ));
        $order_state = (string) $wpdb->get_var($wpdb->prepare(
            "SELECT CONCAT(COALESCE(MAX(id),0),':',COALESCE(SUM(price),0)) FROM {$t['orders']} WHERE user_id=%d AND submission_key LIKE %s AND payment_status IN ('wallet_paid','approved') AND status NOT IN ('failed','rejected') AND (wallet_effect IS NULL OR wallet_effect='' OR wallet_effect='local')",
            $user_id,
            'wallet-pay-%'
        ));
        $fingerprint = substr(hash('sha256', $user_id . '|' . (string) $tel_id . '|' . $amount . '|' . $receipt_state . '|' . $order_state), 0, 32);
        $submission_key = 'wallet-sync-' . $user_id . '-' . $fingerprint;
        $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE submission_key=%s LIMIT 1", $submission_key));
        if ($existing) {
            return $existing;
        }

        $payload = array(
            'purpose' => 'merge_site_wallet_into_bot',
            'site_balance' => $amount,
            'bot_tel_id' => (string) $tel_id,
            'fingerprint' => $fingerprint,
        );
        $inserted = $wpdb->insert($t['receipts'], array(
            'order_id' => 0,
            'submission_key' => $submission_key,
            'user_id' => $user_id,
            'phone' => (string) $user->phone,
            'type' => 'wallet_admin_debit',
            'plan_id' => null,
            'attachment_id' => 0,
            'file_url' => '',
            'amount' => $amount,
            'status' => 'pending',
            'wallet_effect' => 'local',
            'admin_note' => 'انتقال خودکار موجودی سایت به کیف پول مشترک پس از اتصال تلگرام',
            'remote_source' => 'bot_wallet_sync',
            'remote_payload' => wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'created_at' => $this->now(),
        ));
        if (!$inserted) {
            $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE submission_key=%s LIMIT 1", $submission_key));
            if ($existing) {
                return $existing;
            }
            return new WP_Error('wallet_sync_receipt_failed', 'ثبت انتقال موجودی سایت به کیف پول مشترک ناموفق بود.');
        }
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE id=%d", (int) $wpdb->insert_id));
    }

    public function complete_wallet_sync_debit($receipt_id, $remote_response = array())
    {
        global $wpdb;
        $t = $this->tables();
        $receipt = $this->get_receipt((int) $receipt_id);
        if (!$receipt || (string) $receipt->remote_source !== 'bot_wallet_sync') {
            return false;
        }
        $payload = !empty($receipt->remote_payload) ? json_decode((string) $receipt->remote_payload, true) : array();
        $payload = is_array($payload) ? $payload : array();
        $payload['synced_at'] = $this->now();
        $payload['remote_response'] = is_array($remote_response) ? $remote_response : array();
        return $wpdb->update($t['receipts'], array(
            'status' => 'approved',
            'wallet_effect' => 'local',
            'reviewed_at' => $this->now(),
            'remote_payload' => wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        ), array('id' => (int) $receipt_id));
    }

    public function get_local_wallet_balance_by_phone($phone)
    {
        $user = $this->get_or_create_user($phone);
        return $user ? $this->get_local_wallet_balance($user->id) : 0;
    }

    public function can_pay_with_local_wallet($user_id, $amount)
    {
        return $this->get_local_wallet_balance($user_id) >= (int) $amount;
    }


    public function get_wallet_transactions($user_id, $limit = 30)
    {
        global $wpdb;
        $t = $this->tables();
        $user_id = (int) $user_id;
        $limit = max(1, min(100, (int) $limit));
        if ($user_id <= 0) {
            return array();
        }
        $items = array();
        $receipts = $wpdb->get_results($wpdb->prepare("SELECT id, type, amount, status, created_at, reviewed_at, admin_note, attachment_id, file_url, remote_source FROM {$t['receipts']} WHERE user_id=%d AND type IN ('wallet','wallet_admin_credit','wallet_admin_debit','wallet_renewal','wallet_bot_renewal','wallet_extra_volume') ORDER BY id DESC LIMIT %d", $user_id, $limit));
        foreach ($receipts as $r) {
            $r_type = (string) $r->type;
            $is_debit = in_array($r_type, array('wallet_admin_debit','wallet_renewal','wallet_bot_renewal','wallet_extra_volume'), true);
            $title = 'شارژ کیف پول';
            if ($r_type === 'wallet_admin_credit') {
                $title = 'شارژ دستی کیف پول';
            } elseif ($r_type === 'wallet_admin_debit') {
                $title = ($r->remote_source ?? '') === 'reseller' ? 'پرداخت عملیات نمایندگی' : 'کسر دستی کیف پول';
            } elseif ($r_type === 'wallet_renewal') {
                $title = 'تمدید با کیف پول';
            } elseif ($r_type === 'wallet_bot_renewal') {
                $title = 'تمدید سفارش ربات با کیف پول';
            } elseif ($r_type === 'wallet_extra_volume') {
                $title = 'خرید حجم اضافه با کیف پول';
            }
            $items[] = (object) array(
                'kind' => $is_debit ? 'debit' : 'credit',
                'title' => $title,
                'amount' => (int) $r->amount,
                'status' => $r->status,
                'date' => !empty($r->reviewed_at) ? $r->reviewed_at : $r->created_at,
                'ref' => '#' . $r->id,
                'attachment_id' => (int) $r->attachment_id,
                'file_url' => $r->file_url,
                'note' => $r->admin_note,
            );
        }
        $orders = $wpdb->get_results($wpdb->prepare("SELECT id, order_code, price, status, payment_status, created_at, approved_at FROM {$t['orders']} WHERE user_id=%d AND submission_key LIKE %s ORDER BY id DESC LIMIT %d", $user_id, 'wallet-pay-%', $limit));
        foreach ($orders as $o) {
            $items[] = (object) array(
                'kind' => 'debit',
                'title' => 'پرداخت سفارش با کیف پول',
                'amount' => (int) $o->price,
                'status' => $o->payment_status ?: $o->status,
                'date' => !empty($o->approved_at) ? $o->approved_at : $o->created_at,
                'ref' => $o->order_code ?: ('#' . $o->id),
                'attachment_id' => 0,
                'file_url' => '',
                'note' => '',
            );
        }
        usort($items, function($a, $b) {
            return strcmp((string) $b->date, (string) $a->date);
        });
        return array_slice($items, 0, $limit);
    }


    public function admin_adjust_wallet($user_id, $direction, $amount, $note = '', $wallet_effect = 'local', $origin = 'admin_wallet_adjustment')
    {
        if (class_exists('IPSVP_Loyalty')) { IPSVP_Loyalty::clear_cache(); }
        global $wpdb;
        $t = $this->tables();
        $user_id = (int) $user_id;
        $amount = max(0, (int) $amount);
        $direction = $direction === 'debit' ? 'debit' : 'credit';
        $wallet_effect = $wallet_effect === 'remote' ? 'remote' : 'local';
        if ($user_id <= 0 || $amount < 1000) {
            return new WP_Error('invalid_wallet_adjustment', 'مبلغ یا کاربر معتبر نیست.');
        }
        $locked = IPSVP_Reseller_Store::lock($user_id);
        if (is_wp_error($locked)) { return $locked; }
        $user = $this->get_user_by_id($user_id);
        if (!$user) {
            return new WP_Error('wallet_user_not_found', 'کاربر پیدا نشد.');
        }
        if ($direction === 'debit' && $wallet_effect === 'local' && $this->get_local_wallet_balance($user_id) < $amount) {
            return new WP_Error('wallet_balance_low', 'موجودی کیف پول سایت برای کسر کافی نیست.');
        }
        $type = $direction === 'debit' ? 'wallet_admin_debit' : 'wallet_admin_credit';
        $inserted = $wpdb->insert($t['receipts'], array(
            'order_id' => 0,
            'submission_key' => 'wallet-admin-' . $direction . '-' . time() . '-' . wp_generate_password(6, false, false),
            'user_id' => $user_id,
            'phone' => $user->phone,
            'type' => $type,
            'plan_id' => null,
            'attachment_id' => 0,
            'file_url' => '',
            'amount' => $amount,
            'status' => 'approved',
            'wallet_effect' => $wallet_effect,
            'admin_note' => sanitize_textarea_field($note),
            'remote_source' => $wallet_effect === 'remote' && $origin === 'admin_wallet_adjustment' ? 'admin_wallet_pending' : (in_array($origin, array('admin_wallet_adjustment','service_payment','service_refund'), true) ? $origin : 'service_payment'),
            'created_at' => $this->now(),
            'reviewed_at' => $this->now(),
        ));
        if (!$inserted) {
            return new WP_Error('wallet_adjustment_insert_failed', 'ثبت تراکنش کیف پول در دیتابیس ناموفق بود.');
        }
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE id=%d", (int) $wpdb->insert_id));
    }

    public function confirm_admin_wallet_adjustment($receipt_id)
    {
        global $wpdb;
        $t = $this->tables();
        $changed = $wpdb->update($t['receipts'], array('remote_source' => 'admin_wallet_adjustment', 'reviewed_at' => $this->now()), array('id' => (int) $receipt_id, 'remote_source' => 'admin_wallet_pending', 'status' => 'approved', 'wallet_effect' => 'remote'));
        if (class_exists('IPSVP_Loyalty')) { IPSVP_Loyalty::clear_cache(); }
        return $changed === 1;
    }

    public function disconnect_bot_link($user_id)
    {
        global $wpdb;
        $t = $this->tables();
        return $wpdb->update($t['users'], array(
            'bot_tel_id' => null,
            'bot_username' => null,
            'bot_first_name' => null,
            'bot_link_code' => null,
            'bot_link_expires_at' => null,
            'bot_linked_at' => null,
        ), array('id' => (int) $user_id));
    }

    public function create_bot_link_code($phone)
    {
        global $wpdb;
        $t = $this->tables();
        $phone = $this->normalize_phone($phone);
        $user = $this->get_or_create_user($phone);
        if (!$user) {
            return new WP_Error('invalid_phone', 'شماره موبایل نامعتبر است.');
        }
        $code = (string) wp_rand(100000, 999999);
        $expires = date('Y-m-d H:i:s', current_time('timestamp') + 15 * MINUTE_IN_SECONDS);
        $wpdb->update($t['users'], array(
            'bot_link_code' => $code,
            'bot_link_expires_at' => $expires,
        ), array('id' => (int) $user->id));
        return array('code' => $code, 'expires_at' => $expires);
    }

    public function confirm_bot_link_code($code, $tel_id, $telegram = array())
    {
        global $wpdb;
        $t = $this->tables();
        $code = preg_replace('/[^0-9]/', '', (string) $code);
        $tel_id = preg_replace('/[^0-9\-]/', '', (string) $tel_id);
        if (!$code || !$tel_id) {
            return new WP_Error('invalid_link_data', 'کد اتصال یا شناسه تلگرام نامعتبر است.');
        }
        $now = $this->now();
        $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['users']} WHERE bot_link_code=%s AND (bot_link_expires_at IS NULL OR bot_link_expires_at >= %s) LIMIT 1", $code, $now));
        if (!$user) {
            return new WP_Error('invalid_link_code', 'کد اتصال نامعتبر یا منقضی شده است.');
        }
        $other_user_id = (int) $wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['users']} WHERE bot_tel_id=%s AND id<>%d LIMIT 1", $tel_id, (int) $user->id));
        if ($other_user_id > 0) {
            return new WP_Error('telegram_already_linked', 'این حساب تلگرام قبلا به یک حساب کاربری دیگر متصل شده است. ابتدا اتصال قبلی را قطع کنید.');
        }
        $linked_at = !empty($user->bot_linked_at) && (string) $user->bot_tel_id === (string) $tel_id ? (string) $user->bot_linked_at : $now;
        $wpdb->update($t['users'], array(
            'bot_tel_id' => $tel_id,
            'bot_username' => isset($telegram['username']) ? sanitize_text_field($telegram['username']) : null,
            'bot_first_name' => isset($telegram['first_name']) ? sanitize_text_field($telegram['first_name']) : null,
            'bot_link_code' => null,
            'bot_link_expires_at' => null,
            'bot_linked_at' => $linked_at,
            'last_seen_at' => $now,
        ), array('id' => (int) $user->id));
        if (class_exists('IPSVP_Customer_Loyalty_Sync')) {
            IPSVP_Customer_Loyalty_Sync::adopt_override($this->get_user_by_id($user->id));
        }
        return $this->get_user_by_id($user->id);
    }

    public function get_site_orders_for_sync($phone)
    {
        $orders = $this->get_user_orders($phone);
        $out = array();
        foreach ($orders as $o) {
            $payload = $this->order_payload_for_bot($o);
            if ($payload) {
                $out[] = $payload;
            }
        }
        return $out;
    }

    public function order_is_bot_managed($order)
    {
        // Proxy and other add-ons use base orders without a VPN plan.
        // Use the raw type: normalization maps unknown service types to shared.
        return $order && !empty($order->id)
            && (int) ($order->plan_id ?? 0) > 0
            && in_array((string) ($order->service_type ?? 'shared'), array('', 'shared'), true)
            && in_array((string) ($order->panel_provider ?? ''), array('', 'pasarguard'), true);
    }

    public function order_payload_for_bot($order)
    {
        if (!$this->order_is_bot_managed($order)) {
            return array();
        }
        $is_all_countries = ((int) ($order->country_id ?? -1) === 0);
        $all_country_group_id = $this->all_countries_group_id();
        $sync_country_id = $is_all_countries && $all_country_group_id > 0 ? $all_country_group_id : (int) ($order->country_id ?? 0);
        $pg_group_id = !empty($order->pg_group_id) ? (int) $order->pg_group_id : 0;
        if ($is_all_countries && $all_country_group_id > 0) {
            $pg_group_id = $all_country_group_id;
        }
        $pg_group_ids = $pg_group_id > 0 ? array($pg_group_id) : array();
        return array(
            'site_order_id' => (int) $order->id,
            'order_code' => (string) $order->order_code,
            'source' => 'wordpress',
            'service_type' => $this->order_service_type($order),
            'remark' => (string) $order->order_code,
            'plan' => (string) ($order->country_name ?? ''),
            'list_title' => (string) $order->order_code,
            'list_subtitle' => (string) ($order->country_name ?? ''),
            'display_title' => (string) $order->order_code,
            'display_subtitle' => (string) ($order->country_name ?? ''),
            'phone' => (string) $order->phone,
            'plan_title' => (string) ($order->plan_title ?? ''),
            'gb' => (int) ($order->gb ?? 0),
            'days' => (int) ($order->days ?? 0),
            'country_id' => $sync_country_id,
            'is_all_countries' => $is_all_countries,
            'all_countries_group_id' => $is_all_countries ? $all_country_group_id : 0,
            'country_name' => (string) ($order->country_name ?? ''),
            'country_flag' => (string) ($order->flag ?? ''),
            'price' => (int) ($order->price ?? 0),
            'status' => (string) ($order->status ?? ''),
            'pg_username' => (string) ($order->pg_username ?? ''),
            'pg_user_id' => (string) ($order->pg_user_id ?? ''),
            'pg_status' => (string) ($order->pg_status ?? ''),
            'pg_group_id' => $pg_group_id,
            'pg_group_ids' => $pg_group_ids,
            'panel_url' => $this->panel_url_for_bot_sync(),
            'panel_url_raw' => $this->panel_url_raw_for_bot_sync(),
            'subscription_url' => (string) ($order->pg_subscription_url ?? ''),
            'links' => !empty($order->pg_links) ? json_decode($order->pg_links, true) : array(),
            'created_at' => (string) ($order->created_at ?? ''),
            'approved_at' => (string) ($order->approved_at ?? ''),
        );
    }

    private function panel_url_raw_for_bot_sync()
    {
        $settings = IPSVP_Settings::get();
        return isset($settings['panel_url']) ? trim((string) $settings['panel_url']) : '';
    }

    private function panel_url_for_bot_sync()
    {
        $url = $this->panel_url_raw_for_bot_sync();
        if ($url === '') {
            return '';
        }

        if (!preg_match('#^https?://#i', $url)) {
            $url = 'https://' . $url;
        }

        $url = preg_replace('/#.*/', '', $url);
        $parts = wp_parse_url($url);
        if (empty($parts['scheme']) || empty($parts['host'])) {
            return rtrim($url, '/');
        }

        $base = strtolower($parts['scheme']) . '://' . $parts['host'];
        if (!empty($parts['port'])) {
            $base .= ':' . (int) $parts['port'];
        }

        $path = isset($parts['path']) ? trim($parts['path']) : '';
        $path = preg_replace('#/(dashboard|login|docs|redoc|openapi\.json).*$#i', '', $path);
        $path = trim($path, '/');
        if ($path !== '') {
            $base .= '/' . $path;
        }

        return rtrim($base, '/');
    }

    public function create_wallet_receipt($phone, $amount, $attachment_id, $file_url, $submission_key = '')
    {
        global $wpdb;
        $t = $this->tables();
        $phone = $this->normalize_phone($phone);
        $amount = max(0, (int) $amount);
        $submission_key = $this->sanitize_submission_key($submission_key);
        if ($submission_key) {
            $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE submission_key=%s", $submission_key));
            if ($existing) {
                return $existing;
            }
        }
        $user = $this->get_or_create_user($phone);
        if (!$user) {
            return new WP_Error('invalid_wallet_user', 'کاربر پیدا نشد.');
        }
        if ($amount < 1000) {
            return new WP_Error('invalid_amount', 'مبلغ شارژ کیف پول معتبر نیست.');
        }
        $wpdb->insert($t['receipts'], array(
            'order_id' => 0,
            'submission_key' => $submission_key ? $submission_key : null,
            'user_id' => (int) $user->id,
            'phone' => $user->phone,
            'type' => 'wallet',
            'plan_id' => null,
            'attachment_id' => (int) $attachment_id,
            'file_url' => esc_url_raw($file_url),
            'amount' => $amount,
            'status' => 'pending',
            'created_at' => $this->now(),
        ));
        $receipt_id = (int) $wpdb->insert_id;
        IPSVP_Telegram_Service::queue_pending_payment_notice($receipt_id, $this);
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE id=%d", $receipt_id));
    }

    public function normalize_service_type($service_type)
    {
        return sanitize_key((string) $service_type) === 'dedicated' ? 'dedicated' : 'shared';
    }

    public function active_plans($service_type = 'shared')
    {
        global $wpdb;
        $t = $this->tables();
        $service_type = $this->normalize_service_type($service_type);
        return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['plans']} WHERE status=1 AND service_type=%s ORDER BY sort_order ASC, id ASC", $service_type));
    }

    public function active_countries($service_type = 'shared')
    {
        global $wpdb;
        $t = $this->tables();
        $service_type = $this->normalize_service_type($service_type);
        return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['countries']} WHERE status=1 AND service_type=%s ORDER BY sort_order ASC, id ASC", $service_type));
    }

    public function get_plan($id)
    {
        global $wpdb;
        $t = $this->tables();
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['plans']} WHERE id=%d", $id));
    }

    public function get_country($id)
    {
        global $wpdb;
        $t = $this->tables();
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['countries']} WHERE id=%d", $id));
    }

    public function service_sales_enabled($service_type)
    {
        $settings = IPSVP_Settings::get();
        $key = $this->normalize_service_type($service_type) === 'dedicated' ? 'dedicated_sales_enabled' : 'shared_sales_enabled';
        return !isset($settings[$key]) || (string) $settings[$key] === '1';
    }

    public function order_service_type($order)
    {
        if ($order && !empty($order->service_type)) {
            return $this->normalize_service_type($order->service_type);
        }
        return 'shared';
    }

    public function renewable_statuses()
    {
        return array('created', 'active', 'on_hold', 'disabled', 'volume_finished', 'time_finished');
    }

    public function order_is_within_grace($order)
    {
        if (!$order) {
            return false;
        }
        $status = sanitize_key((string) ($order->status ?? ''));
        if (in_array($status, array('created', 'active', 'on_hold', 'disabled'), true)) {
            return true;
        }
        if (!in_array($status, array('volume_finished', 'time_finished'), true) || empty($order->service_ended_at)) {
            return false;
        }
        $ended = strtotime(get_gmt_from_date((string) $order->service_ended_at));
        return $ended && time() <= ($ended + (7 * DAY_IN_SECONDS));
    }

    public function order_can_renew($order)
    {
        return $order && in_array((string) $order->status, $this->renewable_statuses(), true) && $this->order_is_within_grace($order);
    }

    public function final_price($plan, $retail = false)
    {
        if (!$plan) {
            return 0;
        }
        $amount = ($plan->sale_price !== null && $plan->sale_price !== '' && (int) $plan->sale_price > 0) ? (int) $plan->sale_price : (int) $plan->price;
        return $retail ? $amount : IPSVP_Reseller::price($amount, $this->normalize_service_type($plan->service_type ?? 'shared'));
    }

    public function is_all_countries_selection($country_id)
    {
        return (int) $country_id === 0;
    }

    private function value_from_order($order, $key, $default = null)
    {
        if (is_array($order) && array_key_exists($key, $order)) {
            return $order[$key];
        }
        if (is_object($order) && isset($order->{$key})) {
            return $order->{$key};
        }
        $detail = array();
        if (is_array($order) && !empty($order['detail'])) {
            $detail = $order['detail'];
        } elseif (is_array($order) && !empty($order['raw']) && is_array($order['raw']) && !empty($order['raw']['detail'])) {
            $detail = $order['raw']['detail'];
        }
        if (is_string($detail)) {
            $decoded = json_decode($detail, true);
            $detail = is_array($decoded) ? $decoded : array();
        }
        if (is_array($detail) && array_key_exists($key, $detail)) {
            return $detail[$key];
        }
        if (is_array($detail) && !empty($detail['raw']) && is_array($detail['raw']) && array_key_exists($key, $detail['raw'])) {
            return $detail['raw'][$key];
        }
        return $default;
    }

    private function order_group_ids($order)
    {
        $ids = array();
        foreach (array('pg_group_ids', 'group_ids') as $key) {
            $raw = $this->value_from_order($order, $key, array());
            if (is_string($raw)) {
                $decoded = json_decode($raw, true);
                $raw = is_array($decoded) ? $decoded : preg_split('/\s*,\s*/', $raw);
            }
            foreach ((array) $raw as $id) {
                $id = (int) $id;
                if ($id > 0) {
                    $ids[] = $id;
                }
            }
        }
        foreach (array('pg_group_id', 'all_countries_group_id') as $key) {
            $id = (int) $this->value_from_order($order, $key, 0);
            if ($id > 0) {
                $ids[] = $id;
            }
        }
        return array_values(array_unique($ids));
    }

    public function is_all_countries_order($order)
    {
        if (!$order) {
            return false;
        }
        if (!empty($this->value_from_order($order, 'is_all_countries', 0))) {
            return true;
        }
        $country_id = $this->value_from_order($order, 'country_id', null);
        if ($country_id !== null && $this->is_all_countries_selection($country_id)) {
            return true;
        }
        $country_name = (string) $this->value_from_order($order, 'country_name', '');
        $configured_group_id = $this->all_countries_group_id();
        if ($configured_group_id > 0) {
            if ((int) $country_id === $configured_group_id && ($country_name === '' || mb_strpos($country_name, 'همه کشور') !== false)) {
                return true;
            }
            if (in_array($configured_group_id, $this->order_group_ids($order), true)) {
                return true;
            }
        }
        if ($country_name !== '' && mb_strpos($country_name, 'همه کشور') !== false) {
            return true;
        }
        $all_countries_meta = $this->value_from_order($order, '_all_countries', null);
        if (!empty($all_countries_meta)) {
            return true;
        }
        $raw_response = $this->value_from_order($order, 'pg_response', '');
        if (is_string($raw_response) && $raw_response !== '') {
            $decoded = json_decode($raw_response, true);
            if (is_array($decoded) && (!empty($decoded['_all_countries']) || !empty($decoded['raw']['_all_countries']))) {
                return true;
            }
        }
        return false;
    }

    public function all_countries_price_percent_value()
    {
        $settings = IPSVP_Settings::get();
        $raw = isset($settings['all_countries_price_percent']) ? trim((string) $settings['all_countries_price_percent']) : '';
        return is_numeric($raw) ? max(0, (float) $raw) : 0;
    }

    public function all_countries_enabled()
    {
        $settings = IPSVP_Settings::get();
        return !isset($settings['all_countries_enabled']) || $settings['all_countries_enabled'] === '1';
    }

    public function all_countries_group_id()
    {
        $settings = IPSVP_Settings::get();
        return !empty($settings['all_countries_group_id']) ? (int) $settings['all_countries_group_id'] : 0;
    }

    public function all_countries_group_name()
    {
        $settings = IPSVP_Settings::get();
        return !empty($settings['all_countries_group_name']) ? (string) $settings['all_countries_group_name'] : '';
    }

    public function all_countries_group_ready()
    {
        return $this->all_countries_enabled() && $this->all_countries_group_id() > 0;
    }

    public function all_countries_sync_country_id()
    {
        $group_id = $this->all_countries_group_id();
        return $group_id > 0 ? $group_id : 0;
    }

    public function is_all_countries_group_id($group_id)
    {
        $configured = $this->all_countries_group_id();
        return $configured > 0 && (int) $group_id === $configured;
    }

    public function all_countries_price($plan)
    {
        $base = $this->final_price($plan, true);
        $percent = $this->all_countries_price_percent_value();
        return IPSVP_Reseller::price((int) ceil($base + (($base * $percent) / 100)), $this->normalize_service_type($plan->service_type ?? 'shared'));
    }

    public function all_countries_price_note()
    {
        $settings = IPSVP_Settings::get();
        $percent = isset($settings['all_countries_price_percent']) ? max(0, (int) $settings['all_countries_price_percent']) : 30;
        return $percent > 0 ? ('+' . number_format_i18n($percent) . '٪') : 'بدون افزایش قیمت';
    }

    public function calculate_renewal_plan_price_info($plan, $order)
    {
        $base_price = $this->final_price($plan, true);
        $is_all_countries = $this->is_all_countries_order($order);
        $percent = $is_all_countries ? $this->all_countries_price_percent_value() : 0;
        $final_price = IPSVP_Reseller::price((int) ceil($base_price + (($base_price * $percent) / 100)), $this->order_service_type($order));
        return array(
            'renewal_plan_id' => $plan ? (int) $plan->id : 0,
            'renewal_plan_name' => $plan ? sanitize_text_field((string) $plan->title) : '',
            'renewal_base_price' => (int) $base_price,
            'all_countries_percent' => $percent,
            'renewal_final_price' => (int) $final_price,
            'is_all_countries' => $is_all_countries ? 1 : 0,
        );
    }

    public function calculate_renewal_plan_price($plan, $order)
    {
        $price = $this->calculate_renewal_plan_price_info($plan, $order);
        return (int) $price['renewal_final_price'];
    }

    public function ready_countries($service_type = 'shared')
    {
        $service_type = $this->normalize_service_type($service_type);
        $items = $this->active_countries($service_type);
        $ready = array();
        foreach ($items as $item) {
            if ($service_type === 'dedicated' || !empty($item->pg_group_id)) {
                $ready[] = $item;
            }
        }
        return $ready;
    }

    public function create_order($phone, $plan_id, $country_id, $attachment_id, $file_url, $submission_key = '')
    {
        global $wpdb;
        $t = $this->tables();
        $submission_key = $this->sanitize_submission_key($submission_key);
        if ($submission_key) {
            $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['orders']} WHERE submission_key=%s", $submission_key));
            if ($existing) {
                return $this->get_order($existing->id);
            }
        }
        $user = $this->get_or_create_user($phone);
        $plan = $this->get_plan($plan_id);
        $service_type = $plan ? $this->normalize_service_type($plan->service_type ?? 'shared') : 'shared';
        $all_countries = $this->is_all_countries_selection($country_id);
        $country = $all_countries ? null : $this->get_country($country_id);
        if (!$user || !$plan || (!$all_countries && !$country)) {
            return new WP_Error('invalid_order', 'اطلاعات سفارش ناقص یا نامعتبر است.');
        }
        if (!empty($user->is_blocked)) {
            return new WP_Error('user_blocked', 'این شماره توسط مدیریت مسدود شده و امکان ثبت سفارش ندارد.');
        }
        if (!$this->service_sales_enabled($service_type)) {
            return new WP_Error('service_sales_disabled', 'فروش این نوع سرویس در حال حاضر غیرفعال است.');
        }
        if ($country && $this->normalize_service_type($country->service_type ?? 'shared') !== $service_type) {
            return new WP_Error('service_type_mismatch', 'پلن و کشور انتخاب‌شده متعلق به یک نوع سرویس نیستند.');
        }
        if ($service_type === 'dedicated' && $all_countries) {
            return new WP_Error('dedicated_all_countries_invalid', 'برای سرویس اختصاصی باید یک کشور مشخص انتخاب شود.');
        }
        if ($all_countries) {
            if (!$this->all_countries_enabled()) {
                return new WP_Error('all_countries_disabled', 'گزینه همه کشورها در حال حاضر فعال نیست.');
            }
            if (!$this->all_countries_group_ready()) {
                return new WP_Error('all_countries_group_missing', 'گروه پاسارگارد گزینه همه کشورها انتخاب نشده است. از تنظیمات، گروه فروش همه کشورها را مشخص کنید.');
            }
        } elseif ($service_type === 'shared' && empty($country->pg_group_id)) {
            return new WP_Error('country_group_missing', 'برای این کشور هنوز گروه پاسارگارد تنظیم نشده است.');
        }

        $settings = IPSVP_Settings::get();
        $prefix = !empty($settings['order_prefix']) ? sanitize_key($settings['order_prefix']) : 'IPS';
        $code = strtoupper($prefix) . '-' . date_i18n('Ymd') . '-' . wp_generate_password(6, false, false);
        $price = $all_countries ? $this->all_countries_price($plan) : $this->final_price($plan);

        $wpdb->insert($t['orders'], array(
            'order_code' => $code,
            'service_type' => $service_type,
            'submission_key' => $submission_key ? $submission_key : null,
            'user_id' => $user->id,
            'phone' => $user->phone,
            'plan_id' => $plan->id,
            'country_id' => $all_countries ? 0 : $country->id,
            'price' => $price,
            'status' => 'waiting_review',
            'payment_status' => 'waiting_review',
            'created_at' => $this->now(),
            'updated_at' => $this->now(),
        ));
        $order_id = $wpdb->insert_id;

        $wpdb->insert($t['receipts'], array(
            'order_id' => $order_id,
            'submission_key' => $submission_key ? ('new-' . $submission_key) : null,
            'user_id' => $user->id,
            'phone' => $user->phone,
            'type' => 'new',
            'plan_id' => $plan->id,
            'attachment_id' => (int) $attachment_id,
            'file_url' => esc_url_raw($file_url),
            'amount' => $price,
            'status' => 'pending',
            'remote_payload' => wp_json_encode(array('payment_method' => 'card'), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'created_at' => $this->now(),
        ));
        $receipt_id = (int) $wpdb->insert_id;
        IPSVP_Telegram_Service::queue_pending_payment_notice($receipt_id, $this);

        return $this->get_order($order_id);
    }


    public function create_wallet_paid_order($phone, $plan_id, $country_id, $submission_key = '', $wallet_effect = 'local')
    {
        global $wpdb;
        $t = $this->tables();
        $submission_key = $this->sanitize_submission_key($submission_key);
        $wallet_effect = $wallet_effect === 'remote' ? 'remote' : 'local';
        if ($submission_key) {
            $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['orders']} WHERE submission_key=%s", $submission_key));
            if ($existing) {
                return $this->get_order($existing->id);
            }
        }
        $user = $this->get_or_create_user($phone);
        $plan = $this->get_plan($plan_id);
        $service_type = $plan ? $this->normalize_service_type($plan->service_type ?? 'shared') : 'shared';
        $all_countries = $this->is_all_countries_selection($country_id);
        $country = $all_countries ? null : $this->get_country($country_id);
        if (!$user || !$plan || (!$all_countries && !$country)) {
            return new WP_Error('invalid_order', 'اطلاعات سفارش ناقص یا نامعتبر است.');
        }
        if (!empty($user->is_blocked)) {
            return new WP_Error('user_blocked', 'این شماره توسط مدیریت مسدود شده و امکان ثبت سفارش ندارد.');
        }
        if (!$this->service_sales_enabled($service_type)) {
            return new WP_Error('service_sales_disabled', 'فروش این نوع سرویس در حال حاضر غیرفعال است.');
        }
        if ($country && $this->normalize_service_type($country->service_type ?? 'shared') !== $service_type) {
            return new WP_Error('service_type_mismatch', 'پلن و کشور انتخاب‌شده متعلق به یک نوع سرویس نیستند.');
        }
        if ($service_type === 'dedicated' && $all_countries) {
            return new WP_Error('dedicated_all_countries_invalid', 'برای سرویس اختصاصی باید یک کشور مشخص انتخاب شود.');
        }
        if ($all_countries) {
            if (!$this->all_countries_enabled()) {
                return new WP_Error('all_countries_disabled', 'گزینه همه کشورها در حال حاضر فعال نیست.');
            }
            if (!$this->all_countries_group_ready()) {
                return new WP_Error('all_countries_group_missing', 'گروه پاسارگارد گزینه همه کشورها انتخاب نشده است. از تنظیمات، گروه فروش همه کشورها را مشخص کنید.');
            }
        } elseif ($service_type === 'shared' && empty($country->pg_group_id)) {
            return new WP_Error('country_group_missing', 'برای این کشور هنوز گروه پاسارگارد تنظیم نشده است.');
        }

        $settings = IPSVP_Settings::get();
        $prefix = !empty($settings['order_prefix']) ? sanitize_key($settings['order_prefix']) : 'IPS';
        $code = strtoupper($prefix) . '-' . date_i18n('Ymd') . '-' . wp_generate_password(6, false, false);
        $price = $all_countries ? $this->all_countries_price($plan) : $this->final_price($plan);
        $wpdb->insert($t['orders'], array(
            'order_code' => $code,
            'service_type' => $service_type,
            'submission_key' => $submission_key ? $submission_key : null,
            'user_id' => $user->id,
            'phone' => $user->phone,
            'plan_id' => $plan->id,
            'country_id' => $all_countries ? 0 : $country->id,
            'price' => $price,
            'status' => $service_type === 'dedicated' ? 'awaiting_assignment' : 'wallet_paid',
            'payment_status' => 'wallet_paid',
            'wallet_effect' => $wallet_effect,
            'created_at' => $this->now(),
            'updated_at' => $this->now(),
            'approved_at' => $this->now(),
        ));
        return $this->get_order((int) $wpdb->insert_id);
    }


    public function create_crypto_pending_order($phone, $plan_id, $country_id, $submission_key = '')
    {
        global $wpdb;
        $t = $this->tables();
        $submission_key = $this->sanitize_submission_key($submission_key);
        if ($submission_key) {
            $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['orders']} WHERE submission_key=%s", $submission_key));
            if ($existing) {
                $receipt = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE order_id=%d AND type='crypto' ORDER BY id DESC LIMIT 1", (int) $existing->id));
                return array('order' => $this->get_order((int) $existing->id), 'receipt' => $receipt);
            }
        }
        $user = $this->get_or_create_user($phone);
        $plan = $this->get_plan($plan_id);
        $service_type = $plan ? $this->normalize_service_type($plan->service_type ?? 'shared') : 'shared';
        $all_countries = $this->is_all_countries_selection($country_id);
        $country = $all_countries ? null : $this->get_country($country_id);
        if (!$user || !$plan || (!$all_countries && !$country)) {
            return new WP_Error('invalid_crypto_order', 'اطلاعات سفارش کریپتو ناقص یا نامعتبر است.');
        }
        if (!empty($user->is_blocked)) {
            return new WP_Error('user_blocked', 'این شماره توسط مدیریت مسدود شده و امکان ثبت سفارش ندارد.');
        }
        if (!$this->service_sales_enabled($service_type)) {
            return new WP_Error('service_sales_disabled', 'فروش این نوع سرویس در حال حاضر غیرفعال است.');
        }
        if ($country && $this->normalize_service_type($country->service_type ?? 'shared') !== $service_type) {
            return new WP_Error('service_type_mismatch', 'پلن و کشور انتخاب‌شده متعلق به یک نوع سرویس نیستند.');
        }
        if ($service_type === 'dedicated' && $all_countries) {
            return new WP_Error('dedicated_all_countries_invalid', 'برای سرویس اختصاصی باید یک کشور مشخص انتخاب شود.');
        }
        if ($all_countries) {
            if (!$this->all_countries_enabled() || !$this->all_countries_group_ready()) {
                return new WP_Error('all_countries_group_missing', 'گروه پاسارگارد گزینه همه کشورها انتخاب نشده است.');
            }
        } elseif ($service_type === 'shared' && empty($country->pg_group_id)) {
            return new WP_Error('country_group_missing', 'برای این کشور هنوز گروه پاسارگارد تنظیم نشده است.');
        }
        $settings = IPSVP_Settings::get();
        $prefix = !empty($settings['order_prefix']) ? sanitize_key($settings['order_prefix']) : 'IPS';
        $code = strtoupper($prefix) . '-' . date_i18n('Ymd') . '-' . wp_generate_password(6, false, false);
        $price = $all_countries ? $this->all_countries_price($plan) : $this->final_price($plan);
        $wpdb->insert($t['orders'], array(
            'order_code' => $code,
            'service_type' => $service_type,
            'submission_key' => $submission_key ? $submission_key : null,
            'user_id' => $user->id,
            'phone' => $user->phone,
            'plan_id' => $plan->id,
            'country_id' => $all_countries ? 0 : $country->id,
            'price' => $price,
            'status' => 'crypto_pending',
            'payment_status' => 'crypto_pending',
            'created_at' => $this->now(),
            'updated_at' => $this->now(),
        ));
        $order_id = (int) $wpdb->insert_id;
        $wpdb->insert($t['receipts'], array(
            'order_id' => $order_id,
            'submission_key' => $submission_key ? ('crypto-' . $submission_key) : null,
            'user_id' => $user->id,
            'phone' => $user->phone,
            'type' => 'crypto',
            'plan_id' => $plan->id,
            'attachment_id' => 0,
            'file_url' => '',
            'amount' => $price,
            'status' => 'pending',
            'remote_source' => 'ramzino',
            'remote_payload' => wp_json_encode(array('payment_method' => 'crypto'), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'created_at' => $this->now(),
        ));
        return array('order' => $this->get_order($order_id), 'receipt' => $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE id=%d", (int) $wpdb->insert_id)));
    }


    public function create_crypto_wallet_receipt($phone, $amount, $submission_key = '')
    {
        global $wpdb;
        $t = $this->tables();
        $phone = $this->normalize_phone($phone);
        $submission_key = $this->sanitize_submission_key($submission_key);
        if ($submission_key) {
            $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE submission_key=%s", $submission_key));
            if ($existing) { return $existing; }
        }
        $user = $this->get_or_create_user($phone);
        $amount = (int) $amount;
        if (!$user || $amount < 1000) { return new WP_Error('invalid_crypto_wallet', 'مبلغ شارژ کیف پول معتبر نیست.'); }
        if (!empty($user->is_blocked)) { return new WP_Error('user_blocked', 'این شماره توسط مدیریت مسدود شده است.'); }
        $wpdb->insert($t['receipts'], array(
            'order_id' => 0,
            'submission_key' => $submission_key ? $submission_key : null,
            'user_id' => (int) $user->id,
            'phone' => $user->phone,
            'type' => 'wallet',
            'plan_id' => 0,
            'attachment_id' => 0,
            'file_url' => '',
            'amount' => $amount,
            'status' => 'pending',
            'remote_source' => 'ramzino',
            'created_at' => $this->now(),
        ));
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE id=%d", (int) $wpdb->insert_id));
    }

    private function renewal_receipt_payload($plan, $order_id, $amount, $payment_method, array $base = array())
    {
        $payload = is_array($base) ? $base : array();
        $payload['purpose'] = 'renewal';
        $payload['renewal_plan_id'] = (int) $plan->id;
        $payload['renewal_plan_name'] = sanitize_text_field((string) $plan->title);
        $payload['renewal_plan_volume_gb'] = (int) $plan->gb;
        $payload['renewal_plan_days'] = (int) $plan->days;
        if (!isset($payload['renewal_base_price'])) {
            $payload['renewal_base_price'] = (int) $amount;
        }
        if (!isset($payload['all_countries_percent'])) {
            $payload['all_countries_percent'] = 0;
        }
        if (!isset($payload['renewal_final_price'])) {
            $payload['renewal_final_price'] = (int) $amount;
        }
        if (!isset($payload['is_all_countries'])) {
            $payload['is_all_countries'] = 0;
        }
        $payload['renewal_amount'] = (int) $amount;
        $payload['order_id'] = (int) $order_id;
        $payload['payment_method'] = sanitize_key((string) $payment_method);
        return $payload;
    }

    public function create_crypto_renewal_receipt($order_id, $phone, $plan_id, $submission_key = '')
    {
        global $wpdb;
        $t = $this->tables();
        $phone = $this->normalize_phone($phone);
        $submission_key = $this->sanitize_submission_key($submission_key);
        if ($submission_key) {
            $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE submission_key=%s", $submission_key));
            if ($existing) { return $existing; }
        }
        $order = $this->get_order_by_phone($order_id, $phone);
        $plan = $this->get_plan($plan_id);
        if (!$order || !$plan) { return new WP_Error('invalid_crypto_renewal', 'اطلاعات تمدید کریپتو نامعتبر است.'); }
        if (!$this->order_can_renew($order) || (empty($order->pg_username) && empty($order->pg_user_id))) { return new WP_Error('not_renewable', 'این سفارش قابل تمدید نیست یا مهلت ۷ روزه آن پایان یافته است.'); }
        if ($this->normalize_service_type($plan->service_type ?? 'shared') !== $this->order_service_type($order)) { return new WP_Error('renewal_plan_type_mismatch', 'پلن تمدید باید از همان نوع سرویس سفارش باشد.'); }
        $user = $this->get_or_create_user($phone);
        if (!empty($user->is_blocked)) { return new WP_Error('user_blocked', 'این شماره توسط مدیریت مسدود شده و امکان تمدید ندارد.'); }
        $price_info = $this->calculate_renewal_plan_price_info($plan, $order);
        $price = (int) $price_info['renewal_final_price'];
        $price_info['order_id'] = (int) $order->id;
        $price_info['payment_method'] = 'crypto';
        $wpdb->insert($t['receipts'], array(
            'order_id' => (int) $order->id,
            'submission_key' => $submission_key ? $submission_key : null,
            'user_id' => (int) $user->id,
            'phone' => $user->phone,
            'type' => 'renewal',
            'plan_id' => (int) $plan->id,
            'attachment_id' => 0,
            'file_url' => '',
            'amount' => (int) $price,
            'status' => 'pending',
            'remote_source' => 'ramzino',
            'remote_payload' => wp_json_encode($this->renewal_receipt_payload($plan, $order->id, $price, 'crypto', $price_info), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'created_at' => $this->now(),
        ));
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE id=%d", (int) $wpdb->insert_id));
    }

    public function create_crypto_bot_renewal_receipt($bot_order, $phone, $plan_id, $submission_key = '')
    {
        global $wpdb;
        $t = $this->tables();
        $phone = $this->normalize_phone($phone);
        $submission_key = $this->sanitize_submission_key($submission_key);
        if ($submission_key) {
            $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE submission_key=%s", $submission_key));
            if ($existing) { return $existing; }
        }
        $bot_order = is_array($bot_order) ? $bot_order : array();
        $bot_order_id = isset($bot_order['id']) ? (int) $bot_order['id'] : 0;
        $plan = $this->get_plan($plan_id);
        $user = $this->get_or_create_user($phone);
        if (!$bot_order_id || !$plan || !$user) { return new WP_Error('invalid_crypto_bot_renewal', 'اطلاعات تمدید کریپتو سفارش ربات نامعتبر است.'); }
        if (!empty($user->is_blocked)) { return new WP_Error('user_blocked', 'این شماره توسط مدیریت مسدود شده و امکان تمدید ندارد.'); }
        if (empty($user->bot_tel_id)) { return new WP_Error('bot_not_linked', 'برای تمدید سفارش ربات، حساب سایت باید به ربات متصل باشد.'); }
        $price_info = $this->calculate_renewal_plan_price_info($plan, $bot_order);
        $price = (int) $price_info['renewal_final_price'];
        $price_info['order_id'] = 0;
        $price_info['payment_method'] = 'crypto';
        $wpdb->insert($t['receipts'], array(
            'order_id' => 0,
            'submission_key' => $submission_key ? $submission_key : null,
            'user_id' => (int) $user->id,
            'phone' => $user->phone,
            'type' => 'bot_renewal',
            'plan_id' => (int) $plan->id,
            'attachment_id' => 0,
            'file_url' => '',
            'amount' => (int) $price,
            'status' => 'pending',
            'remote_source' => 'ramzino',
            'remote_order_id' => (string) $bot_order_id,
            'remote_payload' => wp_json_encode($this->renewal_receipt_payload($plan, 0, $price, 'crypto', array_merge($bot_order, $price_info)), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'created_at' => $this->now(),
        ));
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE id=%d", (int) $wpdb->insert_id));
    }

    public function get_order($id)
    {
        global $wpdb;
        $t = $this->tables();
        return $wpdb->get_row($wpdb->prepare("SELECT o.*, p.title plan_title, p.gb, p.days, CASE WHEN o.country_id=0 THEN 'همه کشورها' ELSE c.name END country_name, CASE WHEN o.country_id=0 THEN '🌍' ELSE c.flag END flag, c.pg_group_id, c.pg_group_name
            FROM {$t['orders']} o
            LEFT JOIN {$t['plans']} p ON p.id=o.plan_id
            LEFT JOIN {$t['countries']} c ON c.id=o.country_id
            WHERE o.id=%d", $id));
    }

    public function get_order_by_submission_key($submission_key)
    {
        global $wpdb;
        $t = $this->tables();
        $submission_key = $this->sanitize_submission_key($submission_key);
        if (!$submission_key) {
            return null;
        }
        $row = $wpdb->get_row($wpdb->prepare("SELECT id FROM {$t['orders']} WHERE submission_key=%s", $submission_key));
        return $row ? $this->get_order($row->id) : null;
    }

    public function get_receipt_by_submission_key($submission_key)
    {
        global $wpdb;
        $t = $this->tables();
        $submission_key = $this->sanitize_submission_key($submission_key);
        if (!$submission_key) {
            return null;
        }
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE submission_key=%s", $submission_key));
    }

    public function get_order_by_phone($id, $phone)
    {
        global $wpdb;
        $t = $this->tables();
        $phone = $this->normalize_phone($phone);
        return $wpdb->get_row($wpdb->prepare("SELECT o.*, p.title plan_title, p.gb, p.days, CASE WHEN o.country_id=0 THEN 'همه کشورها' ELSE c.name END country_name, CASE WHEN o.country_id=0 THEN '🌍' ELSE c.flag END flag, c.pg_group_id, c.pg_group_name
            FROM {$t['orders']} o
            LEFT JOIN {$t['plans']} p ON p.id=o.plan_id
            LEFT JOIN {$t['countries']} c ON c.id=o.country_id
            WHERE o.id=%d AND o.phone=%s", $id, $phone));
    }

    public function get_user_orders($phone)
    {
        global $wpdb;
        $t = $this->tables();
        $phone = $this->normalize_phone($phone);
        $orders = $wpdb->get_results($wpdb->prepare("SELECT o.*, p.title plan_title, p.gb, p.days, CASE WHEN o.country_id=0 THEN 'همه کشورها' ELSE c.name END country_name, CASE WHEN o.country_id=0 THEN '🌍' ELSE c.flag END flag
            FROM {$t['orders']} o
            LEFT JOIN {$t['plans']} p ON p.id=o.plan_id
            LEFT JOIN {$t['countries']} c ON c.id=o.country_id
            WHERE o.phone=%s ORDER BY o.id DESC", $phone));
        return apply_filters('ipsvp_user_orders', $orders, $phone, $this);
    }

    private function find_expiry_value($value)
    {
        if (!is_array($value)) {
            return '';
        }
        $keys = array('expire', 'expired_at', 'expiry_time', 'expire_at', 'expires_at', 'expiration', 'expiry');
        foreach ($keys as $key) {
            if (array_key_exists($key, $value) && !is_array($value[$key]) && !is_object($value[$key]) && $value[$key] !== '') {
                return (string) $value[$key];
            }
        }
        if (!empty($value['after']) && is_array($value['after'])) {
            $found = $this->find_expiry_value($value['after']);
            if ($found !== '') {
                return $found;
            }
        }
        foreach ($value as $key => $nested) {
            if ((string) $key === 'after') {
                continue;
            }
            if (is_array($nested)) {
                $found = $this->find_expiry_value($nested);
                if ($found !== '') {
                    return $found;
                }
            }
        }
        return '';
    }

    public function order_pasarguard_expiry($order)
    {
        if (!$order || empty($order->pg_response)) {
            return array('value' => '', 'timestamp' => 0);
        }
        $raw = json_decode((string) $order->pg_response, true);
        $value = is_array($raw) ? $this->find_expiry_value($raw) : '';
        if ($value === '') {
            return array('value' => '', 'timestamp' => 0);
        }
        if (is_numeric($value)) {
            $number = (float) $value;
            $timestamp = $number > 1000000000000 ? (int) floor($number / 1000) : (int) $number;
        } else {
            $timestamp = strtotime($value);
        }
        return array('value' => $value, 'timestamp' => $timestamp ? (int) $timestamp : 0);
    }

    public function get_dedicated_expiring_orders($days = 5)
    {
        global $wpdb;
        $t = $this->tables();
        $orders = $wpdb->get_results("SELECT o.*, p.title plan_title,
                CASE WHEN o.country_id=0 THEN 'همه کشورها' ELSE c.name END country_name,
                CASE WHEN o.country_id=0 THEN '🌍' ELSE c.flag END flag,
                (SELECT COUNT(*) FROM {$t['receipts']} r
                    WHERE r.order_id=o.id
                      AND r.type IN ('renewal','wallet_renewal')
                      AND r.status='pending') pending_renewal_count
            FROM {$t['orders']} o
            LEFT JOIN {$t['plans']} p ON p.id=o.plan_id
            LEFT JOIN {$t['countries']} c ON c.id=o.country_id
            WHERE o.service_type='dedicated'
              AND o.status IN ('created','active','on_hold','volume_finished','time_finished')
              AND (o.pg_username IS NOT NULL AND o.pg_username<>'' OR o.pg_user_id IS NOT NULL AND o.pg_user_id<>'')");
        $deadline = time() + (max(1, (int) $days) * DAY_IN_SECONDS);
        $result = array();
        foreach ($orders as $order) {
            $expiry = $this->order_pasarguard_expiry($order);
            if (empty($expiry['timestamp']) || (int) $expiry['timestamp'] > $deadline) {
                continue;
            }
            $order->pasarguard_expiry = (string) $expiry['value'];
            $order->pasarguard_expiry_ts = (int) $expiry['timestamp'];
            $order->seconds_left = (int) $expiry['timestamp'] - time();
            $order->renewal_pending = (int) $order->pending_renewal_count > 0;
            $result[] = $order;
        }
        usort($result, static function ($a, $b) {
            return (int) $a->pasarguard_expiry_ts <=> (int) $b->pasarguard_expiry_ts;
        });
        return $result;
    }

    public function update_order($id, $data)
    {
        global $wpdb;
        $t = $this->tables();
        $data['updated_at'] = $this->now();
        return $wpdb->update($t['orders'], $data, array('id' => (int) $id));
    }

    public function confirm_dedicated_order_payment($order_id, array $data, $receipt_id = 0)
    {
        global $wpdb;
        $order = $this->get_order($order_id);
        if (!$order || $this->order_service_type($order) !== 'dedicated') { return new WP_Error('dedicated_order_missing', 'سفارش اختصاصی پیدا نشد.'); }
        $t = $this->tables();
        if ($wpdb->query('START TRANSACTION') === false) { return new WP_Error('payment_transaction', 'آغاز ذخیره اطلاعات پرداخت ناموفق بود.'); }
        // Only the initial purchase is confirmed here. Renewal/extra-volume approval
        // must go through its own workflow so the purchased benefit is actually applied.
        $receipts = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE order_id=%d AND type='new' AND status='pending'" . ($receipt_id > 0 ? ' AND id=%d' : '') . ' FOR UPDATE', ...($receipt_id > 0 ? array($order_id, $receipt_id) : array($order_id))));
        if ($receipts === null || !empty($wpdb->last_error) || ($receipt_id > 0 && !$receipts)) {
            $wpdb->query('ROLLBACK');
            return new WP_Error('receipt_not_pending', 'رسید در انتظار بررسی پیدا نشد یا قبلاً بررسی شده است.');
        }
        $data['payment_status'] = 'approved';
        $data['approved_at'] = !empty($order->approved_at) ? $order->approved_at : $this->now();
        if ($this->update_order($order_id, $data) === false) {
            $wpdb->query('ROLLBACK');
            return new WP_Error('order_payment_save', 'ذخیره وضعیت سفارش ناموفق بود.');
        }
        foreach ($receipts as $receipt) {
            if ($wpdb->update($t['receipts'], array('status' => 'approved', 'reviewed_at' => $this->now()), array('id' => (int) $receipt->id, 'order_id' => (int) $order_id, 'status' => 'pending')) !== 1) {
                $wpdb->query('ROLLBACK');
                return new WP_Error('receipt_payment_save', 'ذخیره تایید رسید ناموفق بود.');
            }
        }
        if ($wpdb->query('COMMIT') === false) { $wpdb->query('ROLLBACK'); return new WP_Error('payment_commit', 'ثبت نهایی پرداخت ناموفق بود.'); }
        return $receipts;
    }

    private function snapshot_timestamp($value)
    {
        if ($value === '' || $value === null || is_array($value) || is_object($value)) {
            return 0;
        }
        if (is_numeric($value)) {
            $value = (float) $value;
            return $value > 1000000000000 ? (int) floor($value / 1000) : (int) $value;
        }
        $timestamp = strtotime((string) $value);
        return $timestamp ? (int) $timestamp : 0;
    }

    public function apply_order_lifecycle_snapshot($order, $snapshot)
    {
        if (!$order || empty($order->id) || !is_array($snapshot) || empty($snapshot['live'])) {
            return $order;
        }
        $current = sanitize_key((string) ($order->status ?? ''));
        if (in_array($current, array('pending_receipt','waiting_review','crypto_pending','rejected','failed','awaiting_assignment','cancelled'), true)) {
            return $order;
        }

        $now = time();
        $expire_ts = $this->snapshot_timestamp($snapshot['expire'] ?? '');
        $used = isset($snapshot['used']) && is_numeric($snapshot['used']) ? (float) $snapshot['used'] : null;
        $limit = isset($snapshot['limit']) && is_numeric($snapshot['limit']) ? (float) $snapshot['limit'] : null;
        $remote_status = strtolower(trim((string) ($snapshot['status'] ?? '')));
        $next = in_array($current, array('created','active','on_hold','disabled','volume_finished','time_finished'), true) ? $current : 'active';

        if (($expire_ts > 0 && $expire_ts <= $now) || $remote_status === 'expired') {
            $next = 'time_finished';
        } elseif ($remote_status === 'limited' || ($limit !== null && $limit > 0 && $used !== null && $used >= $limit)) {
            $next = 'volume_finished';
        } elseif (in_array($remote_status, array('disabled','deleted'), true)) {
            $next = 'disabled';
        } elseif ($remote_status === 'on_hold') {
            $next = 'on_hold';
        } elseif ($remote_status === 'active') {
            $next = 'active';
        } elseif ($remote_status === '' && $expire_ts > $now && ($limit === null || $limit <= 0 || $used === null || $used < $limit)) {
            $next = in_array($current, array('created','active','on_hold'), true) ? $current : 'active';
        }

        $update = array();
        $ended_at = !empty($order->service_ended_at) ? (string) $order->service_ended_at : '';
        if (in_array($next, array('volume_finished','time_finished'), true)) {
            if ($ended_at === '') {
                $ended_at = $this->now();
                $update['service_ended_at'] = $ended_at;
            }
            $ended_ts = strtotime(get_gmt_from_date($ended_at));
            if ($ended_ts && $now > ($ended_ts + (7 * DAY_IN_SECONDS))) {
                $next = 'cancelled';
                $update['cancelled_at'] = $this->now();
            }
        } elseif (in_array($next, array('active','on_hold'), true)) {
            $update['service_ended_at'] = null;
            $update['cancelled_at'] = null;
        }

        if ($next !== $current) {
            $update['status'] = $next;
        }
        if ($update) {
            $this->update_order((int) $order->id, $update);
            if ($next !== $current) {
                $this->create_user_notification(
                    (int) ($order->user_id ?? 0),
                    (string) ($order->phone ?? ''),
                    'تغییر وضعیت سرویس',
                    'وضعیت سفارش ' . (string) ($order->order_code ?? ('#' . (int) $order->id)) . ' به «' . $this->status_label($next) . '» تغییر کرد.',
                    'order',
                    (int) $order->id
                );
            }
            return $this->get_order((int) $order->id);
        }
        return $order;
    }

    public function get_receipt($id)
    {
        global $wpdb;
        $t = $this->tables();
        return $wpdb->get_row($wpdb->prepare("SELECT r.*, o.order_code, o.plan_id order_plan_id, o.country_id, o.status order_status
            FROM {$t['receipts']} r
            LEFT JOIN {$t['orders']} o ON o.id=r.order_id
            WHERE r.id=%d", $id));
    }

    public function get_user_by_phone($phone)
    {
        global $wpdb;
        $t = $this->tables();
        $phone = $this->normalize_phone($phone);
        if (!$phone) {
            return null;
        }
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['users']} WHERE phone=%s", $phone));
    }

    public function set_user_password($phone, $password)
    {
        global $wpdb;
        $t = $this->tables();
        $phone = $this->normalize_phone($phone);
        if (!$phone || trim((string) $password) === '') {
            return false;
        }
        $this->get_or_create_user($phone);
        return $wpdb->update($t['users'], array(
            'password_hash' => wp_hash_password($password),
            'last_seen_at' => $this->now(),
        ), array('phone' => $phone));
    }

    public function create_renewal_receipt($order_id, $phone, $plan_id, $attachment_id, $file_url, $submission_key = '')
    {
        global $wpdb;
        $t = $this->tables();
        $phone = $this->normalize_phone($phone);
        $submission_key = $this->sanitize_submission_key($submission_key);
        if ($submission_key) {
            $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE submission_key=%s", $submission_key));
            if ($existing) {
                return $existing;
            }
        }
        $order = $this->get_order_by_phone($order_id, $phone);
        $plan = $this->get_plan($plan_id);
        if (!$order || !$plan) {
            return new WP_Error('invalid_renewal', 'اطلاعات تمدید نامعتبر است.');
        }
        if (!$this->order_can_renew($order) || (empty($order->pg_username) && empty($order->pg_user_id))) {
            return new WP_Error('not_renewable', 'این سفارش قابل تمدید نیست یا مهلت ۷ روزه آن پایان یافته است.');
        }
        if ($this->normalize_service_type($plan->service_type ?? 'shared') !== $this->order_service_type($order)) {
            return new WP_Error('renewal_plan_type_mismatch', 'پلن تمدید باید از همان نوع سرویس سفارش باشد.');
        }
        $user = $this->get_or_create_user($phone);
        if (!empty($user->is_blocked)) {
            return new WP_Error('user_blocked', 'این شماره توسط مدیریت مسدود شده و امکان تمدید ندارد.');
        }
        $price_info = $this->calculate_renewal_plan_price_info($plan, $order);
        $price = (int) $price_info['renewal_final_price'];
        $price_info['order_id'] = (int) $order->id;
        $price_info['payment_method'] = 'card';
        $wpdb->insert($t['receipts'], array(
            'order_id' => $order->id,
            'submission_key' => $submission_key ? $submission_key : null,
            'user_id' => $user->id,
            'phone' => $user->phone,
            'type' => 'renewal',
            'plan_id' => $plan->id,
            'attachment_id' => (int) $attachment_id,
            'file_url' => esc_url_raw($file_url),
            'amount' => $price,
            'status' => 'pending',
            'remote_payload' => wp_json_encode($this->renewal_receipt_payload($plan, $order->id, $price, 'card', $price_info), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'created_at' => $this->now(),
        ));
        $receipt_id = (int) $wpdb->insert_id;
        IPSVP_Telegram_Service::queue_pending_payment_notice($receipt_id, $this);
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE id=%d", $receipt_id));
    }

    public function create_bot_renewal_receipt($bot_order, $phone, $plan_id, $attachment_id, $file_url, $submission_key = '')
    {
        global $wpdb;
        $t = $this->tables();
        $phone = $this->normalize_phone($phone);
        $submission_key = $this->sanitize_submission_key($submission_key);
        if ($submission_key) {
            $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE submission_key=%s", $submission_key));
            if ($existing) {
                return $existing;
            }
        }
        $bot_order = is_array($bot_order) ? $bot_order : array();
        $bot_order_id = isset($bot_order['id']) ? (int) $bot_order['id'] : 0;
        $plan = $this->get_plan($plan_id);
        $user = $this->get_or_create_user($phone);
        if (!$bot_order_id || !$plan || !$user) {
            return new WP_Error('invalid_bot_renewal', 'اطلاعات تمدید سفارش ربات نامعتبر است.');
        }
        if (!empty($user->is_blocked)) {
            return new WP_Error('user_blocked', 'این شماره توسط مدیریت مسدود شده و امکان تمدید ندارد.');
        }
        if (empty($user->bot_tel_id)) {
            return new WP_Error('bot_not_linked', 'برای تمدید سفارش ربات، حساب سایت باید به ربات متصل باشد.');
        }
        $price_info = $this->calculate_renewal_plan_price_info($plan, $bot_order);
        $price = (int) $price_info['renewal_final_price'];
        $price_info['order_id'] = 0;
        $price_info['payment_method'] = 'card';
        $wpdb->insert($t['receipts'], array(
            'order_id' => 0,
            'submission_key' => $submission_key ? $submission_key : null,
            'user_id' => (int) $user->id,
            'phone' => $user->phone,
            'type' => 'bot_renewal',
            'plan_id' => (int) $plan->id,
            'attachment_id' => (int) $attachment_id,
            'file_url' => esc_url_raw($file_url),
            'amount' => $price,
            'status' => 'pending',
            'remote_source' => 'bot',
            'remote_order_id' => (string) $bot_order_id,
            'remote_payload' => wp_json_encode($this->renewal_receipt_payload($plan, 0, $price, 'card', array_merge($bot_order, $price_info)), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'created_at' => $this->now(),
        ));
        $receipt_id = (int) $wpdb->insert_id;
        IPSVP_Telegram_Service::queue_pending_payment_notice($receipt_id, $this);
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE id=%d", $receipt_id));
    }


    public function create_wallet_renewal_receipt($order_id, $phone, $plan_id, $submission_key = '')
    {
        global $wpdb;
        $t = $this->tables();
        $phone = $this->normalize_phone($phone);
        $submission_key = $this->sanitize_submission_key($submission_key);
        if ($submission_key) {
            $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE submission_key=%s", $submission_key));
            if ($existing) {
                return $existing;
            }
        }
        $order = $this->get_order_by_phone($order_id, $phone);
        $plan = $this->get_plan($plan_id);
        if (!$order || !$plan) {
            return new WP_Error('invalid_wallet_renewal', 'اطلاعات تمدید با کیف پول نامعتبر است.');
        }
        if (!$this->order_can_renew($order) || (empty($order->pg_username) && empty($order->pg_user_id))) {
            return new WP_Error('not_renewable', 'این سفارش قابل تمدید نیست یا مهلت ۷ روزه آن پایان یافته است.');
        }
        if ($this->normalize_service_type($plan->service_type ?? 'shared') !== $this->order_service_type($order)) {
            return new WP_Error('renewal_plan_type_mismatch', 'پلن تمدید باید از همان نوع سرویس سفارش باشد.');
        }
        $user = $this->get_or_create_user($phone);
        if (!empty($user->is_blocked)) {
            return new WP_Error('user_blocked', 'این شماره توسط مدیریت مسدود شده و امکان تمدید ندارد.');
        }
        $price_info = $this->calculate_renewal_plan_price_info($plan, $order);
        $price = (int) $price_info['renewal_final_price'];
        $price_info['order_id'] = (int) $order->id;
        $price_info['payment_method'] = 'wallet';
        $wpdb->insert($t['receipts'], array(
            'order_id' => (int) $order->id,
            'submission_key' => $submission_key ? $submission_key : null,
            'user_id' => (int) $user->id,
            'phone' => $user->phone,
            'type' => 'wallet_renewal',
            'plan_id' => (int) $plan->id,
            'attachment_id' => 0,
            'file_url' => '',
            'amount' => (int) $price,
            'status' => 'pending',
            'remote_payload' => wp_json_encode($this->renewal_receipt_payload($plan, $order->id, $price, 'wallet', $price_info), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'created_at' => $this->now(),
        ));
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE id=%d", (int) $wpdb->insert_id));
    }

    public function create_wallet_bot_renewal_receipt($bot_order, $phone, $plan_id, $submission_key = '')
    {
        global $wpdb;
        $t = $this->tables();
        $phone = $this->normalize_phone($phone);
        $submission_key = $this->sanitize_submission_key($submission_key);
        if ($submission_key) {
            $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE submission_key=%s", $submission_key));
            if ($existing) {
                return $existing;
            }
        }
        $bot_order = is_array($bot_order) ? $bot_order : array();
        $bot_order_id = isset($bot_order['id']) ? (int) $bot_order['id'] : 0;
        $plan = $this->get_plan($plan_id);
        $user = $this->get_or_create_user($phone);
        if (!$bot_order_id || !$plan || !$user) {
            return new WP_Error('invalid_wallet_bot_renewal', 'اطلاعات تمدید سفارش ربات با کیف پول نامعتبر است.');
        }
        if (!empty($user->is_blocked)) {
            return new WP_Error('user_blocked', 'این شماره توسط مدیریت مسدود شده و امکان تمدید ندارد.');
        }
        if (empty($user->bot_tel_id)) {
            return new WP_Error('bot_not_linked', 'برای تمدید سفارش ربات، حساب سایت باید به ربات متصل باشد.');
        }
        $price_info = $this->calculate_renewal_plan_price_info($plan, $bot_order);
        $price = (int) $price_info['renewal_final_price'];
        $price_info['order_id'] = 0;
        $price_info['payment_method'] = 'wallet';
        $wpdb->insert($t['receipts'], array(
            'order_id' => 0,
            'submission_key' => $submission_key ? $submission_key : null,
            'user_id' => (int) $user->id,
            'phone' => $user->phone,
            'type' => 'wallet_bot_renewal',
            'plan_id' => (int) $plan->id,
            'attachment_id' => 0,
            'file_url' => '',
            'amount' => (int) $price,
            'status' => 'pending',
            'remote_source' => 'bot',
            'remote_order_id' => (string) $bot_order_id,
            'remote_payload' => wp_json_encode($this->renewal_receipt_payload($plan, 0, $price, 'wallet', array_merge($bot_order, $price_info)), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'created_at' => $this->now(),
        ));
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE id=%d", (int) $wpdb->insert_id));
    }

    public function extra_volume_unit_price($service_type = 'shared')
    {
        $settings = IPSVP_Settings::get();
        $key = $this->normalize_service_type($service_type) === 'dedicated' ? 'dedicated_extra_volume_price_per_gb' : 'extra_volume_price_per_gb';
        $raw = isset($settings[$key]) ? trim((string) $settings[$key]) : '';
        return is_numeric($raw) ? max(0, (int) $raw) : 0;
    }

    public function calculate_extra_volume_price($order, $gb = 1, $retail = false)
    {
        $gb = (int) $gb;
        if ($gb < 1) {
            return new WP_Error('invalid_extra_volume_gb', 'مقدار حجم اضافه باید عدد صحیح مثبت باشد.');
        }
        $base_unit_price = $this->extra_volume_unit_price($this->order_service_type($order));
        if ($base_unit_price <= 0) {
            return new WP_Error('extra_volume_price_missing', 'قیمت هر گیگ حجم اضافه در تنظیمات معتبر نیست.');
        }
        $is_all_countries = $this->is_all_countries_order($order);
        $percent = $is_all_countries ? $this->all_countries_price_percent_value() : 0;
        $final_unit_price = (int) ceil($base_unit_price + (($base_unit_price * $percent) / 100));
        return array(
            'extra_gb' => $gb,
            'base_unit_price' => (int) $base_unit_price,
            'all_countries_percent' => $percent,
            'final_unit_price' => $retail ? (int) $final_unit_price : IPSVP_Reseller::price((int) $final_unit_price, $this->order_service_type($order)),
            'total_amount' => $retail ? (int) ($final_unit_price * $gb) : IPSVP_Reseller::price((int) ($final_unit_price * $gb), $this->order_service_type($order)),
            'is_all_countries' => $is_all_countries ? 1 : 0,
        );
    }

    public function get_extra_volume_unit_price($order)
    {
        $price = $this->calculate_extra_volume_price($order, 1);
        if (is_wp_error($price)) {
            return $price;
        }
        return (int) $price['final_unit_price'];
    }

    public function create_extra_volume_receipt($order_id, $phone, $gb, $payment_method, $attachment_id = 0, $file_url = '', $submission_key = '')
    {
        global $wpdb;
        $t = $this->tables();
        $phone = $this->normalize_phone($phone);
        $submission_key = $this->sanitize_submission_key($submission_key);
        if ($submission_key) {
            $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE submission_key=%s", $submission_key));
            if ($existing) {
                return $existing;
            }
        }
        $order = $this->get_order_by_phone($order_id, $phone);
        if (!$order) {
            return new WP_Error('invalid_extra_volume_order', 'سفارش برای خرید حجم اضافه پیدا نشد.');
        }
        if (!$this->order_can_renew($order) || (empty($order->pg_username) && empty($order->pg_user_id))) {
            return new WP_Error('extra_volume_not_available', 'این سفارش قابل افزایش حجم نیست یا مهلت ۷ روزه آن پایان یافته است.');
        }
        $gb = (int) $gb;
        if ($gb < 1) {
            return new WP_Error('invalid_extra_volume_gb', 'مقدار حجم اضافه باید عدد صحیح مثبت باشد.');
        }
        $payment_method = sanitize_key($payment_method);
        if (!in_array($payment_method, array('card', 'wallet', 'crypto'), true)) {
            return new WP_Error('invalid_extra_volume_payment_method', 'روش پرداخت خرید حجم اضافه معتبر نیست.');
        }
        $user = $this->get_or_create_user($phone);
        if (!$user || (int) $user->id !== (int) $order->user_id) {
            return new WP_Error('invalid_extra_volume_user', 'کاربر سفارش معتبر نیست.');
        }
        if (!empty($user->is_blocked)) {
            return new WP_Error('user_blocked', 'این شماره توسط مدیریت مسدود شده و امکان خرید حجم اضافه ندارد.');
        }
        $price = $this->calculate_extra_volume_price($order, $gb);
        if (is_wp_error($price)) {
            return $price;
        }
        $unit_price = (int) $price['final_unit_price'];
        $amount = (int) $price['total_amount'];
        $type = $payment_method === 'wallet' ? 'wallet_extra_volume' : 'extra_volume';
        $payload = array(
            'purpose' => 'extra_volume',
            'order_id' => (int) $order->id,
            'user_id' => (int) $user->id,
            'gb' => $gb,
            'extra_gb' => $gb,
            'base_unit_price' => (int) $price['base_unit_price'],
            'all_countries_percent' => $price['all_countries_percent'],
            'final_unit_price' => $unit_price,
            'total_amount' => $amount,
            'is_all_countries' => !empty($price['is_all_countries']) ? 1 : 0,
            'unit_price' => $unit_price,
            'amount' => $amount,
            'payment_method' => $payment_method,
            'payment_status' => 'pending',
            'extra_volume_applied' => 0,
            'telegram_report_sent' => 0,
        );
        $wpdb->insert($t['receipts'], array(
            'order_id' => (int) $order->id,
            'submission_key' => $submission_key ? $submission_key : null,
            'user_id' => (int) $user->id,
            'phone' => $user->phone,
            'type' => $type,
            'plan_id' => 0,
            'attachment_id' => (int) $attachment_id,
            'file_url' => esc_url_raw($file_url),
            'amount' => (int) $amount,
            'status' => 'pending',
            'remote_source' => $payment_method === 'crypto' ? 'ramzino' : null,
            'remote_payload' => wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'created_at' => $this->now(),
        ));
        $receipt_id = (int) $wpdb->insert_id;
        if ($payment_method === 'card') {
            IPSVP_Telegram_Service::queue_pending_payment_notice($receipt_id, $this);
        }
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE id=%d", $receipt_id));
    }

    public function get_bot_order_renewal_receipts($bot_order_id, $phone = '')
    {
        global $wpdb;
        $t = $this->tables();
        $bot_order_id = (string) (int) $bot_order_id;
        if ($bot_order_id === '0') {
            return array();
        }
        if ($phone !== '') {
            $phone = $this->normalize_phone($phone);
            return $wpdb->get_results($wpdb->prepare("SELECT r.*, p.title plan_title, p.gb, p.days FROM {$t['receipts']} r LEFT JOIN {$t['plans']} p ON p.id=r.plan_id WHERE r.type IN ('bot_renewal','wallet_bot_renewal') AND r.remote_order_id=%s AND r.phone=%s ORDER BY r.id DESC", $bot_order_id, $phone));
        }
        return $wpdb->get_results($wpdb->prepare("SELECT r.*, p.title plan_title, p.gb, p.days FROM {$t['receipts']} r LEFT JOIN {$t['plans']} p ON p.id=r.plan_id WHERE r.type IN ('bot_renewal','wallet_bot_renewal') AND r.remote_order_id=%s ORDER BY r.id DESC", $bot_order_id));
    }

    public function get_order_receipts($order_id)
    {
        global $wpdb;
        $t = $this->tables();
        return $wpdb->get_results($wpdb->prepare("SELECT r.*, p.title plan_title, p.gb, p.days
            FROM {$t['receipts']} r
            LEFT JOIN {$t['orders']} o ON o.id=r.order_id
            LEFT JOIN {$t['plans']} p ON p.id=COALESCE(r.plan_id, o.plan_id)
            WHERE r.order_id=%d
            ORDER BY r.id DESC", $order_id));
    }

    public function get_payment_method_label($payment_method)
    {
        $payment_method = sanitize_key((string) $payment_method);
        if (in_array($payment_method, array('wallet', 'wallet_paid'), true)) {
            return 'کیف پول';
        }
        if (in_array($payment_method, array('card', 'bank_card', 'card_to_card'), true)) {
            return 'کارت به کارت';
        }
        if (in_array($payment_method, array('crypto', 'ramzino'), true)) {
            return 'کریپتو رمزینو';
        }
        return 'نامشخص';
    }

    public function payment_method_from_receipt($receipt)
    {
        if (!$receipt) {
            return '';
        }
        if (($receipt->remote_source ?? '') === 'reseller') { return 'wallet'; }
        $payload = !empty($receipt->remote_payload) ? json_decode((string) $receipt->remote_payload, true) : array();
        if (is_array($payload) && !empty($payload['payment_method'])) {
            return sanitize_key((string) $payload['payment_method']);
        }
        $type = !empty($receipt->type) ? sanitize_key((string) $receipt->type) : '';
        if (in_array($type, array('wallet_extra_volume', 'wallet_renewal', 'wallet_bot_renewal'), true)) {
            return 'wallet';
        }
        if ($type === 'crypto' || (!empty($receipt->remote_source) && (string) $receipt->remote_source === 'ramzino')) {
            return 'crypto';
        }
        if (in_array($type, array('new', 'renewal', 'bot_renewal', 'extra_volume'), true) && (!empty($receipt->file_url) || !empty($receipt->attachment_id))) {
            return 'card';
        }
        return '';
    }

    public function get_order_payment_method_label($order)
    {
        if (!$order) {
            return 'نامشخص';
        }
        global $wpdb;
        $t = $this->tables();
        $order_id = (int) $this->value_from_order($order, 'id', 0);
        if ($order_id > 0) {
            $receipt = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE order_id=%d ORDER BY id DESC LIMIT 1", $order_id));
            $method = $this->payment_method_from_receipt($receipt);
            if ($method !== '') {
                return $this->get_payment_method_label($method);
            }
        }
        $payment_status = sanitize_key((string) $this->value_from_order($order, 'payment_status', ''));
        $status = sanitize_key((string) $this->value_from_order($order, 'status', ''));
        $submission_key = (string) $this->value_from_order($order, 'submission_key', '');
        if (strpos($payment_status, 'wallet') !== false || strpos($status, 'wallet') !== false || strpos($submission_key, 'wallet-pay-') === 0 || strpos($submission_key, 'reseller-') === 0) {
            return $this->get_payment_method_label('wallet');
        }
        if (strpos($payment_status, 'crypto') !== false || strpos($status, 'crypto') !== false || strpos($submission_key, 'crypto-pay-') === 0) {
            return $this->get_payment_method_label('crypto');
        }
        return 'نامشخص';
    }

    public function create_user_notification($user_id, $phone, $title, $message, $type = 'order', $order_id = 0, $receipt_id = 0, $action_url = '')
    {
        global $wpdb;
        $t = $this->tables();
        $phone = $this->normalize_phone($phone);
        $user_id = (int) $user_id;
        if (!$phone && $user_id) {
            $u = $this->get_user_by_id($user_id);
            if ($u) {
                $phone = $u->phone;
            }
        }
        if (!$phone) {
            return false;
        }
        if (!$action_url) {
            $settings = IPSVP_Settings::get();
            $base = !empty($settings['dashboard_url']) ? $settings['dashboard_url'] : home_url('/dashboard/');
            if ((int) $order_id > 0) {
                $action_url = add_query_arg(array('ipsvp_tab' => 'detail', 'ipsvp_order_id' => (int) $order_id), $base);
            } elseif ($type === 'wallet') {
                $action_url = add_query_arg(array('ipsvp_tab' => 'wallet'), $base);
            } else {
                $action_url = add_query_arg(array('ipsvp_tab' => 'orders'), $base);
            }
        }
        $wpdb->insert($t['notifications'], array(
            'user_id' => $user_id ?: null,
            'phone' => $phone,
            'order_id' => (int) $order_id ?: null,
            'receipt_id' => (int) $receipt_id ?: null,
            'type' => sanitize_key($type ?: 'order'),
            'status' => 'unread',
            'title' => sanitize_text_field($title),
            'message' => sanitize_textarea_field($message),
            'action_url' => esc_url_raw($action_url),
            'created_at' => $this->now(),
        ));
        return (int) $wpdb->insert_id;
    }

    public function get_unread_notifications($phone, $limit = 8)
    {
        global $wpdb;
        $t = $this->tables();
        $phone = $this->normalize_phone($phone);
        if (!$phone) {
            return array();
        }
        return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['notifications']} WHERE phone=%s AND status='unread' ORDER BY id DESC LIMIT %d", $phone, (int) $limit));
    }

    public function count_unread_notifications($phone, $type = '')
    {
        global $wpdb;
        $t = $this->tables();
        $phone = $this->normalize_phone($phone);
        if (!$phone) {
            return 0;
        }
        if ($type !== '') {
            return (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['notifications']} WHERE phone=%s AND status='unread' AND type=%s", $phone, sanitize_key($type)));
        }
        return (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['notifications']} WHERE phone=%s AND status='unread'", $phone));
    }

    public function mark_notifications_seen($phone, $type = '')
    {
        global $wpdb;
        $t = $this->tables();
        $phone = $this->normalize_phone($phone);
        if (!$phone) {
            return false;
        }
        $where = array('phone' => $phone, 'status' => 'unread');
        $where_format = array('%s', '%s');
        if ($type !== '') {
            $where['type'] = sanitize_key($type);
            $where_format[] = '%s';
        }
        return $wpdb->update($t['notifications'], array('status' => 'seen', 'seen_at' => $this->now()), $where, array('%s', '%s'), $where_format);
    }

    public function add_log($level, $source, $message, $context = array(), $phone = '', $order_id = 0, $receipt_id = 0, $user_id = 0)
    {
        global $wpdb;
        $t = $this->tables();
        if (empty($t['logs'])) {
            return false;
        }
        $phone = $phone ? $this->normalize_phone($phone) : '';
        $level = sanitize_key($level ? $level : 'error');
        $source = sanitize_text_field((string) $source);
        $message = sanitize_textarea_field((string) $message);
        $context_json = '';
        if (!empty($context)) {
            $context_json = wp_json_encode($context, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        }
        return $wpdb->insert($t['logs'], array(
            'user_id' => $user_id ? (int) $user_id : null,
            'phone' => $phone ? $phone : null,
            'order_id' => $order_id ? (int) $order_id : null,
            'receipt_id' => $receipt_id ? (int) $receipt_id : null,
            'level' => $level,
            'source' => $source,
            'message' => $message,
            'context' => $context_json,
            'created_at' => $this->now(),
        ));
    }

    public function get_logs($search = '', $limit = 300)
    {
        global $wpdb;
        $t = $this->tables();
        $limit = max(20, min(1000, (int) $limit));
        $search = trim((string) $search);
        if ($search !== '') {
            $like = '%' . $wpdb->esc_like($search) . '%';
            return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['logs']} WHERE phone LIKE %s OR message LIKE %s OR source LIKE %s OR context LIKE %s OR order_id LIKE %s OR receipt_id LIKE %s ORDER BY id DESC LIMIT {$limit}", $like, $like, $like, $like, $like, $like));
        }
        return $wpdb->get_results("SELECT * FROM {$t['logs']} ORDER BY id DESC LIMIT {$limit}");
    }

    public function confirmed_purchase_statuses()
    {
        return array('approved', 'paid', 'completed', 'confirmed', 'delivered', 'wallet_paid', 'crypto_paid', 'over-paid', 'over_paid', 'created', 'active', 'on_hold', 'volume_finished', 'time_finished', 'cancelled', 'disabled');
    }

    public function get_user_confirmed_purchase_total($user_id)
    {
        global $wpdb;
        $t = $this->tables();
        $user_id = (int) $user_id;
        if ($user_id <= 0) {
            return 0;
        }

        $paid = $this->confirmed_purchase_statuses();
        $receipt_types = array(
            'new', 'renewal', 'bot_renewal', 'extra_volume',
            'wallet_renewal', 'wallet_bot_renewal', 'wallet_extra_volume',
            'proxyline_card', 'proxyline_crypto', 'proxyline_renewal_card', 'proxyline_renewal_crypto',
        );
        $status_placeholders = implode(',', array_fill(0, count($paid), '%s'));
        $type_placeholders = implode(',', array_fill(0, count($receipt_types), '%s'));

        $receipt_sql = "SELECT COALESCE(SUM(r.amount),0)
            FROM {$t['receipts']} r
            LEFT JOIN {$t['orders']} o ON o.id = r.order_id
            WHERE r.user_id = %d
              AND LOWER(TRIM(r.status)) IN ({$status_placeholders})
              AND COALESCE(NULLIF(r.type,''),'new') IN ({$type_placeholders})
              AND (r.order_id IS NULL OR r.order_id = 0 OR LOWER(TRIM(COALESCE(o.status, ''))) IN ({$status_placeholders}))";
        $receipt_args = array_merge(array($user_id), $paid, $receipt_types, $paid);
        $total = (int) $wpdb->get_var($wpdb->prepare($receipt_sql, $receipt_args));

        $wallet_order_sql = "SELECT COALESCE(SUM(o.price),0)
            FROM {$t['orders']} o
            WHERE o.user_id = %d
              AND o.submission_key LIKE %s
              AND LOWER(TRIM(o.payment_status)) IN ({$status_placeholders})
              AND LOWER(TRIM(o.status)) IN ({$status_placeholders})";
        $wallet_order_args = array_merge(array($user_id, 'wallet-pay-%'), $paid, $paid);
        $total += (int) $wpdb->get_var($wpdb->prepare($wallet_order_sql, $wallet_order_args));

        // Reseller orders are debited through their operation receipt, not wallet-pay orders.
        $reseller_ops = IPSVP_Reseller_Store::table('operations');
        $total += (int) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM $reseller_ops WHERE user_id=%d AND state='succeeded' AND action IN ('purchase','renew','extra-volume')", $user_id));

        $proxy_table = $wpdb->prefix . 'ipspla_orders';
        $table_exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $proxy_table));
        if ($table_exists === $proxy_table) {
            $proxy_sql = "SELECT COALESCE(SUM(final_amount_irt),0)
                FROM {$proxy_table}
                WHERE wp_user_id = %d
                  AND (receipt_id IS NULL OR receipt_id = 0)
                  AND LOWER(TRIM(payment_method)) = 'wallet'
                  AND LOWER(TRIM(payment_status)) IN ({$status_placeholders})
                  AND LOWER(TRIM(order_status)) IN ('completed','created','delivered')";
            $proxy_args = array_merge(array($user_id), $paid);
            $total += (int) $wpdb->get_var($wpdb->prepare($proxy_sql, $proxy_args));
        }

        return max(0, (int) apply_filters('ipsvp_user_confirmed_purchase_total', $total, $user_id, $this));
    }

    public function status_label($status)
    {
        $labels = array(
            'reseller_processing' => 'در حال پردازش نمایندگی',
            'reseller_reserved' => 'مبلغ رزرو شده نمایندگی',
            'reseller_pending' => 'در انتظار نتیجه کیف پول نمایندگی',
            'reseller_refunded' => 'مبلغ نمایندگی آزاد یا بازپرداخت شد',
            'pending_receipt' => 'در انتظار ارسال رسید',
            'waiting_review' => 'در انتظار بررسی پرداخت',
            'paid' => 'پرداخت تایید شد',
            'created' => 'فعال',
            'awaiting_assignment' => 'در انتظار اتصال',
            'volume_finished' => 'اتمام حجم',
            'time_finished' => 'اتمام زمان',
            'cancelled' => 'لغو شده',
            'rejected' => 'رد شده',
            'failed' => 'خطا در عملیات',
            'proxy_renew_failed' => 'خطا در تمدید پروکسی',
            'pending' => 'در انتظار بررسی',
            'approved' => 'تایید شده',
            'new' => 'خرید جدید',
            'renewal' => 'تمدید',
            'bot_renewal' => 'تمدید سفارش ربات',
            'wallet' => 'شارژ کیف پول',
            'wallet_admin_credit' => 'شارژ دستی کیف پول',
            'wallet_admin_debit' => 'کسر دستی کیف پول',
            'wallet_paid' => 'پرداخت با کیف پول',
            'wallet_renewal' => 'تمدید با کیف پول',
            'wallet_bot_renewal' => 'تمدید سفارش ربات با کیف پول',
            'extra_volume' => 'خرید حجم اضافه',
            'wallet_extra_volume' => 'خرید حجم اضافه با کیف پول',
            'wallet_failed' => 'خطای پرداخت کیف پول',
            'wallet_refund' => 'برگشت کیف پول',
            'crypto' => 'پرداخت کریپتو',
            'crypto_pending' => 'در انتظار پرداخت کریپتو',
            'crypto_paid' => 'پرداخت شده با کریپتو',
            'crypto_failed' => 'خطای پرداخت کریپتو',
            'active' => 'فعال',
            'on_hold' => 'در انتظار اتصال',
            'disabled' => 'معلق',
            'limited' => 'محدود شده',
            'expired' => 'منقضی شده',
        );
        return isset($labels[$status]) ? $labels[$status] : $status;
    }
}

if (!function_exists('get_user_confirmed_purchase_total')) {
    function get_user_confirmed_purchase_total($user_id)
    {
        $db = new IPSVP_DB();
        return $db->get_user_confirmed_purchase_total((int) $user_id);
    }
}

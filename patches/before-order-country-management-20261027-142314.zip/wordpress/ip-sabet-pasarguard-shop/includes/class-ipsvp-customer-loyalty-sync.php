<?php
/** Read-only financial federation. Existing receipts/payments remain the only ledgers. */
defined('ABSPATH') || exit;

final class IPSVP_Customer_Loyalty_Sync
{
    private static $events = array();

    public static function enabled()
    {
        return !defined('IPSVP_CUSTOMER_LOYALTY_BOT') || IPSVP_CUSTOMER_LOYALTY_BOT;
    }

    public static function register()
    {
        foreach (array('profile', 'settings', 'override') as $action) {
            register_rest_route('ipsvp/v1', '/sync/customer-loyalty/' . $action, array(
                'methods' => 'POST', 'permission_callback' => array(__CLASS__, 'authorize'),
                'callback' => static function ($request) use ($action) { return self::dispatch($action, $request); },
            ));
        }
    }

    public static function authorize($request)
    {
        $settings = IPSVP_Settings::get();
        $key = (string) ($settings['wp_sync_secret'] ?? '');
        return $key !== '' && hash_equals($key, (string) $request->get_header('x-ipsabet-api-key'))
            ? true : new WP_Error('forbidden', 'دسترسی مجاز نیست.', array('status' => 403));
    }

    public static function events($tel_id)
    {
        if (!isset(self::$events[$tel_id])) {
            $response = IPSVP_Bot_API::request('POST', '/api/wp-sync/customer-loyalty/events', array('tel_id' => (string) $tel_id));
            if (is_wp_error($response) || empty($response['ok'])) {
                // Never quote a silently lower discount when the authoritative source is unavailable.
                throw new RuntimeException('استعلام تخفیف ربات انجام نشد؛ دوباره تلاش کنید.');
            }
            self::$events[$tel_id] = self::validate_events($response['events'] ?? null);
        }
        return self::$events[$tel_id];
    }

    public static function validate_events($events)
    {
        if (!is_array($events) || ($events['currency'] ?? '') !== 'IRT' || !is_array($events['rows'] ?? null)
            || !is_bool($events['first_purchase'] ?? null)) throw new InvalidArgumentException('invalid_events');
        $seen = array(); $rows = array();
        foreach ($events['rows'] as $row) {
            if (!is_array($row) || !is_int($row['id'] ?? null) || $row['id'] < 1
                || !is_int($row['amount'] ?? null) || $row['amount'] < 1 || !is_int($row['approved_at'] ?? null)
                || !in_array($row['type'] ?? '', array('wallet','wallet_admin_credit','wallet_admin_debit','new','renewal','extra_volume'), true)
                || ($row['key'] ?? '') !== 'bot:' . $row['id']) throw new InvalidArgumentException('invalid_event');
            if (isset($seen[$row['key']])) continue;
            $seen[$row['key']] = true;
            $admin = in_array($row['type'], array('wallet_admin_credit','wallet_admin_debit'), true);
            $rows[] = (object) array('id' => $row['id'], 'type' => $row['type'], 'amount' => $row['amount'],
                'status' => 'approved', 'reviewed_at' => wp_date('Y-m-d H:i:s', $row['approved_at'], wp_timezone()),
                'remote_source' => $admin ? 'admin_wallet_adjustment' : '', 'remote_payload' => '{"payment_method":"card"}',
                'submission_key' => $row['key']);
        }
        return array('rows' => $rows, 'first_purchase' => $events['first_purchase']);
    }

    public static function merge($user, array $rows, $first)
    {
        if (!self::enabled() || empty($user->bot_tel_id)) return array($rows, $first);
        $events = self::events((string) $user->bot_tel_id);
        // Mirrors and balance-sync are not independent payments. Site-origin bot credits
        // are excluded by the bot endpoint; their originals remain in $rows.
        $rows = array_values(array_filter($rows, static function ($r) {
            return !in_array($r->remote_source ?? '', array('bot_wallet_mirror','bot_wallet_sync'), true);
        }));
        return array(array_merge($rows, $events['rows']), $first || $events['first_purchase']);
    }

    private static function user($tel_id)
    {
        global $wpdb;
        $db = new IPSVP_DB(); $tables = $db->tables();
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$tables['users']} WHERE bot_tel_id=%s", $tel_id));
    }

    /** Move the unlinked override once; an existing site override (including zero) wins. */
    public static function adopt_override($user)
    {
        if (!$user || empty($user->bot_tel_id) || IPSVP_Reseller_Store::approved($user->id)) return;
        $key = 'ipsvp_bot_customer_discount_' . $user->bot_tel_id;
        $value = get_option($key, null);
        if ($value === null) return;
        if (($user->manual_discount_percent ?? null) === null && $value !== '') {
            $result = IPSVP_Loyalty::save_override($user->id, $value);
            if (is_wp_error($result)) return;
        }
        delete_option($key);
    }

    public static function dispatch($action, $request)
    {
        try {
            if ($action === 'settings') {
                $settings = IPSVP_Loyalty::settings();
                if ($request->has_param('customer')) {
                    $customer = $request->get_param('customer');
                    // This endpoint changes customers only; preserve the actual saved reseller policy.
                    $saved = get_option(IPSVP_Loyalty::OPTION, IPSVP_Loyalty::defaults());
                    if (!is_array($saved)) throw new InvalidArgumentException('invalid_saved_settings');
                    if (!is_array($customer)) throw new InvalidArgumentException('invalid_customer_settings');
                    foreach ($customer as $tier) {
                        if (!is_array($tier) || (int) ($tier['strict'] ?? 0) !== 0) throw new InvalidArgumentException('inclusive_threshold_required');
                    }
                    $saved['customer'] = $customer;
                    $checked = IPSVP_Loyalty::validate_settings($saved);
                    if (is_wp_error($checked)) return $checked;
                    $saved['customer'] = $checked['customer'];
                    update_option(IPSVP_Loyalty::OPTION, $saved, false);
                    $settings = $saved;
                }
                return array('ok' => true, 'customer' => $settings['customer'], 'currency' => 'IRT');
            }
            $tel = (string) $request->get_param('tel_id');
            if (!preg_match('/^[1-9][0-9]{0,19}$/D', $tel)) throw new InvalidArgumentException('invalid_tel_id');
            $user = self::user($tel);
            if ($user && IPSVP_Reseller_Store::approved($user->id)) {
                return new WP_Error('customer_only', 'این بخش فقط برای کاربران عادی است.', array('status' => 422));
            }
            $option = 'ipsvp_bot_customer_discount_' . $tel;
            if ($action === 'override') {
                if (!$request->has_param('value')) throw new InvalidArgumentException('value_required');
                $value = $request->get_param('value');
                if (!is_string($value) || ($value !== '' && !preg_match('/^(?:100(?:\.0{1,2})?|[0-9]{1,2}(?:\.[0-9]{1,2})?)$/D', $value))) throw new InvalidArgumentException('invalid_discount');
                if ($user) {
                    $result = IPSVP_Loyalty::save_override($user->id, $value);
                    if (is_wp_error($result)) return $result;
                } else {
                    // Unlinked bot users still use the same site authority. No wallet row is created.
                    update_option($option, $value, false);
                }
                return array('ok' => true);
            }
            if ($request->has_param('events')) self::$events[$tel] = self::validate_events($request->get_param('events'));
            if ($user) {
                if (!self::enabled()) throw new RuntimeException('customer_loyalty_bridge_disabled');
                $profile = IPSVP_Loyalty::profile($user->id, false);
                $manual = $user->manual_discount_percent ?? null;
            } else {
                $events = self::events($tel);
                $manual = get_option($option, '');
                $profile = IPSVP_Loyalty::calculate($events['rows'], false, $manual, $events['first_purchase'], IPSVP_Loyalty::settings(), time());
            }
            $profile['manual_value'] = $manual === null ? '' : (string) $manual;
            $profile['next_amount'] = null;
            $profile['next_percent'] = null;
            $profile['next_stars'] = null;
            if ($profile['source'] === 'automatic') {
                foreach (IPSVP_Loyalty::settings()['customer'] as $index => $tier) {
                    $floor = $tier['min'] + $tier['strict'];
                    if ($floor > $profile['total']) {
                        $profile['next_amount'] = $floor - $profile['total'];
                        $profile['next_percent'] = (float) $tier['percent'];
                        $profile['next_stars'] = $index + 1;
                        break;
                    }
                }
            }
            return array('ok' => true, 'profile' => $profile, 'currency' => 'IRT');
        } catch (InvalidArgumentException $e) {
            return new WP_Error('invalid_loyalty_input', $e->getMessage(), array('status' => 422));
        } catch (RuntimeException $e) {
            return new WP_Error('loyalty_unavailable', $e->getMessage(), array('status' => 503));
        }
    }
}
add_action('rest_api_init', array('IPSVP_Customer_Loyalty_Sync', 'register'));

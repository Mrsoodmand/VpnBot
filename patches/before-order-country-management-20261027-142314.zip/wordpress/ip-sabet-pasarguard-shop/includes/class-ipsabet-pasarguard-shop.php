<?php
/**
 * Main plugin coordinator.
 *
 * @package IPSabet_PasarGuard_Shop
 */

defined('ABSPATH') || exit;

final class IPSabet_PasarGuard_Shop
{
    const VERSION = '1.5.3';
    const OPTION_KEY = 'ipsvp_settings';

    private static $instance = null;
    private $db;
    private $api;
    private $admin;
    private $frontend;

    public static function instance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        IPSVP_Captcha_Service::init();
        $this->db = new IPSVP_DB();
        $this->api = new IPSVP_PasarGuard_API();
        IPSVP_Loyalty::init($this->db);
        new IPSVP_Reseller($this->db, $this->api);
        if (is_admin()) {
            $this->admin = new IPSVP_Admin($this->db, $this->api);
        }
        $this->frontend = new IPSVP_Frontend($this->db, $this->api);

        IPSVP_Receipt_Uploader::init();
        add_action(IPSVP_Telegram_Service::PENDING_NOTICE_HOOK, array('IPSVP_Telegram_Service', 'deliver_pending_payment_notice'), 10, 2);
        add_action('init', array($this, 'load_assets_hooks'));
        add_action('plugins_loaded', array($this, 'maybe_upgrade'));
        add_action('rest_api_init', array($this, 'register_rest_routes'));
        add_action('ipsvp_sync_linked_wallets', array($this, 'sync_linked_wallets'));
        add_action('ipsvp_sync_order_lifecycle', array($this, 'sync_order_lifecycle'));
        if (!wp_next_scheduled('ipsvp_sync_order_lifecycle')) {
            wp_schedule_event(time() + 300, 'hourly', 'ipsvp_sync_order_lifecycle');
        }
    }

    public function register_rest_routes()
    {
        register_rest_route('ipsvp/v1', '/telegram/(?P<secret>[a-zA-Z0-9_\-]+)', array(
            'methods' => 'POST',
            'callback' => array($this, 'handle_telegram_webhook'),
            'permission_callback' => array($this, 'authorize_telegram_webhook'),
        ));

        register_rest_route('ipsvp/v1', '/sync/confirm-link', array(
            'methods' => 'POST',
            'callback' => array($this, 'handle_sync_confirm_link'),
            'permission_callback' => array($this, 'authorize_sync_request'),
        ));
    }

    public function authorize_telegram_webhook($request)
    {
        $settings = IPSVP_Settings::get();
        $expected = isset($settings['telegram_webhook_secret']) ? (string) $settings['telegram_webhook_secret'] : '';
        $provided = (string) $request->get_param('secret');

        if ($expected && hash_equals($expected, $provided)) {
            return true;
        }

        return new WP_Error('ipsvp_rest_forbidden', 'درخواست وبهوک معتبر نیست.', array('status' => 403));
    }

    public function authorize_sync_request($request)
    {
        $settings = IPSVP_Settings::get();
        $expected = isset($settings['wp_sync_secret']) ? (string) $settings['wp_sync_secret'] : '';
        $provided = (string) $request->get_header('x-ipsabet-api-key');

        if ($expected && hash_equals($expected, $provided)) {
            return true;
        }

        return new WP_Error('ipsvp_rest_forbidden', 'درخواست همگام‌سازی معتبر نیست.', array('status' => 403));
    }

    public function handle_telegram_webhook($request)
    {
        return IPSVP_Telegram_Service::handle_webhook($request, $this->db, $this->api);
    }

    public function handle_sync_confirm_link($request)
    {
        return IPSVP_Bot_API::handle_confirm_link_request($request, $this->db);
    }

    public function load_assets_hooks()
    {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_front_assets'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
    }

    public function enqueue_front_assets()
    {
        wp_register_style('ipsvp-front-base', IPSVP_PLUGIN_URL . 'assets/css/frontend.css', array('ipsvp-palette'), self::VERSION);
        wp_register_style('ipsvp-front', IPSVP_PLUGIN_URL . 'assets/css/commerce.css', array('ipsvp-front-base'), self::VERSION);
        wp_register_script('ipsvp-commerce-ui', IPSVP_PLUGIN_URL . 'assets/js/commerce-ui.js', array(), self::VERSION . '-admin2', true);
        wp_register_script('ipsvp-front', IPSVP_PLUGIN_URL . 'assets/js/frontend.js', array('jquery', 'ipsvp-commerce-ui'), self::VERSION, true);
        IPSVP_Captcha_Service::register_assets();
        wp_localize_script('ipsvp-front', 'IPSVP_RECEIPT_UPLOAD', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ipsvp_receipt_upload'),
            'max_size' => IPSVP_Receipt_Uploader::max_upload_size(),
            'allowed' => IPSVP_Receipt_Uploader::allowed_extensions(),
            'invalid_type' => 'فرمت فایل مجاز نیست. فقط تصویر یا PDF قابل قبول است.',
            'upload_error' => 'آپلود رسید ناموفق بود.',
            'processing' => 'فایل ارسال شد؛ در حال ثبت روی سرور...',
            'fallback' => 'فایل انتخاب‌شده حفظ شد و هنگام ثبت فرم دوباره ارسال می‌شود.',
            'network_error' => 'ارتباط با سرور هنگام آپلود قطع شد.',
            'timeout_error' => 'زمان پاسخ سرور برای آپلود به پایان رسید.',
            'timeout' => 180000,
            'response_timeout' => 45000,
            'status_timeout' => 12000,
            'hard_timeout' => 480000,
            'max_retries' => 1,
        ));

        // Site-wide user notifications: if the panel login cookie exists, load the lightweight
        // frontend notification assets on every page so status changes are shown immediately.
        $phone = IPSVP_Session::get_phone($this->db);
        if ($phone) {
            wp_enqueue_style('ipsvp-front');
            wp_enqueue_script('ipsvp-front');
            wp_localize_script('ipsvp-front', 'IPSVP_PANEL_NOTIFICATIONS', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('ipsvp_panel_notifications'),
                'poll_interval' => 30000,
                'unread_count' => $this->db->count_unread_notifications($phone),
                'notification_counts' => apply_filters('ipsvp_panel_notification_counts', array(
                    'orders' => $this->db->count_unread_notifications($phone, 'order'),
                ), $phone, $this->db),
                'sound' => true,
                'min_created_at' => !empty($_GET['ipsvp_order_done']) ? time() : 0,
                'suppress_existing_on_load' => !empty($_GET['ipsvp_order_done']) ? 1 : 0,
            ));
        }
    }

    public function enqueue_admin_assets()
    {
        wp_add_inline_style('common', '#adminmenu .wp-submenu .ipsvp-menu-group{display:block;font-size:10px;line-height:1.8;opacity:.6;padding:10px 0 4px;margin-top:5px;border-top:1px solid #ffffff24;font-weight:500}');
        wp_register_style('ipsvp-admin-palette', IPSVP_PLUGIN_URL . 'assets/css/palette.css', array(), self::VERSION);
        wp_register_style('ipsvp-admin-base', IPSVP_PLUGIN_URL . 'assets/css/admin.css', array('ipsvp-admin-palette'), self::VERSION);
        wp_register_style('ipsvp-admin', IPSVP_PLUGIN_URL . 'assets/css/admin-commerce.css', array('ipsvp-admin-base'), self::VERSION . '-admin2');
        IPSVP_Captcha_Service::register_assets();
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        if (preg_match('/^(ipsvp|ipspla|ips-server)(-|$)/', $page)) {
            wp_enqueue_script('ipsvp-commerce-ui', IPSVP_PLUGIN_URL . 'assets/js/commerce-ui.js', array(), self::VERSION . '-admin2', true);
        }
        if ($page === 'ipsvp-settings') {
            IPSVP_Captcha_Service::enqueue_assets();
        }
        if ($page === 'ipsvp-users') {
            wp_enqueue_script('ipsvp-admin-user', IPSVP_PLUGIN_URL . 'assets/js/admin-user.js', array(), self::VERSION, true);
        }
        if ($page === 'ipsvp-orders') {
            wp_enqueue_script('ipsvp-admin-assignment', IPSVP_PLUGIN_URL . 'assets/js/admin-assignment.js', array(), self::VERSION, true);
        }
    }

    public function maybe_upgrade()
    {
        $installed = get_option('ipsvp_version');
        if ($installed !== self::VERSION) {
            $this->db->install();
            IPSVP_Loyalty::migrate_settings();
            self::create_default_pages();
            update_option('ipsvp_version', self::VERSION);
            delete_option('ipsvp_wallet_sync_cursor');
            if (!wp_next_scheduled('ipsvp_sync_linked_wallets')) {
                wp_schedule_single_event(time() + 10, 'ipsvp_sync_linked_wallets');
            }
            IPSVP_Receipt_Uploader::schedule_cleanup();
        }
    }

    public function sync_linked_wallets()
    {
        global $wpdb;
        $t = $this->db->tables();
        $cursor = max(0, (int) get_option('ipsvp_wallet_sync_cursor', 0));
        $users = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$t['users']} WHERE id>%d AND bot_tel_id IS NOT NULL AND bot_tel_id<>'' ORDER BY id ASC LIMIT 10",
            $cursor
        ));
        foreach ($users as $user) {
            IPSVP_Bot_API::unified_wallet($user, $this->db, true);
            $cursor = max($cursor, (int) $user->id);
        }
        if (count($users) === 10) {
            update_option('ipsvp_wallet_sync_cursor', $cursor, false);
            wp_schedule_single_event(time() + 20, 'ipsvp_sync_linked_wallets');
        } else {
            delete_option('ipsvp_wallet_sync_cursor');
        }
    }

    public function sync_order_lifecycle()
    {
        global $wpdb;
        $t = $this->db->tables();
        $orders = $wpdb->get_results("SELECT id FROM {$t['orders']} WHERE status IN ('created','active','on_hold','volume_finished','time_finished') AND (pg_username IS NOT NULL AND pg_username<>'' OR pg_user_id IS NOT NULL AND pg_user_id<>'') ORDER BY updated_at ASC, id ASC LIMIT 100");
        foreach ($orders as $row) {
            $order = $this->db->get_order((int) $row->id);
            if (!$order) { continue; }
            $snapshot = $this->api->user_snapshot($order->pg_username, $order->pg_user_id, $order);
            if (empty($snapshot['live'])) { continue; }
            $live = $snapshot['live'];
            if (!empty($order->pg_response)) {
                $old = json_decode((string) $order->pg_response, true);
                if (is_array($old) && !empty($old['_all_countries'])) {
                    $live['_all_countries'] = $old['_all_countries'];
                }
            }
            $this->db->update_order((int) $order->id, array(
                'pg_response' => wp_json_encode($live, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                'pg_status' => !empty($snapshot['status']) ? (string) $snapshot['status'] : (string) $order->pg_status,
                'pg_synced_at' => $this->db->now(),
            ));
            $order = $this->db->get_order((int) $row->id);
            $updated = $this->db->apply_order_lifecycle_snapshot($order, $snapshot);
            if ($updated && (string) $updated->status === 'cancelled' && (string) $order->status !== 'cancelled') {
                $remote = $this->api->update_user_status_for_order($updated, 'cancelled');
                if (is_wp_error($remote)) {
                    $this->db->add_log('warning', 'cron_auto_cancel_pg_status', $remote->get_error_message(), array('order_id' => $updated->id), $updated->phone, $updated->id, 0, $updated->user_id);
                }
            }
        }
    }

    public static function activate()
    {
        $db = new IPSVP_DB();
        $db->install();
        update_option('ipsvp_version', self::VERSION);
        self::create_default_pages();
        self::seed_defaults();
        if (!wp_next_scheduled('ipsvp_sync_linked_wallets')) {
            wp_schedule_single_event(time() + 10, 'ipsvp_sync_linked_wallets');
        }
        if (!wp_next_scheduled('ipsvp_sync_order_lifecycle')) {
            wp_schedule_event(time() + 300, 'hourly', 'ipsvp_sync_order_lifecycle');
        }
        IPSVP_Receipt_Uploader::schedule_cleanup();
    }

    public static function deactivate()
    {
        wp_clear_scheduled_hook('ipsvp_sync_order_lifecycle');
        IPSVP_Receipt_Uploader::clear_cleanup_schedule();
    }

    private static function create_default_pages()
    {
        $pages = array(
            'خرید کانفیگ آی پی ثابت' => '[ips_config_shop]',
            'پنل کاربری آی پی ثابت' => '[ips_config_panel]',
            'پلن های آی پی ثابت' => '[ips_config_plans]',
        );
        foreach ($pages as $title => $content) {
            $exists = get_page_by_title($title, OBJECT, 'page');
            if (!$exists) {
                wp_insert_post(array(
                    'post_title'   => $title,
                    'post_content' => $content,
                    'post_status'  => 'publish',
                    'post_type'    => 'page',
                ));
            }
        }
    }

    private static function seed_defaults()
    {
        $settings = get_option(self::OPTION_KEY, array());
        if (empty($settings)) {
            update_option(self::OPTION_KEY, array(
                'brand_name' => 'آی پی ثابت من',
                'panel_url' => '',
                'panel_username' => '',
                'panel_password' => '',
                'bank_card' => '',
                'bank_account_name' => '',
                'bank_iban' => '',
                'bank_note' => '',
                'announcement_text' => '',
                'client_type' => 'links',
                'ssl_verify' => '1',
                'order_prefix' => 'IPS',
                'telegram_admin' => '',
                'whatsapp_admin' => '',
                'buy_url' => 'https://ip-sabet.me/buy',
                'dashboard_url' => 'https://ip-sabet.me/dashboard',
                'telegram_bot_token' => '',
                'telegram_chat_id' => '',
                'telegram_notifications' => '0',
                'telegram_webhook_secret' => wp_generate_password(24, false, false),
                'telegram_webhook_mode' => 'existing',
                'telegram_existing_webhook_url' => 'https://bot.ipsabet.app/api/telegram-webhook',
                'bot_api_url' => 'https://bot.ipsabet.app',
                'wp_sync_secret' => wp_generate_password(48, false, false),
                'otp_login_enabled' => '0',
                'smsir_api_key' => '',
                'smsir_template_id' => '',
                'smsir_code_param' => 'Code',
                'otp_code_length' => '6',
                'otp_expire_minutes' => '5',
                'otp_resend_seconds' => '60',
                'captcha_enabled' => '1',
                'captcha_length' => '4',
                'captcha_ttl_minutes' => '10',
                'captcha_show_panel' => '1',
                'captcha_show_config' => '1',
                'captcha_show_proxy' => '1',
                'captcha_show_otp' => '1',
                'captcha_max_attempts' => '3',
                'captcha_color_mode' => 'auto',
                'all_countries_enabled' => '1',
                'shared_sales_enabled' => '1',
                'dedicated_sales_enabled' => '1',
                'all_countries_price_percent' => '30',
                'all_countries_group_id' => '',
                'all_countries_group_name' => '',
                'extra_volume_price_per_gb' => '10000',
                'dedicated_extra_volume_price_per_gb' => '10000',
                'service_warnings_enabled' => '1',
                'warning_expiry_enabled' => '1',
                'warning_expiry_days' => '1',
                'warning_expiry_title' => 'تمدید سرویس نزدیک است',
                'warning_expiry_message' => 'اعتبار سرویس شما رو به پایان است. برای جلوگیری از قطع سرویس، تمدید را انجام دهید.',
                'warning_expiry_button' => 'تمدید سرویس',
                'warning_traffic_enabled' => '1',
                'warning_traffic_gb' => '1',
                'warning_traffic_title' => 'حجم سرویس رو به پایان است',
                'warning_traffic_message' => 'حجم باقی‌مانده سرویس شما کم است. برای ادامه استفاده، حجم اضافه تهیه کنید.',
                'warning_traffic_button' => 'خرید حجم اضافه',
                'warning_popup_repeat_mode' => 'daily',
                'warning_once_after_login' => '0',
                'warning_combine_enabled' => '1',
            ));
        }
    }
}

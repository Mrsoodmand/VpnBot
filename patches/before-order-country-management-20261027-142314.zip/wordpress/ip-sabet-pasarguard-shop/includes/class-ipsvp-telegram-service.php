<?php
/**
 * Telegram notification and webhook service.
 *
 * @package IPSabet_PasarGuard_Shop
 */

defined('ABSPATH') || exit;

final class IPSVP_Telegram_Service
{
    // Match the divider used in the bot admin receipts.
    private const RECEIPT_SEPARATOR = '────────────────────────────────';

    private static function settings()
    {
        return IPSVP_Settings::get();
    }

    public static function webhook_url()
    {
        $s = self::settings();
        return rest_url('ipsvp/v1/telegram/' . rawurlencode($s['telegram_webhook_secret']));
    }

    public static function target_webhook_url()
    {
        $s = self::settings();
        $mode = isset($s['telegram_webhook_mode']) ? $s['telegram_webhook_mode'] : 'existing';
        if ($mode === 'existing') {
            $existing = isset($s['telegram_existing_webhook_url']) ? trim($s['telegram_existing_webhook_url']) : '';
            if ($existing !== '') {
                return esc_url_raw($existing);
            }
        }
        return self::webhook_url();
    }

    public static function set_webhook($db = null)
    {
        $s = self::settings();
        if (empty($s['telegram_bot_token'])) {
            return new WP_Error('telegram_token_missing', 'توکن ربات تلگرام وارد نشده است.');
        }
        $target_url = self::target_webhook_url();
        if (empty($target_url) || !wp_http_validate_url($target_url)) {
            return new WP_Error('telegram_webhook_url_invalid', 'آدرس وبهوک تلگرام معتبر نیست. اگر از ربات اصلی استفاده می کنید، آدرس وبهوک فعلی ربات را وارد کنید.');
        }
        $url = 'https://api.telegram.org/bot' . trim($s['telegram_bot_token']) . '/setWebhook';
        $res = wp_remote_post($url, array(
            'timeout' => 20,
            'body' => array('url' => $target_url),
        ));
        if (is_wp_error($res)) {
            if ($db) {
                $db->add_log('error', 'telegram_set_webhook', $res->get_error_message());
            }
            return $res;
        }
        $code = (int) wp_remote_retrieve_response_code($res);
        $body = wp_remote_retrieve_body($res);
        if ($code < 200 || $code >= 300) {
            if ($db) {
                $db->add_log('error', 'telegram_set_webhook', 'HTTP ' . $code . ' - ' . $body);
            }
            return new WP_Error('telegram_set_webhook_failed', 'خطای ثبت وبهوک تلگرام: HTTP ' . $code . ' - ' . $body);
        }
        return json_decode($body, true);
    }

    public static function send_receipt_notification($receipt_id, $db)
    {
        $s = self::settings();
        if (empty($s['telegram_notifications']) || $s['telegram_notifications'] !== '1' || empty($s['telegram_bot_token']) || empty($s['telegram_chat_id'])) {
            return false;
        }
        $receipt = $db->get_receipt($receipt_id);
        if (!$receipt) {
            return false;
        }
        $order = !empty($receipt->order_id) ? $db->get_order($receipt->order_id) : null;
        if (!$order && (!isset($receipt->type) || $receipt->type !== 'wallet')) {
            return false;
        }

        $text = self::build_receipt_message($receipt, $order, 'pending', array(), $db);
        $is_dedicated = self::order_service_type($order) === 'dedicated';
        if ($is_dedicated) {
            $text .= "\n\nℹ️ تایید یا رد این تراکنش فقط از مدیریت وردپرس انجام می‌شود.";
        }
        $reply_markup = '';
        if (!$is_dedicated) {
            $keyboard = array('inline_keyboard' => array(array(
                array('text' => '✅ تایید', 'callback_data' => self::callback_data('approve', $receipt->id, $s)),
                array('text' => '❌ رد', 'callback_data' => self::callback_data('reject', $receipt->id, $s)),
            )));
            $reply_markup = wp_json_encode($keyboard, JSON_UNESCAPED_UNICODE);
        }

        /*
         * Telegram may fail to fetch protected / cached / Cloudflare upload URLs and returns:
         * Bad Request: failed to get HTTP URL content
         * So we first try to upload the receipt file from the local WordPress uploads path.
         */
        $file_path = self::receipt_local_file_path($receipt);
        if ($file_path) {
            $photo_payload = array(
                'chat_id' => $s['telegram_chat_id'],
                'caption' => $text,
            );
            if ($reply_markup !== '') { $photo_payload['reply_markup'] = $reply_markup; }

            $res = self::telegram_post_multipart('sendPhoto', $photo_payload, 'photo', $file_path);
            if (!empty($res['ok'])) {
                self::store_pending_message_from_telegram_response($receipt, $db, $res);
                return true;
            }

            // Some file formats or large images may be rejected as photos; send as document instead.
            $doc_payload = array(
                'chat_id' => $s['telegram_chat_id'],
                'caption' => $text,
            );
            if ($reply_markup !== '') { $doc_payload['reply_markup'] = $reply_markup; }
            $doc_res = self::telegram_post_multipart('sendDocument', $doc_payload, 'document', $file_path);
            if (!empty($doc_res['ok'])) {
                self::store_pending_message_from_telegram_response($receipt, $db, $doc_res);
                return true;
            }

            $db->add_log('warning', 'telegram_send_receipt_file', self::telegram_result_message($res, 'ارسال فایل رسید به تلگرام ناموفق بود.'), array('receipt_id' => $receipt_id, 'path' => basename($file_path)), $receipt->phone, ($order ? $order->id : 0), $receipt_id, $receipt->user_id);
        }

        // Final safe fallback: notify admin with text and buttons, so the receipt is still trackable from admin panel.
        $payload = array(
            'chat_id' => $s['telegram_chat_id'],
            'text' => $text . "

رسید در بخش کارت به کارت های پنل وردپرس قابل مشاهده است.",
        );
        if ($reply_markup !== '') { $payload['reply_markup'] = $reply_markup; }
        $res = wp_remote_post(self::telegram_api_url('sendMessage'), array('timeout' => 25, 'body' => $payload));
        if (is_wp_error($res)) {
            $db->add_log('error', 'telegram_send_receipt', $res->get_error_message(), array('receipt_id' => $receipt_id), $receipt->phone, ($order ? $order->id : 0), $receipt_id, $receipt->user_id);
            return false;
        }
        $code = (int) wp_remote_retrieve_response_code($res);
        $body = wp_remote_retrieve_body($res);
        if ($code < 200 || $code >= 300) {
            $db->add_log('error', 'telegram_send_receipt', 'HTTP ' . $code . ' - ' . $body, array('receipt_id' => $receipt_id), $receipt->phone, ($order ? $order->id : 0), $receipt_id, $receipt->user_id);
            return false;
        }
        self::store_pending_message_from_telegram_response($receipt, $db, array('body' => $body, 'code' => $code));
        return true;
    }

    public static function send_telegram_pending_payment_notice($receipt_id, $db)
    {
        return self::send_receipt_notification($receipt_id, $db);
    }

    const PENDING_NOTICE_HOOK = 'ipsvp_send_pending_receipt_notice';

    public static function queue_pending_payment_notice($receipt_id, $db)
    {
        $receipt_id = (int) $receipt_id;
        if ($receipt_id <= 0 || !self::telegram_enabled()) { return false; }
        $receipt = $db->get_receipt($receipt_id);
        if (!$receipt || $receipt->status !== 'pending') { return false; }
        if (!empty(self::receipt_payload_array($receipt)['telegram_pending_notice_sent'])) { return true; }
        foreach (range(0, 3) as $attempt) {
            if (wp_next_scheduled(self::PENDING_NOTICE_HOOK, array($receipt_id, $attempt))) { return true; }
        }
        $scheduled = wp_schedule_single_event(time() + 1, self::PENDING_NOTICE_HOOK, array($receipt_id, 0), true);
        if (is_wp_error($scheduled) || !$scheduled) {
            $db->add_log('error', 'receipt_notice_queue', 'اعلان رسید در صف قرار نگرفت؛ رسید در مدیریت قابل بررسی است.', array('receipt_id' => $receipt_id));
            return false;
        }
        return true;
    }

    public static function deliver_pending_payment_notice($receipt_id, $attempt = 0)
    {
        global $wpdb;
        $receipt_id = (int) $receipt_id;
        $attempt = max(0, min(3, (int) $attempt));
        if ($receipt_id <= 0 || !self::telegram_enabled()) { return; }
        $lock = 'ipsvp_notice_' . substr(hash('sha256', $wpdb->prefix . ':' . $receipt_id), 0, 40);
        if ((string) $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 0)', $lock)) !== '1') {
            wp_schedule_single_event(time() + 30, self::PENDING_NOTICE_HOOK, array($receipt_id, $attempt));
            return;
        }
        $db = new IPSVP_DB();
        try {
            $receipt = $db->get_receipt($receipt_id);
            if (!$receipt || $receipt->status !== 'pending' || !empty(self::receipt_payload_array($receipt)['telegram_pending_notice_sent'])) { return; }
            try {
                $sent = self::send_receipt_notification($receipt_id, $db);
            } catch (Throwable $error) {
                $sent = false;
                $db->add_log('error', 'receipt_notice_delivery', 'ارسال اعلان رسید ناموفق بود؛ تلاش مجدد در پس‌زمینه انجام می‌شود.', array('receipt_id' => $receipt_id, 'attempt' => $attempt));
            }
            if (!$sent && $attempt < 3) {
                wp_schedule_single_event(time() + (60 * (2 ** $attempt)), self::PENDING_NOTICE_HOOK, array($receipt_id, $attempt + 1));
            }
        } finally {
            $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock));
        }
    }

    private static function telegram_api_url($endpoint)
    {
        $s = self::settings();
        return 'https://api.telegram.org/bot' . trim($s['telegram_bot_token']) . '/' . ltrim($endpoint, '/');
    }

    private static function receipt_local_file_path($receipt)
    {
        if (!empty($receipt->attachment_id)) {
            $path = get_attached_file((int) $receipt->attachment_id);
            if ($path && is_readable($path) && is_file($path)) {
                return $path;
            }
        }

        if (empty($receipt->file_url)) {
            return '';
        }

        if (class_exists('IPSVP_Receipt_Uploader') && method_exists('IPSVP_Receipt_Uploader', 'local_path_from_url')) {
            $private_path = IPSVP_Receipt_Uploader::local_path_from_url((string) $receipt->file_url);
            if ($private_path !== '') {
                return $private_path;
            }
        }

        $url_path = (string) parse_url($receipt->file_url, PHP_URL_PATH);
        if ($url_path === '') {
            return '';
        }

        $uploads = wp_upload_dir();
        if (!empty($uploads['baseurl']) && !empty($uploads['basedir'])) {
            $base_url_path = (string) parse_url($uploads['baseurl'], PHP_URL_PATH);
            if ($base_url_path !== '' && strpos($url_path, $base_url_path) === 0) {
                $relative = ltrim(substr($url_path, strlen($base_url_path)), '/');
                $candidate = trailingslashit($uploads['basedir']) . $relative;
                if (is_readable($candidate) && is_file($candidate)) {
                    return $candidate;
                }
            }
        }

        if (defined('ABSPATH') && strpos($url_path, '/wp-content/uploads/') !== false) {
            $relative = ltrim($url_path, '/');
            $candidate = trailingslashit(ABSPATH) . $relative;
            if (is_readable($candidate) && is_file($candidate)) {
                return $candidate;
            }
        }

        return '';
    }

    private static function telegram_file_mime($file_path)
    {
        $type = '';
        if (function_exists('wp_check_filetype')) {
            $check = wp_check_filetype($file_path);
            if (!empty($check['type'])) {
                $type = $check['type'];
            }
        }
        if (!$type && function_exists('mime_content_type')) {
            $type = mime_content_type($file_path);
        }
        return $type ? $type : 'application/octet-stream';
    }

    private static function telegram_post_multipart($endpoint, $fields, $file_field, $file_path)
    {
        if (!function_exists('curl_init') || !class_exists('CURLFile') || !is_readable($file_path)) {
            return array('ok' => false, 'error' => 'cURL برای ارسال فایل به تلگرام در دسترس نیست یا فایل رسید خواندنی نیست.');
        }

        $fields[$file_field] = new CURLFile($file_path, self::telegram_file_mime($file_path), basename($file_path));
        $ch = curl_init(self::telegram_api_url($endpoint));
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 35);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        curl_setopt($ch, CURLOPT_USERAGENT, 'IP-Sabet-WP-Plugin/1.0');

        $body = curl_exec($ch);
        $err = curl_error($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($body === false || $body === null || $body === '') {
            return array('ok' => false, 'code' => $code, 'error' => $err ? $err : 'پاسخ خالی از تلگرام');
        }

        $json = json_decode($body, true);
        $ok = ($code >= 200 && $code < 300 && is_array($json) && !empty($json['ok']));
        return array('ok' => $ok, 'code' => $code, 'body' => $body, 'error' => $err);
    }

    private static function telegram_result_message($result, $fallback)
    {
        if (!empty($result['body'])) {
            return 'HTTP ' . (int) ($result['code'] ?? 0) . ' - ' . $result['body'];
        }
        if (!empty($result['error'])) {
            return $result['error'];
        }
        return $fallback;
    }

    private static function store_pending_message_from_telegram_response($receipt, $db, $result)
    {
        if (!$receipt || !$db || empty($result['body'])) {
            return false;
        }
        $json = json_decode((string) $result['body'], true);
        if (!is_array($json) || empty($json['result']['message_id'])) {
            return false;
        }
        $chat_id = !empty($json['result']['chat']['id']) ? (string) $json['result']['chat']['id'] : '';
        global $wpdb;
        $t = $db->tables();
        $payload = self::receipt_payload_array($receipt);
        $payload['telegram_pending_notice_sent'] = 1;
        $payload['telegram_pending_notice_sent_at'] = $db->now();
        $payload['telegram_message_id'] = (int) $json['result']['message_id'];
        if ($chat_id !== '') {
            $payload['telegram_chat_id'] = $chat_id;
        }
        return $wpdb->update($t['receipts'], array(
            'remote_payload' => wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        ), array('id' => (int) $receipt->id));
    }

    private static function telegram_enabled()
    {
        $s = self::settings();
        return !empty($s['telegram_notifications']) && $s['telegram_notifications'] === '1' && !empty($s['telegram_bot_token']) && !empty($s['telegram_chat_id']);
    }

    private static function receipt_payload_array($receipt)
    {
        $payload = !empty($receipt->remote_payload) ? json_decode((string) $receipt->remote_payload, true) : array();
        return is_array($payload) ? $payload : array();
    }

    private static function toman($amount)
    {
        return number_format_i18n((int) $amount) . ' تومان';
    }

    private static function user_label($receipt, $order = null)
    {
        if (!empty($receipt->phone)) {
            return (string) $receipt->phone;
        }
        if ($order && !empty($order->phone)) {
            return (string) $order->phone;
        }
        if (!empty($receipt->user_id)) {
            return '#' . (int) $receipt->user_id;
        }
        return '-';
    }

    private static function service_label($order, $fallback = '-')
    {
        if ($order) {
            if (!empty($order->pg_username)) {
                return (string) $order->pg_username;
            }
            if (!empty($order->pg_user_id)) {
                return (string) $order->pg_user_id;
            }
            if (!empty($order->order_code)) {
                return (string) $order->order_code;
            }
        }
        return $fallback !== '' ? $fallback : '-';
    }

    private static function order_service_type($order)
    {
        return $order && !empty($order->service_type) && sanitize_key((string) $order->service_type) === 'dedicated' ? 'dedicated' : 'shared';
    }

    private static function order_service_type_label($order)
    {
        return self::order_service_type($order) === 'dedicated' ? 'آی پی ثابت اختصاصی' : 'آی پی ثابت اشتراکی';
    }

    public static function format_telegram_payment_method($method)
    {
        $method = sanitize_key((string) $method);
        if ($method === 'wallet' || $method === 'wallet_paid') {
            return 'کیف پول';
        }
        if ($method === 'crypto' || $method === 'ramzino') {
            return 'کریپتو';
        }
        if ($method === 'card') {
            return 'کارت به کارت';
        }
        if ($method === 'card_approved') {
            return 'کارت به کارت تایید شده';
        }
        return $method ? $method : '-';
    }

    private static function receipt_payment_method($receipt, $payload = array())
    {
        if (!empty($payload['payment_method'])) {
            return sanitize_key((string) $payload['payment_method']);
        }
        $type = !empty($receipt->type) ? (string) $receipt->type : 'new';
        if (in_array($type, array('wallet_extra_volume','wallet_renewal','wallet_bot_renewal'), true)) {
            return 'wallet';
        }
        if ($type === 'crypto' || (!empty($receipt->remote_source) && $receipt->remote_source === 'ramzino')) {
            return 'crypto';
        }
        return 'card';
    }

    private static function normalize_digits_for_compare($value)
    {
        return strtr((string) $value, array(
            '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
            '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
            '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
        ));
    }

    private static function renewal_plan_label_from_parts($name, $gb = 0, $days = 0)
    {
        $label = trim(wp_strip_all_tags((string) $name));
        $normalized_label = self::normalize_digits_for_compare($label);
        $parts = array();

        if ($label !== '') {
            $parts[] = $label;
        }
        if ((int) $gb > 0 && ($label === '' || strpos($normalized_label, (string) (int) $gb) === false || strpos($label, 'گیگ') === false)) {
            $parts[] = number_format_i18n((int) $gb) . ' گیگ';
        }
        if ((int) $days > 0 && ($label === '' || strpos($normalized_label, (string) (int) $days) === false || strpos($label, 'روز') === false)) {
            $parts[] = number_format_i18n((int) $days) . ' روز';
        }

        return $parts ? implode(' / ', array_unique($parts)) : '-';
    }

    private static function get_renewal_plan_label($payment_or_meta, $order = null, $db = null)
    {
        $receipt = is_object($payment_or_meta) ? $payment_or_meta : null;
        if (is_array($payment_or_meta)) {
            $meta = $payment_or_meta;
        } elseif ($receipt) {
            $meta = self::receipt_payload_array($receipt);
        } else {
            $meta = array();
        }

        if (!empty($meta['renewal_plan_name'])) {
            return self::renewal_plan_label_from_parts(
                sanitize_text_field((string) $meta['renewal_plan_name']),
                !empty($meta['renewal_plan_volume_gb']) ? (int) $meta['renewal_plan_volume_gb'] : 0,
                !empty($meta['renewal_plan_days']) ? (int) $meta['renewal_plan_days'] : 0
            );
        }

        $renewal_plan_id = !empty($meta['renewal_plan_id']) ? (int) $meta['renewal_plan_id'] : 0;
        if ($renewal_plan_id > 0 && $db && method_exists($db, 'get_plan')) {
            $plan = $db->get_plan($renewal_plan_id);
            if ($plan) {
                return self::renewal_plan_label_from_parts((string) $plan->title, (int) $plan->gb, (int) $plan->days);
            }
        }

        if ($receipt && $db && method_exists($db, 'add_log')) {
            $db->add_log(
                'warning',
                'renewal_plan_meta_missing',
                'اطلاعات snapshot پلن تمدید در meta تراکنش پیدا نشد و از fallback استفاده شد.',
                array(
                    'receipt_id' => (int) ($receipt->id ?? 0),
                    'receipt_type' => (string) ($receipt->type ?? ''),
                    'receipt_plan_id' => (int) ($receipt->plan_id ?? 0),
                    'order_plan_id' => (int) ($receipt->order_plan_id ?? 0),
                ),
                (string) ($receipt->phone ?? ''),
                $order && !empty($order->id) ? (int) $order->id : (int) ($receipt->order_id ?? 0),
                (int) ($receipt->id ?? 0),
                (int) ($receipt->user_id ?? 0)
            );
        }

        $fallback_plan_id = $receipt && !empty($receipt->plan_id) ? (int) $receipt->plan_id : 0;
        if ($fallback_plan_id > 0 && $db && method_exists($db, 'get_plan')) {
            $plan = $db->get_plan($fallback_plan_id);
            if ($plan) {
                return self::renewal_plan_label_from_parts((string) $plan->title, (int) $plan->gb, (int) $plan->days);
            }
        }

        if ($order && !empty($order->plan_title)) {
            return self::renewal_plan_label_from_parts((string) $order->plan_title, (int) ($order->gb ?? 0), (int) ($order->days ?? 0));
        }

        return '-';
    }

    private static function should_send_success_report($receipt, $payload = array())
    {
        $type = !empty($receipt->type) ? (string) $receipt->type : 'new';
        $method = self::receipt_payment_method($receipt, $payload);
        if (in_array($type, array('proxyline_card','proxyline_renewal_card'), true)) {
            return false;
        }
        if (in_array($type, array('proxyline_crypto','proxyline_renewal_crypto'), true)) {
            return (string) $receipt->status === 'approved';
        }
        if ($method === 'card') {
            return false;
        }
        if ($type === 'wallet') {
            return (string) $receipt->status === 'approved';
        }
        if (in_array($type, array('extra_volume','wallet_extra_volume'), true)) {
            return (string) $receipt->status === 'approved';
        }
        if (in_array($type, array('wallet_renewal','wallet_bot_renewal'), true)) {
            return (string) $receipt->status === 'approved';
        }
        if (in_array($type, array('renewal','bot_renewal','crypto'), true) && $method === 'crypto') {
            return (string) $receipt->status === 'approved';
        }
        if ($type === 'new' && $method !== 'card') {
            return (string) $receipt->status === 'approved';
        }
        return false;
    }

    private static function send_plain_message($text, $db, $context = array(), $phone = '', $order_id = 0, $receipt_id = 0, $user_id = 0)
    {
        if (!self::telegram_enabled()) {
            return false;
        }
        $s = self::settings();
        $res = wp_remote_post(self::telegram_api_url('sendMessage'), array(
            'timeout' => 25,
            'body' => array(
                'chat_id' => $s['telegram_chat_id'],
                'text' => $text,
            ),
        ));
        if (is_wp_error($res)) {
            $db->add_log('warning', 'telegram_success_report_failed', $res->get_error_message(), $context, $phone, $order_id, $receipt_id, $user_id);
            return false;
        }
        $code = (int) wp_remote_retrieve_response_code($res);
        $body = wp_remote_retrieve_body($res);
        if ($code < 200 || $code >= 300) {
            $db->add_log('warning', 'telegram_success_report_failed', 'HTTP ' . $code . ' - ' . $body, $context, $phone, $order_id, $receipt_id, $user_id);
            return false;
        }
        return true;
    }

    private static function mark_receipt_report_sent($receipt, $db, $method)
    {
        global $wpdb;
        $t = $db->tables();
        $payload = self::receipt_payload_array($receipt);
        $payload['telegram_report_sent'] = 1;
        $payload['telegram_report_sent_at'] = $db->now();
        $payload['telegram_report_method'] = $method;
        return $wpdb->update($t['receipts'], array(
            'remote_payload' => wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        ), array('id' => (int) $receipt->id));
    }

    private static function build_success_payment_report($receipt, $order, $db, $payload = array())
    {
        $type = !empty($receipt->type) ? (string) $receipt->type : 'new';
        $method = self::receipt_payment_method($receipt, $payload);
        $method_label = self::format_telegram_payment_method($method === 'card' && $type === 'wallet' ? 'card_approved' : $method);
        $user = self::user_label($receipt, $order);
        $amount = (int) $receipt->amount;

        if ($type === 'wallet') {
            return "✅ شارژ کیف پول موفق\n" . self::RECEIPT_SEPARATOR . "\n"
                . "نوع عملیات: شارژ کیف پول\n"
                . "کاربر: {$user}\n"
                . "مبلغ: " . self::toman($amount) . "\n"
                . "روش پرداخت: {$method_label}\n"
                . "وضعیت: پرداخت شده";
        }

        if (in_array($type, array('extra_volume','wallet_extra_volume'), true)) {
            $gb = !empty($payload['extra_gb']) ? (int) $payload['extra_gb'] : (!empty($payload['gb']) ? (int) $payload['gb'] : 0);
            $unit_price = !empty($payload['final_unit_price']) ? (int) $payload['final_unit_price'] : (!empty($payload['unit_price']) ? (int) $payload['unit_price'] : ($gb > 0 ? (int) floor($amount / $gb) : 0));
            $total = !empty($payload['total_amount']) ? (int) $payload['total_amount'] : (!empty($payload['amount']) ? (int) $payload['amount'] : $amount);
            return "✅ خرید حجم اضافه موفق\n" . self::RECEIPT_SEPARATOR . "\n"
                . "نوع خرید: خرید حجم اضافه\n"
                . "نوع سرویس: " . self::order_service_type_label($order) . "\n"
                . "کد سفارش: " . ($order && !empty($order->order_code) ? $order->order_code : '-') . "\n"
                . "کاربر: {$user}\n"
                . "سرویس/یوزرنیم: " . self::service_label($order) . "\n"
                . "مقدار گیگ: " . number_format_i18n($gb) . " گیگ\n"
                . "قیمت هر گیگ: " . self::toman($unit_price) . "\n"
                . "مبلغ کل: " . self::toman($total) . "\n"
                . "روش پرداخت: {$method_label}\n"
                . "وضعیت: پرداخت شده";
        }

        if (in_array($type, array('renewal','wallet_renewal','bot_renewal','wallet_bot_renewal'), true)) {
            $plan_label = self::get_renewal_plan_label($receipt, $order, $db);
            $code = $order && !empty($order->order_code) ? $order->order_code : (!empty($receipt->remote_order_id) ? ('BOT-' . $receipt->remote_order_id) : '-');
            $service = self::service_label($order, !empty($receipt->remote_order_id) ? ('BOT-' . $receipt->remote_order_id) : '-');
            $type_label = in_array($type, array('bot_renewal','wallet_bot_renewal'), true) ? 'تمدید سفارش ربات' : 'تمدید سایت';
            $country_label = $order ? trim((string) $order->country_name . ' ' . (string) $order->flag) : '-';
            return "🧾 رسید جدید آی پی ثابت\n" . self::RECEIPT_SEPARATOR . "\n"
                . "نوع: {$type_label}\n"
                . "نوع سرویس: " . self::order_service_type_label($order) . "\n"
                . "وضعیت: پرداخت شده\n"
                . "کد سفارش: {$code}\n"
                . "موبایل: {$user}\n"
                . "پلن تمدید: {$plan_label}\n"
                . "کشور: {$country_label}\n"
                . "مبلغ: " . self::toman($amount) . "\n"
                . "شناسه رسید: #{$receipt->id}\n"
                . "روش پرداخت: {$method_label}\n"
                . "\nریمارک تحویل داده شده:\n{$service}";
        }

        if (in_array($type, array('proxyline_card','proxyline_crypto','proxyline_renewal_card','proxyline_renewal_crypto'), true)) {
            $is_renewal = in_array($type, array('proxyline_renewal_card','proxyline_renewal_crypto'), true);
            $code = $order && !empty($order->order_code) ? (string) $order->order_code : (!empty($payload['proxyline_order_code']) ? (string) $payload['proxyline_order_code'] : '-');
            $product = !empty($payload['product_label']) ? (string) $payload['product_label'] : ($order && !empty($order->pg_username) ? (string) $order->pg_username : 'پروکسی');
            $country = !empty($payload['country_label']) ? (string) $payload['country_label'] : (!empty($payload['country_code']) ? (string) $payload['country_code'] : '-');
            $city = !empty($payload['city_label']) ? (string) $payload['city_label'] : '-';
            $period = $is_renewal ? (!empty($payload['renewal_period']) ? (int) $payload['renewal_period'] : 0) : (!empty($payload['period']) ? (int) $payload['period'] : 0);
            return "✅ " . ($is_renewal ? "تمدید پروکسی تکمیل شد" : "خرید پروکسی تکمیل شد") . "\n" . self::RECEIPT_SEPARATOR . "\n"
                . "کاربر: {$user}\n"
                . "موبایل: " . (!empty($receipt->phone) ? $receipt->phone : $user) . "\n"
                . "کد سفارش: {$code}\n"
                . "محصول: {$product}\n"
                . "کشور: {$country}\n"
                . "شهر: {$city}\n"
                . ($period > 0 ? (($is_renewal ? "مدت تمدید: " : "مدت: ") . number_format_i18n($period) . " روز\n") : '')
                . "مبلغ: " . self::toman($amount) . "\n"
                . "روش پرداخت: {$method_label}\n"
                . "وضعیت: تحویل داده شد";
        }

        $plan_label = $order && !empty($order->plan_title) ? $order->plan_title : '-';
        $country_label = $order ? trim((string) $order->country_name . ' ' . (string) $order->flag) : '-';
        return "✅ خرید موفق\n" . self::RECEIPT_SEPARATOR . "\n"
            . "نوع خرید: خرید سرویس\n"
            . "نوع سرویس: " . self::order_service_type_label($order) . "\n"
            . "کد سفارش: " . ($order && !empty($order->order_code) ? $order->order_code : '-') . "\n"
            . "کاربر: {$user}\n"
            . "پلن: {$plan_label}\n"
            . "کشور/گروه: {$country_label}\n"
            . "مبلغ: " . self::toman($amount) . "\n"
            . "روش پرداخت: {$method_label}\n"
            . "وضعیت: پرداخت شده";
    }

    public static function send_telegram_success_payment_report($receipt_id, $db)
    {
        $receipt = $db->get_receipt($receipt_id);
        if (!$receipt) {
            return false;
        }
        $payload = self::receipt_payload_array($receipt);
        $order = !empty($receipt->order_id) ? $db->get_order((int) $receipt->order_id) : null;
        $method = self::receipt_payment_method($receipt, $payload);
        if (!empty($payload['telegram_report_sent'])) {
            $db->add_log('info', 'telegram_success_report_duplicate', 'گزارش تلگرام این تراکنش قبلا ارسال شده است.', array('receipt_id' => (int) $receipt->id, 'payment_method' => $method), $receipt->phone, ($order ? (int) $order->id : 0), (int) $receipt->id, $receipt->user_id);
            return true;
        }
        if (!self::should_send_success_report($receipt, $payload)) {
            return false;
        }
        $text = self::build_success_payment_report($receipt, $order, $db, $payload);
        $context = array('receipt_id' => (int) $receipt->id, 'type' => (string) $receipt->type, 'payment_method' => $method);
        $sent = self::send_plain_message($text, $db, $context, $receipt->phone, ($order ? (int) $order->id : 0), (int) $receipt->id, (int) $receipt->user_id);
        if ($sent) {
            self::mark_receipt_report_sent($receipt, $db, $method);
            $db->add_log('info', 'telegram_success_report_sent', 'گزارش موفق پرداخت به تلگرام ارسال شد.', $context, $receipt->phone, ($order ? (int) $order->id : 0), (int) $receipt->id, (int) $receipt->user_id);
        }
        return $sent;
    }

    private static function order_report_payload($order)
    {
        $payload = !empty($order->pg_response) ? json_decode((string) $order->pg_response, true) : array();
        return is_array($payload) ? $payload : array();
    }

    public static function send_telegram_order_success_report($order_id, $db, $payment_method = 'wallet')
    {
        $order = $db->get_order($order_id);
        if (!$order) {
            return false;
        }
        $payload = self::order_report_payload($order);
        if (!empty($payload['_telegram_report_sent'])) {
            $db->add_log('info', 'telegram_success_report_duplicate', 'گزارش تلگرام این سفارش قبلا ارسال شده است.', array('order_id' => (int) $order->id, 'payment_method' => $payment_method), $order->phone, (int) $order->id, 0, (int) $order->user_id);
            return true;
        }
        $method_label = self::format_telegram_payment_method($payment_method);
        $country_label = trim((string) $order->country_name . ' ' . (string) $order->flag);
        $text = "✅ خرید موفق\n" . self::RECEIPT_SEPARATOR . "\n"
            . "نوع خرید: خرید سرویس\n"
            . "نوع سرویس: " . self::order_service_type_label($order) . "\n"
            . "کد سفارش: {$order->order_code}\n"
            . "کاربر: {$order->phone}\n"
            . "پلن: {$order->plan_title}\n"
            . "کشور/گروه: {$country_label}\n"
            . "مبلغ: " . self::toman((int) $order->price) . "\n"
            . "روش پرداخت: {$method_label}\n"
            . "وضعیت: پرداخت شده";
        $context = array('order_id' => (int) $order->id, 'payment_method' => $payment_method, 'type' => 'wallet_paid_order');
        $sent = self::send_plain_message($text, $db, $context, $order->phone, (int) $order->id, 0, (int) $order->user_id);
        if ($sent) {
            $payload['_telegram_report_sent'] = 1;
            $payload['_telegram_report_sent_at'] = $db->now();
            $payload['_telegram_report_method'] = $payment_method;
            $db->update_order((int) $order->id, array('pg_response' => wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)));
            $db->add_log('info', 'telegram_success_report_sent', 'گزارش موفق خرید کیف پول به تلگرام ارسال شد.', $context, $order->phone, (int) $order->id, 0, (int) $order->user_id);
        }
        return $sent;
    }

    private static function proxyline_delivery_text($payload)
    {
        $proxies = !empty($payload['delivery_proxies']) && is_array($payload['delivery_proxies']) ? $payload['delivery_proxies'] : array();
        if (!$proxies) {
            return "\nاطلاعات کامل فقط در پنل سایت قابل مشاهده است.";
        }
        $show_full = false;
        if (class_exists('IPSPLA_Settings')) {
            $settings = IPSPLA_Settings::get();
            $show_full = !empty($settings['telegram_full_proxy_details']) && $settings['telegram_full_proxy_details'] === '1';
        }
        $text = "\n\nاطلاعات تحویل:";
        $i = 1;
        foreach ($proxies as $proxy) {
            if (!is_array($proxy)) {
                continue;
            }
            $ip = !empty($proxy['ip']) ? sanitize_text_field((string) $proxy['ip']) : '-';
            $http = !empty($proxy['port_http']) ? sanitize_text_field((string) $proxy['port_http']) : '-';
            $socks = !empty($proxy['port_socks5']) ? sanitize_text_field((string) $proxy['port_socks5']) : '-';
            $text .= "\n\nپروکسی {$i}:";
            $text .= "\nIP: {$ip}";
            $text .= "\nHTTP Port: {$http}";
            $text .= "\nSOCKS5 Port: {$socks}";
            if ($show_full) {
                $username = !empty($proxy['username']) ? sanitize_text_field((string) $proxy['username']) : '-';
                $password = !empty($proxy['password']) ? sanitize_text_field((string) $proxy['password']) : '-';
                $text .= "\nUsername: {$username}";
                $text .= "\nPassword: {$password}";
            }
            $i++;
        }
        if (!$show_full) {
            $text .= "\n\nاطلاعات کامل فقط در پنل سایت قابل مشاهده است.";
        }
        return $text;
    }

    private static function build_receipt_message($receipt, $order, $state = 'pending', $result = array(), $db = null)
    {
        $payload = self::receipt_payload_array($receipt);
        if (!empty($receipt->type) && in_array((string) $receipt->type, array('proxyline_card','proxyline_crypto','proxyline_renewal_card','proxyline_renewal_crypto'), true)) {
            $status_label = 'در انتظار تایید';
            if ($state === 'approved') {
                $status_label = '✅ تایید شده';
            } elseif ($state === 'rejected') {
                $status_label = '❌ رد شده';
            } elseif ($state === 'failed') {
                $status_label = '⚠️ خطا در عملیات';
            }
            $is_renewal = in_array((string) $receipt->type, array('proxyline_renewal_card','proxyline_renewal_crypto'), true);
            $type_label = $is_renewal ? 'تمدید پروکسی' : 'خرید پروکسی';
            $method = self::format_telegram_payment_method(self::receipt_payment_method($receipt, $payload));
            $code = $order && !empty($order->order_code) ? (string) $order->order_code : (!empty($payload['proxyline_order_code']) ? (string) $payload['proxyline_order_code'] : '-');
            $product = !empty($payload['product_label']) ? (string) $payload['product_label'] : ($order && !empty($order->pg_username) ? (string) $order->pg_username : 'پروکسی');
            $country = !empty($payload['country_label']) ? (string) $payload['country_label'] : (!empty($payload['country_code']) ? (string) $payload['country_code'] : '-');
            $city = !empty($payload['city_label']) ? (string) $payload['city_label'] : '-';
            $period = $is_renewal ? (!empty($payload['renewal_period']) ? (int) $payload['renewal_period'] : 0) : (!empty($payload['period']) ? (int) $payload['period'] : 0);

            if ($state === 'approved') {
                $title = $is_renewal ? "✅ تمدید پروکسی تایید و اعمال شد" : "✅ خرید پروکسی تایید و تحویل داده شد";
                $status_label = $is_renewal ? 'تمدید اعمال شد' : 'تحویل داده شد';
            } elseif ($state === 'rejected') {
                $title = $is_renewal ? "❌ تمدید پروکسی رد شد" : "❌ خرید پروکسی رد شد";
            } elseif ($state === 'failed') {
                $title = $is_renewal ? "⚠️ پرداخت تایید شد اما تمدید پروکسی با خطا مواجه شد" : "⚠️ پرداخت تایید شد اما ساخت سفارش پروکسی با خطا مواجه شد";
                $status_label = 'نیاز به بررسی دستی';
            } else {
                $title = "رسید جدید آی پی ثابت 🧾";
            }

            $text = $title . "\n" . self::RECEIPT_SEPARATOR . "\n";
            $text .= "نوع: {$type_label}\n";
            $text .= "وضعیت: {$status_label}\n";
            $text .= "کاربر: " . self::user_label($receipt, $order) . "\n";
            $text .= "موبایل: " . (!empty($receipt->phone) ? $receipt->phone : self::user_label($receipt, $order)) . "\n";
            $text .= "محصول: {$product}\n";
            $text .= "کشور: {$country}\n";
            $text .= "شهر: {$city}\n";
            if ($period > 0) {
                $text .= ($is_renewal ? "مدت تمدید: " : "مدت: ") . number_format_i18n($period) . " روز\n";
            }
            $text .= "مبلغ: " . self::toman((int) $receipt->amount) . "\n";
            $text .= "روش پرداخت: {$method}\n";
            $text .= "شناسه رسید: #{$receipt->id}\n";
            $text .= "کد سفارش: {$code}\n";
            if ($state === 'approved') {
                if ($is_renewal) {
                    if (!empty($payload['new_expires_at'])) {
                        $text .= "\nتاریخ انقضای جدید: " . sanitize_text_field((string) $payload['new_expires_at']);
                    } else {
                        $text .= "\nتمدید پروکسی اعمال شد.";
                    }
                } else {
                    $text .= self::proxyline_delivery_text($payload);
                }
            } elseif ($state === 'rejected') {
                $text .= $is_renewal ? "\nتمدید انجام نشد." : "\nسفارش از API پروکسی ساخته نشد.";
            } elseif ($state === 'failed' && !empty($result['message'])) {
                $text .= "\nمبلغ پرداخت‌شده: " . self::toman((int) $receipt->amount);
                $text .= "\nخطا: " . wp_strip_all_tags($result['message']);
                $text .= "\nلطفاً سفارش را دستی بررسی کنید.";
            }
            return $text;
        }
        if (!empty($receipt->type) && in_array((string) $receipt->type, array('extra_volume','wallet_extra_volume'), true)) {
            $status_label = 'در انتظار تایید رسید';
            if ($state === 'approved') {
                $status_label = '✅ تایید شده';
            } elseif ($state === 'rejected') {
                $status_label = '❌ رد شده';
            } elseif ($state === 'failed') {
                $status_label = '⚠️ خطا در پردازش';
            }
            $gb = !empty($payload['extra_gb']) ? (int) $payload['extra_gb'] : (!empty($payload['gb']) ? (int) $payload['gb'] : 0);
            $unit_price = !empty($payload['final_unit_price']) ? (int) $payload['final_unit_price'] : (!empty($payload['unit_price']) ? (int) $payload['unit_price'] : ($gb > 0 ? (int) floor((int) $receipt->amount / $gb) : 0));
            $total = !empty($payload['total_amount']) ? (int) $payload['total_amount'] : (!empty($payload['amount']) ? (int) $payload['amount'] : (int) $receipt->amount);
            $method = self::format_telegram_payment_method(self::receipt_payment_method($receipt, $payload));

            $text = "🧾 رسید جدید آی پی ثابت\n" . self::RECEIPT_SEPARATOR . "\n";
            $text .= "نوع خرید: خرید حجم اضافه\n";
            $text .= "نوع سرویس: " . self::order_service_type_label($order) . "\n";
            $text .= "کد سفارش: " . ($order && !empty($order->order_code) ? $order->order_code : '-') . "\n";
            $text .= "کاربر: " . self::user_label($receipt, $order) . "\n";
            $text .= "سرویس/یوزرنیم: " . self::service_label($order) . "\n";
            $text .= "مقدار گیگ: " . number_format_i18n($gb) . " گیگ\n";
            $text .= "قیمت هر گیگ: " . self::toman($unit_price) . "\n";
            $text .= "مبلغ کل: " . self::toman($total) . "\n";
            $text .= "روش پرداخت: {$method}\n";
            $text .= "وضعیت: {$status_label}\n";
            $text .= "شناسه رسید: #{$receipt->id}\n";
            if ($state === 'approved') {
                $text .= "\nحجم اضافه به سرویس اعمال شد.";
            } elseif ($state === 'rejected') {
                $text .= "\nرسید رد شد و حجمی اعمال نشد.";
            } elseif ($state === 'failed' && !empty($result['message'])) {
                $text .= "\nخطا: " . wp_strip_all_tags($result['message']);
            }
            return $text;
        }

        if (!empty($receipt->type) && in_array((string) $receipt->type, array('renewal','wallet_renewal','bot_renewal','wallet_bot_renewal'), true)) {
            $status_label = 'در انتظار تایید';
            if ($state === 'approved') {
                $status_label = 'تایید شده';
            } elseif ($state === 'rejected') {
                $status_label = 'رد شده';
            } elseif ($state === 'failed') {
                $status_label = 'خطا در پردازش';
            }
            $type_label = in_array((string) $receipt->type, array('bot_renewal','wallet_bot_renewal'), true) ? 'تمدید سفارش ربات' : 'تمدید سایت';
            $code = $order && !empty($order->order_code) ? (string) $order->order_code : (!empty($receipt->remote_order_id) ? ('BOT-' . $receipt->remote_order_id) : '-');
            $country_label = $order ? trim((string) $order->country_name . ' ' . (string) $order->flag) : '-';
            $plan_label = self::get_renewal_plan_label($receipt, $order, $db);
            $remark = '';
            if (!empty($result['pg_username'])) {
                $remark = (string) $result['pg_username'];
            } elseif ($order && !empty($order->pg_username)) {
                $remark = (string) $order->pg_username;
            } elseif (!empty($receipt->remote_order_id)) {
                $remark = 'BOT-' . (string) $receipt->remote_order_id;
            }

            $text = "🧾 رسید جدید آی پی ثابت\n" . self::RECEIPT_SEPARATOR . "\n";
            $text .= "نوع: {$type_label}\n";
            $text .= "نوع سرویس: " . self::order_service_type_label($order) . "\n";
            $text .= "وضعیت: {$status_label}\n";
            $text .= "کد سفارش: {$code}\n";
            $text .= "موبایل: {$receipt->phone}\n";
            $text .= "پلن تمدید: {$plan_label}\n";
            $text .= "کشور: {$country_label}\n";
            $text .= "مبلغ: " . number_format_i18n((int) $receipt->amount) . " تومان\n";
            $text .= "شناسه رسید: #{$receipt->id}\n";
            if ($remark !== '') {
                $text .= "\nریمارک تحویل داده شده:\n{$remark}";
            } elseif ($state === 'approved') {
                $text .= "\nپرداخت تایید شد. برای مشاهده ریمارک، جزییات سفارش را در وردپرس بررسی کنید.";
            }
            if ($state === 'rejected') {
                $text .= "\nرسید توسط ادمین رد شد.";
            } elseif ($state === 'failed' && !empty($result['message'])) {
                $text .= "\nخطا: " . wp_strip_all_tags($result['message']);
            }
            return $text;
        }

        if (!empty($receipt->type) && $receipt->type === 'wallet') {
            $type_label = 'شارژ کیف پول سایت';
        } elseif (!empty($receipt->type) && $receipt->type === 'bot_renewal') {
            $type_label = 'تمدید سفارش ربات';
        } else {
            $type_label = (!empty($receipt->type) && $receipt->type === 'renewal') ? 'تمدید سایت' : 'خرید جدید سایت';
        }
        $status_label = 'در انتظار بررسی';
        if ($state === 'approved') {
            $status_label = '✅ تایید شده';
        } elseif ($state === 'rejected') {
            $status_label = '❌ رد شده';
        } elseif ($state === 'failed') {
            $status_label = '⚠️ خطا در پردازش';
        }

        $text = "🧾 رسید جدید آی پی ثابت\n" . self::RECEIPT_SEPARATOR . "\n";
        $text .= "نوع: {$type_label}\n";
        if ($order) {
            $text .= "نوع سرویس: " . self::order_service_type_label($order) . "\n";
        }
        $text .= "وضعیت: {$status_label}\n";
        if ($order) {
            $text .= "کد سفارش: {$order->order_code}\n";
        }
        $text .= "موبایل: {$receipt->phone}\n";
        if ($order) {
            $text .= "پلن: {$order->plan_title}\n";
            $text .= "کشور: {$order->country_name} {$order->flag}\n";
        }
        $text .= "مبلغ: " . number_format_i18n((int) $receipt->amount) . " تومان\n";
        $text .= "شناسه رسید: #{$receipt->id}\n";

        if ($state === 'approved') {
            if (!empty($receipt->type) && $receipt->type === 'wallet') {
                $text .= "\nکیف پول کاربر شارژ شد.";
                if (isset($result['wallet_balance']) && $result['wallet_balance'] !== null) {
                    $text .= "\nموجودی جدید: " . number_format_i18n((int) $result['wallet_balance']) . " تومان";
                }
            } else {
                $remark = '';
                if (!empty($result['pg_username'])) {
                    $remark = $result['pg_username'];
                } elseif ($order && !empty($order->pg_username)) {
                    $remark = $order->pg_username;
                } elseif (!empty($result['order_id'])) {
                    $fresh_order = (new IPSVP_DB())->get_order((int) $result['order_id']);
                    if ($fresh_order && !empty($fresh_order->pg_username)) {
                        $remark = $fresh_order->pg_username;
                    }
                }
                if ($remark !== '') {
                    $text .= "\nریمارک تحویل داده شده: {$remark}";
                } else {
                    $text .= "\nپرداخت تایید شد. برای مشاهده ریمارک، جزییات سفارش را در وردپرس بررسی کنید.";
                }
            }
        } elseif ($state === 'rejected') {
            $text .= "\nرسید توسط ادمین رد شد.";
        } elseif ($state === 'failed' && !empty($result['message'])) {
            $text .= "\nخطا: " . wp_strip_all_tags($result['message']);
        }
        return $text;
    }

    private static function callback_data($action, $receipt_id, $settings = null)
    {
        $settings = $settings ? $settings : self::settings();
        $token = self::callback_token($action, $receipt_id, $settings);
        return 'type=ipsvp|action=' . $action . '|id=' . (int) $receipt_id . '|token=' . $token;
    }

    private static function callback_token($action, $receipt_id, $settings = null)
    {
        $settings = $settings ? $settings : self::settings();
        return substr(hash_hmac('sha256', $action . '|' . (int) $receipt_id, $settings['telegram_webhook_secret'] . wp_salt('auth')), 0, 14);
    }

    private static function parse_callback_data($data)
    {
        $data = trim((string) $data);
        if ($data === '') {
            return array();
        }

        // New format for the main bot router: type=ipsvp|action=approve|id=123|token=xxxx
        $map = array();
        foreach (explode('|', $data) as $part) {
            if (strpos($part, '=') === false) {
                continue;
            }
            list($key, $value) = explode('=', $part, 2);
            $map[sanitize_key($key)] = sanitize_text_field($value);
        }
        if (!empty($map['type']) && $map['type'] === 'ipsvp') {
            return array(
                'action' => isset($map['action']) ? $map['action'] : '',
                'receipt_id' => isset($map['id']) ? (int) $map['id'] : (isset($map['receipt_id']) ? (int) $map['receipt_id'] : 0),
                'token' => isset($map['token']) ? $map['token'] : '',
            );
        }

        // Backward compatibility for buttons already sent by older plugin versions: ipsvp|approve|123|xxxx
        $parts = explode('|', $data);
        if (count($parts) === 4 && $parts[0] === 'ipsvp') {
            return array(
                'action' => $parts[1],
                'receipt_id' => (int) $parts[2],
                'token' => $parts[3],
            );
        }

        return array();
    }

    public static function handle_webhook($request, $db, $api)
    {
        $s = self::settings();
        $secret = $request->get_param('secret');
        if (empty($s['telegram_webhook_secret']) || !hash_equals((string) $s['telegram_webhook_secret'], (string) $secret)) {
            return new WP_REST_Response(array('ok' => false), 403);
        }
        $update = $request->get_json_params();
        if (empty($update['callback_query'])) {
            return new WP_REST_Response(array('ok' => true), 200);
        }
        $cb = $update['callback_query'];
        $data = isset($cb['data']) ? (string) $cb['data'] : '';
        $parsed = self::parse_callback_data($data);
        if (empty($parsed)) {
            return new WP_REST_Response(array('ok' => true), 200);
        }
        $action = sanitize_key($parsed['action']);
        $receipt_id = (int) $parsed['receipt_id'];
        $token = (string) $parsed['token'];
        if (!in_array($action, array('approve', 'reject'), true) || $receipt_id <= 0 || !hash_equals(self::callback_token($action, $receipt_id, $s), $token)) {
            self::answer_callback($cb, 'درخواست نامعتبر است.');
            return new WP_REST_Response(array('ok' => false), 200);
        }
        $receipt = $db->get_receipt($receipt_id);
        $order = $receipt && !empty($receipt->order_id) ? $db->get_order((int) $receipt->order_id) : null;
        if ($order && self::order_service_type($order) === 'dedicated') {
            self::answer_callback($cb, 'رسید سفارش اختصاصی فقط از مدیریت سایت تایید یا رد می‌شود.');
            return new WP_REST_Response(array('ok' => true, 'site_review_required' => true), 200);
        }
        if ($action === 'approve') {
            $result = IPSVP_Receipt_Manager::approve($receipt_id, $db, $api);
        } else {
            $result = IPSVP_Receipt_Manager::reject($receipt_id, $db);
        }
        self::answer_callback($cb, $result['message']);
        self::edit_callback_message($cb, $receipt_id, $db, $result, $action);
        return new WP_REST_Response(array('ok' => true), 200);
    }

    private static function answer_callback($cb, $text)
    {
        $s = self::settings();
        if (empty($s['telegram_bot_token']) || empty($cb['id'])) {
            return;
        }
        wp_remote_post('https://api.telegram.org/bot' . trim($s['telegram_bot_token']) . '/answerCallbackQuery', array('timeout' => 10, 'body' => array(
            'callback_query_id' => $cb['id'],
            'text' => wp_strip_all_tags($text),
            'show_alert' => false,
        )));
    }

    private static function edit_callback_message($cb, $receipt_id, $db, $result, $action)
    {
        $s = self::settings();
        if (empty($s['telegram_bot_token']) || empty($cb['message']['message_id']) || empty($cb['message']['chat']['id'])) {
            return;
        }
        $receipt = $db->get_receipt($receipt_id);
        if (!$receipt) {
            return;
        }
        $order = !empty($receipt->order_id) ? $db->get_order($receipt->order_id) : null;
        $state = ($action === 'reject') ? 'rejected' : (!empty($result['ok']) ? 'approved' : 'failed');
        $text = self::build_receipt_message($receipt, $order, $state, is_array($result) ? $result : array(), $db);
        $is_photo = !empty($cb['message']['photo']) || isset($cb['message']['caption']);
        $endpoint = $is_photo ? 'editMessageCaption' : 'editMessageText';
        $body = array(
            'chat_id' => $cb['message']['chat']['id'],
            'message_id' => $cb['message']['message_id'],
            'reply_markup' => wp_json_encode(array('inline_keyboard' => array()), JSON_UNESCAPED_UNICODE),
        );
        if ($is_photo) {
            $body['caption'] = $text;
        } else {
            $body['text'] = $text;
        }
        $res = wp_remote_post('https://api.telegram.org/bot' . trim($s['telegram_bot_token']) . '/' . $endpoint, array('timeout' => 12, 'body' => $body));
        if (is_wp_error($res)) {
            $db->add_log('error', 'telegram_edit_callback_message', $res->get_error_message(), array('receipt_id' => $receipt_id, 'action' => $action), $receipt->phone, ($order ? $order->id : 0), $receipt_id, $receipt->user_id);
            return;
        }
        $code = (int) wp_remote_retrieve_response_code($res);
        if ($code >= 200 && $code < 300) {
            global $wpdb;
            $t = $db->tables();
            $payload = self::receipt_payload_array($receipt);
            $payload['telegram_pending_notice_edited'] = 1;
            $payload['telegram_pending_notice_edited_at'] = $db->now();
            $payload['telegram_pending_notice_edited_state'] = $state;
            $wpdb->update($t['receipts'], array(
                'remote_payload' => wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            ), array('id' => (int) $receipt_id));
        } else {
            $db->add_log('warning', 'telegram_edit_callback_message', 'HTTP ' . $code . ' - ' . wp_remote_retrieve_body($res), array('receipt_id' => $receipt_id, 'action' => $action), $receipt->phone, ($order ? $order->id : 0), $receipt_id, $receipt->user_id);
        }
    }

}

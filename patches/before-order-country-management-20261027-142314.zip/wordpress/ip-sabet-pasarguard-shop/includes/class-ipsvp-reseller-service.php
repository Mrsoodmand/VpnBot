<?php
/** One purchase path for the reseller dashboard and REST API. */
defined('ABSPATH') || exit;

final class IPSVP_Reseller_Service
{
    private $db;
    private $api;

    public function __construct($db, $api)
    {
        $this->db = $db;
        $this->api = $api;
    }

    public static function integer($value, $min = 1, $max = 1000000000)
    {
        if ((!is_int($value) && !is_string($value)) || !preg_match('/^(0|[1-9][0-9]*)$/D', (string) $value)) {
            return false;
        }
        return (float) $value >= $min && (float) $value <= min($max, PHP_INT_MAX) ? (int) $value : false;
    }

    public function owned_order($user, $id)
    {
        $order = $this->db->get_order((int) $id);
        if (!$order || (int) $order->user_id !== (int) $user->id || $this->db->order_service_type($order) !== 'shared') {
            return IPSVP_Reseller_Store::error('order_not_found', 'سفارش پیدا نشد.', 404);
        }
        return $order;
    }

    public function quote($user, $action, array $input)
    {
        $account = IPSVP_Reseller_Store::approved($user->id);
        if (!$account || !empty($user->is_blocked)) {
            return IPSVP_Reseller_Store::error('not_approved', 'نمایندگی فعال و تأییدشده لازم است.', 403);
        }
        if (!in_array($action, array('purchase', 'renew', 'extra-volume', 'disable', 'enable'), true)) {
            return IPSVP_Reseller_Store::error('invalid_action', 'عملیات نامعتبر است.');
        }
        if (in_array($action, array('purchase', 'renew', 'extra-volume'), true) && !$this->db->service_sales_enabled('shared')) {
            return IPSVP_Reseller_Store::error('sales_disabled', 'فروش کانفیگ اشتراکی موقتاً غیرفعال است.', 409);
        }
        $settings = IPSVP_Settings::get();
        $wallet_enabled = class_exists('IPSPM_Payment_Manager') ? IPSPM_Payment_Manager::method_enabled('wallet', 'ip-sabet') : (!isset($settings['payment_wallet_enabled']) || $settings['payment_wallet_enabled'] === '1');
        if (in_array($action, array('purchase', 'renew', 'extra-volume'), true) && !$wallet_enabled) {
            return IPSVP_Reseller_Store::error('wallet_disabled', 'پرداخت کیف پول موقتاً غیرفعال است.', 409);
        }
        $data = array('action' => $action);
        $plan = $order = null;
        $base = 0;
        if ($action !== 'purchase') {
            $id = self::integer($input['order_id'] ?? null);
            if ($id === false) { return IPSVP_Reseller_Store::error('invalid_order_id', 'order_id باید عدد صحیح مثبت باشد.'); }
            $order = $this->owned_order($user, $id);
            if (is_wp_error($order)) { return $order; }
            $data['order_id'] = $id;
            if (!$this->db->order_can_renew($order) || (empty($order->pg_user_id) && empty($order->pg_username))) {
                return IPSVP_Reseller_Store::error('order_unavailable', 'سفارش در وضعیت قابل مدیریت نیست یا مهلت تمدید گذشته است.', 409);
            }
        }
        if (in_array($action, array('purchase', 'renew'), true)) {
            $id = self::integer($input['plan_id'] ?? null);
            $plan = $id === false ? null : $this->db->get_plan($id);
            if (!$plan || (int) $plan->status !== 1 || $this->db->normalize_service_type($plan->service_type) !== 'shared') {
                return IPSVP_Reseller_Store::error('invalid_plan', 'پلن فعال اشتراکی انتخاب کنید.');
            }
            $data['plan_id'] = $id;
            // Read the site's retail price, independent of the current browser session.
            $base = $this->db->final_price($plan, true);
            if ($action === 'purchase') {
                $country_id = self::integer($input['country_id'] ?? null, 0);
                if ($country_id === false) { return IPSVP_Reseller_Store::error('invalid_country', 'country_id نامعتبر است.'); }
                if ($country_id === 0) {
                    if (!$this->db->all_countries_enabled() || !$this->db->all_countries_group_ready()) {
                        return IPSVP_Reseller_Store::error('invalid_country', 'فروش همه کشورها در دسترس نیست.');
                    }
                } else {
                    $country = $this->db->get_country($country_id);
                    if (!$country || (int) $country->status !== 1 || empty($country->pg_group_id) || $this->db->normalize_service_type($country->service_type) !== 'shared') {
                        return IPSVP_Reseller_Store::error('invalid_country', 'کشور فعال اشتراکی انتخاب کنید.');
                    }
                }
                $data['country_id'] = $country_id;
                $all = $country_id === 0;
            } else {
                $all = $this->db->is_all_countries_order($order);
            }
            if ($all) { $base = (int) ceil($base * (100 + $this->db->all_countries_price_percent_value()) / 100); }
        } elseif ($action === 'extra-volume') {
            $gb = self::integer($input['gb'] ?? null, 1, 10000);
            if ($gb === false) { return IPSVP_Reseller_Store::error('invalid_gb', 'gb باید عدد صحیح بین ۱ تا ۱۰۰۰۰ باشد.'); }
            $data['gb'] = $gb;
            $price = $this->db->calculate_extra_volume_price($order, $gb, true);
            if (is_wp_error($price)) { return $price; }
            $base = (int) $price['total_amount'];
        } else {
            $expected = $action === 'disable' ? 'active' : 'disabled';
            if ($order->status !== $expected) {
                return IPSVP_Reseller_Store::error('invalid_status', 'توقف فقط برای سرویس فعال و فعال‌سازی فقط برای سرویس متوقف مجاز است.', 409);
            }
        }
        if ($base < 0 || $base > 100000000000) {
            return IPSVP_Reseller_Store::error('invalid_price', 'قیمت تنظیم‌شده نامعتبر است.', 409);
        }
        return array('request' => $data, 'base_amount' => $base, 'discount_percent' => (float) $account->discount_percent,
            'amount' => IPSVP_Reseller_Store::discount($base, $account->discount_percent), 'currency' => 'IRT');
    }

    /** Bind a key to the submitted semantic body, not mutable prices or catalog state. */
    public static function fingerprint($action, array $input)
    {
        $canonical = array('action' => $action);
        foreach (array('order_id', 'plan_id', 'country_id', 'gb', 'max_amount', 'customer_reference') as $key) {
            if (isset($input[$key])) {
                if (!is_scalar($input[$key])) { return false; }
                $canonical[$key] = (string) $input[$key];
            }
        }
        return hash('sha256', wp_json_encode($canonical));
    }

    public function execute($user, $action, array $input, $key, $channel = 'api')
    {
        global $wpdb;
        if (!is_string($key) || !preg_match('/^[A-Za-z0-9._:-]{16,100}$/D', $key)) {
            return IPSVP_Reseller_Store::error('idempotency_required', 'شناسه Idempotency-Key با طول ۱۶ تا ۱۰۰ کاراکتر لازم است.');
        }
        $hash = self::fingerprint($action, $input);
        if (!$hash) { return IPSVP_Reseller_Store::error('invalid_input', 'ساختار ورودی نامعتبر است.'); }
        $locked = IPSVP_Reseller_Store::lock($user->id);
        if (is_wp_error($locked)) { return $locked; }
        $user = $this->db->get_user_by_id($user->id);
        if (!$user || !empty($user->is_blocked) || !IPSVP_Reseller_Store::approved($user->id)) {
            return IPSVP_Reseller_Store::error('not_approved', 'نمایندگی فعال نیست.', 403);
        }
        $table = IPSVP_Reseller_Store::table('operations');
        $key_hash = hash('sha256', $key);
        $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE user_id=%d AND idempotency_hash=%s", $user->id, $key_hash));
        if ($existing) {
            if (!hash_equals($existing->request_hash, $hash)) {
                return IPSVP_Reseller_Store::error('idempotency_conflict', 'این شناسه قبلاً برای ورودی دیگری استفاده شده است.', 409);
            }
            return $existing;
        }
        // Uncertain debits/provisioning must be reconciled before more side effects.
        if ($wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE user_id=%d AND state IN ('reserved','processing','manual_review','refund_review') LIMIT 1", $user->id))) {
            return IPSVP_Reseller_Store::error('operation_unresolved', 'یک عملیات تعیین‌تکلیف‌نشده دارید؛ وضعیت آن را بررسی کنید یا با پشتیبانی تماس بگیرید.', 409);
        }
        $quote = $this->quote($user, $action, $input);
        if (is_wp_error($quote)) { return $quote; }
        if (isset($input['max_amount'])) {
            $max = self::integer($input['max_amount'], 0, 100000000000);
            if ($max === false) { return IPSVP_Reseller_Store::error('invalid_max_amount', 'max_amount باید عدد صحیح غیرمنفی باشد.'); }
            if ($quote['amount'] > $max) { return IPSVP_Reseller_Store::error('price_changed', 'قیمت فعلی بیشتر از سقف مجاز شماست؛ قیمت را دوباره استعلام کنید.', 409); }
        }
        $reference = $input['customer_reference'] ?? '';
        if (!is_string($reference) || strlen($reference) > 100) {
            return IPSVP_Reseller_Store::error('invalid_reference', 'customer_reference حداکثر ۱۰۰ بایت است.');
        }
        $storage = IPSVP_Reseller_Store::transactional_storage($this->db);
        if (is_wp_error($storage)) { return $storage; }
        $balance = IPSVP_Reseller_Store::balance($user, $this->db);
        if (is_wp_error($balance)) { return $balance; }
        if ($balance < $quote['amount']) { return IPSVP_Reseller_Store::error('insufficient_balance', 'موجودی کیف پول کافی نیست.', 402); }
        if (in_array($action, array('enable', 'extra-volume'), true)) {
            $order = $this->owned_order($user, $quote['request']['order_id']);
            $snapshot = $this->api->user_snapshot($order->pg_username, $order->pg_user_id, $order);
            if (empty($snapshot['live'])) { return IPSVP_Reseller_Store::error('upstream_unavailable', 'وضعیت سرویس از پنل دریافت نشد.', 503); }
            if ($action === 'extra-volume' && (!is_numeric($snapshot['limit']) || (float) $snapshot['limit'] <= 0)) {
                return IPSVP_Reseller_Store::error('unlimited_service', 'سرویس نامحدود نیاز به حجم اضافه ندارد.', 409);
            }
            if ($action === 'enable') {
                $expire = is_numeric($snapshot['expire']) ? (int) $snapshot['expire'] : strtotime((string) $snapshot['expire']);
                if (!is_numeric($snapshot['limit']) || !is_numeric($snapshot['used']) || $snapshot['expire'] === '' || ($expire === false && $snapshot['expire'] !== null)) {
                    return IPSVP_Reseller_Store::error('upstream_unavailable', 'اطلاعات زمان و حجم سرویس کامل نیست؛ فعال‌سازی انجام نشد.', 503);
                }
                if (in_array($snapshot['status'], array('expired', 'limited'), true) || ($expire && $expire <= time()) || ((float) $snapshot['limit'] > 0 && (float) $snapshot['used'] >= (float) $snapshot['limit'])) {
                    return IPSVP_Reseller_Store::error('renewal_required', 'زمان یا حجم سرویس تمام شده است؛ ابتدا تمدید کنید.', 409);
                }
            }
        }
        $op_id = 0;
        $committed = false;
        try {
            if ($wpdb->query('START TRANSACTION') === false) { throw new RuntimeException('Transaction failed'); }
            $now = $this->db->now();
            $source = empty($user->bot_tel_id) ? 'local' : 'remote';
            $this->insert($table, array('user_id' => $user->id, 'idempotency_hash' => $key_hash, 'request_hash' => $hash,
                'action' => $action, 'channel' => $channel, 'state' => 'reserved', 'stage' => 'reserved',
                'order_id' => $quote['request']['order_id'] ?? 0, 'base_amount' => $quote['base_amount'],
                'discount_percent' => $quote['discount_percent'], 'amount' => $quote['amount'], 'wallet_source' => $source,
                'bot_tel_id' => $user->bot_tel_id ?? null, 'customer_reference' => sanitize_text_field($reference),
                'request_json' => wp_json_encode($quote['request']), 'created_at' => $now, 'updated_at' => $now));
            $op_id = (int) $wpdb->insert_id;
            $tables = $this->db->tables();
            if ($action === 'purchase') {
                $this->insert($tables['orders'], array('order_code' => 'RS-' . $op_id . '-' . strtoupper(wp_generate_password(8, false, false)),
                    'service_type' => 'shared', 'submission_key' => 'reseller-' . $op_id, 'user_id' => $user->id,
                    'phone' => $user->phone, 'plan_id' => $quote['request']['plan_id'], 'country_id' => $quote['request']['country_id'],
                    'price' => $quote['amount'], 'status' => 'reseller_processing', 'payment_status' => 'reseller_reserved',
                    'wallet_effect' => $source, 'created_at' => $now, 'updated_at' => $now));
                IPSVP_Reseller_Store::update_operation($op_id, array('order_id' => (int) $wpdb->insert_id));
            }
            if ($quote['amount'] > 0) {
                $op = IPSVP_Reseller_Store::operation($op_id);
                $this->insert($tables['receipts'], array('order_id' => $op->order_id, 'submission_key' => 'reseller-debit-' . $op_id,
                    'user_id' => $user->id, 'phone' => $user->phone, 'type' => 'wallet_admin_debit',
                    'amount' => $quote['amount'], 'status' => $source === 'local' ? 'approved' : 'reseller_pending',
                    'wallet_effect' => $source, 'remote_source' => 'reseller', 'admin_note' => 'عملیات نمایندگی #' . $op_id . ' / ' . $action,
                    'created_at' => $now, 'reviewed_at' => $source === 'local' ? $now : null));
                IPSVP_Reseller_Store::update_operation($op_id, array('receipt_id' => (int) $wpdb->insert_id));
            }
            if ($wpdb->query('COMMIT') === false) { throw new RuntimeException('Commit failed'); }
            $committed = true;
            $op = IPSVP_Reseller_Store::operation($op_id);
            if ($source === 'remote' && $quote['amount'] > 0) {
                IPSVP_Reseller_Store::update_operation($op_id, array('state' => 'processing', 'stage' => 'debit_pending'));
                $debit = IPSVP_Bot_API::debit_wallet($op->bot_tel_id, $op->amount, 'RS-OP-' . $op_id, $user->phone);
                if (is_wp_error($debit) || empty($debit['ok'])) {
                    return $this->review($op_id, 'wallet_debit_uncertain');
                }
                if (false === $wpdb->update($tables['receipts'], array('status' => 'approved', 'reviewed_at' => $now), array('id' => $op->receipt_id))) {
                    throw new RuntimeException('Debit mirror failed');
                }
            }
            IPSVP_Reseller_Store::update_operation($op_id, array('state' => 'processing', 'stage' => 'provider_pending'));
            $order = $this->db->get_order($op->order_id);
            if ($action === 'purchase') {
                $result = (int) $order->country_id === 0
                    ? $this->api->create_users_for_all_countries_order($order, $this->db->ready_countries('shared'))
                    : $this->api->create_user_for_order($order);
            } elseif ($action === 'renew') {
                $result = $this->api->extend_user_for_order($order, $this->db->get_plan($quote['request']['plan_id']));
            } elseif ($action === 'extra-volume') {
                $result = $this->api->add_extra_volume_for_order($order, $quote['request']['gb']);
            } else {
                $result = $this->api->update_user_status_for_order($order, $action === 'disable' ? 'disabled' : 'active');
            }
            if (is_wp_error($result) || !is_array($result) || empty($result['user_id'])) {
                // Timeouts and even 5xx can follow a successful upstream mutation. Never retry/refund blindly.
                return $this->review($op_id, 'provider_result_uncertain');
            }
            IPSVP_Reseller_Store::update_operation($op_id, array('stage' => 'provider_completed', 'provider_result' => wp_json_encode($result)));
            return $this->complete(IPSVP_Reseller_Store::operation($op_id));
        } catch (Throwable $e) {
            if (!$committed) {
                $wpdb->query('ROLLBACK');
                return IPSVP_Reseller_Store::error('storage_failed', 'ثبت مالی انجام نشد؛ وضعیت عملیات را با همان شناسه پیگیری کنید.', 503);
            }
            return $this->review($op_id, 'finalization_uncertain');
        }
    }

    private function insert($table, $data)
    {
        global $wpdb;
        if (!$wpdb->insert($table, $data)) { throw new RuntimeException('Insert failed'); }
    }

    private function review($id, $code)
    {
        try {
            IPSVP_Reseller_Store::update_operation($id, array('state' => 'manual_review', 'error_code' => $code));
        } catch (Throwable $e) {
            // The already durable reserved/processing state also prevents automatic retries.
        }
        return IPSVP_Reseller_Store::operation($id);
    }

    public function complete($op)
    {
        $result = json_decode((string) $op->provider_result, true);
        if (!is_array($result) || !$result) { return IPSVP_Reseller_Store::error('no_provider_result', 'ابتدا نتیجه واقعی عملیات را از پنل تأیید کنید.', 409); }
        $order = $this->db->get_order($op->order_id);
        if (!$order) { return IPSVP_Reseller_Store::error('order_not_found', 'سفارش پیدا نشد.', 404); }
        $update = array('payment_status' => 'approved', 'approved_at' => $this->db->now());
        if (in_array($op->action, array('enable', 'disable'), true)) {
            $update['status'] = $op->action === 'disable' ? 'disabled' : 'active';
            $update['pg_status'] = $result['pg_status'] ?? $update['status'];
        } else {
            $update['status'] = !empty($result['status']) && $result['status'] === 'on_hold' ? 'on_hold' : 'active';
            $update['pg_status'] = $result['status'] ?? $update['status'];
            $update['service_ended_at'] = null;
            $update['cancelled_at'] = null;
            if (!empty($result['username'])) { $update['pg_username'] = $result['username']; }
            if (!empty($result['user_id'])) { $update['pg_user_id'] = $result['user_id']; }
            if (!empty($result['subscription_url']) && ($op->action !== 'extra-volume' || empty($order->pg_subscription_url))) {
                $update['pg_subscription_url'] = $result['subscription_url'];
            }
            if (!empty($result['links']) && ($op->action !== 'extra-volume' || empty($order->pg_links))) { $update['pg_links'] = wp_json_encode($result['links']); }
            $raw = $result['raw']['after'] ?? ($result['raw'] ?? array());
            $old = json_decode((string) $order->pg_response, true);
            if (!empty($old['_all_countries'])) { $raw['_all_countries'] = $old['_all_countries']; }
            if (!empty($result['expire_at'])) { $raw['expire'] = $result['expire_at']; }
            $update['pg_response'] = wp_json_encode($raw);
            $update['pg_synced_at'] = $this->db->now();
        }
        if (false === $this->db->update_order($order->id, $update)) { throw new RuntimeException('Order update failed'); }
        IPSVP_Reseller_Store::update_operation($op->id, array('state' => 'succeeded', 'stage' => 'completed', 'error_code' => null));
        // Financial record belongs to the operation; no second order/receipt debit or referral payout.
        return IPSVP_Reseller_Store::operation($op->id);
    }

    public function public_order($order, $live = false)
    {
        $out = array('id' => (int) $order->id, 'code' => $order->order_code, 'plan_id' => (int) $order->plan_id,
            'country_id' => (int) $order->country_id, 'status' => $order->status, 'amount' => (int) $order->price,
            'currency' => 'IRT', 'subscription_url' => $order->pg_subscription_url,
            'links' => json_decode((string) $order->pg_links, true) ?: array(), 'created_at' => $order->created_at);
        if ($live) {
            $snapshot = $this->api->user_snapshot($order->pg_username, $order->pg_user_id, $order);
            $out['live_available'] = !empty($snapshot['live']);
            foreach (array('status', 'used', 'limit', 'expire') as $key) { $out['usage'][$key] = $snapshot[$key] ?? null; }
        }
        return $out;
    }
}

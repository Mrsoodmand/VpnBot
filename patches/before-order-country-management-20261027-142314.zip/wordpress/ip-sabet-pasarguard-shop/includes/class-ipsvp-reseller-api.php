<?php
defined('ABSPATH') || exit;

final class IPSVP_Reseller_API
{
    const NS = 'ips-reseller/v1';
    private $db;
    private $service;
    private $authenticated;

    public function __construct($db, $service)
    {
        $this->authenticated = new SplObjectStorage();
        $this->db = $db;
        $this->service = $service;
        add_action('rest_api_init', array($this, 'routes'));
        add_filter('rest_post_dispatch', array($this, 'no_cache'), 10, 3);
    }

    public static function endpoints()
    {
        return array(
            array('GET', '/account', 'اطلاعات نمایندگی، درصد تخفیف و تاریخ اعتبار کلید', array()),
            array('GET', '/wallet', 'مانده قابل مصرف کیف پول به تومان', array()),
            array('GET', '/plans', 'پلن‌های فعال و قیمت پایه، نمایندگی و همه کشورها', array()),
            array('GET', '/countries', 'کشورهای قابل خرید؛ شناسه صفر برای همه کشورها', array()),
            array('POST', '/quote', 'استعلام قیمت؛ هیچ مبلغی کسر نمی‌شود', array('action' => 'purchase|renew|extra-volume|disable|enable', 'plan_id' => 1, 'country_id' => 1)),
            array('GET', '/orders', 'سفارش‌های اشتراکی خودتان؛ page و per_page (۱ تا ۵۰)', array()),
            array('GET', '/orders/{id}', 'جزئیات سفارش، لینک اشتراک و کانفیگ‌ها', array()),
            array('GET', '/orders/{id}/usage', 'وضعیت زنده، مصرف و سقف حجم به بایت و انقضا', array()),
            array('POST', '/orders', 'خرید کانفیگ اشتراکی از کیف پول', array('plan_id' => 1, 'country_id' => 1, 'customer_reference' => 'customer-123', 'max_amount' => 500000)),
            array('POST', '/orders/{id}/renew', 'تمدید با پلن فعال اشتراکی', array('plan_id' => 1, 'max_amount' => 500000)),
            array('POST', '/orders/{id}/extra-volume', 'خرید حجم اضافه با تخفیف نمایندگی', array('gb' => 10, 'max_amount' => 100000)),
            array('POST', '/orders/{id}/disable', 'توقف سرویس فعال؛ رایگان؛ زمان اعتبار متوقف نمی‌شود', array()),
            array('POST', '/orders/{id}/enable', 'فعال‌سازی سرویس متوقف دارای حجم و زمان؛ رایگان', array()),
            array('GET', '/operations', 'تراکنش‌ها با قیمت و درصد تخفیف ثبت‌شده؛ page و per_page', array()),
            array('GET', '/operations/{id}', 'پیگیری نتیجه عملیات؛ بدون اجرای مجدد', array()),
            array('GET', '/operations/lookup', 'بازیابی عملیات با هدر Idempotency-Key پس از قطع ارتباط', array()),
        );
    }

    public function routes()
    {
        foreach (self::endpoints() as $endpoint) {
            $path = str_replace('{id}', '(?P<id>[1-9][0-9]*)', $endpoint[1]);
            register_rest_route(self::NS, $path, array('methods' => $endpoint[0],
                'permission_callback' => array($this, 'authorize'), 'callback' => array($this, 'dispatch')));
        }
        register_rest_route(self::NS, '/openapi', array('methods' => 'GET', 'permission_callback' => '__return_true',
            'callback' => array('IPSVP_Reseller_Docs', 'openapi')));
    }

    public function no_cache($response, $server, $request)
    {
        if (strpos($request->get_route(), '/' . self::NS . '/') === 0) {
            $response->header('Cache-Control', 'private, no-store, max-age=0');
            $response->header('Vary', 'Authorization');
            $response->header('X-Content-Type-Options', 'nosniff');
        }
        return $response;
    }

    public function authorize($request)
    {
        global $wpdb;
        // A failed re-authorization must erase any earlier identity on the same request.
        if ($this->authenticated->contains($request)) { $this->authenticated->detach($request); }
        if (!is_ssl()) { return IPSVP_Reseller_Store::error('https_required', 'فقط HTTPS مجاز است.', 403); }
        $header = (string) $request->get_header('authorization');
        if (!preg_match('/^Bearer (ipsr_[a-f0-9]{64})$/D', $header, $matches)) {
            return IPSVP_Reseller_Store::error('unauthorized', 'کلید دسترسی معتبر لازم است.', 401);
        }
        $table = IPSVP_Reseller_Store::table('accounts');
        $account = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE key_hash=%s", hash('sha256', $matches[1])));
        if (!$account || $account->status !== 'approved' || !$account->key_expires_at || strtotime($account->key_expires_at . ' UTC') <= time()) {
            return IPSVP_Reseller_Store::error('unauthorized', 'کلید نامعتبر، منقضی یا لغوشده است.', 401);
        }
        $user = $this->db->get_user_by_id($account->user_id);
        if (!$user || !empty($user->is_blocked)) { return IPSVP_Reseller_Store::error('forbidden', 'دسترسی این حساب مسدود است.', 403); }
        if (!self::ip_allowed((string) $account->allowed_ips, $_SERVER['REMOTE_ADDR'] ?? '')) {
            return IPSVP_Reseller_Store::error('ip_forbidden', 'IP درخواست در فهرست مجاز نیست.', 403);
        }
        $window = (int) floor(time() / 60);
        // Atomic fixed-window limiter. A transient read-then-write permits concurrent bypass.
        $ok = $wpdb->query($wpdb->prepare("UPDATE $table SET rate_count=IF(rate_window=%d,rate_count+1,1), rate_window=%d, last_used_at=%s WHERE user_id=%d AND (rate_window<>%d OR rate_count<60)", $window, $window, gmdate('Y-m-d H:i:s'), $user->id, $window));
        if ($ok === false) { return IPSVP_Reseller_Store::error('storage_unavailable', 'سرویس موقتاً در دسترس نیست.', 503); }
        if ($ok !== 1) { return IPSVP_Reseller_Store::error('rate_limited', 'حداکثر ۶۰ درخواست در دقیقه مجاز است؛ دقیقه بعد تلاش کنید.', 429); }
        // Keep identity outside user-controlled REST parameters.
        $this->authenticated[$request] = array('user_id' => (int) $user->id, 'key_hash' => (string) $account->key_hash);
        return true;
    }

    public static function ip_allowed($list, $remote_ip)
    {
        if (trim($list) === '') { return true; }
        $remote = @inet_pton($remote_ip);
        if ($remote === false) { return false; }
        foreach (preg_split('/[\s,]+/', trim($list)) as $ip) {
            if (@inet_pton($ip) === $remote) { return true; }
        }
        return false;
    }

    public function dispatch($request)
    {
        global $wpdb;
        if (!$this->authenticated->contains($request)) { return IPSVP_Reseller_Store::error('unauthorized', 'احراز هویت لازم است.', 401); }
        $identity = $this->authenticated[$request];
        $path = substr($request->get_route(), strlen('/' . self::NS));
        $method = $request->get_method();
        $endpoint = null;
        $path_exists = false;
        foreach (self::endpoints() as $candidate) {
            $pattern = str_replace('\\{id\\}', '[1-9][0-9]*', preg_quote($candidate[1], '~'));
            if (preg_match('~^' . $pattern . '$~D', $path)) {
                $path_exists = true;
                if ($candidate[0] === $method) { $endpoint = $candidate; break; }
            }
        }
        if (!$endpoint) { return IPSVP_Reseller_Store::error($path_exists ? 'method_not_allowed' : 'route_not_found', 'مسیر یا روش درخواست مجاز نیست.', $path_exists ? 405 : 404); }
        if ($method === 'POST' && $path !== '/quote') {
            $locked = IPSVP_Reseller_Store::lock($identity['user_id']);
            if (is_wp_error($locked)) { return $locked; }
        }
        // Recheck under the wallet lock before mutations: key rotation/revocation uses this lock too.
        $account = IPSVP_Reseller_Store::approved($identity['user_id']);
        $user = $this->db->get_user_by_id($identity['user_id']);
        if (!$account || !$user || !empty($user->is_blocked) || !$account->key_hash || !hash_equals($identity['key_hash'], (string) $account->key_hash)
            || !$account->key_expires_at || strtotime($account->key_expires_at . ' UTC') <= time()
            || !self::ip_allowed((string) $account->allowed_ips, $_SERVER['REMOTE_ADDR'] ?? '')) {
            $this->authenticated->detach($request);
            return IPSVP_Reseller_Store::error('unauthorized', 'دسترسی لغو یا منقضی شده است.', 401);
        }
        $id = 0;
        if (strpos($endpoint[1], '{id}') !== false) {
            // Read identity from the matched URL itself; body/query parameters cannot replace it.
            preg_match('~^/(?:orders|operations)/([1-9][0-9]*)~D', $path, $id_match);
            $id = IPSVP_Reseller_Service::integer($id_match[1] ?? null);
            if ($id === false) { return IPSVP_Reseller_Store::error('invalid_id', 'شناسه نامعتبر است.'); }
        }
        if ($method === 'POST') {
            if (!$request->is_json_content_type()) { return IPSVP_Reseller_Store::error('json_required', 'Content-Type باید application/json باشد.', 415); }
            if (strlen($request->get_body()) > 8192) { return IPSVP_Reseller_Store::error('body_too_large', 'بدنه درخواست بیش از حد بزرگ است.', 413); }
            $body = $request->get_json_params();
            if (!is_object(json_decode($request->get_body())) || !is_array($body)) { return IPSVP_Reseller_Store::error('invalid_json', 'یک شیء JSON ارسال کنید.'); }
            if ($path === '/quote') {
                $action = isset($body['action']) && is_string($body['action']) ? $body['action'] : '';
                if (array_diff(array_keys($body), array('action', 'order_id', 'plan_id', 'country_id', 'gb'))) { return IPSVP_Reseller_Store::error('unknown_fields', 'فیلد ناشناخته در درخواست وجود دارد.'); }
                $result = $this->service->quote($user, $action, $body);
                return is_wp_error($result) ? $result : $this->response($result);
            }
            $action = $path === '/orders' ? 'purchase' : basename($path);
            $allowed = array('purchase' => array('plan_id', 'country_id'), 'renew' => array('order_id', 'plan_id'),
                'extra-volume' => array('order_id', 'gb'), 'enable' => array('order_id'), 'disable' => array('order_id'));
            $fields = array_merge(array_diff($allowed[$action] ?? array(), array('order_id')), array('customer_reference', 'max_amount'));
            if (array_diff(array_keys($body), $fields)) { return IPSVP_Reseller_Store::error('unknown_fields', 'فیلد ناشناخته در درخواست وجود دارد.'); }
            if ($id) { $body['order_id'] = $id; }
            $op = $this->service->execute($user, $action, $body, (string) $request->get_header('idempotency-key'));
            return is_wp_error($op) ? $op : $this->operation_response($op);
        }
        if ($path === '/account') {
            $a = IPSVP_Reseller_Store::approved($user->id);
            if (!$a) { return IPSVP_Reseller_Store::error('not_approved', 'نمایندگی فعال لازم است.', 403); }
            return $this->response(array('user_id' => (int) $user->id, 'status' => $a->status, 'discount_percent' => (float) $a->discount_percent,
                'discount_source' => isset($a->loyalty) ? $a->loyalty['source'] : 'manual',
                'discount_expires_at' => !empty($a->loyalty['expires_at']) ? gmdate('c', $a->loyalty['expires_at']) : null,
                'stars' => isset($a->loyalty) ? $a->loyalty['stars'] : 1,
                'business_name' => $a->business_name, 'key_expires_at' => $a->key_expires_at, 'currency' => 'IRT', 'rate_limit_per_minute' => 60));
        }
        if ($path === '/wallet') {
            $balance = IPSVP_Reseller_Store::balance($user, $this->db);
            return is_wp_error($balance) ? $balance : $this->response(array('balance' => $balance, 'currency' => 'IRT'));
        }
        if ($path === '/plans') { return $this->response($this->plans($user)); }
        if ($path === '/countries') { return $this->response($this->countries()); }
        if (strpos($path, '/orders/') === 0) {
            $order = $this->service->owned_order($user, $id);
            return is_wp_error($order) ? $order : $this->response($this->service->public_order($order, substr($path, -6) === '/usage'));
        }
        if (strpos($path, '/operations/') === 0) {
            if ($path === '/operations/lookup') {
                $table = IPSVP_Reseller_Store::table('operations');
                $op = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE user_id=%d AND idempotency_hash=%s", $user->id, hash('sha256', (string) $request->get_header('idempotency-key'))));
            } else { $op = IPSVP_Reseller_Store::operation($id, $user->id); }
            return $op ? $this->operation_response($op) : IPSVP_Reseller_Store::error('operation_not_found', 'عملیات پیدا نشد.', 404);
        }
        $page = IPSVP_Reseller_Service::integer($request->get_param('page') ?? 1, 1, 1000000);
        $size = IPSVP_Reseller_Service::integer($request->get_param('per_page') ?? 20, 1, 50);
        if ($page === false || $size === false) { return IPSVP_Reseller_Store::error('invalid_pagination', 'page یا per_page نامعتبر است.'); }
        if ($path === '/orders') {
            $table = $this->db->tables()['orders'];
            $where = "user_id=%d AND service_type='shared'";
            $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE $where ORDER BY id DESC LIMIT %d OFFSET %d", $user->id, $size, ($page - 1) * $size));
            $items = array_map(array($this->service, 'public_order'), $rows);
        } else {
            $table = IPSVP_Reseller_Store::table('operations');
            $where = 'user_id=%d';
            $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE $where ORDER BY id DESC LIMIT %d OFFSET %d", $user->id, $size, ($page - 1) * $size));
            $items = array_map(array('IPSVP_Reseller_Store', 'public_operation'), $rows);
        }
        $total = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE $where", $user->id));
        return $this->response(array('items' => $items, 'page' => $page, 'per_page' => $size, 'total' => $total, 'total_pages' => (int) ceil($total / $size)));
    }

    public function plans($user)
    {
        $a = IPSVP_Reseller_Store::approved($user->id);
        $out = array();
        foreach ($this->db->active_plans('shared') as $plan) {
            $base = $this->db->final_price($plan, true);
            $all = (int) ceil($base * (100 + $this->db->all_countries_price_percent_value()) / 100);
            $out[] = array('id' => (int) $plan->id, 'title' => $plan->title, 'gb' => (int) $plan->gb, 'days' => (int) $plan->days,
                'base_amount' => $base, 'amount' => IPSVP_Reseller_Store::discount($base, $a ? $a->discount_percent : 0),
                'all_countries_amount' => $this->db->all_countries_enabled() && $this->db->all_countries_group_ready() ? IPSVP_Reseller_Store::discount($all, $a ? $a->discount_percent : 0) : null,
                'currency' => 'IRT', 'sales_enabled' => $this->db->service_sales_enabled('shared'));
        }
        return $out;
    }

    public function countries()
    {
        $out = array();
        foreach ($this->db->ready_countries('shared') as $country) { $out[] = array('id' => (int) $country->id, 'name' => $country->name, 'flag' => $country->flag); }
        if ($this->db->all_countries_enabled() && $this->db->all_countries_group_ready()) { $out[] = array('id' => 0, 'name' => 'همه کشورها', 'flag' => '🌍'); }
        return $out;
    }

    private function operation_response($op)
    {
        if (!$op) { return IPSVP_Reseller_Store::error('storage_unavailable', 'وضعیت عملیات را با همان شناسه پیگیری کنید.', 503); }
        $out = array('operation' => IPSVP_Reseller_Store::public_operation($op));
        $order = $this->db->get_order($op->order_id);
        if ($order && (int) $order->user_id === (int) $op->user_id) { $out['order'] = $this->service->public_order($order); }
        return $this->response($out, in_array($op->state, array('succeeded', 'failed', 'refunded'), true) ? 200 : 202);
    }

    private function response($data, $status = 200)
    {
        return new WP_REST_Response(array('data' => $data), $status);
    }
}

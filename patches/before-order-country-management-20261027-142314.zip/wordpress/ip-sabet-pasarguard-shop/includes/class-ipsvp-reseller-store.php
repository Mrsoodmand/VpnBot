<?php
/** Durable reseller accounts, operation journal and shared wallet serialization. */
defined('ABSPATH') || exit;

final class IPSVP_Reseller_Store
{
    const MIN_BALANCE = 2000000;
    private static $locks = array();

    public static function table($name)
    {
        global $wpdb;
        return $wpdb->prefix . 'ipsvp_reseller_' . $name;
    }

    public static function install()
    {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $accounts = self::table('accounts');
        $operations = self::table('operations');
        dbDelta("CREATE TABLE $accounts (
            user_id BIGINT UNSIGNED NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            discount_percent DECIMAL(5,2) NULL DEFAULT NULL,
            business_name VARCHAR(191) NOT NULL DEFAULT '',
            website VARCHAR(255) NOT NULL DEFAULT '',
            application_note TEXT NULL,
            review_note TEXT NULL,
            reviewed_by BIGINT UNSIGNED NULL,
            requested_at DATETIME NOT NULL,
            approved_at DATETIME NULL,
            reviewed_at DATETIME NULL,
            key_hash CHAR(64) NULL,
            key_hint VARCHAR(16) NULL,
            key_expires_at DATETIME NULL,
            key_created_at DATETIME NULL,
            last_used_at DATETIME NULL,
            allowed_ips TEXT NULL,
            rate_window BIGINT UNSIGNED NOT NULL DEFAULT 0,
            rate_count INT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY (user_id),
            UNIQUE KEY key_hash (key_hash),
            KEY status (status)
        ) ENGINE=InnoDB $charset;");
        // dbDelta does not reliably detect a nullability-only change. Preserve all
        // existing explicit percentages, including zero; only new/unset values are NULL.
        $column = $wpdb->get_row("SHOW COLUMNS FROM $accounts LIKE 'discount_percent'");
        if ($column && $column->Null !== 'YES') {
            $wpdb->query("ALTER TABLE $accounts MODIFY discount_percent DECIMAL(5,2) NULL DEFAULT NULL");
        }
        $wpdb->query("UPDATE $accounts SET discount_percent=NULL WHERE discount_percent=0 AND reviewed_at IS NULL AND reviewed_by IS NULL");
        dbDelta("CREATE TABLE $operations (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            idempotency_hash CHAR(64) NOT NULL,
            request_hash CHAR(64) NOT NULL,
            action VARCHAR(24) NOT NULL,
            channel VARCHAR(12) NOT NULL DEFAULT 'api',
            state VARCHAR(24) NOT NULL DEFAULT 'reserved',
            stage VARCHAR(32) NOT NULL DEFAULT 'reserved',
            order_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            receipt_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            base_amount BIGINT UNSIGNED NOT NULL DEFAULT 0,
            discount_percent DECIMAL(5,2) NOT NULL DEFAULT 0,
            amount BIGINT UNSIGNED NOT NULL DEFAULT 0,
            wallet_source VARCHAR(12) NOT NULL DEFAULT 'local',
            bot_tel_id VARCHAR(64) NULL,
            customer_reference VARCHAR(100) NOT NULL DEFAULT '',
            request_json LONGTEXT NOT NULL,
            provider_result LONGTEXT NULL,
            error_code VARCHAR(80) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY user_request (user_id,idempotency_hash),
            KEY user_state (user_id,state),
            KEY order_id (order_id),
            KEY user_created (user_id,created_at),
            KEY user_order_action (user_id,order_id,action)
        ) ENGINE=InnoDB $charset;");
    }

    /** Hold until request shutdown, including legacy wallet reads followed by writes. */
    public static function lock($user_id)
    {
        global $wpdb;
        $name = 'ipsvp_wallet_' . substr(hash('sha256', (defined('DB_NAME') ? DB_NAME : '') . ':' . $wpdb->prefix . ':' . (int) $user_id), 0, 40);
        if (isset(self::$locks[$name])) {
            return true;
        }
        if ((string) $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 5)', $name)) !== '1') {
            return self::error('wallet_busy', 'عملیات دیگری روی این حساب در حال انجام است؛ کمی بعد دوباره تلاش کنید.', 409);
        }
        self::$locks[$name] = true;
        register_shutdown_function(static function () use ($name) {
            global $wpdb;
            $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $name));
        });
        return true;
    }

    public static function require_lock($user_id)
    {
        $locked = self::lock($user_id);
        if (is_wp_error($locked)) {
            // A fabricated zero balance would hide a failed lock and allow unsafe credits/sync.
            throw new RuntimeException($locked->get_error_message());
        }
    }

    public static function transactional_storage($db)
    {
        global $wpdb;
        $tables = $db->tables();
        foreach (array($tables['orders'], $tables['receipts'], self::table('operations')) as $table) {
            $engine = $wpdb->get_var($wpdb->prepare('SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=%s', $table));
            if (strtoupper((string) $engine) !== 'INNODB') {
                return self::error('storage_unavailable', 'جداول مالی باید از نوع InnoDB باشند؛ با مدیریت تماس بگیرید.', 503);
            }
        }
        return true;
    }

    public static function error($code, $message, $status = 400)
    {
        return new WP_Error('ipsr_' . $code, $message, array('status' => $status));
    }

    public static function account($user_id)
    {
        global $wpdb;
        $table = self::table('accounts');
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE user_id=%d", $user_id));
    }

    public static function approved($user_id)
    {
        $account = self::account($user_id);
        return $account && $account->status === 'approved' ? (class_exists('IPSVP_Loyalty') ? IPSVP_Loyalty::decorate($account) : $account) : false;
    }

    public static function discount($amount, $percent)
    {
        $basis_points = max(0, min(10000, (int) round((float) $percent * 100)));
        return (int) ceil(max(0, (int) $amount) * (10000 - $basis_points) / 10000);
    }

    public static function balance($user, $db)
    {
        $locked = self::lock($user->id);
        if (is_wp_error($locked)) { return $locked; }
        if (!empty($user->bot_tel_id)) {
            $wallet = IPSVP_Bot_API::unified_wallet($user, $db, true);
            if (is_wp_error($wallet) || empty($wallet['ok']) || !isset($wallet['balance'])) {
                return self::error('wallet_unavailable', 'دریافت موجودی کیف پول مشترک ناموفق بود؛ عملیات انجام نشد.', 503);
            }
            return (int) $wallet['balance'];
        }
        return $db->get_local_wallet_balance($user->id);
    }

    public static function operation($id, $user_id = 0)
    {
        global $wpdb;
        $table = self::table('operations');
        return $user_id
            ? $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id=%d AND user_id=%d", $id, $user_id))
            : $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id=%d", $id));
    }

    public static function update_operation($id, $data)
    {
        global $wpdb;
        $data['updated_at'] = current_time('mysql');
        if (false === $wpdb->update(self::table('operations'), $data, array('id' => (int) $id))) {
            throw new RuntimeException('Cannot persist reseller operation state.');
        }
    }

    public static function public_operation($op)
    {
        return array(
            'id' => (int) $op->id, 'action' => $op->action, 'state' => $op->state,
            'order_id' => (int) $op->order_id, 'base_amount' => (int) $op->base_amount,
            'discount_percent' => (float) $op->discount_percent, 'amount' => (int) $op->amount,
            'currency' => 'IRT', 'customer_reference' => $op->customer_reference,
            'error_code' => $op->error_code, 'created_at' => $op->created_at,
            'updated_at' => $op->updated_at,
        );
    }

    public static function audit($db, $user, $message, $context = array())
    {
        $context['admin_id'] = get_current_user_id();
        $db->add_log('info', 'reseller', $message, $context, $user->phone, 0, 0, $user->id);
    }
}

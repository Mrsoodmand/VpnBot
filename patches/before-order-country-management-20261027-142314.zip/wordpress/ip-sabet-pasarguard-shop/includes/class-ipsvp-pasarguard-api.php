<?php
/**
 * PasarGuard API client.
 *
 * @package IPSabet_PasarGuard_Shop
 */

defined('ABSPATH') || exit;

final class IPSVP_PasarGuard_API
{
    private function settings()
    {
        return IPSVP_Settings::get();
    }

    private function base_url()
    {
        $settings = $this->settings();
        return $this->normalize_panel_url($settings['panel_url']);
    }

    private function normalize_panel_url($url)
    {
        $url = trim((string) $url);
        if ($url === '') {
            return '';
        }

        if (!preg_match('#^https?://#i', $url)) {
            $url = 'https://' . $url;
        }

        // Some admins paste the dashboard login URL, for example:
        // https://domain:8000/dashboard/#/login
        // API routes are served from the panel origin, not from /dashboard/.
        $url = preg_replace('/#.*/', '', $url);
        $parts = wp_parse_url($url);
        if (empty($parts['scheme']) || empty($parts['host'])) {
            return rtrim($url, '/');
        }

        $base = strtolower($parts['scheme']) . '://' . $parts['host'];
        if (!empty($parts['port'])) {
            $base .= ':' . (int) $parts['port'];
        }

        $path = isset($parts['path']) ? trim($parts['path']) : '';
        $path = preg_replace('#/(dashboard|login|docs|redoc|openapi\.json).*$#i', '', $path);
        $path = trim($path, '/');
        if ($path !== '') {
            $base .= '/' . $path;
        }

        return rtrim($base, '/');
    }

    public function test_connection()
    {
        $token = $this->token(true);
        if (is_wp_error($token)) {
            return $token;
        }
        return $this->get_groups();
    }

    public function token($force = false)
    {
        $settings = $this->settings();
        $base = $this->base_url();
        if (!$base || empty($settings['panel_username']) || empty($settings['panel_password'])) {
            return new WP_Error('missing_settings', 'آدرس پنل، نام کاربری یا رمز عبور پاسارگارد تنظیم نشده است.');
        }
        $key = 'ipsvp_pg_token_' . md5($base . '|' . $settings['panel_username']);
        if (!$force) {
            $cached = get_transient($key);
            if ($cached) {
                return $cached;
            }
        }
        $login_url = $base . '/api/admin/token';
        $response = wp_remote_post($login_url, array(
            'headers' => array('Content-Type' => 'application/x-www-form-urlencoded'),
            'body' => array(
                'username' => $settings['panel_username'],
                'password' => $settings['panel_password'],
            ),
            'timeout' => 30,
            'sslverify' => !empty($settings['ssl_verify']),
        ));
        if (is_wp_error($response)) {
            return $response;
        }
        $code = (int) wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($code < 200 || $code >= 300 || empty($body['access_token'])) {
            $message = wp_remote_retrieve_body($response);
            if (stripos($message, 'Method Not Allowed') !== false) {
                $message .= ' | نکته: آدرس پنل را به شکل دامنه اصلی وارد کنید، نه آدرس داشبورد. نمونه صحیح: https://multi.ipsabet.app:8000';
            }
            return new WP_Error('login_failed', 'اتصال به پاسارگارد ناموفق بود: HTTP ' . $code . ' - ' . $message . ' | endpoint: ' . $login_url);
        }
        set_transient($key, $body['access_token'], 45 * MINUTE_IN_SECONDS);
        return $body['access_token'];
    }

    private function request($method, $path, $body = null, $raw = false)
    {
        $settings = $this->settings();
        $token = $this->token();
        if (is_wp_error($token)) {
            return $token;
        }
        $url = $this->base_url() . $path;
        $args = array(
            'method' => strtoupper($method),
            'headers' => array('Authorization' => 'Bearer ' . $token),
            'timeout' => 30,
            'sslverify' => !empty($settings['ssl_verify']),
        );
        if ($body !== null) {
            $args['headers']['Content-Type'] = 'application/json';
            $args['body'] = wp_json_encode($body);
        }
        $response = wp_remote_request($url, $args);
        if (is_wp_error($response)) {
            return $response;
        }
        $code = (int) wp_remote_retrieve_response_code($response);
        $content = wp_remote_retrieve_body($response);
        if ($code === 401) {
            $this->token(true);
            $args['headers']['Authorization'] = 'Bearer ' . $this->token();
            $response = wp_remote_request($url, $args);
            if (is_wp_error($response)) {
                return $response;
            }
            $code = (int) wp_remote_retrieve_response_code($response);
            $content = wp_remote_retrieve_body($response);
        }
        if ($code < 200 || $code >= 300) {
            return new WP_Error('pg_api_error', 'خطای API پاسارگارد: HTTP ' . $code . ' - ' . $content);
        }
        if ($raw) {
            return $content;
        }
        $decoded = json_decode($content, true);
        return $decoded !== null ? $decoded : $content;
    }

    public function get_groups()
    {
        // PasarGuard routes use prefix /api/group and route path s/simple,
        // so the final endpoint in current versions is /api/groups/simple.
        // Older/experimental builds may still expose /api/group/s/simple, so we keep a safe fallback.
        $endpoints = array(
            '/api/groups/simple?limit=1000&offset=0',
            '/api/groups/simple?limit=1000',
            '/api/groups?limit=1000&offset=0',
            '/api/group/s/simple?limit=1000&offset=0',
        );

        $last_error = null;
        foreach ($endpoints as $endpoint) {
            $res = $this->request('GET', $endpoint);
            if (!is_wp_error($res)) {
                $groups = $this->normalize_groups($res);
                if (!empty($groups)) {
                    return $groups;
                }
                // A valid empty response means the connection is OK but no group exists yet.
                return array();
            }
            $last_error = $res;
        }

        if ($last_error) {
            return new WP_Error(
                'pg_groups_failed',
                $last_error->get_error_message() . ' | مسیرهای تست شده: ' . implode(' , ', $endpoints)
            );
        }

        return array();
    }

    private function normalize_groups($data)
    {
        if (!is_array($data)) {
            return array();
        }
        $possible = array('groups', 'items', 'data', 'results');
        foreach ($possible as $key) {
            if (isset($data[$key]) && is_array($data[$key])) {
                $data = $data[$key];
                break;
            }
        }
        $groups = array();
        foreach ($data as $row) {
            if (!is_array($row)) {
                continue;
            }
            $id = isset($row['id']) ? $row['id'] : (isset($row['group_id']) ? $row['group_id'] : '');
            $name = isset($row['name']) ? $row['name'] : (isset($row['title']) ? $row['title'] : '');
            if ($id !== '' && $name !== '') {
                $groups[] = array('id' => (int) $id, 'name' => sanitize_text_field($name));
            }
        }
        return $groups;
    }

    public function create_user_for_order($order)
    {
        if (!$order) {
            return new WP_Error('no_order', 'سفارش یافت نشد.');
        }
        $username = $this->safe_username($order);
        $duration_seconds = max(0, (int) $order->days * DAY_IN_SECONDS);
        $expire = 0;
        $bytes = (int) $order->gb * 1024 * 1024 * 1024;
        $group_ids = $this->order_group_ids($order);
        if (empty($group_ids)) {
            return new WP_Error('missing_pg_group_ids', 'گروه پاسارگارد برای ساخت کانفیگ مشخص نیست.');
        }
        $payload = array(
            'username' => $username,
            'status' => 'on_hold',
            'expire' => $expire,
            'data_limit' => $bytes,
            'data_limit_reset_strategy' => 'no_reset',
            'group_ids' => $group_ids,
            'note' => 'Created from ip-sabet.me order ' . $order->order_code . ' phone ' . $order->phone,
            'proxy_settings' => new stdClass(),
            'on_hold_timeout' => gmdate('Y-m-d\TH:i:s\Z', time() + max(DAY_IN_SECONDS, $duration_seconds)),
            'on_hold_expire_duration' => $duration_seconds,
        );
        $res = $this->request('POST', '/api/user', $payload);
        if (is_wp_error($res)) {
            return $res;
        }

        $created = is_array($res) ? $res : array('response' => $res);
        $user_id = $this->extract_numeric_user_id($created);
        $sub_url = $this->extract_subscription_url($created);
        $links = $this->extract_config_links($created);

        $fresh = $this->get_user($username);
        if (!is_wp_error($fresh) && is_array($fresh)) {
            $sub_url = $sub_url ? $sub_url : $this->extract_subscription_url($fresh);
            $links = array_values(array_unique(array_merge($links, $this->extract_config_links($fresh))));
            $fresh_user_id = $this->extract_numeric_user_id($fresh);
            if ($fresh_user_id) {
                $user_id = $fresh_user_id;
            }
            $created['_fresh_user'] = $fresh;
        }

        if ($user_id) {
            $subscription_package = $this->get_user_subscription_package($user_id);
            if (!empty($subscription_package['content'])) {
                $created['_subscription_content'] = $subscription_package['content'];
                $created['_subscription_type'] = $subscription_package['type'];
            }
            if (!empty($subscription_package['links'])) {
                $links = array_values(array_unique(array_merge($links, $subscription_package['links'])));
            }
            if (!empty($subscription_package['error'])) {
                $created['_subscription_error'] = $subscription_package['error'];
            }
        }

        $pg_status = $this->pick_first($created, array('status'));
        if (!$pg_status && !empty($created['_fresh_user']) && is_array($created['_fresh_user'])) {
            $pg_status = $this->pick_first($created['_fresh_user'], array('status'));
        }
        if (!$pg_status) {
            $pg_status = 'on_hold';
        }

        return array(
            'username' => $username,
            'user_id' => $user_id,
            'status' => $pg_status,
            'subscription_url' => $sub_url,
            'links' => $links,
            'raw' => $created,
        );
    }

    public function create_users_for_all_countries_order($order, $countries)
    {
        $settings = IPSVP_Settings::get();
        $group_id = !empty($settings['all_countries_group_id']) ? (int) $settings['all_countries_group_id'] : 0;
        $group_name = !empty($settings['all_countries_group_name']) ? (string) $settings['all_countries_group_name'] : 'همه کشورها';
        if ($group_id <= 0) {
            return new WP_Error('all_countries_group_missing', 'گروه پاسارگارد گزینه همه کشورها انتخاب نشده است. از تنظیمات، گروه فروش همه کشورها را مشخص کنید.');
        }

        $countries = is_array($countries) ? $countries : array();
        $items = array();
        foreach ($countries as $country) {
            if (empty($country->id) || empty($country->name)) {
                continue;
            }
            $items[] = array(
                'country_id' => (int) $country->id,
                'country_name' => (string) $country->name,
                'country_flag' => (string) $country->flag,
                'pg_group_id' => !empty($country->pg_group_id) ? (int) $country->pg_group_id : 0,
                'pg_group_name' => !empty($country->pg_group_name) ? (string) $country->pg_group_name : '',
            );
        }

        $all_order = (object) array_merge((array) $order, array(
            'country_id' => 0,
            'country_name' => 'همه کشورها',
            'flag' => '🌍',
            'pg_group_id' => $group_id,
            'pg_group_ids' => array($group_id),
            'pg_group_name' => $group_name,
        ));

        $created = $this->create_user_for_order($all_order);
        if (is_wp_error($created)) {
            return new WP_Error('all_countries_create_failed', 'ساخت کانفیگ برای همه کشورها ناموفق بود: ' . $created->get_error_message());
        }

        $raw = !empty($created['raw']) && is_array($created['raw']) ? $created['raw'] : array();
        $raw['_all_countries'] = array(
            'enabled' => true,
            'mode' => 'single_user_selected_all_countries_group',
            'group_ids' => array($group_id),
            'group_id' => $group_id,
            'group_name' => $group_name,
            'countries' => $items,
            'countries_count' => count($items),
        );

        return array(
            'username' => (string) ($created['username'] ?? ''),
            'user_id' => (string) ($created['user_id'] ?? ''),
            'status' => (string) ($created['status'] ?? 'on_hold'),
            'subscription_url' => (string) ($created['subscription_url'] ?? ''),
            'links' => !empty($created['links']) && is_array($created['links']) ? array_values(array_unique($created['links'])) : array(),
            'raw' => $raw,
        );
    }


    public function ensure_all_countries_groups_for_order($order, $countries)
    {
        if (IPSVP_Sanaei_API::is_order($order)) { return false; }
        if (!$order || (int) ($order->country_id ?? -1) !== 0 || (empty($order->pg_username) && empty($order->pg_user_id))) {
            return false;
        }

        $settings = IPSVP_Settings::get();
        $configured_group_id = !empty($settings['all_countries_group_id']) ? (int) $settings['all_countries_group_id'] : 0;
        if ($configured_group_id > 0) {
            $group_ids = array($configured_group_id);
        } else {
            $countries = is_array($countries) ? $countries : array();
            $group_ids = array();
            foreach ($countries as $country) {
                if (empty($country->pg_group_id)) {
                    continue;
                }
                $group_id = (int) $country->pg_group_id;
                if ($group_id > 0) {
                    $group_ids[] = $group_id;
                }
            }
            $group_ids = array_values(array_unique($group_ids));
        }
        if (empty($group_ids)) {
            return false;
        }

        $fresh = array();
        if (!empty($order->pg_username) && !preg_match('#^(vless|vmess|trojan|ss|hysteria2)://#i', $order->pg_username)) {
            $by_username = $this->get_user($order->pg_username);
            if (!is_wp_error($by_username) && is_array($by_username)) {
                $fresh = $by_username;
            }
        }
        if (!$fresh && !empty($order->pg_user_id)) {
            $by_id = $this->get_user_by_id($order->pg_user_id);
            if (!is_wp_error($by_id) && is_array($by_id)) {
                $fresh = $by_id;
            }
        }

        $user_id = !empty($order->pg_user_id) && ctype_digit((string) $order->pg_user_id) ? (string) $order->pg_user_id : '';
        if (!$user_id && $fresh) {
            $user_id = $this->extract_numeric_user_id($fresh);
        }
        if (!$user_id) {
            return false;
        }

        $current_group_ids = $fresh ? $this->extract_group_ids_from_user($fresh) : array();
        $current_group_ids = array_values(array_unique(array_map('intval', $current_group_ids)));
        sort($current_group_ids);
        $target_group_ids = array_values(array_unique(array_map('intval', $group_ids)));
        sort($target_group_ids);
        if ($current_group_ids && $current_group_ids === $target_group_ids) {
            return false;
        }

        // برای جابجایی سفارش‌های قبلی «همه کشورها» فقط group_ids را ارسال می‌کنیم.
        // ارسال status/expire/data_limit باعث خطای PasarGuard برای کاربران on_hold می‌شد
        // و همچنین ممکن بود لینک یا زمان/حجم کاربر تغییر کند.
        $payload = array(
            'group_ids' => $target_group_ids,
        );

        return $this->update_user_payload_patch_first($user_id, $payload);
    }


    public function migrate_all_countries_order_to_selected_group($order, $countries = array())
    {
        if (!$order || (int) ($order->country_id ?? -1) !== 0) {
            return new WP_Error('not_all_countries_order', 'این سفارش از نوع همه کشورها نیست.');
        }
        if (empty($order->pg_username) && empty($order->pg_user_id)) {
            return new WP_Error('missing_pg_user', 'برای این سفارش یوزر پاسارگارد ثبت نشده است.');
        }

        $settings = IPSVP_Settings::get();
        $group_id = !empty($settings['all_countries_group_id']) ? (int) $settings['all_countries_group_id'] : 0;
        $group_name = !empty($settings['all_countries_group_name']) ? (string) $settings['all_countries_group_name'] : '';
        if ($group_id <= 0) {
            return new WP_Error('all_countries_group_missing', 'گروه مخصوص همه کشورها در تنظیمات انتخاب نشده است.');
        }

        $before = $this->user_snapshot($order->pg_username ?? '', $order->pg_user_id ?? '');
        $before_user_id = !empty($before['user_id']) ? (string) $before['user_id'] : (string) ($order->pg_user_id ?? '');
        $before_sub = !empty($before['subscription_url']) ? (string) $before['subscription_url'] : (string) ($order->pg_subscription_url ?? '');
        $before_group_ids = !empty($before['group_ids']) && is_array($before['group_ids']) ? array_values(array_unique(array_map('intval', $before['group_ids']))) : array();

        $updated = $this->ensure_all_countries_groups_for_order($order, $countries);
        if (is_wp_error($updated)) {
            return $updated;
        }

        $after = $this->user_snapshot($order->pg_username ?? '', $order->pg_user_id ?? '');
        $after_user_id = !empty($after['user_id']) ? (string) $after['user_id'] : $before_user_id;
        $after_sub = !empty($after['subscription_url']) ? (string) $after['subscription_url'] : $before_sub;

        $identity_changed = ($before_user_id !== '' && $after_user_id !== '' && $before_user_id !== $after_user_id);
        $subscription_changed = ($before_sub !== '' && $after_sub !== '' && $before_sub !== $after_sub);

        if ($identity_changed || $subscription_changed) {
            if (!empty($before_group_ids) && $after_user_id !== '') {
                $this->update_user_payload_patch_first($after_user_id, array('group_ids' => $before_group_ids));
            }
            return new WP_Error(
                'all_countries_link_or_identity_changed',
                'آپدیت متوقف شد چون بعد از تغییر گروه، لینک ساب یا شناسه کاربر تغییر کرد. تغییر گروه به حالت قبل برگردانده شد.'
            );
        }

        $raw = array();
        if (!empty($order->pg_response)) {
            $decoded = json_decode((string) $order->pg_response, true);
            if (is_array($decoded)) {
                $raw = $decoded;
            }
        }
        if (!empty($after['live']) && is_array($after['live'])) {
            $raw = array_merge($raw, $after['live']);
        }

        $country_items = array();
        $countries = is_array($countries) ? $countries : array();
        foreach ($countries as $country) {
            if (empty($country->id) || empty($country->name)) {
                continue;
            }
            $country_items[] = array(
                'country_id' => (int) $country->id,
                'country_name' => (string) $country->name,
                'country_flag' => (string) $country->flag,
                'pg_group_id' => !empty($country->pg_group_id) ? (int) $country->pg_group_id : 0,
                'pg_group_name' => !empty($country->pg_group_name) ? (string) $country->pg_group_name : '',
            );
        }

        $raw['_all_countries'] = array(
            'enabled' => true,
            'mode' => 'single_user_selected_all_countries_group',
            'migrated_to_selected_group' => true,
            'group_ids' => array($group_id),
            'group_id' => $group_id,
            'group_name' => $group_name,
            'countries' => $country_items,
            'countries_count' => count($country_items),
            'updated_at' => current_time('mysql'),
            'identity_changed' => $identity_changed,
            'subscription_changed' => $subscription_changed,
        );

        return array(
            'updated' => $updated !== false,
            'group_id' => $group_id,
            'group_name' => $group_name,
            'before_user_id' => $before_user_id,
            'after_user_id' => $after_user_id,
            'before_subscription_url' => $before_sub,
            'after_subscription_url' => $after_sub,
            'identity_changed' => $identity_changed,
            'subscription_changed' => $subscription_changed,
            'snapshot' => $after,
            'raw' => $raw,
        );
    }

    private function extract_group_ids_from_user($data)
    {
        $ids = array();
        $this->collect_group_ids($data, $ids);
        $clean = array();
        foreach ($ids as $id) {
            $id = (int) $id;
            if ($id > 0) {
                $clean[] = $id;
            }
        }
        return array_values(array_unique($clean));
    }

    private function collect_group_ids($data, &$ids)
    {
        if (!is_array($data)) {
            return;
        }
        foreach ($data as $key => $value) {
            if (($key === 'group_id' || $key === 'group') && is_numeric($value)) {
                $ids[] = (int) $value;
                continue;
            }
            if ($key === 'group_ids' && is_array($value)) {
                foreach ($value as $id) {
                    if (is_numeric($id)) {
                        $ids[] = (int) $id;
                    } elseif (is_array($id) && isset($id['id']) && is_numeric($id['id'])) {
                        $ids[] = (int) $id['id'];
                    }
                }
                continue;
            }
            if ($key === 'groups' && is_array($value)) {
                foreach ($value as $group) {
                    if (is_numeric($group)) {
                        $ids[] = (int) $group;
                    } elseif (is_array($group)) {
                        if (isset($group['id']) && is_numeric($group['id'])) {
                            $ids[] = (int) $group['id'];
                        }
                        if (isset($group['group_id']) && is_numeric($group['group_id'])) {
                            $ids[] = (int) $group['group_id'];
                        }
                    }
                }
            }
            if (is_array($value)) {
                $this->collect_group_ids($value, $ids);
            }
        }
    }


    public function extend_user_for_order($order, $plan)
    {
        if (IPSVP_Sanaei_API::is_order($order)) { return (new IPSVP_Sanaei_API())->extend_user_for_order($order, $plan); }
        if (!$order || !$plan || (empty($order->pg_username) && empty($order->pg_user_id))) {
            return new WP_Error('invalid_renew_order', 'اطلاعات سفارش برای تمدید کامل نیست.');
        }

        $fresh = array();
        if (!empty($order->pg_username) && !preg_match('#^(vless|vmess|trojan|ss|hysteria2)://#i', (string) $order->pg_username)) {
            $by_username = $this->get_user($order->pg_username);
            if (!is_wp_error($by_username) && is_array($by_username)) {
                $fresh = $by_username;
            } elseif (is_wp_error($by_username) && empty($order->pg_user_id)) {
                return $by_username;
            }
        }
        if (!$fresh && !empty($order->pg_user_id)) {
            $by_id = $this->get_user_by_id($order->pg_user_id);
            if (is_wp_error($by_id)) {
                return $by_id;
            }
            if (is_array($by_id)) {
                $fresh = $by_id;
            }
        }
        if (!$fresh) {
            return new WP_Error('pg_user_not_found', 'کاربر پاسارگارد برای تمدید پیدا نشد.');
        }

        $user_id = (!empty($order->pg_user_id) && ctype_digit((string) $order->pg_user_id)) ? (int) $order->pg_user_id : $this->extract_numeric_user_id($fresh);
        if (!$user_id) {
            return new WP_Error('missing_pg_user_id', 'آیدی کاربر پاسارگارد برای تمدید پیدا نشد.');
        }

        $current_expire = $this->pick_first($fresh, array('expire', 'expired_at', 'expiry_time'));
        $base_ts = $this->parse_time_value($current_expire);
        if ($base_ts < time()) {
            $base_ts = time();
        }
        $new_expire = gmdate('Y-m-d\TH:i:s\Z', $base_ts + ((int) $plan->days * DAY_IN_SECONDS));

        $current_limit = $this->pick_first($fresh, array('data_limit', 'total', 'total_traffic'));
        $current_limit = is_numeric($current_limit) ? (float) $current_limit : ((int) $order->gb * 1024 * 1024 * 1024);
        $new_limit = (int) $current_limit + ((int) $plan->gb * 1024 * 1024 * 1024);

        $payload = array(
            'status' => 'active',
            'expire' => $new_expire,
            'data_limit' => $new_limit,
            'data_limit_reset_strategy' => 'no_reset',
            'note' => 'Renewed from ip-sabet.me order ' . $order->order_code . ' phone ' . $order->phone,
        );
        $renew_group_ids = $this->order_group_ids($order);
        if (empty($renew_group_ids) && !empty($fresh) && is_array($fresh)) {
            $renew_group_ids = $this->extract_group_ids_from_user($fresh);
        }
        if (!empty($renew_group_ids)) {
            $payload['group_ids'] = array_values(array_unique(array_map('intval', $renew_group_ids)));
        }

        $updated = $this->update_user_payload($user_id, $payload);
        if (is_wp_error($updated)) {
            return $updated;
        }

        $after = !empty($order->pg_username)
            ? $this->get_user($order->pg_username)
            : $this->get_user_by_id($user_id);
        $raw = array('renewal_update' => $updated, 'before' => $fresh);
        if (!is_wp_error($after) && is_array($after)) {
            $raw['after'] = $after;
        }

        $sub_url = '';
        $links = array();
        if (!empty($raw['after'])) {
            $sub_url = $this->extract_subscription_url($raw['after']);
            $links = $this->extract_config_links($raw['after']);
        }

        $subscription_package = $this->get_user_subscription_package($user_id);
        if (!empty($subscription_package['content'])) {
            $raw['_subscription_content'] = $subscription_package['content'];
            $raw['_subscription_type'] = $subscription_package['type'];
        }
        if (!empty($subscription_package['links'])) {
            $links = array_values(array_unique(array_merge($links, $subscription_package['links'])));
        }
        if (!empty($subscription_package['error'])) {
            $raw['_subscription_error'] = $subscription_package['error'];
        }

        $pg_status = '';
        if (!empty($raw['after']) && is_array($raw['after'])) {
            $pg_status = $this->pick_first($raw['after'], array('status'));
        }
        if (!$pg_status) {
            $pg_status = $this->pick_first($fresh, array('status'));
        }
        if (!$pg_status) {
            $pg_status = 'active';
        }

        $final_expire = $new_expire;
        if (!empty($raw['after']) && is_array($raw['after'])) {
            $after_expire = $this->pick_first($raw['after'], array('expire', 'expired_at', 'expiry_time'));
            if ($after_expire !== '') {
                $final_expire = $after_expire;
            }
        }

        return array(
            'user_id' => (string) $user_id,
            'status' => $pg_status,
            'subscription_url' => $sub_url,
            'links' => $links,
            'expire_at' => $final_expire,
            'raw' => $raw,
        );
    }

    public function add_extra_volume_for_order($order, $gb)
    {
        if (IPSVP_Sanaei_API::is_order($order)) { return (new IPSVP_Sanaei_API())->add_extra_volume_for_order($order, $gb); }
        if (!$order || (empty($order->pg_username) && empty($order->pg_user_id))) {
            return new WP_Error('invalid_extra_volume_order', 'اطلاعات پاسارگارد سفارش برای افزایش حجم کامل نیست.');
        }
        $gb = (int) $gb;
        if ($gb < 1) {
            return new WP_Error('invalid_extra_volume_gb', 'مقدار حجم اضافه باید عدد صحیح مثبت باشد.');
        }

        $fresh = array();
        if (!empty($order->pg_username) && !preg_match('#^(vless|vmess|trojan|ss|hysteria2)://#i', (string) $order->pg_username)) {
            $by_username = $this->get_user($order->pg_username);
            if (!is_wp_error($by_username) && is_array($by_username)) {
                $fresh = $by_username;
            } elseif (is_wp_error($by_username) && empty($order->pg_user_id)) {
                return $by_username;
            }
        }
        if (!$fresh && !empty($order->pg_user_id)) {
            $by_id = $this->get_user_by_id($order->pg_user_id);
            if (is_wp_error($by_id)) {
                return $by_id;
            }
            if (is_array($by_id)) {
                $fresh = $by_id;
            }
        }
        if (!$fresh) {
            return new WP_Error('pg_user_not_found', 'کاربر پاسارگارد برای افزایش حجم پیدا نشد.');
        }

        $user_id = (!empty($order->pg_user_id) && ctype_digit((string) $order->pg_user_id)) ? (string) $order->pg_user_id : $this->extract_numeric_user_id($fresh);
        if (!$user_id) {
            return new WP_Error('missing_pg_user_id', 'آیدی کاربر پاسارگارد برای افزایش حجم پیدا نشد.');
        }

        $limit_value = $this->pick_first_with_key($fresh, array('data_limit', 'total', 'total_traffic', 'limit', 'total_bytes'));
        $current_limit_raw = $limit_value['value'];
        $limit_field = $limit_value['key'] ? $limit_value['key'] : 'data_limit';
        if ($current_limit_raw === '' || !is_numeric($current_limit_raw) || (float) $current_limit_raw <= 0) {
            return new WP_Error('extra_volume_unlimited', 'این سرویس نامحدود است و نیازی به خرید حجم اضافه ندارد.');
        }
        $current_limit = (int) floor((float) $current_limit_raw);
        $added_bytes = $gb * 1024 * 1024 * 1024;
        $new_limit = $current_limit + $added_bytes;

        $updated = $this->update_user_payload_patch_first($user_id, array(
            $limit_field => $new_limit,
            'status' => 'active',
        ));
        if (is_wp_error($updated)) {
            return $updated;
        }

        $after = array();
        if (!empty($order->pg_username) && !preg_match('#^(vless|vmess|trojan|ss|hysteria2)://#i', (string) $order->pg_username)) {
            $after_by_username = $this->get_user($order->pg_username);
            if (!is_wp_error($after_by_username) && is_array($after_by_username)) {
                $after = $after_by_username;
            }
        }
        if (!$after) {
            $after_by_id = $this->get_user_by_id($user_id);
            if (!is_wp_error($after_by_id) && is_array($after_by_id)) {
                $after = $after_by_id;
            }
        }

        return array(
            'user_id' => (string) $user_id,
            'gb' => $gb,
            'added_bytes' => $added_bytes,
            'old_limit' => $current_limit,
            'new_limit' => $new_limit,
            'status' => $after ? $this->pick_first($after, array('status')) : $this->pick_first($fresh, array('status')),
            'subscription_url' => $after ? $this->extract_subscription_url($after) : '',
            'links' => $after ? $this->extract_config_links($after) : array(),
            'raw' => array(
                'extra_volume_update' => $updated,
                'before' => $fresh,
                'after' => $after,
            ),
        );
    }

    private function update_user_payload($user_id, $payload)
    {
        $user_id = rawurlencode((string) $user_id);
        $attempts = array(
            array('PUT', '/api/user/by-id/' . $user_id),
            array('PATCH', '/api/user/by-id/' . $user_id),
            array('PUT', '/api/user/' . $user_id),
            array('PATCH', '/api/user/' . $user_id),
        );
        $last_error = null;
        foreach ($attempts as $attempt) {
            $res = $this->request($attempt[0], $attempt[1], $payload);
            if (!is_wp_error($res)) {
                return $res;
            }
            $last_error = $res;
        }
        return $last_error ? $last_error : new WP_Error('pg_update_failed', 'تمدید کاربر در پاسارگارد ناموفق بود.');
    }


    private function update_user_payload_patch_first($user_id, $payload)
    {
        $user_id = rawurlencode((string) $user_id);
        $attempts = array(
            array('PATCH', '/api/user/by-id/' . $user_id),
            array('PATCH', '/api/user/' . $user_id),
            array('PUT', '/api/user/by-id/' . $user_id),
            array('PUT', '/api/user/' . $user_id),
        );
        $last_error = null;
        foreach ($attempts as $attempt) {
            $res = $this->request($attempt[0], $attempt[1], $payload);
            if (!is_wp_error($res)) {
                return $res;
            }
            $last_error = $res;
        }
        return $last_error ? $last_error : new WP_Error('pg_update_failed', 'بروزرسانی گروه‌های کاربر در پاسارگارد ناموفق بود.');
    }

    private function parse_time_value($value)
    {
        if (is_numeric($value)) {
            $n = (float) $value;
            if ($n > 1000000000000) {
                return (int) floor($n / 1000);
            }
            if ($n > 1000000000) {
                return (int) $n;
            }
        }
        if (is_string($value) && trim($value) !== '') {
            $ts = strtotime($value);
            if ($ts) {
                return $ts;
            }
        }
        return time();
    }

    public function get_user($username)
    {
        return $this->request('GET', '/api/user/by-username/' . rawurlencode($username));
    }

    public function get_user_by_id($user_id)
    {
        $user_id = trim((string) $user_id);
        if ($user_id === '') {
            return new WP_Error('missing_pg_user_id', 'آیدی کاربر پاسارگارد مشخص نیست.');
        }
        $encoded = rawurlencode($user_id);
        $attempts = array(
            '/api/user/by-id/' . $encoded,
            '/api/user/' . $encoded,
        );
        $last_error = null;
        foreach ($attempts as $path) {
            $res = $this->request('GET', $path);
            if (!is_wp_error($res)) {
                return $res;
            }
            $last_error = $res;
        }
        return $last_error ? $last_error : new WP_Error('pg_user_not_found', 'کاربر پاسارگارد پیدا نشد.');
    }

    public function user_snapshot($username = '', $user_id = '', $order = null)
    {
        if (IPSVP_Sanaei_API::is_order($order)) { return (new IPSVP_Sanaei_API())->user_snapshot($order); }
        $username = trim((string) $username);
        $user_id = trim((string) $user_id);
        $live = array();
        $error = '';

        if ($username !== '' && !preg_match('#^(vless|vmess|trojan|ss|hysteria2)://#i', $username)) {
            $fresh = $this->get_user($username);
            if (!is_wp_error($fresh) && is_array($fresh)) {
                $live = $fresh;
            } elseif (is_wp_error($fresh)) {
                $error = $fresh->get_error_message();
            }
        }

        if (!$live && $user_id !== '') {
            $fresh = $this->get_user_by_id($user_id);
            if (!is_wp_error($fresh) && is_array($fresh)) {
                $live = $fresh;
            } elseif (is_wp_error($fresh)) {
                $error = $fresh->get_error_message();
            }
        }

        $resolved_user_id = $user_id;
        if ($live) {
            $found_user_id = $this->extract_numeric_user_id($live);
            if ($found_user_id) {
                $resolved_user_id = $found_user_id;
            }
        }

        $sub_url = $live ? $this->extract_subscription_url($live) : '';
        $links = $live ? $this->extract_config_links($live) : array();
        $subscription_content = '';
        $subscription_type = '';
        $subscription_error = '';

        if ($resolved_user_id !== '' && ctype_digit((string) $resolved_user_id)) {
            $subscription_package = $this->get_user_subscription_package($resolved_user_id);
            if (!empty($subscription_package['content'])) {
                $subscription_content = $subscription_package['content'];
                $subscription_type = isset($subscription_package['type']) ? (string) $subscription_package['type'] : '';
            }
            if (!empty($subscription_package['links'])) {
                $links = array_values(array_unique(array_merge($links, $subscription_package['links'])));
            }
            if (!empty($subscription_package['error'])) {
                $subscription_error = (string) $subscription_package['error'];
            }
        }

        return array(
            'live' => $live,
            'error' => $error,
            'username' => $live ? $this->pick_first($live, array('username')) : $username,
            'user_id' => $resolved_user_id,
            'status' => $live ? $this->pick_first($live, array('status')) : '',
            'used' => $live ? $this->pick_first($live, array('used_traffic', 'used', 'data_usage', 'used_data', 'used_bytes')) : '',
            'limit' => $live ? $this->pick_first($live, array('data_limit', 'total', 'total_traffic', 'limit', 'total_bytes')) : '',
            'expire' => $live ? $this->pick_first($live, array('expire', 'expired_at', 'expiry_time', 'expire_at')) : '',
            'group_ids' => $live ? $this->extract_group_ids_from_user($live) : array(),
            'subscription_url' => $sub_url,
            'links' => $links,
            'subscription_content' => $subscription_content,
            'subscription_type' => $subscription_type,
            'subscription_error' => $subscription_error,
        );
    }

    public function update_user_status_for_order($order, $local_status)
    {
        if (IPSVP_Sanaei_API::is_order($order)) { return (new IPSVP_Sanaei_API())->update_user_status_for_order($order, $local_status); }
        if (!$order || (empty($order->pg_username) && empty($order->pg_user_id))) {
            return new WP_Error('missing_pg_user', 'یوزر پاسارگارد برای این سفارش مشخص نشده است.');
        }
        $snapshot = $this->user_snapshot($order->pg_username ?? '', $order->pg_user_id ?? '');
        if (empty($snapshot['live']) || empty($snapshot['user_id'])) {
            return new WP_Error('pg_user_not_found', !empty($snapshot['error']) ? (string) $snapshot['error'] : 'یوزر موردنظر در پاسارگارد پیدا نشد.');
        }
        $map = array(
            'created' => 'active',
            'active' => 'active',
            'on_hold' => 'on_hold',
            'disabled' => 'disabled',
            'volume_finished' => 'limited',
            'time_finished' => 'expired',
            'cancelled' => 'disabled',
        );
        $local_status = sanitize_key((string) $local_status);
        if (!isset($map[$local_status])) {
            return new WP_Error('unsupported_pg_status', 'این وضعیت قابل ارسال به پاسارگارد نیست.');
        }
        $updated = $this->update_user_payload_patch_first((string) $snapshot['user_id'], array('status' => $map[$local_status]));
        if (is_wp_error($updated)) {
            return $updated;
        }
        return array(
            'user_id' => (string) $snapshot['user_id'],
            'username' => (string) ($snapshot['username'] ?? ($order->pg_username ?? '')),
            'local_status' => $local_status,
            'pg_status' => $map[$local_status],
            'raw' => $updated,
        );
    }

    public function get_subscription_content($user_id, $client_type)
    {
        $client_type = $this->normalize_client_type($client_type);
        return $this->request('GET', '/api/user/' . rawurlencode($user_id) . '/subscription/' . rawurlencode($client_type), null, true);
    }

    public function preferred_client_type()
    {
        $settings = $this->settings();
        return $this->normalize_client_type(isset($settings['client_type']) ? $settings['client_type'] : 'links');
    }

    private function normalize_client_type($client_type)
    {
        $client_type = strtolower(trim((string) $client_type));
        $client_type = str_replace('-', '_', $client_type);
        $aliases = array(
            'v2ray' => 'links',
            'v2rayng' => 'links',
            'vless' => 'links',
            'vmess' => 'links',
            'link' => 'links',
            'sub' => 'links',
            'subscription' => 'links',
        );
        if (isset($aliases[$client_type])) {
            return $aliases[$client_type];
        }
        $allowed = array('links', 'links_base64', 'xray', 'wireguard', 'sing_box', 'clash', 'clash_meta', 'outline');
        return in_array($client_type, $allowed, true) ? $client_type : 'links';
    }

    public function get_user_subscription_package($user_id)
    {
        $user_id = trim((string) $user_id);
        if ($user_id === '' || !ctype_digit($user_id)) {
            return array('links' => array(), 'content' => '', 'type' => '', 'error' => '');
        }

        $types = array_values(array_unique(array($this->preferred_client_type(), 'links')));
        $last_error = '';
        foreach ($types as $type) {
            $content = $this->get_subscription_content($user_id, $type);
            if (is_wp_error($content)) {
                $last_error = $content->get_error_message();
                continue;
            }
            if (is_string($content) && trim($content) !== '') {
                return array(
                    'links' => $this->extract_config_links($content),
                    'content' => $content,
                    'type' => $type,
                    'error' => '',
                );
            }
        }

        return array('links' => array(), 'content' => '', 'type' => '', 'error' => $last_error);
    }

    private function safe_username($order)
    {
        $group_suffix = !empty($order->pg_group_id) ? '_' . substr(md5((string) $order->pg_group_id), 0, 4) : '';
        if (!empty($order->pg_group_ids) && is_array($order->pg_group_ids)) {
            $group_suffix = '_all';
        }
        $base = 'ips' . (int) $order->id . $group_suffix . '_' . substr(md5($order->phone . $order->order_code), 0, 6);
        $base = strtolower(preg_replace('/[^a-z0-9_]/', '', $base));
        return substr($base, 0, 32);
    }

    private function order_group_ids($order)
    {
        $ids = array();
        if (!empty($order->pg_group_ids) && is_array($order->pg_group_ids)) {
            $ids = $order->pg_group_ids;
        } elseif (!empty($order->pg_group_ids) && is_string($order->pg_group_ids)) {
            $decoded = json_decode($order->pg_group_ids, true);
            $ids = is_array($decoded) ? $decoded : preg_split('/[,|]+/', $order->pg_group_ids);
        } elseif (!empty($order->pg_group_id)) {
            $ids = array($order->pg_group_id);
        }

        if (empty($ids) && !empty($order->pg_response)) {
            $raw = is_array($order->pg_response) ? $order->pg_response : json_decode((string) $order->pg_response, true);
            if (is_array($raw)) {
                if (!empty($raw['_all_countries']['group_ids']) && is_array($raw['_all_countries']['group_ids'])) {
                    $ids = $raw['_all_countries']['group_ids'];
                } elseif (!empty($raw['raw']['_all_countries']['group_ids']) && is_array($raw['raw']['_all_countries']['group_ids'])) {
                    $ids = $raw['raw']['_all_countries']['group_ids'];
                }
            }
        }

        $clean = array();
        foreach ($ids as $id) {
            $id = (int) $id;
            if ($id > 0) {
                $clean[] = $id;
            }
        }
        return array_values(array_unique($clean));
    }

    public function extract_numeric_user_id($data)
    {
        if (!is_array($data)) {
            return '';
        }
        $candidates = array();
        foreach (array('id', 'user_id') as $key) {
            if (isset($data[$key]) && is_numeric($data[$key])) {
                return (string) (int) $data[$key];
            }
        }
        foreach (array('data', 'user', 'result', 'item') as $wrapper) {
            if (isset($data[$wrapper]) && is_array($data[$wrapper])) {
                foreach (array('id', 'user_id') as $key) {
                    if (isset($data[$wrapper][$key]) && is_numeric($data[$wrapper][$key])) {
                        return (string) (int) $data[$wrapper][$key];
                    }
                }
            }
        }
        $this->collect_numeric_ids($data, $candidates);
        return $candidates ? (string) (int) $candidates[0] : '';
    }

    private function collect_numeric_ids($data, &$candidates)
    {
        if (!is_array($data)) {
            return;
        }
        foreach ($data as $key => $value) {
            if (($key === 'id' || $key === 'user_id') && is_numeric($value)) {
                $candidates[] = (int) $value;
                continue;
            }
            if (is_array($value)) {
                $this->collect_numeric_ids($value, $candidates);
            }
        }
    }

    public function extract_subscription_url($data)
    {
        if (!is_array($data)) {
            return '';
        }
        $keys = array('subscription_url', 'sub_url', 'subscription_link', 'sub_link', 'user_subscription_url', 'subscription');
        foreach ($keys as $key) {
            $value = $this->find_key_recursive($data, $key);
            if (is_string($value)) {
                $url = $this->normalize_subscription_url($value);
                if ($url) {
                    return $url;
                }
            }
        }
        return $this->find_subscription_url_in_strings($data);
    }

    private function normalize_subscription_url($value)
    {
        $value = trim((string) $value);
        if ($value === '' || preg_match('/\s/', $value)) {
            return '';
        }

        if (preg_match('#^https?://#i', $value)) {
            return esc_url_raw($value);
        }

        $base = $this->base_url();
        if (!$base) {
            return '';
        }

        if (strpos($value, '//') === 0) {
            $scheme = preg_match('#^http:#i', $base) ? 'http:' : 'https:';
            return esc_url_raw($scheme . $value);
        }

        if (preg_match('#^/(sub|subscription)/[^/\s]+#i', $value)) {
            return esc_url_raw($base . $value);
        }

        if (preg_match('#^(sub|subscription)/[^/\s]+#i', $value)) {
            return esc_url_raw($base . '/' . ltrim($value, '/'));
        }

        return '';
    }

    private function find_subscription_url_in_strings($data)
    {
        if (is_array($data)) {
            foreach ($data as $value) {
                $found = $this->find_subscription_url_in_strings($value);
                if ($found) {
                    return $found;
                }
            }
        } elseif (is_string($data)) {
            $parts = preg_split('/\s+/', $data);
            foreach ($parts as $part) {
                $url = $this->normalize_subscription_url(trim($part));
                if ($url) {
                    return $url;
                }
            }
        }
        return '';
    }

    public function extract_config_links($data)
    {
        $links = array();
        $this->walk_links($data, $links);
        return array_values(array_unique($links));
    }

    private function walk_links($data, &$links)
    {
        if (is_array($data)) {
            foreach ($data as $value) {
                $this->walk_links($value, $links);
            }
        } elseif (is_string($data)) {
            $parts = preg_split('/\s+/', $data);
            foreach ($parts as $part) {
                $part = trim($part);
                if (preg_match('#^(vless|vmess|trojan|ss|hysteria2)://#i', $part)) {
                    $links[] = $part;
                }
            }
        }
    }

    private function find_key_recursive($array, $needle)
    {
        foreach ($array as $key => $value) {
            if ($key === $needle) {
                return $value;
            }
            if (is_array($value)) {
                $found = $this->find_key_recursive($value, $needle);
                if ($found !== null && $found !== '') {
                    return $found;
                }
            }
        }
        return null;
    }

    private function pick_first($array, $keys)
    {
        foreach ($keys as $key) {
            $value = $this->find_key_recursive($array, $key);
            if ($value !== null && $value !== '') {
                return (string) $value;
            }
        }
        return '';
    }

    private function pick_first_with_key($array, $keys)
    {
        foreach ($keys as $key) {
            $value = $this->find_key_recursive($array, $key);
            if ($value !== null && $value !== '') {
                return array('key' => (string) $key, 'value' => (string) $value);
            }
        }
        return array('key' => '', 'value' => '');
    }
}

<?php
/**
 * Plugin settings repository.
 *
 * @package IPSabet_PasarGuard_Shop
 */

defined('ABSPATH') || exit;

final class IPSVP_Settings
{
    public static function get()
    {
        $defaults = array(
            'brand_name' => 'آی پی ثابت من',
            'panel_url' => '',
            'panel_username' => '',
            'panel_password' => '',
            'sanaei_panel_url' => '',
            'sanaei_token' => '',
            'sanaei_username' => '',
            'sanaei_password' => '',
            'sanaei_ssl_verify' => '1',
            'bank_card' => '',
            'bank_account_name' => '',
            'bank_iban' => '',
            'bank_note' => '',
            'announcement_text' => '',
            'client_type' => 'links',
            'ssl_verify' => '1',
            'order_prefix' => 'IPS',
            'telegram_admin' => '',
            'whatsapp_admin' => '',
            'buy_url' => 'https://ip-sabet.me/buy',
            'dashboard_url' => 'https://ip-sabet.me/dashboard',
            'telegram_bot_token' => '',
            'telegram_chat_id' => '',
            'telegram_notifications' => '0',
            'telegram_webhook_secret' => '',
            'telegram_webhook_mode' => 'existing',
            'telegram_existing_webhook_url' => 'https://bot.ipsabet.app/api/telegram-webhook',
            'bot_api_url' => 'https://bot.ipsabet.app',
            'wp_sync_secret' => '',
            'otp_login_enabled' => '0',
            'smsir_api_key' => '',
            'smsir_template_id' => '',
            'smsir_code_param' => 'Code',
            'otp_code_length' => '6',
            'otp_expire_minutes' => '5',
            'otp_resend_seconds' => '60',
            'captcha_enabled' => '1',
            'captcha_length' => '4',
            'captcha_ttl_minutes' => '10',
            'captcha_show_panel' => '1',
            'captcha_show_config' => '1',
            'captcha_show_proxy' => '1',
            'captcha_show_otp' => '1',
            'captcha_max_attempts' => '3',
            'captcha_color_mode' => 'auto',
            'all_countries_enabled' => '1',
            'shared_sales_enabled' => '1',
            'dedicated_sales_enabled' => '1',
            'all_countries_price_percent' => '30',
            'all_countries_group_id' => '',
            'all_countries_group_name' => '',
            'extra_volume_price_per_gb' => '10000',
            'dedicated_extra_volume_price_per_gb' => '10000',
            'service_warnings_enabled' => '1',
            'warning_expiry_enabled' => '1',
            'warning_expiry_days' => '1',
            'warning_expiry_title' => 'تمدید سرویس نزدیک است',
            'warning_expiry_message' => 'اعتبار سرویس شما رو به پایان است. برای جلوگیری از قطع سرویس، تمدید را انجام دهید.',
            'warning_expiry_button' => 'تمدید سرویس',
            'warning_traffic_enabled' => '1',
            'warning_traffic_gb' => '1',
            'warning_traffic_title' => 'حجم سرویس رو به پایان است',
            'warning_traffic_message' => 'حجم باقی‌مانده سرویس شما کم است. برای ادامه استفاده، حجم اضافه تهیه کنید.',
            'warning_traffic_button' => 'خرید حجم اضافه',
            'warning_popup_repeat_mode' => 'daily',
            'warning_once_after_login' => '0',
            'warning_combine_enabled' => '1',
            'payment_card_enabled' => '1',
            'payment_wallet_enabled' => '1',
            'payment_crypto_enabled' => '0',
            'ramzino_secret' => '',
            'ramzino_to_currency' => 'IRT',
            'ramzino_lifetime' => '20',
            'ramzino_status_callback_url' => '',
            'ramzino_success_callback_url' => '',
            'ramzino_fail_callback_url' => '',
        );
        $settings = get_option(IPSabet_PasarGuard_Shop::OPTION_KEY, array());
        $settings = wp_parse_args(is_array($settings) ? $settings : array(), $defaults);
        $changed = false;
        if (empty($settings['telegram_webhook_secret'])) {
            $settings['telegram_webhook_secret'] = wp_generate_password(24, false, false);
            $changed = true;
        }
        if (empty($settings['bot_api_url'])) {
            $settings['bot_api_url'] = 'https://bot.ipsabet.app';
            $changed = true;
        }
        if (empty($settings['wp_sync_secret'])) {
            $settings['wp_sync_secret'] = wp_generate_password(48, false, false);
            $changed = true;
        }
        if ($changed) {
            update_option(IPSabet_PasarGuard_Shop::OPTION_KEY, $settings, false);
        }
        // Keep every existing consumer in sync with the standalone payment
        // manager without forcing product modules to know where settings live.
        if (class_exists('IPSPM_Payment_Manager')) {
            $settings = array_merge($settings, IPSPM_Payment_Manager::legacy_settings());
        }
        return $settings;
    }

    public static function update($settings)
    {
        if (class_exists('IPSPM_Payment_Manager')) {
            $stored = get_option(IPSabet_PasarGuard_Shop::OPTION_KEY, array());
            $stored = is_array($stored) ? $stored : array();
            foreach (array_keys(IPSPM_Payment_Manager::legacy_settings()) as $key) {
                if (array_key_exists($key, $stored)) {
                    $settings[$key] = $stored[$key];
                } else {
                    unset($settings[$key]);
                }
            }
        }
        update_option(IPSabet_PasarGuard_Shop::OPTION_KEY, $settings, false);
    }
}

<?php
defined('ABSPATH') || exit;

final class IPSVP_Reseller_Docs
{
    public static function shortcode()
    {
        $base = untrailingslashit(rest_url(IPSVP_Reseller_API::NS));
        static $instance = 0;
        $uid = 'ipsr-docs-' . ++$instance;
        $endpoints = IPSVP_Reseller_API::endpoints();
        $sections = array('start' => 'شروع سریع', 'auth' => 'احراز هویت', 'pricing' => 'قیمت و تخفیف', 'idempotency' => 'جلوگیری از کسر تکراری', 'endpoints' => 'فهرست مسیرها', 'examples' => 'نمونه خرید و پیگیری', 'responses' => 'پاسخ‌ها و وضعیت‌ها', 'errors' => 'خطاها و محدودیت‌ها');
        ob_start();
        include __DIR__ . '/../templates/reseller-docs.php';
        return ob_get_clean();
    }

    private static function endpoint_id($endpoint)
    {
        return strtolower($endpoint[0]) . '-' . trim(preg_replace('/[^a-zA-Z0-9]+/', '-', $endpoint[1]), '-');
    }

    private static function code_block($code, $label)
    {
        ?><div class="ipsr-code"><div class="ipsr-code-bar"><span><?php echo esc_html($label); ?></span><button type="button" class="ipsr-copy" data-ipsr-copy hidden>کپی کد</button></div><pre><code><?php echo esc_html($code); ?></code></pre></div><?php
    }

    private static function curl_example($base, $endpoint)
    {
        // Use shell quoting as well as HTML escaping: REST URLs may contain query strings.
        $quote = static function ($value) { return "'" . str_replace("'", "'\\''", $value) . "'"; };
        $url = str_replace('{id}', '105', $base . $endpoint[1]);
        if ($endpoint[1] === '/operations/{id}') { $url = str_replace('/operations/105', '/operations/42', $url); }
        $lines = array('curl -X ' . $endpoint[0] . ' ' . $quote($url), '  -H "Authorization: Bearer YOUR_API_KEY"');
        if ($endpoint[0] === 'POST') { $lines[] = '  -H "Content-Type: application/json"'; }
        if (($endpoint[0] === 'POST' && $endpoint[1] !== '/quote') || $endpoint[1] === '/operations/lookup') {
            $lines[] = '  -H "Idempotency-Key: 4f2e5b76-4c13-4be1-9a73-71497c8c41c9"';
        }
        if ($endpoint[0] === 'POST') {
            $body = $endpoint[1] === '/quote' ? array('action' => 'purchase', 'plan_id' => 1, 'country_id' => 1) : (object) $endpoint[3];
            $lines[] = '  --data ' . $quote(wp_json_encode($body, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
        }
        return implode(' ' . chr(92) . PHP_EOL, $lines);
    }

    private static function body_schema($path)
    {
        $id = array('type' => 'integer', 'minimum' => 1, 'maximum' => 1000000000);
        $fields = array(
            'action' => array('type' => 'string', 'enum' => array('purchase', 'renew', 'extra-volume', 'disable', 'enable'), 'description' => 'نوع عملیات برای استعلام.'),
            'order_id' => $id + array('description' => 'شناسه سفارش متعلق به خودتان؛ برای استعلام تمدید، حجم یا وضعیت لازم است.'),
            'plan_id' => $id + array('description' => 'شناسه پلن فعال اشتراکی از GET /plans؛ برای خرید و تمدید الزامی.'),
            'country_id' => array('type' => 'integer', 'minimum' => 0, 'maximum' => 1000000000, 'description' => 'شناسه کشور از GET /countries؛ صفر یعنی همه کشورها. فقط خرید.'),
            'gb' => array('type' => 'integer', 'minimum' => 1, 'maximum' => 10000, 'description' => 'حجم اضافه به گیگابایت؛ عدد صحیح ۱ تا ۱۰۰۰۰.'),
            'customer_reference' => array('type' => 'string', 'maxLength' => 100, 'description' => 'شناسه داخلی مشتری شما، حداکثر ۱۰۰ بایت؛ صرفاً برچسب است و مالکیت سفارش را تغییر نمی‌دهد.'),
            'max_amount' => array('type' => 'integer', 'minimum' => 0, 'maximum' => 100000000000, 'description' => 'سقف مجاز کسر به تومان؛ اگر مبلغ نهایی بیشتر باشد، عملیات انجام نمی‌شود.'),
        );
        if ($path === '/quote') { $keys = array('action', 'order_id', 'plan_id', 'country_id', 'gb'); $required = array('action'); }
        elseif ($path === '/orders') { $keys = array('plan_id', 'country_id', 'customer_reference', 'max_amount'); $required = array('plan_id', 'country_id'); }
        elseif (substr($path, -6) === '/renew') { $keys = array('plan_id', 'customer_reference', 'max_amount'); $required = array('plan_id'); }
        elseif (substr($path, -13) === '/extra-volume') { $keys = array('gb', 'customer_reference', 'max_amount'); $required = array('gb'); }
        else { $keys = array('customer_reference', 'max_amount'); $required = array(); }
        $properties = array_intersect_key($fields, array_flip($keys));
        $out = array('type' => 'object', 'properties' => $properties, 'additionalProperties' => false);
        if ($required) { $out['required'] = $required; }
        return $out;
    }

    public static function openapi()
    {
        $paths = array();
        foreach (IPSVP_Reseller_API::endpoints() as $e) {
            $parameters = array();
            if (strpos($e[1], '{id}') !== false) { $parameters[] = array('in' => 'path', 'name' => 'id', 'required' => true, 'schema' => array('type' => 'integer', 'minimum' => 1)); }
            if (($e[0] === 'POST' && $e[1] !== '/quote') || $e[1] === '/operations/lookup') {
                $parameters[] = array('in' => 'header', 'name' => 'Idempotency-Key', 'required' => true, 'schema' => array('type' => 'string', 'pattern' => '^[A-Za-z0-9._:-]{16,100}$'));
            }
            if ($e[0] === 'GET' && in_array($e[1], array('/orders', '/operations'), true)) {
                foreach (array('page' => array(1, 1000000), 'per_page' => array(20, 50)) as $key => $range) {
                    $parameters[] = array('in' => 'query', 'name' => $key, 'schema' => array('type' => 'integer', 'minimum' => 1, 'maximum' => $range[1], 'default' => $range[0]));
                }
            }
            $op = array('summary' => $e[2], 'security' => array(array('bearerAuth' => array())), 'parameters' => $parameters,
                'responses' => array('200' => array('description' => 'Success; all amounts are integer IRT (toman).', 'content' => array('application/json' => array('schema' => self::response_schema($e[0], $e[1])))),
                    'default' => array('description' => 'WordPress REST error; 400/401/402/403/404/409/413/415/429/503.', 'content' => array('application/json' => array('schema' => array('$ref' => '#/components/schemas/Error'))))));
            if ($e[0] === 'POST') {
                $op['requestBody'] = array('required' => true, 'content' => array('application/json' => array('schema' => self::body_schema($e[1]), 'example' => $e[1] === '/quote' ? array('action' => 'purchase', 'plan_id' => 1, 'country_id' => 1) : (object) $e[3])));
            }
            if (($e[0] === 'POST' && $e[1] !== '/quote') || strpos($e[1], '/operations/') === 0) {
                $op['responses']['202'] = array('description' => 'Not final: reserved, processing, manual_review or refund_review. Poll the operation; do not generate a new key.', 'content' => array('application/json' => array('schema' => self::response_schema($e[0], $e[1]))));
            }
            $paths[$e[1]][strtolower($e[0])] = $op;
        }
        return array('openapi' => '3.0.3', 'info' => array('title' => 'IP Sabet Reseller API', 'version' => '1.0.0',
            'description' => 'Shared configurations only. IRT=toman. HTTPS Bearer authentication. 60 requests/minute/account. Persist Idempotency-Key before every mutation; reuse after timeouts. Quotes do not reserve prices. Key expiry timestamps are UTC; operation timestamps use the site timezone.'),
            'servers' => array(array('url' => untrailingslashit(rest_url(IPSVP_Reseller_API::NS)))), 'paths' => $paths,
            'components' => array('securitySchemes' => array('bearerAuth' => array('type' => 'http', 'scheme' => 'bearer', 'bearerFormat' => 'ipsr_<64 hex characters>')), 'schemas' => self::schemas()));
    }

    private static function response_schema($method, $path)
    {
        if (($method === 'POST' && $path !== '/quote') || strpos($path, '/operations/') === 0) { $ref = 'OperationResult'; }
        elseif ($path === '/orders' || $path === '/operations') { $ref = $path === '/orders' ? 'OrderPage' : 'OperationPage'; }
        elseif (strpos($path, '/orders/') === 0) { $ref = 'Order'; }
        else { $ref = array('/account' => 'Account', '/wallet' => 'Wallet', '/plans' => 'Plan', '/countries' => 'Country', '/quote' => 'Quote')[$path]; }
        $data = array('$ref' => '#/components/schemas/' . $ref);
        if (in_array($path, array('/plans', '/countries'), true)) { $data = array('type' => 'array', 'items' => $data); }
        return array('type' => 'object', 'required' => array('data'), 'properties' => array('data' => $data));
    }

    private static function schemas()
    {
        $int = array('type' => 'integer'); $str = array('type' => 'string'); $number = array('type' => 'number');
        $currency = array('type' => 'string', 'enum' => array('IRT'));
        $quote = array('base_amount' => $int, 'discount_percent' => $number, 'amount' => $int, 'currency' => $currency);
        $operation = array('id' => $int, 'action' => $str, 'state' => array('type' => 'string', 'enum' => array('reserved', 'processing', 'manual_review', 'refund_review', 'succeeded', 'failed', 'refunded')), 'order_id' => $int) + $quote + array('customer_reference' => $str, 'error_code' => array('type' => 'string', 'nullable' => true), 'created_at' => $str, 'updated_at' => $str);
        $order = array('id' => $int, 'code' => $str, 'plan_id' => $int, 'country_id' => $int, 'status' => $str, 'amount' => $int, 'currency' => $currency,
            'subscription_url' => array('type' => 'string', 'nullable' => true), 'links' => array('type' => 'array', 'items' => $str), 'created_at' => $str, 'live_available' => array('type' => 'boolean'),
            'usage' => array('type' => 'object', 'description' => 'status; used/limit in bytes; expire as Unix seconds or provider ISO date.', 'properties' => array('status' => $str, 'used' => array('oneOf' => array($number, $str), 'nullable' => true), 'limit' => array('oneOf' => array($number, $str), 'nullable' => true), 'expire' => array('oneOf' => array($number, $str), 'nullable' => true))));
        $defs = array('Operation' => $operation, 'Order' => $order,
            'OperationResult' => array('operation' => array('$ref' => '#/components/schemas/Operation'), 'order' => array('$ref' => '#/components/schemas/Order')),
            'Quote' => $quote + array('request' => array('type' => 'object')),
            'Wallet' => array('balance' => $int, 'currency' => $currency),
            'Account' => array('user_id' => $int, 'status' => $str, 'discount_percent' => $number, 'discount_source' => array('type' => 'string', 'enum' => array('automatic','manual')), 'discount_expires_at' => array('type' => 'string', 'format' => 'date-time', 'nullable' => true), 'stars' => array('type' => 'integer', 'minimum' => 1, 'maximum' => 4), 'business_name' => $str, 'key_expires_at' => $str, 'currency' => $currency, 'rate_limit_per_minute' => $int),
            'Plan' => array('id' => $int, 'title' => $str, 'gb' => $int, 'days' => $int, 'base_amount' => $int, 'amount' => $int, 'all_countries_amount' => array('type' => 'integer', 'nullable' => true), 'currency' => $currency, 'sales_enabled' => array('type' => 'boolean')),
            'Country' => array('id' => $int, 'name' => $str, 'flag' => $str),
            'Error' => array('code' => $str, 'message' => $str, 'data' => array('type' => 'object', 'properties' => array('status' => $int))));
        foreach (array('Order', 'Operation') as $name) { $defs[$name . 'Page'] = array('items' => array('type' => 'array', 'items' => array('$ref' => '#/components/schemas/' . $name)), 'page' => $int, 'per_page' => $int, 'total' => $int, 'total_pages' => $int); }
        foreach ($defs as $key => $props) { $defs[$key] = array('type' => 'object', 'properties' => $props); }
        return $defs;
    }
}

<?php
/**
 * Receipt approval and rejection workflow.
 *
 * @package IPSabet_PasarGuard_Shop
 */

defined('ABSPATH') || exit;

final class IPSVP_Receipt_Manager
{
    private static function bot_order_detail_array($order)
    {
        $order = is_array($order) ? $order : array();
        $detail = isset($order['detail']) ? $order['detail'] : array();
        if (is_string($detail)) {
            $decoded = json_decode($detail, true);
            $detail = is_array($decoded) ? $decoded : array('raw' => $detail);
        }
        if (!is_array($detail)) {
            $detail = array();
        }
        if (empty($detail['code']) && !empty($order['remark'])) {
            $detail['code'] = $order['remark'];
        }
        if (empty($detail['pg_user_id']) && !empty($order['uid'])) {
            $detail['pg_user_id'] = $order['uid'];
        }
        if (empty($detail['subscription_url']) && !empty($order['sub_id'])) {
            $detail['subscription_url'] = $order['sub_id'];
        }
        if (empty($detail['pg_status']) && isset($order['status'])) {
            $detail['pg_status'] = $order['status'];
        }
        return $detail;
    }

    private static function bot_order_group_ids($detail)
    {
        $ids = array();
        if (!empty($detail['pg_group_ids']) && is_array($detail['pg_group_ids'])) {
            $ids = $detail['pg_group_ids'];
        } elseif (!empty($detail['pg_group_ids']) && is_string($detail['pg_group_ids'])) {
            $decoded = json_decode($detail['pg_group_ids'], true);
            $ids = is_array($decoded) ? $decoded : preg_split('/[,|]+/', $detail['pg_group_ids']);
        } elseif (!empty($detail['_all_countries']['group_ids']) && is_array($detail['_all_countries']['group_ids'])) {
            $ids = $detail['_all_countries']['group_ids'];
        } elseif (!empty($detail['raw']['_all_countries']['group_ids']) && is_array($detail['raw']['_all_countries']['group_ids'])) {
            $ids = $detail['raw']['_all_countries']['group_ids'];
        } elseif (!empty($detail['pg_group_id'])) {
            $ids = array($detail['pg_group_id']);
        }

        $settings = IPSVP_Settings::get();
        $all_group_id = !empty($settings['all_countries_group_id']) ? (int) $settings['all_countries_group_id'] : 0;
        $detail_country_id = !empty($detail['country_id']) ? (int) $detail['country_id'] : 0;
        if ($all_group_id > 0 && $detail_country_id === $all_group_id) {
            $ids[] = $all_group_id;
        }

        $clean = array();
        foreach ((array) $ids as $id) {
            $id = (int) $id;
            if ($id > 0) {
                $clean[] = $id;
            }
        }
        return array_values(array_unique($clean));
    }

    private static function bot_order_to_renewable_order($bot_order, $receipt, $plan)
    {
        $bot_order = is_array($bot_order) ? $bot_order : array();
        $detail = self::bot_order_detail_array($bot_order);
        $remark = '';
        if (!empty($bot_order['remark'])) {
            $remark = (string) $bot_order['remark'];
        } elseif (!empty($detail['code']) && !preg_match('#^(vless|vmess|trojan|ss|hysteria2)://#i', (string) $detail['code'])) {
            $remark = (string) $detail['code'];
        }
        $pg_user_id = '';
        if (!empty($detail['pg_user_id'])) {
            $pg_user_id = (string) $detail['pg_user_id'];
        } elseif (!empty($bot_order['uid'])) {
            $pg_user_id = (string) $bot_order['uid'];
        }
        $gb = 0;
        if (!empty($detail['gb'])) {
            $gb = (int) $detail['gb'];
        } elseif (!empty($bot_order['plan']) && preg_match('/(\d+)\s*GB/i', (string) $bot_order['plan'], $m)) {
            $gb = (int) $m[1];
        }
        if ($gb <= 0 && $plan) {
            $gb = (int) $plan->gb;
        }
        $bot_group_ids = self::bot_order_group_ids($detail);
        $settings = IPSVP_Settings::get();
        $all_group_id = !empty($settings['all_countries_group_id']) ? (int) $settings['all_countries_group_id'] : 0;
        $detail_country_id = !empty($detail['country_id']) ? (int) $detail['country_id'] : 0;
        $is_all_countries_bot_order = ($all_group_id > 0 && (in_array($all_group_id, array_map('intval', $bot_group_ids), true) || $detail_country_id === $all_group_id || !empty($detail['is_all_countries'])));
        if ($is_all_countries_bot_order && $all_group_id > 0 && !in_array($all_group_id, array_map('intval', $bot_group_ids), true)) {
            $bot_group_ids[] = $all_group_id;
            $bot_group_ids = array_values(array_unique(array_map('intval', $bot_group_ids)));
        }
        $bot_pg_group_id = $is_all_countries_bot_order ? $all_group_id : (!empty($detail['pg_group_id']) ? (int) $detail['pg_group_id'] : 0);
        $bot_country_id = $is_all_countries_bot_order ? $all_group_id : (count($bot_group_ids) > 1 ? 0 : $detail_country_id);
        return (object) array(
            'id' => 0,
            'country_id' => $bot_country_id,
            'pg_username' => $remark,
            'pg_user_id' => $pg_user_id,
            'pg_group_id' => $bot_pg_group_id,
            'pg_group_ids' => $bot_group_ids,
            'pg_response' => wp_json_encode($detail, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'gb' => $gb,
            'order_code' => 'BOT-' . (int) ($bot_order['id'] ?? 0),
            'phone' => (string) ($receipt->phone ?? ''),
        );
    }

    private static function notify_receipt_change($db, $receipt, $state, $message, $order_id = 0)
    {
        if (!$receipt || !method_exists($db, 'create_user_notification')) {
            return;
        }
        $receipt_type = !empty($receipt->type) ? (string) $receipt->type : 'new';
        $type = $receipt_type === 'wallet' ? 'wallet' : 'order';
        $title = 'تغییر وضعیت سفارش';
        if ($receipt_type === 'wallet') {
            $title = 'تغییر وضعیت شارژ کیف پول';
        } elseif (in_array($receipt_type, array('bot_renewal','wallet_bot_renewal'), true)) {
            $title = 'تغییر وضعیت تمدید سفارش ربات';
        } elseif (in_array($receipt_type, array('renewal','wallet_renewal'), true)) {
            $title = 'تغییر وضعیت تمدید سفارش';
        } elseif (in_array($receipt_type, array('extra_volume','wallet_extra_volume'), true)) {
            $title = 'تغییر وضعیت خرید حجم اضافه';
        }
        $action_url = '';
        $settings = IPSVP_Settings::get();
        $base = !empty($settings['dashboard_url']) ? $settings['dashboard_url'] : home_url('/dashboard/');
        if ($type === 'wallet') {
            $action_url = add_query_arg(array('ipsvp_tab' => 'wallet'), $base);
        } elseif ((int) $order_id > 0) {
            $action_url = add_query_arg(array('ipsvp_tab' => 'detail', 'ipsvp_order_id' => (int) $order_id), $base);
        } else {
            $action_url = add_query_arg(array('ipsvp_tab' => 'orders'), $base);
        }
        $db->create_user_notification(
            (int) ($receipt->user_id ?? 0),
            (string) ($receipt->phone ?? ''),
            $title,
            $message,
            $type,
            (int) $order_id,
            (int) ($receipt->id ?? 0),
            $action_url
        );
    }

    private static function receipt_payload($receipt)
    {
        $payload = !empty($receipt->remote_payload) ? json_decode((string) $receipt->remote_payload, true) : array();
        return is_array($payload) ? $payload : array();
    }

    private static function update_receipt_payload($db, $receipt_id, array $payload, $status = '', $admin_note = '')
    {
        global $wpdb;
        $t = $db->tables();
        $data = array(
            'remote_payload' => wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        );
        if ($status !== '') {
            $data['status'] = $status;
            $data['reviewed_at'] = $db->now();
        }
        if ($admin_note !== '') {
            $data['admin_note'] = $admin_note;
        }
        return $wpdb->update($t['receipts'], $data, array('id' => (int) $receipt_id));
    }

    private static function approve_extra_volume($receipt, $order, $db, $api)
    {
        $receipt_id = (int) $receipt->id;
        $payload = self::receipt_payload($receipt);
        if (!empty($payload['extra_volume_applied'])) {
            $db->add_log('info', 'approve_extra_volume_duplicate', 'اعمال دوباره حجم اضافه جلوگیری شد.', array('receipt_id' => $receipt_id, 'order_id' => $order->id), $receipt->phone, $order->id, $receipt_id, $receipt->user_id);
            IPSVP_Telegram_Service::send_telegram_success_payment_report($receipt_id, $db);
            return array('ok' => true, 'type' => 'success', 'message' => 'حجم اضافه این تراکنش قبلا اعمال شده است.', 'order_id' => (int) $order->id, 'receipt_type' => (string) $receipt->type);
        }
        $gb = !empty($payload['gb']) ? (int) $payload['gb'] : 0;
        if ($gb < 1) {
            return array('ok' => false, 'type' => 'error', 'message' => 'مقدار حجم اضافه در تراکنش معتبر نیست.', 'order_id' => (int) $order->id, 'receipt_type' => (string) $receipt->type);
        }

        $old_sub = (string) ($order->pg_subscription_url ?? '');
        $old_links = array();
        if (!empty($order->pg_links)) {
            $decoded_links = json_decode((string) $order->pg_links, true);
            if (is_array($decoded_links)) {
                $old_links = array_values($decoded_links);
            }
        }

        $applied = $api->add_extra_volume_for_order($order, $gb);
        if (is_wp_error($applied)) {
            $payload['payment_status'] = 'failed';
            $payload['extra_volume_error'] = $applied->get_error_message();
            self::update_receipt_payload($db, $receipt_id, $payload, 'failed', $applied->get_error_message());
            $db->add_log('error', 'approve_extra_volume', $applied->get_error_message(), array('receipt_id' => $receipt_id, 'order_id' => $order->id, 'gb' => $gb), $receipt->phone, $order->id, $receipt_id, $receipt->user_id);
            return array('ok' => false, 'type' => 'error', 'message' => $applied->get_error_message(), 'order_id' => (int) $order->id, 'receipt_type' => (string) $receipt->type);
        }

        $payload['payment_status'] = 'approved';
        $payload['extra_volume_applied'] = 1;
        $payload['extra_volume_applied_at'] = $db->now();
        $payload['applied'] = array(
            'user_id' => (string) ($applied['user_id'] ?? ''),
            'gb' => (int) ($applied['gb'] ?? $gb),
            'added_bytes' => (int) ($applied['added_bytes'] ?? 0),
            'old_limit' => (int) ($applied['old_limit'] ?? 0),
            'new_limit' => (int) ($applied['new_limit'] ?? 0),
        );
        self::update_receipt_payload($db, $receipt_id, $payload, 'approved');

        $update = array(
            'status' => 'active',
            'payment_status' => 'approved',
            'pg_user_id' => !empty($applied['user_id']) ? (string) $applied['user_id'] : (string) $order->pg_user_id,
            'pg_status' => !empty($applied['status']) ? (string) $applied['status'] : (string) $order->pg_status,
            'updated_at' => $db->now(),
            'service_ended_at' => null,
            'cancelled_at' => null,
        );
        if (!empty($applied['raw'])) {
            $update['pg_response'] = wp_json_encode($applied['raw'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        }
        $db->update_order($order->id, $update);

        $new_sub = !empty($applied['subscription_url']) ? (string) $applied['subscription_url'] : '';
        if ($old_sub !== '' && $new_sub !== '' && $new_sub !== $old_sub) {
            $db->add_log('warning', 'extra_volume_subscription_changed', 'PasarGuard بعد از افزایش حجم لینک ساب متفاوت برگرداند؛ لینک قبلی سفارش بازنویسی نشد.', array('receipt_id' => $receipt_id, 'order_id' => $order->id, 'old_subscription_url' => $old_sub, 'new_subscription_url' => $new_sub), $receipt->phone, $order->id, $receipt_id, $receipt->user_id);
        }
        if (!empty($applied['links']) && $old_links && array_values($applied['links']) !== $old_links) {
            $db->add_log('warning', 'extra_volume_links_changed', 'PasarGuard بعد از افزایش حجم لینک کانفیگ متفاوت برگرداند؛ لینک‌های قبلی سفارش بازنویسی نشد.', array('receipt_id' => $receipt_id, 'order_id' => $order->id), $receipt->phone, $order->id, $receipt_id, $receipt->user_id);
        }

        $imported = IPSVP_Bot_API::import_site_order($db->get_order($order->id));
        if (is_wp_error($imported)) {
            $db->add_log('warning', 'bot_import_site_order_after_extra_volume', $imported->get_error_message(), array('order_id' => $order->id, 'receipt_id' => $receipt_id), $receipt->phone, $order->id, $receipt_id, $receipt->user_id);
        }
        $db->add_log('info', 'approve_extra_volume', 'حجم اضافه با موفقیت اعمال شد.', array('receipt_id' => $receipt_id, 'order_id' => $order->id, 'gb' => $gb, 'new_limit' => ($applied['new_limit'] ?? 0)), $receipt->phone, $order->id, $receipt_id, $receipt->user_id);
        self::notify_receipt_change($db, $receipt, 'approved', 'خرید حجم اضافه تایید شد و حجم به سرویس فعلی شما اضافه شد.', $order->id);
        IPSVP_Telegram_Service::send_telegram_success_payment_report($receipt_id, $db);
        return array('ok' => true, 'type' => 'success', 'message' => 'خرید حجم اضافه تایید شد و حجم سرویس افزایش یافت.', 'order_id' => (int) $order->id, 'receipt_type' => (string) $receipt->type);
    }

    public static function confirm_dedicated_payment($order, array $data, $db, $receipt_id = 0)
    {
        $receipts = $db->confirm_dedicated_order_payment((int) $order->id, $data, $receipt_id);
        if (is_wp_error($receipts)) { return $receipts; }
        foreach ($receipts as $receipt) {
            self::notify_receipt_change($db, $receipt, 'approved', 'رسید خرید سرویس اختصاصی تایید شد.', (int) $order->id);
            IPSVP_Telegram_Service::send_telegram_success_payment_report((int) $receipt->id, $db);
        }
        $first_approval = empty($order->approved_at) && !in_array((string) $order->payment_status, array('approved', 'wallet_paid', 'crypto_paid', 'paid'), true);
        if ($first_approval && (!empty($order->pg_username) || !empty($order->pg_user_id))) {
            $fresh = $db->get_order((int) $order->id);
            $imported = IPSVP_Bot_API::import_site_order($fresh);
            if (is_wp_error($imported)) { $db->add_log('warning', 'bot_import_dedicated_order', $imported->get_error_message(), array('order_id' => $order->id), $order->phone, $order->id, $receipt_id, $order->user_id); }
            do_action('ips_config_order_approved', (int) $order->id, (int) $order->user_id, $fresh);
        }
        return count($receipts);
    }

    public static function approve($receipt_id, $db, $api)
    {
        if (class_exists('IPSVP_Loyalty')) { IPSVP_Loyalty::clear_cache(); }
        global $wpdb;
        $t = $db->tables();
        $receipt = $db->get_receipt($receipt_id);
        if (!$receipt) {
            return array('ok' => false, 'type' => 'error', 'message' => 'رسید پیدا نشد.');
        }
        if (($receipt->remote_source ?? '') === 'reseller') {
            return array('ok' => false, 'type' => 'error', 'message' => 'این تراکنش در بخش نمایندگان و وب‌سرویس تعیین تکلیف می‌شود.');
        }
        $addon_result = apply_filters('ipsvp_receipt_approve_result', null, $receipt, $db, $api);
        if ($addon_result !== null) {
            return $addon_result;
        }
        $receipt_type = !empty($receipt->type) ? $receipt->type : 'new';
        if (in_array($receipt_type, array('wallet_renewal', 'wallet_bot_renewal', 'wallet_extra_volume'), true)) {
            $locked = IPSVP_Reseller_Store::lock($receipt->user_id);
            if (is_wp_error($locked)) { return array('ok' => false, 'type' => 'error', 'message' => $locked->get_error_message()); }
            $receipt = $db->get_receipt($receipt_id);
            if (!$receipt) { return array('ok' => false, 'type' => 'error', 'message' => 'رسید پیدا نشد.'); }
            if ($receipt->status === 'pending' && ($receipt->wallet_effect ?? 'local') !== 'remote' && $db->get_local_wallet_balance($receipt->user_id) < (int) $receipt->amount) {
                return array('ok' => false, 'type' => 'error', 'message' => 'موجودی کیف پول برای این عملیات کافی نیست.');
            }
        }
        if ((string) $receipt->status === 'approved') {
            return array('ok' => true, 'type' => 'success', 'message' => 'این رسید قبلاً تایید شده است.', 'order_id' => (int) $receipt->order_id, 'receipt_type' => $receipt_type);
        }
        if ((string) $receipt->status !== 'pending') {
            return array('ok' => false, 'type' => 'error', 'message' => 'فقط رسید در انتظار بررسی قابل تایید است.');
        }
        if ($receipt_type === 'wallet') {
            if ($receipt->status === 'approved') {
                IPSVP_Telegram_Service::send_telegram_success_payment_report($receipt_id, $db);
                return array('ok' => true, 'type' => 'success', 'message' => 'این رسید شارژ کیف پول قبلا تایید شده است.', 'order_id' => 0, 'receipt_type' => 'wallet');
            }
            $user = $db->get_user_by_id($receipt->user_id);
            $wallet_balance = null;
            if ($user && !empty($user->bot_tel_id)) {
                $credited = IPSVP_Bot_API::credit_wallet($user->bot_tel_id, (int) $receipt->amount, $receipt_id, $receipt->phone);
                if (is_wp_error($credited) || empty($credited['ok'])) {
                    $msg = is_wp_error($credited) ? $credited->get_error_message() : (!empty($credited['message']) ? $credited['message'] : 'خطای نامشخص در شارژ کیف پول ربات');
                    $db->add_log('error', 'approve_wallet_receipt', $msg, array('receipt_id' => $receipt_id, 'bot_response' => $credited), $receipt->phone, 0, $receipt_id, $receipt->user_id);
                    return array('ok' => false, 'type' => 'error', 'message' => 'رسید تایید نشد؛ شارژ کیف پول ربات خطا داد: ' . $msg);
                }
                $wallet_balance = isset($credited['balance']) ? $credited['balance'] : null;
            }
            $wpdb->update($t['receipts'], array(
                'status' => 'approved',
                'wallet_effect' => $user && !empty($user->bot_tel_id) ? 'remote' : 'local',
                'reviewed_at' => $db->now(),
            ), array('id' => $receipt_id));
            if ($user && empty($user->bot_tel_id)) {
                $wallet_balance = $db->get_local_wallet_balance($user->id);
            }
            self::notify_receipt_change($db, $receipt, 'approved', 'درخواست شارژ کیف پول شما تایید شد و موجودی کیف پول بروزرسانی شد.', 0);
            IPSVP_Telegram_Service::send_telegram_success_payment_report($receipt_id, $db);
            return array('ok' => true, 'type' => 'success', 'message' => $user && !empty($user->bot_tel_id) ? 'رسید تایید شد و کیف پول مشترک ربات شارژ شد.' : 'رسید تایید شد و کیف پول سایت شارژ شد.', 'order_id' => 0, 'receipt_type' => 'wallet', 'wallet_balance' => $wallet_balance);
        }

        if (in_array($receipt_type, array('bot_renewal','wallet_bot_renewal'), true)) {
            if ($receipt->status === 'approved') {
                IPSVP_Telegram_Service::send_telegram_success_payment_report($receipt_id, $db);
                return array('ok' => true, 'type' => 'success', 'message' => 'این رسید تمدید ربات قبلا تایید شده است.', 'order_id' => 0, 'receipt_type' => $receipt_type);
            }
            $user = $db->get_user_by_id($receipt->user_id);
            if (!$user || empty($user->bot_tel_id)) {
                return array('ok' => false, 'type' => 'error', 'message' => 'کاربر به ربات متصل نیست.');
            }
            $bot_order_id = !empty($receipt->remote_order_id) ? (int) $receipt->remote_order_id : 0;
            $receipt_payload = self::receipt_payload($receipt);
            $bot_order = $receipt_payload;
            if (!empty($receipt->remote_payload)) {
                $decoded = json_decode($receipt->remote_payload, true);
                if (is_array($decoded)) {
                    $bot_order = $decoded;
                }
            }
            $fresh_bot_order = IPSVP_Bot_API::find_bot_order($user->bot_tel_id, $bot_order_id);
            if (is_wp_error($fresh_bot_order)) {
                $db->add_log('warning', 'bot_renewal_fetch_order', $fresh_bot_order->get_error_message(), array('receipt_id' => $receipt_id, 'bot_order_id' => $bot_order_id), $receipt->phone, 0, $receipt_id, $receipt->user_id);
            } elseif (is_array($fresh_bot_order)) {
                $bot_order = array_merge($bot_order, $fresh_bot_order);
            }
            if (!$bot_order_id || empty($bot_order)) {
                return array('ok' => false, 'type' => 'error', 'message' => 'سفارش ربات برای تمدید پیدا نشد.');
            }
            $plan_id = !empty($receipt->plan_id) ? (int) $receipt->plan_id : 0;
            $plan = $db->get_plan($plan_id);
            if (!$plan) {
                return array('ok' => false, 'type' => 'error', 'message' => 'پلن تمدید پیدا نشد.');
            }
            $renew_order = self::bot_order_to_renewable_order($bot_order, $receipt, $plan);
            if (empty($renew_order->pg_username) && empty($renew_order->pg_user_id)) {
                return array('ok' => false, 'type' => 'error', 'message' => 'در دیتای سفارش ربات، ریمارک یا شناسه کاربر پاسارگارد برای تمدید پیدا نشد.');
            }
            $renewed = $api->extend_user_for_order($renew_order, $plan);
            if (is_wp_error($renewed)) {
                $wpdb->update($t['receipts'], array('status' => 'failed', 'reviewed_at' => $db->now(), 'admin_note' => $renewed->get_error_message()), array('id' => $receipt_id));
                $db->add_log('error', 'approve_bot_renewal', $renewed->get_error_message(), array('receipt_id' => $receipt_id, 'bot_order_id' => $bot_order_id), $receipt->phone, 0, $receipt_id, $receipt->user_id);
                return array('ok' => false, 'type' => 'error', 'message' => 'رسید دریافت شد اما تمدید سفارش ربات خطا داد: ' . $renewed->get_error_message());
            }
            $detail = self::bot_order_detail_array($bot_order);
            $detail['pg_user_id'] = !empty($renewed['user_id']) ? $renewed['user_id'] : (!empty($detail['pg_user_id']) ? $detail['pg_user_id'] : '');
            $detail['pg_status'] = !empty($renewed['status']) ? $renewed['status'] : (!empty($detail['pg_status']) ? $detail['pg_status'] : 'active');
            if (!empty($renewed['subscription_url'])) {
                $detail['subscription_url'] = $renewed['subscription_url'];
            }
            if (!empty($renewed['links'])) {
                $detail['links'] = $renewed['links'];
            }
            $detail['last_renewed_from_wordpress'] = $db->now();
            $detail['last_renewal_receipt_id'] = (int) $receipt_id;
            $detail['last_renewal_plan'] = array(
                'id' => (int) $plan->id,
                'title' => (string) $plan->title,
                'gb' => (int) $plan->gb,
                'days' => (int) $plan->days,
                'price' => (int) $receipt->amount,
            );
            $remote_update = IPSVP_Bot_API::update_bot_order($user->bot_tel_id, $bot_order_id, array(
                'status' => !empty($renewed['status']) ? $renewed['status'] : 'active',
                'uid' => !empty($renewed['user_id']) ? (string) $renewed['user_id'] : (string) ($bot_order['uid'] ?? ''),
                'sub_id' => !empty($renewed['subscription_url']) ? (string) $renewed['subscription_url'] : (string) ($bot_order['sub_id'] ?? ''),
                'expire_at' => !empty($renewed['expire_at']) ? (string) $renewed['expire_at'] : '',
                'detail' => $detail,
            ));
            if (is_wp_error($remote_update)) {
                $db->add_log('warning', 'bot_renewal_update_remote', $remote_update->get_error_message(), array('receipt_id' => $receipt_id, 'bot_order_id' => $bot_order_id), $receipt->phone, 0, $receipt_id, $receipt->user_id);
            } elseif (empty($remote_update['ok'])) {
                $db->add_log('warning', 'bot_renewal_update_remote', !empty($remote_update['message']) ? $remote_update['message'] : 'خطای نامشخص در بروزرسانی سفارش ربات', array('receipt_id' => $receipt_id, 'bot_order_id' => $bot_order_id, 'response' => $remote_update), $receipt->phone, 0, $receipt_id, $receipt->user_id);
            }
            $updated_payload = array_merge($receipt_payload, $bot_order);
            $updated_payload['detail'] = $detail;
            $wpdb->update($t['receipts'], array(
                'status' => 'approved',
                'reviewed_at' => $db->now(),
                'remote_payload' => wp_json_encode($updated_payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            ), array('id' => $receipt_id));
            self::notify_receipt_change($db, $receipt, 'approved', 'درخواست تمدید سفارش ربات شما تایید شد و کانفیگ تمدید شد.', 0);
            IPSVP_Telegram_Service::send_telegram_success_payment_report($receipt_id, $db);
            return array('ok' => true, 'type' => 'success', 'message' => 'رسید تمدید تایید شد و سفارش ربات تمدید شد.', 'pg_username' => $renew_order->pg_username, 'order_id' => 0, 'receipt_type' => $receipt_type);
        }

        $order = $db->get_order($receipt->order_id);
        if (!$order) {
            $db->add_log('error', 'approve_receipt', 'سفارش رسید پیدا نشد.', array('receipt_id' => $receipt_id), $receipt->phone, 0, $receipt_id, $receipt->user_id);
            return array('ok' => false, 'type' => 'error', 'message' => 'سفارش پیدا نشد.');
        }

        if (in_array($receipt_type, array('extra_volume','wallet_extra_volume'), true)) {
            return self::approve_extra_volume($receipt, $order, $db, $api);
        }

        if ($receipt_type === 'new' && $db->order_service_type($order) === 'dedicated') {
            $has_assigned_user = !empty($order->pg_username) || !empty($order->pg_user_id);
            $target_status = (string) $order->status === 'on_hold' ? 'on_hold' : 'active';
            if ($has_assigned_user) {
                $remote = $api->update_user_status_for_order($order, $target_status);
                if (is_wp_error($remote)) {
                    $db->add_log('error', 'approve_dedicated_activate_panel', $remote->get_error_message(), array('receipt_id' => $receipt_id, 'order_id' => $order->id), $receipt->phone, $order->id, $receipt_id, $receipt->user_id);
                    return array('ok' => false, 'type' => 'error', 'message' => 'رسید تایید نشد؛ بروزرسانی وضعیت سرویس در پنل خطا داد: ' . $remote->get_error_message());
                }
            }
            $data = array(
                'status' => $has_assigned_user ? $target_status : 'awaiting_assignment',
                'pg_status' => $has_assigned_user ? (string) $remote['pg_status'] : (string) $order->pg_status,
                'service_ended_at' => null,
                'cancelled_at' => null,
            );
            if ($has_assigned_user && IPSVP_Sanaei_API::is_order($order) && !empty($remote['raw'])) {
                $data['pg_response'] = wp_json_encode($remote['raw'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                $data['pg_synced_at'] = $db->now();
            }
            $confirmed = self::confirm_dedicated_payment($order, $data, $db, (int) $receipt_id);
            if (is_wp_error($confirmed)) { return array('ok' => false, 'type' => 'error', 'message' => $confirmed->get_error_message()); }
            delete_transient('ipsvp_traffic_sync_' . (int) $order->id);
            $message = $has_assigned_user
                ? 'رسید تایید شد و وضعیت سرویس «' . $db->status_label($target_status) . '» است.'
                : 'پرداخت سفارش تایید شد و سرویس در انتظار اتصال توسط مدیریت است.';
            return array('ok' => true, 'type' => 'success', 'message' => $message, 'order_id' => (int) $order->id, 'receipt_type' => 'new');
        }

        if ($receipt->status === 'approved' && in_array((string) $order->status, array('created','active','on_hold'), true)) {
            IPSVP_Telegram_Service::send_telegram_success_payment_report($receipt_id, $db);
            return array('ok' => true, 'type' => 'success', 'message' => 'این رسید قبلا تایید شده است.', 'pg_username' => $order->pg_username, 'order_id' => $order->id, 'receipt_type' => (!empty($receipt->type) ? $receipt->type : 'new'));
        }

        if (in_array($receipt_type, array('renewal','wallet_renewal'), true)) {
            $plan_id = !empty($receipt->plan_id) ? (int) $receipt->plan_id : (int) $receipt->order_plan_id;
            $plan = $db->get_plan($plan_id);
            if (!$plan) {
                $db->add_log('error', 'approve_renewal', 'پلن تمدید پیدا نشد.', array('receipt_id' => $receipt_id, 'plan_id' => $plan_id), $receipt->phone, ($order ? $order->id : 0), $receipt_id, $receipt->user_id);
                return array('ok' => false, 'type' => 'error', 'message' => 'پلن تمدید پیدا نشد.');
            }
            if ((int) ($order->country_id ?? -1) === 0) {
                $api->ensure_all_countries_groups_for_order($order, $db->ready_countries());
                $order = $db->get_order($order->id);
            }
            $renewed = $api->extend_user_for_order($order, $plan);
            if (is_wp_error($renewed)) {
                $wpdb->update($t['receipts'], array('status' => 'failed', 'reviewed_at' => $db->now(), 'admin_note' => $renewed->get_error_message()), array('id' => $receipt_id));
                $db->update_order($order->id, array('admin_note' => 'خطا در تمدید رسید #' . $receipt_id . ': ' . $renewed->get_error_message()));
                $db->add_log('error', 'approve_renewal', $renewed->get_error_message(), array('receipt_id' => $receipt_id, 'order_id' => $order->id), $receipt->phone, ($order ? $order->id : 0), $receipt_id, $receipt->user_id);
                return array('ok' => false, 'type' => 'error', 'message' => 'رسید دریافت شد اما تمدید خطا داد: ' . $renewed->get_error_message());
            }
            $wpdb->update($t['receipts'], array('status' => 'approved', 'reviewed_at' => $db->now()), array('id' => $receipt_id));
            $update = array(
                'status' => 'active',
                'payment_status' => 'approved',
                'pg_user_id' => !empty($renewed['user_id']) ? $renewed['user_id'] : $order->pg_user_id,
                'pg_status' => !empty($renewed['status']) ? $renewed['status'] : 'active',
                'approved_at' => $db->now(),
                'service_ended_at' => null,
                'cancelled_at' => null,
            );
            if (!empty($renewed['subscription_url'])) {
                $update['pg_subscription_url'] = $renewed['subscription_url'];
            }
            if (!empty($renewed['links'])) {
                $update['pg_links'] = wp_json_encode($renewed['links']);
            }
            if (!empty($renewed['raw'])) {
                $renewed_snapshot = !empty($renewed['raw']['after']) && is_array($renewed['raw']['after'])
                    ? $renewed['raw']['after']
                    : $renewed['raw'];
                if (!empty($renewed['expire_at'])) {
                    $renewed_snapshot['expire'] = (string) $renewed['expire_at'];
                }
                $update['pg_response'] = wp_json_encode($renewed_snapshot, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                $update['pg_synced_at'] = $db->now();
            }
            $db->update_order($order->id, $update);
            $imported_order = $db->get_order($order->id);
            $imported = IPSVP_Bot_API::import_site_order($imported_order);
            if (is_wp_error($imported)) {
                $db->add_log('warning', 'bot_import_site_order', $imported->get_error_message(), array('order_id' => $order->id), $receipt->phone, ($order ? $order->id : 0), $receipt_id, $receipt->user_id);
            }
            self::notify_receipt_change($db, $receipt, 'approved', 'درخواست تمدید سفارش شما تایید شد و کانفیگ تمدید شد.', $order->id);
            IPSVP_Telegram_Service::send_telegram_success_payment_report($receipt_id, $db);
            return array('ok' => true, 'type' => 'success', 'message' => 'رسید تمدید تایید شد و کانفیگ تمدید شد.', 'pg_username' => $order->pg_username, 'order_id' => $order->id, 'receipt_type' => $receipt_type);
        }

        if ($order->pg_username) {
            $wpdb->update($t['receipts'], array('status' => 'approved', 'reviewed_at' => $db->now()), array('id' => $receipt_id));
            $existing_status = (string) $order->pg_status === 'on_hold' ? 'on_hold' : 'active';
            $db->update_order($order->id, array('status' => $existing_status, 'payment_status' => 'approved', 'approved_at' => $db->now()));
            $imported = IPSVP_Bot_API::import_site_order($db->get_order($order->id));
            if (is_wp_error($imported)) {
                $db->add_log('warning', 'bot_import_site_order', $imported->get_error_message(), array('order_id' => $order->id), $receipt->phone, ($order ? $order->id : 0), $receipt_id, $receipt->user_id);
            }
            // Standard integration hook for add-ons. Fires only for approved service/config purchases.
            do_action('ips_config_order_approved', (int) $order->id, (int) $order->user_id, $db->get_order($order->id));
            self::notify_receipt_change($db, $receipt, 'approved', 'رسید سفارش شما تایید شد و سفارش آماده استفاده است.', $order->id);
            IPSVP_Telegram_Service::send_telegram_success_payment_report($receipt_id, $db);
            return array('ok' => true, 'type' => 'success', 'message' => 'این سفارش قبلا کانفیگ گرفته بود. رسید تایید شد.', 'pg_username' => $order->pg_username, 'order_id' => $order->id, 'receipt_type' => 'new');
        }

        $created = ((int) $order->country_id === 0) ? $api->create_users_for_all_countries_order($order, $db->ready_countries()) : $api->create_user_for_order($order);
        if (is_wp_error($created)) {
            $wpdb->update($t['receipts'], array('status' => 'approved', 'reviewed_at' => $db->now()), array('id' => $receipt_id));
            $db->update_order($order->id, array(
                'status' => 'failed',
                'payment_status' => 'approved',
                'admin_note' => $created->get_error_message(),
                'approved_at' => $db->now(),
            ));
            $db->add_log('error', 'create_config', $created->get_error_message(), array('receipt_id' => $receipt_id, 'order_id' => $order->id), $receipt->phone, ($order ? $order->id : 0), $receipt_id, $receipt->user_id);
            self::notify_receipt_change($db, $receipt, 'failed', 'پرداخت سفارش شما تایید شد اما ساخت کانفیگ با خطا مواجه شد. پشتیبانی در حال بررسی است.', $order->id);
            return array('ok' => false, 'type' => 'error', 'message' => 'پرداخت تایید شد اما ساخت کانفیگ خطا داد: ' . $created->get_error_message());
        }

        if (!empty($created['raw']['_subscription_error'])) {
            $db->add_log('warning', 'get_subscription_after_create', $created['raw']['_subscription_error'], array('order_id' => $order->id, 'pg_username' => $created['username'], 'pg_user_id' => $created['user_id']), $receipt->phone, ($order ? $order->id : 0), $receipt_id, $receipt->user_id);
        }

        $wpdb->update($t['receipts'], array('status' => 'approved', 'reviewed_at' => $db->now()), array('id' => $receipt_id));
        $db->update_order($order->id, array(
            'status' => !empty($created['status']) && (string) $created['status'] === 'active' ? 'active' : 'on_hold',
            'payment_status' => 'approved',
            'pg_username' => $created['username'],
            'pg_user_id' => $created['user_id'],
            'pg_status' => !empty($created['status']) ? $created['status'] : 'on_hold',
            'pg_subscription_url' => $created['subscription_url'],
            'pg_links' => wp_json_encode($created['links']),
            'pg_response' => wp_json_encode($created['raw']),
            'approved_at' => $db->now(),
        ));
        $imported = IPSVP_Bot_API::import_site_order($db->get_order($order->id));
        if (is_wp_error($imported)) {
            $db->add_log('warning', 'bot_import_site_order', $imported->get_error_message(), array('order_id' => $order->id), $receipt->phone, ($order ? $order->id : 0), $receipt_id, $receipt->user_id);
        }
        // Standard integration hook for add-ons. Fires only for approved service/config purchases.
        do_action('ips_config_order_approved', (int) $order->id, (int) $order->user_id, $db->get_order($order->id));
        self::notify_receipt_change($db, $receipt, 'approved', 'رسید سفارش شما تایید شد و کانفیگ ساخته شد.', $order->id);
        IPSVP_Telegram_Service::send_telegram_success_payment_report($receipt_id, $db);
        return array('ok' => true, 'type' => 'success', 'message' => 'رسید تایید شد و کانفیگ ساخته شد.', 'pg_username' => $created['username'], 'order_id' => $order->id, 'receipt_type' => 'new');
    }

    public static function reject($receipt_id, $db)
    {
        if (class_exists('IPSVP_Loyalty')) { IPSVP_Loyalty::clear_cache(); }
        global $wpdb;
        $t = $db->tables();
        $receipt = $db->get_receipt($receipt_id);
        if (!$receipt) {
            return array('ok' => false, 'type' => 'error', 'message' => 'رسید پیدا نشد.');
        }
        if ((string) $receipt->status !== 'pending') {
            return array('ok' => false, 'type' => 'error', 'message' => 'این رسید قبلاً بررسی شده است و قابل رد کردن نیست.');
        }
        if (($receipt->remote_source ?? '') === 'reseller') {
            return array('ok' => false, 'type' => 'error', 'message' => 'این تراکنش در بخش نمایندگان و وب‌سرویس تعیین تکلیف می‌شود.');
        }
        $addon_result = apply_filters('ipsvp_receipt_reject_result', null, $receipt, $db);
        if ($addon_result !== null) {
            return $addon_result;
        }
        if ($wpdb->update($t['receipts'], array('status' => 'rejected', 'reviewed_at' => $db->now()), array('id' => $receipt_id, 'status' => 'pending')) !== 1) {
            return array('ok' => false, 'type' => 'error', 'message' => 'رسید ذخیره نشد یا هم‌زمان بررسی شده است.');
        }
        if (($receipt->type ? $receipt->type : 'new') === 'new') {
            $db->update_order($receipt->order_id, array('status' => 'rejected', 'payment_status' => 'rejected'));
        }
        $notify_order_id = (($receipt->type ? $receipt->type : 'new') === 'wallet' || ($receipt->type ? $receipt->type : 'new') === 'bot_renewal' || ($receipt->type ? $receipt->type : 'new') === 'wallet_bot_renewal') ? 0 : (int) $receipt->order_id;
        $reject_type = ($receipt->type ? $receipt->type : 'new');
        if ($reject_type === 'wallet') {
            $reject_message = 'درخواست شارژ کیف پول شما رد شد.';
        } elseif (in_array($reject_type, array('extra_volume','wallet_extra_volume'), true)) {
            $reject_message = 'درخواست خرید حجم اضافه شما رد شد.';
            $payload = self::receipt_payload($receipt);
            $payload['payment_status'] = 'rejected';
            $payload['extra_volume_applied'] = !empty($payload['extra_volume_applied']) ? 1 : 0;
            self::update_receipt_payload($db, $receipt_id, $payload, 'rejected');
            $db->add_log('info', 'reject_extra_volume', 'درخواست خرید حجم اضافه رد شد و حجمی اعمال نشد.', array('receipt_id' => $receipt_id, 'order_id' => (int) $receipt->order_id), $receipt->phone, (int) $receipt->order_id, $receipt_id, $receipt->user_id);
        } else {
            $reject_message = 'رسید سفارش شما رد شد.';
        }
        self::notify_receipt_change($db, $receipt, 'rejected', $reject_message, $notify_order_id);
        return array('ok' => true, 'type' => 'success', 'message' => 'رسید رد شد.', 'order_id' => $receipt->order_id, 'receipt_type' => ($receipt->type ? $receipt->type : 'new'));
    }
}

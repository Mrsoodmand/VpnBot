<?php
/**
 * SMS.ir verification-code client.
 *
 * @package IPSabet_PasarGuard_Shop
 */

defined('ABSPATH') || exit;

final class IPSVP_SMS_IR
{
    const VERIFY_ENDPOINT = 'https://api.sms.ir/v1/send/verify';

    public static function send_verify_code($phone, $code)
    {
        $settings = IPSVP_Settings::get();
        $api_key = isset($settings['smsir_api_key']) ? trim((string) $settings['smsir_api_key']) : '';
        $template_id = isset($settings['smsir_template_id']) ? (int) $settings['smsir_template_id'] : 0;
        $param_name = !empty($settings['smsir_code_param']) ? preg_replace('/[^a-zA-Z0-9_\-]/', '', (string) $settings['smsir_code_param']) : 'Code';
        if ($param_name === '') {
            $param_name = 'Code';
        }
        $mobile = self::to_local_mobile($phone);

        if ($api_key === '' || $template_id <= 0) {
            return new WP_Error('smsir_missing_settings', 'تنظیمات پنل پیامک کامل نیست.');
        }
        if ($mobile === '') {
            return new WP_Error('smsir_bad_mobile', 'شماره موبایل برای ارسال پیامک معتبر نیست.');
        }

        $response = wp_remote_post(self::VERIFY_ENDPOINT, array(
            'timeout' => 15,
            'headers' => array(
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
                'X-API-KEY' => $api_key,
            ),
            'body' => wp_json_encode(array(
                'mobile' => $mobile,
                'templateId' => $template_id,
                'parameters' => array(
                    array(
                        'name' => $param_name,
                        'value' => (string) $code,
                    ),
                ),
            ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        ));

        if (is_wp_error($response)) {
            return new WP_Error('smsir_request_failed', 'ارسال پیامک ناموفق بود: ' . $response->get_error_message());
        }

        $http_code = (int) wp_remote_retrieve_response_code($response);
        $body_raw = (string) wp_remote_retrieve_body($response);
        $body = json_decode($body_raw, true);
        if ($http_code < 200 || $http_code >= 300) {
            $message = is_array($body) && !empty($body['message']) ? $body['message'] : ('HTTP ' . $http_code);
            return new WP_Error('smsir_http_error', 'ارسال پیامک ناموفق بود: ' . $message);
        }
        if (is_array($body) && isset($body['status']) && (int) $body['status'] !== 1) {
            $message = !empty($body['message']) ? $body['message'] : 'پاسخ پنل پیامک موفق نبود.';
            return new WP_Error('smsir_bad_status', 'ارسال پیامک ناموفق بود: ' . $message);
        }

        return true;
    }

    private static function to_local_mobile($phone)
    {
        $phone = trim((string) $phone);
        $phone = strtr($phone, array(
            '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
            '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
            '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
        ));
        $digits = preg_replace('/\D+/', '', $phone);
        if (strpos($digits, '0098') === 0) {
            $digits = '0' . substr($digits, 4);
        } elseif (strpos($digits, '98') === 0 && strlen($digits) >= 12) {
            $digits = '0' . substr($digits, 2);
        }
        if (strpos($digits, '9') === 0 && strlen($digits) === 10) {
            $digits = '0' . $digits;
        }
        return preg_match('/^09\d{9}$/', $digits) ? $digits : '';
    }
}

<?php
/**
 * Public shortcodes, forms, and account workflows.
 *
 * @package IPSabet_PasarGuard_Shop
 */

defined('ABSPATH') || exit;

final class IPSVP_Frontend
{
    private $db;
    private $api;
    private $traffic_summary_cache = array();
    private $wallet_info_cache = array();

    public function __construct($db, $api)
    {
        $this->db = $db;
        $this->api = $api;
        $this->register_shortcodes();
        add_action('init', array($this, 'register_shortcodes'), 1);
        add_filter('the_content', array($this, 'raw_shortcode_fallback'), 12);
        add_filter('widget_text', 'do_shortcode', 11);
        add_action('wp_ajax_ipsvp_panel_notifications', array($this, 'ajax_panel_notifications'));
        add_action('wp_ajax_nopriv_ipsvp_panel_notifications', array($this, 'ajax_panel_notifications'));
        add_action('wp_ajax_ipsvp_panel_login', array($this, 'ajax_panel_login'));
        add_action('wp_ajax_nopriv_ipsvp_panel_login', array($this, 'ajax_panel_login'));
        add_action('wp_ajax_ipsvp_receipt_upload', array($this, 'ajax_receipt_upload'));
        add_action('wp_ajax_nopriv_ipsvp_receipt_upload', array($this, 'ajax_receipt_upload'));
        add_action('wp_ajax_ipsvp_receipt_upload_status', array($this, 'ajax_receipt_upload_status'));
        add_action('wp_ajax_nopriv_ipsvp_receipt_upload_status', array($this, 'ajax_receipt_upload_status'));
    }

    public function ajax_receipt_upload()
    {
        if (check_ajax_referer('ipsvp_receipt_upload', 'nonce', false) === false) {
            wp_send_json_error(array('message' => 'اعتبار صفحه منقضی شده است. صفحه را تازه کنید و دوباره تلاش کنید.'), 403);
        }
        nocache_headers();
        if (function_exists('send_nosniff_header')) {
            send_nosniff_header();
        }
        // Complete the small final disk write even if a mobile connection drops after sending 100%.
        if (function_exists('ignore_user_abort')) {
            ignore_user_abort(true);
        }
        $phone = $this->get_logged_phone();
        if (!$phone) {
            wp_send_json_error(array('message' => 'نشست ورود منقضی شده است. دوباره وارد حساب کاربری شوید.'), 401);
        }
        $user = $this->db->get_user_by_phone($phone);
        if (!$user || !empty($user->is_blocked)) {
            wp_send_json_error(array('message' => 'حساب کاربری معتبر نیست یا مسدود شده است.'), 403);
        }
        $file = isset($_FILES['receipt']) ? $_FILES['receipt'] : null;
        $upload_key = isset($_POST['upload_key']) && is_string($_POST['upload_key']) ? sanitize_text_field(wp_unslash($_POST['upload_key'])) : '';
        try {
            $upload = IPSVP_Receipt_Uploader::upload($file, (int) $user->id, $phone, $upload_key);
        } catch (Throwable $error) {
            $this->db->add_log('error', 'receipt_ajax_upload', $error->getMessage(), array(
                'file_name' => isset($file['name']) && is_string($file['name']) ? sanitize_file_name($file['name']) : '',
                'file_size' => isset($file['size']) && is_scalar($file['size']) ? (int) $file['size'] : 0,
            ), $phone, 0, 0, (int) $user->id);
            wp_send_json_error(array('message' => 'سرور هنگام ثبت فایل رسید با خطا روبه‌رو شد. فایل در فرم حفظ شده است.'), 500);
        }
        if (is_wp_error($upload)) {
            $this->db->add_log('error', 'receipt_ajax_upload', $upload->get_error_message(), array(
                'error_code' => $upload->get_error_code(),
                'file_name' => isset($file['name']) && is_string($file['name']) ? sanitize_file_name($file['name']) : '',
                'file_size' => isset($file['size']) && is_scalar($file['size']) ? (int) $file['size'] : 0,
            ), $phone, 0, 0, (int) $user->id);
            wp_send_json_error(array(
                'message' => $upload->get_error_message(),
                'code' => $upload->get_error_code(),
            ), $upload->get_error_code() === 'receipt_busy' ? 409 : 400);
        }
        wp_send_json_success(array(
            'attachment_id' => (int) $upload['attachment_id'],
            'url' => esc_url_raw($upload['url']),
            'name' => !empty($upload['name'])
                ? sanitize_file_name($upload['name'])
                : sanitize_file_name(isset($file['name']) ? $file['name'] : ''),
        ));
    }

    public function ajax_receipt_upload_status()
    {
        if (check_ajax_referer('ipsvp_receipt_upload', 'nonce', false) === false) {
            wp_send_json_error(array('message' => 'اعتبار صفحه منقضی شده است. صفحه را تازه کنید و دوباره تلاش کنید.'), 403);
        }
        nocache_headers();
        if (function_exists('send_nosniff_header')) {
            send_nosniff_header();
        }
        $phone = $this->get_logged_phone();
        if (!$phone) {
            wp_send_json_error(array('message' => 'نشست ورود منقضی شده است. دوباره وارد حساب کاربری شوید.'), 401);
        }
        $user = $this->db->get_user_by_phone($phone);
        if (!$user || !empty($user->is_blocked)) {
            wp_send_json_error(array('message' => 'حساب کاربری معتبر نیست یا مسدود شده است.'), 403);
        }
        $upload_key = isset($_POST['upload_key']) && is_string($_POST['upload_key']) ? sanitize_text_field(wp_unslash($_POST['upload_key'])) : '';
        $upload = IPSVP_Receipt_Uploader::find_existing_upload((int) $user->id, $phone, $upload_key);
        if (!$upload) {
            wp_send_json_success(array('found' => false));
        }
        wp_send_json_success(array(
            'found' => true,
            'attachment_id' => (int) $upload['attachment_id'],
            'url' => esc_url_raw($upload['url']),
            'name' => !empty($upload['name']) ? sanitize_file_name($upload['name']) : '',
        ));
    }

    public function ajax_panel_notifications()
    {
        check_ajax_referer('ipsvp_panel_notifications', 'nonce');
        $phone = $this->get_logged_phone();
        if (!$phone) {
            wp_send_json_error(array('message' => 'not_logged_in'));
        }
        $items = array();
        $notifications = $this->db->get_unread_notifications($phone, 8);
        foreach ($notifications as $n) {
            $type = isset($n->type) ? (string) $n->type : 'order';
            $items[] = array(
                'id' => (int) $n->id,
                'type' => $type,
                'title' => (string) $n->title,
                'message' => (string) $n->message,
                'action_url' => (string) $n->action_url,
                'button' => $type === 'wallet' ? 'مشاهده کیف پول' : ($type === 'proxyline' ? 'مشاهده پروکسی' : 'مشاهده سفارش'),
                'created_at' => (string) $n->created_at,
                'created_at_epoch' => $n->created_at ? strtotime((string) $n->created_at) : 0,
            );
        }
        wp_send_json_success(array(
            'count' => $this->db->count_unread_notifications($phone),
            'counts' => apply_filters('ipsvp_panel_notification_counts', array(
                'orders' => $this->db->count_unread_notifications($phone, 'order'),
            ), $phone, $this->db),
            'notifications' => $items,
        ));
    }

    public function ajax_panel_login()
    {
        check_ajax_referer('ipsvp_panel_login_ajax', 'nonce');

        $method = isset($_POST['ipsvp_login_method']) ? sanitize_key(wp_unslash($_POST['ipsvp_login_method'])) : '';
        $step = in_array($method, array('otp_request', 'otp_verify', 'password'), true) ? $method : 'phone';
        $context = IPSVP_Captcha_Service::normalize_context(isset($_POST['ipsvp_captcha_context']) ? wp_unslash($_POST['ipsvp_captcha_context']) : 'panel');
        $phone = $this->db->normalize_phone(isset($_POST['ipsvp_panel_phone']) ? wp_unslash($_POST['ipsvp_panel_phone']) : '');
        if (!$phone || !$this->is_valid_iran_mobile($phone)) {
            wp_send_json_error(array('html' => $this->render_login_form('شماره موبایل نامعتبر است.', '', false, $context)));
        }
        $captcha_pass = isset($_POST['ipsvp_captcha_pass']) ? strtolower(trim((string) wp_unslash($_POST['ipsvp_captcha_pass']))) : '';
        $is_first_step = $step === 'phone' && $captcha_pass === '';
        $security = $is_first_step
            ? IPSVP_Captcha_Service::validate_request($context, 'phone', $this->otp_login_ready())
            : IPSVP_Captcha_Service::validate_pass($captcha_pass, $phone, $context);
        if (is_wp_error($security)) {
            wp_send_json_error(array('html' => $this->render_login_form($security->get_error_message(), '', false, $context)));
        }
        if ($is_first_step) {
            $captcha_pass = IPSVP_Captcha_Service::create_pass($phone, $context);
        }
        $_POST['ipsvp_captcha_pass'] = $captcha_pass;

        $existing_user = $this->db->get_user_by_phone($phone);
        if ($existing_user && !empty($existing_user->is_blocked)) {
            IPSVP_Captcha_Service::delete_pass($captcha_pass);
            wp_send_json_error(array('html' => $this->render_login_form('حساب کاربری این شماره توسط مدیریت مسدود شده است.', $phone, false, $context)));
        }

        // Extension point for add-ons that need an intermediate login/registration step.
        $addon_response = apply_filters('ipsvp_panel_login_ajax_step', null, $step, $phone, $existing_user);
        if (is_array($addon_response)) {
            if (!empty($addon_response['error'])) {
                unset($addon_response['error']);
                wp_send_json_error($addon_response);
            }
            wp_send_json_success($addon_response);
        }

        if ($step === 'phone') {
            if ($this->otp_login_ready()) {
                if ($existing_user && !empty($existing_user->password_hash)) {
                    wp_send_json_success(array('html' => $this->render_login_form('', $phone, true, $context, $captcha_pass)));
                }
                $user = $this->db->get_or_create_user($phone);
                if ($user && !empty($user->is_blocked)) {
                    IPSVP_Captcha_Service::delete_pass($captcha_pass);
                    wp_send_json_error(array('html' => $this->render_login_form('حساب کاربری این شماره توسط مدیریت مسدود شده است.', $phone, false, $context)));
                }
                $sent = $this->send_panel_otp($phone);
                if (is_wp_error($sent)) {
                    wp_send_json_error(array('html' => $this->render_login_form($sent->get_error_message(), $phone, false, $context, $captcha_pass)));
                }
                wp_send_json_success(array('html' => $this->render_otp_verify_form('کد ورود برای شما ارسال شد.', $phone, 'success', $context, $captcha_pass)));
            }

            $user = $this->db->get_or_create_user($phone);
            if ($user && !empty($user->is_blocked)) {
                IPSVP_Captcha_Service::delete_pass($captcha_pass);
                wp_send_json_error(array('html' => $this->render_login_form('حساب کاربری این شماره توسط مدیریت مسدود شده است.', $phone, false, $context)));
            }
            if ($user && !empty($user->password_hash)) {
                wp_send_json_success(array('html' => $this->render_login_form('', $phone, true, $context, $captcha_pass)));
            }
            IPSVP_Captcha_Service::delete_pass($captcha_pass);
            $this->set_login_cookie($phone);
            wp_send_json_success(array('reload' => true));
        }

        if ($step === 'password') {
            $user = $this->db->get_user_by_phone($phone);
            if (!$user || empty($user->password_hash)) {
                wp_send_json_error(array('html' => $this->render_login_form('برای این شماره رمز عبور تعریف نشده است.', $phone, false, $context, $captcha_pass)));
            }
            $password = isset($_POST['ipsvp_password']) ? (string) wp_unslash($_POST['ipsvp_password']) : '';
            if ($password === '' || !wp_check_password($password, $user->password_hash)) {
                wp_send_json_error(array('html' => $this->render_login_form('رمز عبور اشتباه است.', $phone, true, $context, $captcha_pass)));
            }
            IPSVP_Captcha_Service::delete_pass($captcha_pass);
            $this->set_login_cookie($phone);
            wp_send_json_success(array('reload' => true));
        }

        if ($step === 'otp_request') {
            if (!$this->otp_login_ready()) {
                $has_password = ($existing_user && !empty($existing_user->password_hash));
                wp_send_json_error(array('html' => $this->render_login_form('ارسال کد یکبار مصرف فعلا در دسترس نیست. در صورت داشتن رمز عبور، با رمز وارد شوید.', $phone, $has_password, $context, $captcha_pass)));
            }
            $user = $this->db->get_or_create_user($phone);
            if ($user && !empty($user->is_blocked)) {
                IPSVP_Captcha_Service::delete_pass($captcha_pass);
                wp_send_json_error(array('html' => $this->render_login_form('حساب کاربری این شماره توسط مدیریت مسدود شده است.', $phone, false, $context)));
            }
            $sent = $this->send_panel_otp($phone);
            if (is_wp_error($sent)) {
                if (!empty($_POST['ipsvp_from_otp_verify'])) {
                    wp_send_json_error(array('html' => $this->render_otp_verify_form($sent->get_error_message(), $phone, 'error', $context, $captcha_pass)));
                }
                wp_send_json_error(array('html' => $this->render_login_form($sent->get_error_message(), $phone, !empty($user->password_hash), $context, $captcha_pass)));
            }
            wp_send_json_success(array('html' => $this->render_otp_verify_form('کد ورود برای شما ارسال شد.', $phone, 'success', $context, $captcha_pass)));
        }

        if ($step === 'otp_verify') {
            if (!$this->otp_login_ready()) {
                wp_send_json_error(array('html' => $this->render_login_form('ورود با کد یکبار مصرف فعال نیست.', $phone, false, $context, $captcha_pass)));
            }
            $code = isset($_POST['ipsvp_otp_code']) ? wp_unslash($_POST['ipsvp_otp_code']) : '';
            $verified = $this->verify_panel_otp($phone, $code);
            if (is_wp_error($verified)) {
                wp_send_json_error(array('html' => $this->render_otp_verify_form($verified->get_error_message(), $phone, 'error', $context, $captcha_pass)));
            }
            $user = $this->db->get_or_create_user($phone);
            if ($user && !empty($user->is_blocked)) {
                IPSVP_Captcha_Service::delete_pass($captcha_pass);
                wp_send_json_error(array('html' => $this->render_login_form('حساب کاربری این شماره توسط مدیریت مسدود شده است.', $phone, false, $context)));
            }
            IPSVP_Captcha_Service::delete_pass($captcha_pass);
            $this->set_login_cookie($phone);
            wp_send_json_success(array('reload' => true));
        }

        IPSVP_Captcha_Service::delete_pass($captcha_pass);
        wp_send_json_error(array('html' => $this->render_login_form('درخواست ورود نامعتبر است.', $phone, false, $context)));
    }

    public function register_shortcodes()
    {
        add_shortcode('ips_config_shop', array($this, 'shop_shortcode'));
        add_shortcode('ips_config_panel', array($this, 'panel_shortcode'));
        add_shortcode('ips_config_plans', array($this, 'plans_shortcode'));
        add_shortcode('ips_home_plans', array($this, 'plans_shortcode'));
        add_shortcode('ip_sabet_home_plans', array($this, 'plans_shortcode'));

        // Alias های کمکی برای زمانی که قالب یا صفحه ساز با شورت کد قبلی تداخل داشته باشد.
        add_shortcode('ipsvp_shop', array($this, 'shop_shortcode'));
        add_shortcode('ipsvp_panel', array($this, 'panel_shortcode'));
        add_shortcode('ip_sabet_shop', array($this, 'shop_shortcode'));
        add_shortcode('ip_sabet_panel', array($this, 'panel_shortcode'));
        add_shortcode('ipsvp_plans', array($this, 'plans_shortcode'));
        add_shortcode('ip_sabet_plans', array($this, 'plans_shortcode'));
        add_shortcode('ipsvp_active_countries', array($this, 'active_countries_shortcode'));
        add_shortcode('ips_active_countries', array($this, 'active_countries_shortcode'));
        add_shortcode('ip_sabet_active_countries', array($this, 'active_countries_shortcode'));
    }

    public function raw_shortcode_fallback($content)
    {
        if (is_admin() || !is_string($content)) {
            return $content;
        }

        $map = array(
            '[ips_config_shop]' => 'shop_shortcode',
            '[ipsvp_shop]' => 'shop_shortcode',
            '[ip_sabet_shop]' => 'shop_shortcode',
            '[ips_config_plans]' => 'plans_shortcode',
            '[ips_home_plans]' => 'plans_shortcode',
            '[ip_sabet_home_plans]' => 'plans_shortcode',
            '[ipsvp_plans]' => 'plans_shortcode',
            '[ip_sabet_plans]' => 'plans_shortcode',
            '[ipsvp_active_countries]' => 'active_countries_shortcode',
            '[ips_active_countries]' => 'active_countries_shortcode',
            '[ip_sabet_active_countries]' => 'active_countries_shortcode',
            '[ips_config_panel]' => 'panel_shortcode',
            '[ipsvp_panel]' => 'panel_shortcode',
            '[ip_sabet_panel]' => 'panel_shortcode',
        );

        foreach ($map as $tag => $method) {
            if (strpos($content, $tag) !== false) {
                $content = str_replace($tag, call_user_func(array($this, $method)), $content);
            }
        }

        return $content;
    }

    public function plans_shortcode($atts = array())
    {
        wp_enqueue_style('ipsvp-front');
        wp_enqueue_script('ipsvp-front');
        $atts = shortcode_atts(array(
            'checkout_url' => '',
            'title' => '',
            'subtitle' => '',
            'show_intro' => '1',
        ), is_array($atts) ? $atts : array(), 'ips_config_plans');

        $service_type = $this->requested_service_type();
        $plans = $this->db->active_plans($service_type);
        ob_start();
        echo '<section class="ipsvp ipsvp-pricing-only ipsvp-site-plans-section" id="plans" dir="rtl">';
        if ($atts['show_intro'] === '1') {
            $title = $atts['title'] ? $atts['title'] : ($service_type === 'dedicated' ? 'خرید آی پی ثابت اختصاصی' : 'خرید آی پی ثابت اشتراکی');
            $subtitle = $atts['subtitle'] ? $atts['subtitle'] : 'تمام پلن های سه ماهه به بالا آی پی ثابت دارای تخفیف هستند.';
            echo '<div class="ipsvp-site-plans-head"><h2>' . esc_html($title) . '</h2><p>' . esc_html($subtitle) . '</p></div>';
        }
        if (!$this->db->service_sales_enabled($service_type)) {
            echo $this->render_service_tabs($service_type);
            echo '<div class="ipsvp-alert ipsvp-sales-closed">فروش آی پی ثابت ' . ($service_type === 'dedicated' ? 'اختصاصی' : 'اشتراکی') . ' در حال حاضر بسته است.</div></section>';
            return ob_get_clean();
        }
        if (!$plans) {
            echo $this->render_service_tabs($service_type);
            echo '<div class="ipsvp-alert">هنوز پلن فعالی برای نمایش ثبت نشده است.</div></section>';
            return ob_get_clean();
        }
        echo '<div class="ipsvp-plans-toolbar">' . $this->render_service_tabs($service_type) . '<div class="ipsvp-plan-scroll-hint"><span>پلن های بیشتر را با اسکرول چپ و راست ببینید</span></div></div>';
        echo $this->render_plan_cards($plans, 'link', array('checkout_url' => $atts['checkout_url']));
        echo '</section>';
        return ob_get_clean();
    }


    public function active_countries_shortcode($atts = array())
    {
        wp_enqueue_style('ipsvp-front');
        wp_enqueue_script('ipsvp-front');
        $atts = shortcode_atts(array(
            'title' => 'کشورهای فعال',
            'subtitle' => 'سرویس‌های آی پی ثابت در لوکیشن‌های زیر به‌صورت فعال و آنلاین ارائه می‌شوند.',
            'limit' => 0,
        ), is_array($atts) ? $atts : array(), 'ipsvp_active_countries');

        return $this->render_active_countries_section($atts);
    }

    private function active_countries_section_items()
    {
        $items = $this->db->ready_countries();
        if (empty($items)) {
            $items = $this->db->active_countries();
        }
        $items = is_array($items) ? $items : array();
        $clean = array();
        foreach ($items as $item) {
            if (!$item || empty($item->name)) {
                continue;
            }
            $clean[] = $item;
        }
        return $clean;
    }

    private function render_active_countries_section($atts = array())
    {
        $items = $this->active_countries_section_items();
        $limit = isset($atts['limit']) ? max(0, (int) $atts['limit']) : 0;
        if ($limit > 0) {
            $items = array_slice($items, 0, $limit);
        }
        $title = !empty($atts['title']) ? (string) $atts['title'] : 'کشورهای فعال';
        $subtitle = isset($atts['subtitle']) ? (string) $atts['subtitle'] : '';
        $enable_marquee = count($items) > 5;
        ob_start();
        echo '<section class="ipsvp ipsvp-active-countries-section" dir="rtl">';
        echo '<div class="ipsvp-active-countries-shell">';
        echo '<div class="ipsvp-active-countries-bg ipsvp-active-countries-bg-left" aria-hidden="true"></div>';
        echo '<div class="ipsvp-active-countries-bg ipsvp-active-countries-bg-right" aria-hidden="true"></div>';
        echo '<div class="ipsvp-active-countries-head">';
        echo '<h2>' . esc_html($title) . '</h2>';
        if ($subtitle !== '') {
            echo '<p>' . esc_html($subtitle) . '</p>';
        }
        echo '</div>';
        if (empty($items)) {
            echo '<div class="ipsvp-alert">هنوز کشوری برای نمایش در این بخش ثبت نشده است.</div>';
        } elseif ($enable_marquee) {
            echo '<div class="ipsvp-active-countries-marquee" data-ipsvp-country-marquee="1" data-marquee-speed="1">';
            echo '<div class="ipsvp-active-countries-track">';
            for ($i = 0; $i < 2; $i++) {
                echo '<div class="ipsvp-active-countries-set"' . ($i === 1 ? ' aria-hidden="true"' : '') . '>';
                foreach ($items as $item) {
                    echo $this->render_active_country_card($item);
                }
                echo '</div>';
            }
            echo '</div>';
            echo '</div>';
        } else {
            echo '<div class="ipsvp-active-countries-grid">';
            foreach ($items as $item) {
                echo $this->render_active_country_card($item);
            }
            echo '</div>';
        }
        echo '</div>';
        echo '</section>';
        return ob_get_clean();
    }

    private function render_active_country_card($country)
    {
        $flag = !empty($country->flag) ? (string) $country->flag : '🌍';
        $name = !empty($country->name) ? (string) $country->name : 'کشور';
        ob_start();
        echo '<article class="ipsvp-active-country-card">';
        echo '<div class="ipsvp-active-country-flag" aria-hidden="true">' . esc_html($flag) . '</div>';
        echo '<h3>' . esc_html($name) . '</h3>';
        echo '<div class="ipsvp-active-country-status" aria-label="آنلاین">';
        echo '<span class="ipsvp-active-country-dot" aria-hidden="true"></span>';
        echo '<strong>آنلاین</strong>';
        echo '</div>';
        echo '</article>';
        return ob_get_clean();
    }

    public function shop_shortcode()
    {
        wp_enqueue_style('ipsvp-front');
        wp_enqueue_script('ipsvp-front');
        $this->localize_panel_login();
        $html = '<div class="ipsvp" dir="rtl">';
        if (!empty($_GET['ipsvp_crypto_status']) || !empty($_GET['ipsvp_crypto_success']) || !empty($_GET['ipsvp_crypto_return'])) {
            $html .= $this->handle_crypto_return();
            $html .= '</div>';
            return $html;
        }
        if (!empty($_GET['ipsvp_crypto_fail']) || !empty($_GET['ipsvp_crypto_failed'])) {
            $html .= $this->handle_crypto_failed();
            $html .= '</div>';
            return $html;
        }
        if (!empty($_GET['ipsvp_order_done'])) {
            $order = $this->db->get_order((int) $_GET['ipsvp_order_done']);
            $html .= $this->render_order_success($order);
            $html .= '</div>';
            return $html;
        }
        $action = isset($_POST['ipsvp_action']) ? sanitize_key($_POST['ipsvp_action']) : '';
        if (!$action && !empty($_GET['ipsvp_selected_plan'])) {
            $selected = $this->db->get_plan((int) $_GET['ipsvp_selected_plan']);
            $reseller_panel = IPSVP_Reseller::shop_panel($selected ? $this->db->normalize_service_type($selected->service_type ?? 'shared') : $this->requested_service_type());
            if ($reseller_panel !== '') { return $html . $reseller_panel . '</div>'; }
            $html .= $this->render_selected_plan_checkout((int) $_GET['ipsvp_selected_plan']);
            $html .= '</div>';
            return $html;
        }
        if ($action === 'submit_receipt') {
            $html .= $this->handle_receipt_submission();
        } elseif ($action === 'submit_crypto_payment') {
            $html .= $this->handle_crypto_order_payment();
        } elseif ($action === 'submit_wallet_payment') {
            $html .= $this->handle_wallet_order_payment();
        } elseif ($action === 'step_invoice') {
            $html .= $this->render_invoice();
        } elseif ($action === 'step_country') {
            $html .= $this->render_countries();
        } else {
            $reseller_panel = IPSVP_Reseller::shop_panel($this->requested_service_type());
            if ($reseller_panel !== '') { return $html . $reseller_panel . '</div>'; }
            $html .= $this->render_plans($this->requested_service_type());
        }
        $html .= '</div>';
        return $html;
    }

    private function requested_service_type()
    {
        $value = isset($_REQUEST['ipsvp_service_type']) ? wp_unslash($_REQUEST['ipsvp_service_type']) : 'shared';
        return $this->db->normalize_service_type($value);
    }

    private function render_service_tabs($active)
    {
        $active = $this->db->normalize_service_type($active);
        $base = remove_query_arg(array('ipsvp_service_type','ipsvp_selected_plan'), $this->current_page_url());
        return '<nav class="ipsvp-service-tabs" aria-label="نوع آی پی ثابت">'
            . '<a class="' . ($active === 'shared' ? 'is-active' : '') . '" href="' . esc_url(add_query_arg('ipsvp_service_type', 'shared#plans', $base)) . '">آی پی ثابت اشتراکی</a>'
            . '<a class="' . ($active === 'dedicated' ? 'is-active' : '') . '" href="' . esc_url(add_query_arg('ipsvp_service_type', 'dedicated#plans', $base)) . '">آی پی ثابت اختصاصی</a>'
            . '</nav>';
    }

    private function render_plans($service_type = 'shared')
    {
        $service_type = $this->db->normalize_service_type($service_type);
        $plans = $this->db->active_plans($service_type);
        $settings = IPSVP_Settings::get();
        $phone = $this->get_logged_phone();
        ob_start();
        echo '<div class="ipsvp-hero"><div class="ipsvp-hero-content"><span>IP Sabet</span><h2>خرید آی پی ثابت ' . ($service_type === 'dedicated' ? 'اختصاصی' : 'اشتراکی') . '</h2><p>پلن و کشور موردنظر را انتخاب کنید. برای ثبت سفارش و پرداخت، با حساب کاربری خود وارد شوید.</p></div></div>';
        echo $this->render_service_tabs($service_type);
        if (!$this->db->service_sales_enabled($service_type)) {
            echo '<div class="ipsvp-alert ipsvp-sales-closed">فروش این سرویس در حال حاضر بسته است.</div>';
            return ob_get_clean();
        }
        if (!$plans) {
            echo '<div class="ipsvp-alert">هنوز پلن فعالی برای فروش ثبت نشده است. از پیشخوان وردپرس، مسیر آی پی ثابت من > پلن ها را بررسی کنید.</div>';
            return ob_get_clean();
        }
        echo '<form method="post" class="ipsvp-box ipsvp-plan-select-box ipsvp-scrollable-plan-select ipsvp-pricing-only ipsvp-checkout-carousel">';
        wp_nonce_field('ipsvp_buy_step_country');
        echo '<input type="hidden" name="ipsvp_action" value="step_country"><input type="hidden" name="ipsvp_service_type" value="' . esc_attr($service_type) . '">';
        echo '<h3>۱. انتخاب پلن</h3>';
        echo '<div class="ipsvp-plan-scroll-hint ipsvp-checkout-plan-scroll-hint"><span>پلن های بیشتر را با کشیدن کارت ها به چپ و راست ببینید</span></div>';
        echo $this->render_plan_cards($plans, 'radio');
        if (!$phone) {
            echo $this->render_config_auth_required_box();
        } else {
            echo $this->render_config_customer_box($phone);
        }
        echo '<button class="ipsvp-btn" type="submit">ادامه و انتخاب کشور</button></form>';
        if (!$phone) {
            echo $this->render_config_auth_modal();
        }
        return ob_get_clean();
    }


    private function render_selected_plan_compact($plan)
    {
        $price = $this->db->final_price($plan);
        $discount = $this->plan_discount_label($plan);
        $gb = number_format_i18n((int) $plan->gb) . ' گیگ';
        $days = number_format_i18n((int) $plan->days) . ' روز';
        $price_text = number_format_i18n($price) . ' تومان';
        ob_start();
        echo '<div class="ipsvp-selected-plan-compact">';
        echo '<div class="ipsvp-selected-plan-compact-head"><span>پلن انتخاب شده</span><strong>' . esc_html($plan->title) . '</strong></div>';
        echo '<div class="ipsvp-selected-plan-compact-grid">';
        echo '<div class="ipsvp-selected-plan-cell"><span>عنوان پلن</span><strong>' . esc_html($plan->title) . '</strong></div>';
        echo '<div class="ipsvp-selected-plan-cell"><span>ترافیک</span><strong>' . esc_html($gb) . '</strong></div>';
        echo '<div class="ipsvp-selected-plan-cell"><span>مدت اعتبار</span><strong>' . esc_html($days) . '</strong></div>';
        echo '<div class="ipsvp-selected-plan-cell"><span>مبلغ</span><strong>' . esc_html($price_text) . '</strong></div>';
        echo '<div class="ipsvp-selected-plan-cell"><span>تخفیف</span><strong>' . esc_html($discount) . '</strong></div>';
        echo '</div>';
        echo '</div>';
        return ob_get_clean();
    }

    private function render_selected_plan_checkout($plan_id)
    {
        $plan = $this->db->get_plan($plan_id);
        $service_type = $plan ? $this->db->normalize_service_type($plan->service_type ?? 'shared') : 'shared';
        $countries = $this->db->active_countries($service_type);
        if (!$plan || empty($plan->status)) {
            return '<div class="ipsvp-alert">پلن انتخاب شده پیدا نشد یا غیرفعال است.</div>';
        }
        if (!$this->db->service_sales_enabled($service_type)) {
            return '<div class="ipsvp-alert">فروش این نوع سرویس در حال حاضر بسته است.</div>';
        }
        if (!$countries) {
            return '<div class="ipsvp-alert">هنوز کشوری برای فروش ثبت نشده است. از پیشخوان وردپرس، مسیر آی پی ثابت من > کشورها را بررسی کنید.</div>';
        }
        ob_start();
        $phone = $this->get_logged_phone();
        $is_guest = !$phone;
        echo $this->render_selected_plan_compact($plan);
        echo '<form method="post" class="ipsvp-box ipsvp-country-select-box" data-ipsvp-config-checkout data-requires-login="' . esc_attr($is_guest ? '1' : '0') . '">';
        wp_nonce_field('ipsvp_buy_step_invoice');
        echo '<input type="hidden" name="ipsvp_action" value="step_invoice"><input type="hidden" name="ipsvp_service_type" value="' . esc_attr($service_type) . '"><input type="hidden" name="plan_id" value="' . esc_attr($plan->id) . '">';
        if (!$is_guest) {
            echo '<input type="hidden" name="phone" value="' . esc_attr($phone) . '">';
        }
        echo $this->render_country_options($countries, $plan);
        if ($is_guest) {
            echo $this->render_config_auth_required_box();
            echo '<div class="ipsvp-alert ipsvp-config-guest-submit-message" data-ipsvp-config-guest-message hidden>برای ثبت سفارش ابتدا وارد حساب کاربری شوید.</div>';
        } else {
            echo $this->render_config_customer_box($phone);
        }
        echo '<div class="ipsvp-actions"><button class="ipsvp-btn" type="submit">مشاهده فاکتور و پرداخت</button></div></form>';
        if ($is_guest) {
            echo $this->render_config_auth_modal();
        }
        return ob_get_clean();
    }

    private function render_config_auth_required_box()
    {
        return IPSVP_Auth_Renderer::required_box(array(
            'title' => 'برای تکمیل خرید وارد حساب کاربری شوید',
            'description' => 'می‌توانید پلن و کشور موردنظر را انتخاب کنید. برای ثبت سفارش و پرداخت، ابتدا وارد حساب کاربری شوید.',
            'button' => 'ورود به حساب کاربری',
        ));
    }

    private function render_config_auth_modal()
    {
        return IPSVP_Auth_Renderer::modal(array('context' => 'config'));
    }

    private function render_config_customer_box($phone)
    {
        $user = $this->db->get_user_by_phone($phone);
        return IPSVP_Auth_Renderer::customer_box($phone, $user);
    }

    private function render_config_login_required_notice($message = 'برای ثبت سفارش ابتدا وارد حساب کاربری شوید.')
    {
        return '<div class="ipsvp-alert">' . esc_html($message) . '</div>' . $this->render_config_auth_required_box() . $this->render_config_auth_modal();
    }

    private function render_plan_cards($plans, $mode = 'radio', $args = array())
    {
        $plans = is_array($plans) ? $plans : array();
        $args = is_array($args) ? $args : array();
        $checkout_url = !empty($args['checkout_url']) ? $args['checkout_url'] : $this->shop_page_url();
        ob_start();
        $grid_class = 'ipsvp-site-plans-grid ipsvp-site-plans-grid-' . sanitize_html_class($mode);
        $grid_style = '';
        if ($mode === 'radio') {
            $grid_style = ' style="display:flex!important;grid-template-columns:none!important;flex-wrap:nowrap!important;align-items:stretch!important;gap:20px!important;width:100%!important;max-width:100%!important;margin:0 0 22px!important;padding:24px 8px 34px!important;overflow-x:auto!important;overflow-y:visible!important;direction:rtl!important;scroll-snap-type:none!important;scroll-behavior:auto!important;scroll-padding-inline:8px!important;-webkit-overflow-scrolling:touch!important;box-sizing:border-box!important;"';
        }
        echo '<div class="' . esc_attr($grid_class) . '"' . $grid_style . '>';
        foreach ($plans as $p) {
            if (!$p) {
                continue;
            }
            $price = $this->db->final_price($p);
            $original = (int) $p->price;
            $has_sale = ($original > 0 && $price > 0 && $price < $original);
            $discount = $this->plan_discount_label($p);
            $features = $this->plan_features($p);
            $icon = $this->plan_icon_data($p);
            $card_tag = ($mode === 'radio') ? 'label' : 'div';
            $card_style = ($mode === 'radio') ? ' style="flex:0 0 clamp(290px,22vw,315px)!important;width:clamp(290px,22vw,315px)!important;max-width:315px!important;min-width:290px!important;scroll-snap-align:none!important;scroll-snap-stop:normal!important;box-sizing:border-box!important;"' : '';
            echo '<' . $card_tag . ' class="ipsvp-site-plan-card"' . $card_style . '>';
            if ($mode === 'radio') {
                echo '<input class="ipsvp-site-plan-radio" required type="radio" name="plan_id" value="' . esc_attr($p->id) . '">';
            }
            echo '<div class="ipsvp-site-plan-icon-wrap">';
            echo '<div class="ipsvp-site-plan-icon ipsvp-site-plan-icon-light">';
            if (!empty($icon['light'])) {
                echo '<img src="' . esc_url($icon['light']) . '" width="45" height="45" alt="' . esc_attr($p->title) . '">';
            } else {
                echo '<span>' . esc_html($icon['fallback']) . '</span>';
            }
            echo '</div>';
            echo '<div class="ipsvp-site-plan-icon ipsvp-site-plan-icon-dark">';
            if (!empty($icon['dark'])) {
                echo '<img src="' . esc_url($icon['dark']) . '" width="45" height="45" alt="' . esc_attr($p->title) . '">';
            } elseif (!empty($icon['light'])) {
                echo '<img src="' . esc_url($icon['light']) . '" width="45" height="45" alt="' . esc_attr($p->title) . '">';
            } else {
                echo '<span>' . esc_html($icon['fallback']) . '</span>';
            }
            echo '</div></div>';
            echo '<div class="ipsvp-site-plan-top"><h3>' . esc_html($p->title) . '</h3><span>' . esc_html($discount) . '</span></div>';
            echo '<div class="ipsvp-site-plan-duration"><b>' . esc_html(number_format_i18n((int) $p->days)) . '</b><span>روز اعتبار</span></div>';
            echo '<div class="ipsvp-site-price-frame"><div class="ipsvp-site-price-pill">';
            if ($has_sale) {
                echo '<del>' . esc_html(number_format_i18n($original)) . '</del>';
            }
            echo '<strong>' . esc_html(number_format_i18n($price)) . '</strong>';
            echo '<img src="' . esc_url(IPSVP_PLUGIN_URL . 'assets/images/toman.webp') . '" alt="تومان" width="17" height="15" class="ipsvp-site-toman ipsvp-site-toman-light">';
            echo '<img src="' . esc_url(IPSVP_PLUGIN_URL . 'assets/images/toman-dark.webp') . '" alt="تومان" width="17" height="15" class="ipsvp-site-toman ipsvp-site-toman-dark">';
            echo '</div></div>';
            echo '<div class="ipsvp-site-divider"></div>';
            echo '<div class="ipsvp-site-features">';
            $i = 0;
            foreach ($features as $feature) {
                $text = is_array($feature) && isset($feature['text']) ? $feature['text'] : (string) $feature;
                echo '<div class="ipsvp-site-feature"><span class="ipsvp-site-feature-icon">' . $this->plan_feature_svg($i) . '</span><b>' . esc_html($text) . '</b></div>';
                $i++;
            }
            echo '</div>';
            echo '<div class="ipsvp-site-plan-footer">';
            if ($mode === 'radio') {
                echo '<span class="ipsvp-site-buy">خرید اشتراک</span>';
            } elseif ($mode === 'link') {
                $url = add_query_arg(array('ipsvp_selected_plan' => (int) $p->id, 'ipsvp_service_type' => $this->db->normalize_service_type($p->service_type ?? 'shared')), $checkout_url);
                echo '<a class="ipsvp-site-buy" href="' . esc_url($url) . '">خرید اشتراک</a>';
            } else {
                echo '<span class="ipsvp-site-buy ipsvp-site-selected">پلن انتخاب شده</span>';
            }
            echo '</div>';
            echo '</' . $card_tag . '>';
        }
        echo '</div>';
        return ob_get_clean();
    }

    private function plan_discount_label($plan)
    {
        if (isset($plan->discount_label) && trim((string) $plan->discount_label) !== '') {
            return trim((string) $plan->discount_label);
        }
        $price = (int) $plan->price;
        $sale = ($plan->sale_price !== null && $plan->sale_price !== '' && (int) $plan->sale_price > 0) ? (int) $plan->sale_price : 0;
        if ($price > 0 && $sale > 0 && $sale < $price) {
            $percent = round((($price - $sale) / $price) * 100);
            return number_format_i18n($percent) . ' درصد تخفیف';
        }
        return '۰ درصد تخفیف';
    }

    private function plan_icon_data($plan)
    {
        $base = IPSVP_PLUGIN_URL . 'assets/images/';
        $custom = isset($plan->card_icon) ? trim((string) $plan->card_icon) : '';
        $keys = array(
            'almas' => array('almas.webp', 'almas-dark.webp'),
            'diamond' => array('almas.webp', 'almas-dark.webp'),
            '1month' => array('almas.webp', 'almas-dark.webp'),
            'month' => array('almas.webp', 'almas-dark.webp'),
            '3month' => array('3month1.webp', '3month1-dark.webp'),
            '3months' => array('3month1.webp', '3month1-dark.webp'),
            '6month' => array('6month1.webp', '6month1-dark.webp'),
            '6months' => array('6month1.webp', '6month1-dark.webp'),
            '1year' => array('1year.webp', '1year-dark.webp'),
            'year' => array('1year.webp', '1year-dark.webp'),
        );
        if ($custom !== '') {
            $key = strtolower($custom);
            if (isset($keys[$key])) {
                return array('light' => $base . $keys[$key][0], 'dark' => $base . $keys[$key][1], 'fallback' => '💎');
            }
            if (preg_match('#^https?://#i', $custom)) {
                return array('light' => esc_url_raw($custom), 'dark' => '', 'fallback' => '💎');
            }
            return array('light' => '', 'dark' => '', 'fallback' => $custom);
        }
        $days = isset($plan->days) ? (int) $plan->days : 0;
        if ($days >= 365) {
            return array('light' => $base . '1year.webp', 'dark' => $base . '1year-dark.webp', 'fallback' => '💎');
        }
        if ($days >= 180) {
            return array('light' => $base . '6month1.webp', 'dark' => $base . '6month1-dark.webp', 'fallback' => '⭐');
        }
        if ($days >= 90) {
            return array('light' => $base . '3month1.webp', 'dark' => $base . '3month1-dark.webp', 'fallback' => '🚀');
        }
        return array('light' => $base . 'almas.webp', 'dark' => $base . 'almas-dark.webp', 'fallback' => '💎');
    }

    private function plan_features($plan)
    {
        $custom = isset($plan->features) ? trim((string) $plan->features) : '';
        $features = array();
        if ($custom !== '') {
            $lines = preg_split('/\r\n|\r|\n/', $custom);
            foreach ($lines as $line) {
                $line = trim($line);
                if ($line !== '') {
                    $features[] = array('text' => $line);
                }
            }
        }
        if (!$features) {
            if ($this->db->normalize_service_type($plan->service_type ?? 'shared') === 'dedicated') {
                $features = array(
                    array('text' => 'آی پی ثابت اختصاصی'),
                    array('text' => 'ترافیک ' . number_format_i18n((int) $plan->gb) . ' گیگ قابل افزایش'),
                    array('text' => 'لوکیشن اختصاصی انتخاب‌شده'),
                    array('text' => 'لینک ساب و QR اختصاصی'),
                    array('text' => 'امکان تمدید و خرید حجم'),
                    array('text' => 'پشتیبانی و مدیریت سرویس'),
                );
            } else {
                $features = array(
                    array('text' => 'آی پی ثابت ترید و رفع تحریم'),
                    array('text' => 'ترافیک ' . number_format_i18n((int) $plan->gb) . ' گیگ قابل افزایش'),
                    array('text' => 'انتخاب بین ۱۰ لوکیشن برتر'),
                    array('text' => 'استفاده روی تمام دستگاه ها'),
                    array('text' => 'تعداد کاربر نامحدود'),
                    array('text' => 'ضمانت بازگشت وجه'),
                );
            }
        }
        return array_slice($features, 0, 8);
    }

    private function plan_feature_svg($index)
    {
        $svgs = array(
            '<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="9" cy="9" r="7.5" stroke="currentColor" stroke-width="1.125"/><ellipse cx="9" cy="9" rx="3" ry="7.5" stroke="currentColor" stroke-width="1.125"/><path d="M1.5 9H16.5" stroke="currentColor" stroke-width="1.125" stroke-linecap="round" stroke-linejoin="round"/></svg>',
            '<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6.1875 10.875C7.6875 9.375 10.3125 9.375 11.8125 10.875" stroke="currentColor" stroke-width="1.125" stroke-linecap="round" stroke-linejoin="round"/><path d="M13.875 8.625C11.0493 6.125 7.125 6.125 4.125 8.625" stroke="currentColor" stroke-width="1.125" stroke-linecap="round" stroke-linejoin="round"/><path d="M1.5 6.375C6.23684 2.37502 11.7632 2.37501 16.5 6.37492" stroke="currentColor" stroke-width="1.125" stroke-linecap="round" stroke-linejoin="round"/><circle cx="9" cy="13.5" r="1.125" stroke="currentColor" stroke-width="1.125" stroke-linecap="round" stroke-linejoin="round"/></svg>',
            '<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.2133 16.0252C9.88804 16.3298 9.45329 16.5 9.00084 16.5C8.54839 16.5 8.11364 16.3298 7.78837 16.0252C4.80977 13.2195 0.818072 10.0852 2.7647 5.53475C3.81723 3.07437 6.34376 1.5 9.00084 1.5C11.6579 1.5 14.1845 3.07437 15.237 5.53475C17.1811 10.0795 13.1993 13.2292 10.2133 16.0252Z" stroke="currentColor" stroke-width="1.125"/><path d="M11.625 8.25C11.625 9.69975 10.4497 10.875 9 10.875C7.55025 10.875 6.375 9.69975 6.375 8.25C6.375 6.80025 7.55025 5.625 9 5.625C10.4497 5.625 11.625 6.80025 11.625 8.25Z" stroke="currentColor" stroke-width="1.125"/></svg>',
            '<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.2522 1.5H7.50465C5.04332 1.5 3.81266 1.5 2.9403 2.11036C2.61755 2.33618 2.33683 2.61668 2.11084 2.93918C1.5 3.81087 1.5 5.04058 1.5 7.5C1.5 9.95942 1.5 11.1891 2.11084 12.0608C2.33683 12.3833 2.61755 12.6638 2.9403 12.8896C3.81266 13.5 5.04332 13.5 7.50465 13.5H10.507C12.9683 13.5 14.199 13.5 15.0713 12.8896C15.3941 12.6638 15.6748 12.3833 15.9008 12.0608C16.3617 11.4031 16.4747 10.5706 16.5 9.75" stroke="currentColor" stroke-width="1.125" stroke-linecap="round"/><path d="M13.5 7.28571V8.25M13.5 7.28571C12.6324 7.28571 11.868 6.85956 11.4197 6.21248M13.5 7.28571C14.3676 7.28571 15.132 6.85956 15.5803 6.21248M13.5 2.46429C14.3677 2.46429 15.1321 2.8905 15.5804 3.53766M13.5 2.46429C12.6323 2.46429 11.8679 2.8905 11.4196 3.53766M13.5 2.46429V1.5M16.5 2.94643L15.5804 3.53766M10.5003 6.80357L11.4197 6.21248M10.5 2.94643L11.4196 3.53766M16.4997 6.80357L15.5803 6.21248M15.5804 3.53766C15.8454 3.92033 16 4.38026 16 4.875C16 5.3698 15.8454 5.82978 15.5803 6.21248M11.4196 3.53766C11.1546 3.92033 11 4.38026 11 4.875C11 5.3698 11.1546 5.82978 11.4197 6.21248" stroke="currentColor" stroke-width="1.125" stroke-linecap="round"/><path d="M8.25 11.25H9.75" stroke="currentColor" stroke-width="1.125" stroke-linecap="round" stroke-linejoin="round"/><path d="M9 13.5V16.5" stroke="currentColor" stroke-width="1.125"/><path d="M6 16.5H12" stroke="currentColor" stroke-width="1.125" stroke-linecap="round"/></svg>',
            '<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.5804 13.5C16.1424 13.5 16.5894 13.1464 16.9907 12.6519C17.8123 11.6396 16.4634 10.8306 15.9489 10.4345C15.4259 10.0317 14.8419 9.80356 14.2499 9.75M13.4999 8.25C14.5354 8.25 15.3749 7.41053 15.3749 6.375C15.3749 5.33947 14.5354 4.5 13.4999 4.5" stroke="currentColor" stroke-width="1.125" stroke-linecap="round"/><path d="M2.41935 13.5C1.85737 13.5 1.41038 13.1464 1.00904 12.6519C0.187444 11.6396 1.53638 10.8306 2.05086 10.4345C2.57386 10.0317 3.15781 9.80356 3.74988 9.75M4.12488 8.25C3.08934 8.25 2.24988 7.41053 2.24988 6.375C2.24988 5.33947 3.08934 4.5 4.12488 4.5" stroke="currentColor" stroke-width="1.125" stroke-linecap="round"/><path d="M6.06273 11.3334C5.2964 11.8072 3.28712 12.7748 4.5109 13.9856C5.10871 14.577 5.77452 15 6.6116 15H11.3882C12.2252 15 12.891 14.577 13.4889 13.9856C14.7126 12.7748 12.7034 11.8072 11.937 11.3334C10.14 10.2222 7.85977 10.2222 6.06273 11.3334Z" stroke="currentColor" stroke-width="1.125" stroke-linecap="round" stroke-linejoin="round"/><path d="M11.6249 5.625C11.6249 7.07475 10.4496 8.25 8.99988 8.25C7.55013 8.25 6.37488 7.07475 6.37488 5.625C6.37488 4.17525 7.55013 3 8.99988 3C10.4496 3 11.6249 4.17525 11.6249 5.625Z" stroke="currentColor" stroke-width="1.125"/></svg>',
            '<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.5 9C1.5 6.34689 1.5 5.02033 2.2896 4.13467C2.41589 3.99302 2.55508 3.86202 2.70559 3.74315C3.6466 3 5.05607 3 7.875 3H10.125C12.9439 3 14.3534 3 15.2944 3.74315C15.4449 3.86202 15.5841 3.99302 15.7104 4.13467C16.5 5.02033 16.5 6.34689 16.5 9C16.5 11.6531 16.5 12.9797 15.7104 13.8653C15.5841 14.007 15.4449 14.138 15.2944 14.2568C14.3534 15 12.9439 15 10.125 15H7.875C5.05607 15 3.6466 15 2.70559 14.2568C2.55508 14.138 2.41589 14.007 2.2896 13.8653C1.5 12.9797 1.5 11.6531 1.5 9Z" stroke="currentColor" stroke-width="1.125" stroke-linecap="round" stroke-linejoin="round"/><path d="M10.9132 9C10.9132 10.0355 10.0738 10.875 9.03824 10.875C8.00271 10.875 7.16324 10.0355 7.16324 9C7.16324 7.96447 8.00271 7.125 9.03824 7.125C10.0738 7.125 10.9132 7.96447 10.9132 9Z" stroke="currentColor" stroke-width="1.125"/><path d="M3.75 9L4.5 9" stroke="currentColor" stroke-width="1.125" stroke-linecap="round"/><path d="M13.5 9L14.25 9" stroke="currentColor" stroke-width="1.125" stroke-linecap="round"/></svg>',
        );
        return $svgs[$index % count($svgs)];
    }

    private function shop_page_url()
    {
        $settings = IPSVP_Settings::get();
        if (!empty($settings['buy_url'])) {
            return esc_url_raw($settings['buy_url']);
        }
        $page = get_page_by_title('خرید کانفیگ آی پی ثابت', OBJECT, 'page');
        if ($page) {
            return get_permalink($page->ID);
        }
        return $this->current_page_url();
    }

    private function render_country_options($countries, $plan)
    {
        $countries = is_array($countries) ? $countries : array();
        $service_type = $this->db->normalize_service_type($plan->service_type ?? 'shared');
        $ready_count = count($countries);
        $all_countries_group_ready = $this->db->all_countries_group_ready();
        ob_start();
        echo '<h3>۲. انتخاب کشور</h3><div class="ipsvp-country-grid">';
        foreach ($countries as $c) {
            $disabled = $service_type === 'shared' && empty($c->pg_group_id) ? 'disabled' : '';
            $availability = $service_type === 'dedicated' ? 'تحویل اختصاصی' : ($c->pg_group_id ? 'آماده اتصال' : 'گروه تنظیم نشده');
            echo '<label class="ipsvp-country ' . ($disabled ? 'is-disabled' : '') . '"><input required type="radio" name="country_id" value="' . esc_attr($c->id) . '" ' . esc_attr($disabled) . '><span class="flag">' . esc_html($c->flag) . '</span><strong>' . esc_html($c->name) . '</strong><small>' . esc_html($availability) . '</small></label>';
        }
        if ($service_type === 'shared' && $this->db->all_countries_enabled() && $all_countries_group_ready && $ready_count > 1) {
            $all_price = $this->db->all_countries_price($plan);
            echo '<label class="ipsvp-country ipsvp-country-all"><input required type="radio" name="country_id" value="0"><span class="flag">🌍</span><strong>همه کشورها</strong><small>دسترسی از طریق گروه VIP همه کشورها</small><span class="ipsvp-all-country-price">' . esc_html(number_format_i18n($all_price)) . ' تومان</span></label>';
        }
        echo '</div>';
        if ($service_type === 'shared' && $this->db->all_countries_enabled() && $all_countries_group_ready && $ready_count > 1) {
            echo '<div class="ipsvp-all-countries-help">با انتخاب «همه کشورها»، کانفیگ شما از گروه مخصوص همه کشورها در پاسارگارد ساخته می‌شود و دسترسی لوکیشن‌ها از داخل همان گروه مدیریت می‌شود.</div>';
        }
        return ob_get_clean();
    }

    private function render_countries()
    {
        if (!wp_verify_nonce(isset($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '', 'ipsvp_buy_step_country')) {
            return '<div class="ipsvp-alert">درخواست نامعتبر است.</div>';
        }
        $phone = $this->get_logged_phone();
        $is_guest = !$phone;
        $plan_id = isset($_POST['plan_id']) ? (int) $_POST['plan_id'] : 0;
        $plan = $this->db->get_plan($plan_id);
        $service_type = $plan ? $this->db->normalize_service_type($plan->service_type ?? 'shared') : 'shared';
        $countries = $this->db->active_countries($service_type);
        if (!$plan) {
            return '<div class="ipsvp-alert">پلن نامعتبر است.</div>';
        }
        if (!$this->db->service_sales_enabled($service_type)) {
            return '<div class="ipsvp-alert">فروش این نوع سرویس در حال حاضر بسته است.</div>';
        }
        if (!$countries) {
            return '<div class="ipsvp-alert">هنوز کشوری برای فروش ثبت نشده است. از پیشخوان وردپرس، مسیر آی پی ثابت من > کشورها را بررسی کنید.</div>';
        }
        ob_start();
        echo $this->render_selected_plan_compact($plan);
        echo '<form method="post" class="ipsvp-box" data-ipsvp-config-checkout data-requires-login="' . esc_attr($is_guest ? '1' : '0') . '">';
        wp_nonce_field('ipsvp_buy_step_invoice');
        echo '<input type="hidden" name="ipsvp_action" value="step_invoice"><input type="hidden" name="ipsvp_service_type" value="' . esc_attr($service_type) . '"><input type="hidden" name="plan_id" value="' . esc_attr($plan_id) . '">';
        if (!$is_guest) {
            echo '<input type="hidden" name="phone" value="' . esc_attr($phone) . '">';
        }
        $has_ready_country = false;
        foreach ($countries as $c_check) {
            if (!empty($c_check->pg_group_id)) {
                $has_ready_country = true;
                break;
            }
        }
        if ($service_type === 'shared' && !$has_ready_country && !$this->db->all_countries_group_ready()) {
            echo '<div class="ipsvp-alert">کشورها ثبت شده اند اما هیچ کشوری به گروه پاسارگارد وصل نشده است. برای فروش تکی کشورها، برای هر کشور گروه انتخاب کنید؛ برای فروش همه کشورها، از تنظیمات گروه مخصوص همه کشورها را انتخاب کنید.</div>';
        }
        echo $this->render_country_options($countries, $plan);
        if ($is_guest) {
            echo $this->render_config_auth_required_box();
            echo '<div class="ipsvp-alert ipsvp-config-guest-submit-message" data-ipsvp-config-guest-message hidden>برای ثبت سفارش ابتدا وارد حساب کاربری شوید.</div>';
        } else {
            echo $this->render_config_customer_box($phone);
        }
        echo '<div class="ipsvp-actions"><button class="ipsvp-btn" type="submit">مشاهده فاکتور و پرداخت</button></div></form>';
        if ($is_guest) {
            echo $this->render_config_auth_modal();
        }
        return ob_get_clean();
    }


    private function payment_method_enabled($method)
    {
        if (class_exists('IPSPM_Payment_Manager')) {
            return IPSPM_Payment_Manager::method_enabled($method, 'ip-sabet');
        }
        $s = IPSVP_Settings::get();
        $key = 'payment_' . sanitize_key($method) . '_enabled';
        return !isset($s[$key]) || $s[$key] === '1';
    }

    private function crypto_available()
    {
        if (class_exists('IPSPM_Payment_Manager')) {
            return IPSPM_Payment_Manager::crypto_available('ip-sabet');
        }
        if (!$this->payment_method_enabled('crypto')) {
            return false;
        }
        return function_exists('ramzino_crypto_create_invoice') || !empty(IPSVP_Settings::get()['ramzino_secret']);
    }

    private function payment_settings()
    {
        $settings = IPSVP_Settings::get();
        if (class_exists('IPSPM_Payment_Manager')) {
            $settings = array_merge($settings, IPSPM_Payment_Manager::legacy_settings());
        }
        return $settings;
    }

    private function crypto_status_is_paid($status)
    {
        $status = strtolower(trim((string) $status));
        return in_array($status, array('paid','completed','confirmed','success','successful','done','over-paid','over_paid','1'), true);
    }

    private function crypto_status_is_failed($status)
    {
        $status = strtolower(trim((string) $status));
        return in_array($status, array('failed','fail','cancelled','canceled','expired','rejected','error','-1'), true);
    }

    private function ramzino_create_invoice_for_receipt($receipt, $order_code, $description, $return_args = array())
    {
        $s = $this->payment_settings();
        $base_args = array_merge(array('receipt_id' => (int) $receipt->id, 'ipsvp_order_code' => $order_code), $return_args);
        $status_callback = $this->current_page_url(array_merge($base_args, array('ipsvp_crypto_status' => 1)));
        $success = $this->current_page_url(array_merge($base_args, array('ipsvp_crypto_success' => 1)));
        $fail = $this->current_page_url(array_merge($base_args, array('ipsvp_crypto_fail' => 1)));
        if (!class_exists('IPSPM_Payment_Manager')) {
            if (!empty($s['ramzino_status_callback_url'])) { $status_callback = esc_url_raw($s['ramzino_status_callback_url']); }
            if (!empty($s['ramzino_success_callback_url'])) { $success = esc_url_raw($s['ramzino_success_callback_url']); }
            if (!empty($s['ramzino_fail_callback_url'])) { $fail = esc_url_raw($s['ramzino_fail_callback_url']); }
        }
        $args = array(
            'amount' => (float) $receipt->amount,
            'order_id' => $order_code,
            'to_currency' => !empty($s['ramzino_to_currency']) ? $s['ramzino_to_currency'] : 'IRT',
            'lifetime' => !empty($s['ramzino_lifetime']) ? (int) $s['ramzino_lifetime'] : 20,
            'status_callback' => $status_callback,
            'success_callback' => $success,
            'fail_callback' => $fail,
            'description' => $description,
        );
        if (class_exists('IPSPM_Payment_Manager')) {
            $created = IPSPM_Payment_Manager::create_crypto_invoice(array_merge($args, array('context' => 'ip-sabet')));
            if (is_wp_error($created)) { return $created; }
            $invoice = isset($created['raw']) && is_array($created['raw']) ? $created['raw'] : array();
            $url = isset($created['url']) ? (string) $created['url'] : '';
            $uuid = isset($created['uuid']) ? (string) $created['uuid'] : '';
        } elseif (function_exists('ramzino_crypto_create_invoice')) {
            $invoice = ramzino_crypto_create_invoice($args);
        } else {
            $secret = !empty($s['ramzino_secret']) ? (string) $s['ramzino_secret'] : '';
            if ($secret === '') {
                return new WP_Error('ramzino_secret_missing', 'Secret رمزینو تنظیم نشده است.');
            }
            $res = wp_remote_post(rest_url('ramzino/v1/create-invoice'), array(
                'timeout' => 45,
                'headers' => array('X-Ramzino-Secret' => $secret, 'Accept' => 'application/json'),
                'body' => $args,
            ));
            if (is_wp_error($res)) { return $res; }
            $code = wp_remote_retrieve_response_code($res);
            $invoice = json_decode(wp_remote_retrieve_body($res), true);
            if ($code < 200 || $code >= 300 || !is_array($invoice)) {
                return new WP_Error('ramzino_invoice_failed', 'ساخت فاکتور رمزینو ناموفق بود.');
            }
        }
        if (is_wp_error($invoice)) { return $invoice; }
        if (!isset($url)) {
            $url = $this->array_find($invoice, array('url','data.url','payment_url','data.payment_url','paymentUrl','data.paymentUrl','checkout_url','data.checkout_url','pay_url','data.pay_url'));
            $url = $this->normalize_ramzino_payment_url($url);
        }
        if (!isset($uuid)) {
            $uuid = $this->array_find($invoice, array('uuid','data.uuid','invoice_uuid','data.invoice_uuid'));
        }
        if (!$url) {
            return new WP_Error('ramzino_payment_url_missing', 'لینک پرداخت رمزینو در پاسخ درگاه وجود نداشت.');
        }
        global $wpdb;
        $t = $this->db->tables();
        $existing_payload = !empty($receipt->remote_payload) ? json_decode((string) $receipt->remote_payload, true) : array();
        $payload = is_array($existing_payload) ? $existing_payload : array();
        $payload['_ramzino_invoice'] = is_array($invoice) ? $invoice : array('raw' => $invoice);
        $payload['_ipsvp'] = array('uuid' => $uuid, 'url' => $url, 'order_code' => $order_code, 'status_callback' => $status_callback, 'success_callback' => $success, 'fail_callback' => $fail);
        $wpdb->update($t['receipts'], array('remote_payload' => wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)), array('id' => (int) $receipt->id));
        return array('url' => $url, 'uuid' => $uuid, 'raw' => $invoice);
    }


    private function ramzino_base_url()
    {
        if (class_exists('RCG_Helpers') && method_exists('RCG_Helpers', 'get_setting')) {
            $base = RCG_Helpers::get_setting('base_url', 'https://ramzino.me');
        } else {
            $base = 'https://ramzino.me';
        }
        $base = trim((string) $base);
        if ($base === '') { $base = 'https://ramzino.me'; }
        if (!preg_match('#^https?://#i', $base)) { $base = 'https://' . $base; }
        return untrailingslashit(esc_url_raw($base));
    }

    private function normalize_ramzino_payment_url($url)
    {
        $url = trim((string) $url);
        if ($url === '') { return ''; }
        if (preg_match('#^https?://#i', $url)) { return esc_url_raw($url); }
        if (strpos($url, '//') === 0) { return esc_url_raw('https:' . $url); }
        if ($url[0] === '/') { return esc_url_raw($this->ramzino_base_url() . $url); }
        return esc_url_raw($this->ramzino_base_url() . '/' . ltrim($url, '/'));
    }

    private function ramzino_payment_detail($uuid)
    {
        $uuid = sanitize_text_field((string) $uuid);
        if ($uuid === '') { return new WP_Error('ramzino_uuid_missing', 'شناسه پرداخت رمزینو پیدا نشد.'); }
        if (class_exists('IPSPM_Payment_Manager')) {
            return IPSPM_Payment_Manager::payment_detail($uuid);
        }
        if (function_exists('ramzino_crypto_payment_detail')) {
            return ramzino_crypto_payment_detail($uuid);
        }
        $s = $this->payment_settings();
        $secret = !empty($s['ramzino_secret']) ? (string) $s['ramzino_secret'] : '';
        if ($secret === '') { return new WP_Error('ramzino_secret_missing', 'Secret رمزینو تنظیم نشده است.'); }
        $res = wp_remote_post(add_query_arg(array('uuid' => $uuid), rest_url('ramzino/v1/payment-detail')), array(
            'timeout' => 45,
            'headers' => array('X-Ramzino-Secret' => $secret, 'Accept' => 'application/json'),
        ));
        if (is_wp_error($res)) { return $res; }
        $body = json_decode(wp_remote_retrieve_body($res), true);
        if (!is_array($body)) { return new WP_Error('ramzino_bad_response', 'پاسخ رمزینو قابل خواندن نیست.'); }
        return $body;
    }

    private function array_find($array, $keys)
    {
        if (!is_array($array)) { return ''; }
        foreach ($keys as $key) {
            $parts = explode('.', $key);
            $value = $array;
            foreach ($parts as $part) {
                if (!is_array($value) || !array_key_exists($part, $value)) { $value = null; break; }
                $value = $value[$part];
            }
            if ($value !== null && $value !== '') { return is_scalar($value) ? (string) $value : ''; }
        }
        return '';
    }

    private function render_crypto_checkout_panel($phone, $plan_id, $country_id, $price)
    {
        ob_start();
        echo '<form method="post" class="ipsvp-crypto-pay-box">';
        wp_nonce_field('ipsvp_submit_crypto_payment');
        echo '<input type="hidden" name="ipsvp_action" value="submit_crypto_payment"><input type="hidden" name="ipsvp_submission_key" value="' . esc_attr($this->new_submission_key('crypto-pay-')) . '"><input type="hidden" name="phone" value="' . esc_attr($phone) . '"><input type="hidden" name="plan_id" value="' . esc_attr($plan_id) . '"><input type="hidden" name="country_id" value="' . esc_attr($country_id) . '">';
        echo '<button class="ipsvp-btn" type="submit">پرداخت با کریپتو</button>';
        echo '</form>';
        return array(
            'description' => 'بعد از ثبت، به صفحه پرداخت رمزینو منتقل می‌شوید. پس از پرداخت موفق، سفارش بررسی و کانفیگ ساخته می‌شود.',
            'summary' => array(
                array('label' => 'مبلغ سفارش', 'value' => number_format_i18n($price) . ' تومان'),
                array('label' => 'درگاه', 'value' => 'Ramzino Crypto'),
            ),
            'content_html' => ob_get_clean(),
        );
    }

    private function render_invoice()
    {
        if (!wp_verify_nonce(isset($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '', 'ipsvp_buy_step_invoice')) {
            return '<div class="ipsvp-alert">درخواست نامعتبر است.</div>';
        }
        $phone = $this->get_logged_phone();
        if (!$phone) {
            return $this->render_config_login_required_notice();
        }
        $plan_id = isset($_POST['plan_id']) ? (int) $_POST['plan_id'] : 0;
        $country_id = isset($_POST['country_id']) ? (int) $_POST['country_id'] : 0;
        $plan = $this->db->get_plan($plan_id);
        $service_type = $plan ? $this->db->normalize_service_type($plan->service_type ?? 'shared') : 'shared';
        $is_all_countries = $this->db->is_all_countries_selection($country_id);
        $country = $is_all_countries ? null : $this->db->get_country($country_id);
        if (!$phone || !$plan || (!$is_all_countries && !$country)) {
            return '<div class="ipsvp-alert">اطلاعات فاکتور نامعتبر است.</div>';
        }
        if (!$this->db->service_sales_enabled($service_type)) {
            return '<div class="ipsvp-alert">فروش این نوع سرویس در حال حاضر بسته است.</div>';
        }
        if ($country && $this->db->normalize_service_type($country->service_type ?? 'shared') !== $service_type) {
            return '<div class="ipsvp-alert">پلن و کشور انتخاب‌شده هم‌نوع نیستند.</div>';
        }
        if ($service_type === 'dedicated' && $is_all_countries) {
            return '<div class="ipsvp-alert">برای سرویس اختصاصی باید یک کشور مشخص انتخاب شود.</div>';
        }
        if ($service_type === 'shared' && $is_all_countries && !$this->db->all_countries_group_ready()) {
            return '<div class="ipsvp-alert">برای گزینه همه کشورها، گروه پاسارگارد مخصوص همه کشورها در تنظیمات انتخاب نشده است.</div>';
        }
        $settings = IPSVP_Settings::get();
        $price = $is_all_countries ? $this->db->all_countries_price($plan) : $this->db->final_price($plan);
        $country_title = $is_all_countries ? '🌍 همه کشورها' : ($country->flag . ' ' . $country->name);
        $panel_user = $this->db->get_or_create_user($phone);
        ob_start();
        echo '<div class="ipsvp-box ipsvp-invoice ipsvp-checkout-flow">';
        echo '<h3>۳. فاکتور و روش پرداخت</h3>';
        echo '<div class="ipsvp-invoice-grid"><div><span>شماره موبایل</span><b>' . esc_html($phone) . '</b></div><div><span>پلن</span><b>' . esc_html($plan->title) . '</b></div><div><span>کشور</span><b>' . esc_html($country_title) . '</b></div><div><span>مبلغ قابل پرداخت</span><b>' . esc_html(number_format_i18n($price)) . ' تومان</b></div></div>';
        $wallet_label = 'کیف پول سایت';
        $balance = 0;
        $has_wallet_method = false;
        $wallet_error = '';
        if ($panel_user) {
            $has_wallet_method = true;
            $wallet = $this->wallet_payment_info($phone);
            $balance = isset($wallet['balance']) ? (int) $wallet['balance'] : 0;
            $wallet_label = !empty($wallet['label']) ? (string) $wallet['label'] : $wallet_label;
            $wallet_error = empty($wallet['ok']) ? (!empty($wallet['message']) ? (string) $wallet['message'] : 'همگام سازی کیف پول ناموفق بود.') : '';
        }

        $methods = array();
        if ($this->payment_method_enabled('card')) {
            $methods[] = array('id' => 'card', 'title' => 'کارت به کارت', 'desc' => 'ارسال رسید پرداخت');
        }
        if ($this->payment_method_enabled('wallet') && $has_wallet_method) {
            $methods[] = array('id' => 'wallet', 'title' => 'کیف پول', 'desc' => number_format_i18n($balance) . ' تومان');
        }
        if ($this->crypto_available()) {
            $methods[] = array('id' => 'crypto', 'title' => 'کریپتو', 'desc' => 'پرداخت رمزینو');
        }
        if (!$methods) {
            echo '<div class="ipsvp-alert">در حال حاضر هیچ روش پرداختی برای این سفارش فعال نیست.</div></div>';
            return ob_get_clean();
        }
        $default_method = $methods[0]['id'];
        echo '<div class="ipsvp-renew-divider"><span>روش پرداخت را انتخاب کنید</span></div>';
        $panel_configs = array();
        if ($this->payment_method_enabled('card')) {
            ob_start();
            echo '<form method="post" enctype="multipart/form-data">';
            wp_nonce_field('ipsvp_submit_receipt');
            echo '<input type="hidden" name="ipsvp_action" value="submit_receipt"><input type="hidden" name="ipsvp_submission_key" value="' . esc_attr($this->new_submission_key('buy-')) . '"><input type="hidden" name="phone" value="' . esc_attr($phone) . '"><input type="hidden" name="plan_id" value="' . esc_attr($plan_id) . '"><input type="hidden" name="country_id" value="' . esc_attr($country_id) . '">';
            echo $this->render_bank_details($settings);
            echo IPSVP_Receipt_Uploader::render_field('receipt', 'رسید پرداخت کارت به کارت', true);
            echo '<button class="ipsvp-btn" type="submit">ثبت سفارش و ارسال رسید</button>';
            echo '</form>';
            $panel_configs['card'] = array(
                'description' => 'ابتدا اطلاعات کارت را مشاهده کنید، مبلغ فاکتور را واریز کنید و سپس تصویر رسید را ارسال کنید.',
                'summary' => array(array('label' => 'مبلغ سفارش', 'value' => number_format_i18n($price) . ' تومان')),
                'content_html' => ob_get_clean(),
            );
        }

        if ($this->payment_method_enabled('wallet') && $has_wallet_method) {
            ob_start();
            echo '<form method="post" class="ipsvp-wallet-pay-box">';
            wp_nonce_field('ipsvp_submit_wallet_payment');
            echo '<input type="hidden" name="ipsvp_action" value="submit_wallet_payment"><input type="hidden" name="ipsvp_submission_key" value="' . esc_attr($this->new_submission_key('wallet-pay-')) . '"><input type="hidden" name="phone" value="' . esc_attr($phone) . '"><input type="hidden" name="plan_id" value="' . esc_attr($plan_id) . '"><input type="hidden" name="country_id" value="' . esc_attr($country_id) . '">';
            if ($wallet_error !== '') {
                echo '<div class="ipsvp-alert">' . esc_html($wallet_error) . ' تا زمان برقراری همگام سازی، پرداخت از کیف پول غیرفعال است.</div>';
            } elseif ($balance >= $price) {
                echo '<button class="ipsvp-btn" type="submit">پرداخت فوری با کیف پول</button>';
            } else {
                echo '<div class="ipsvp-alert">موجودی کیف پول برای این سفارش کافی نیست.</div><a class="ipsvp-secondary ipsvp-renew-charge-link" href="' . esc_url($this->dashboard_wallet_url()) . '">شارژ کیف پول</a>';
            }
            echo '</form>';
            $panel_configs['wallet'] = array(
                'title' => 'پرداخت با کیف پول',
                'summary' => array(
                    array('label' => $wallet_label, 'value' => number_format_i18n($balance) . ' تومان'),
                    array('label' => 'مبلغ سفارش', 'value' => number_format_i18n($price) . ' تومان'),
                ),
                'content_html' => ob_get_clean(),
            );
        }
        if ($this->crypto_available()) {
            $panel_configs['crypto'] = $this->render_crypto_checkout_panel($phone, $plan_id, $country_id, $price);
        }
        if (class_exists('IPSPM_Payment_Manager')) {
            echo IPSPM_Payment_Manager::render_payment_box(array(
                'context' => 'ip-sabet',
                'input_name' => 'ipsvp_checkout_payment_method',
                'methods' => $methods,
                'panel_configs' => $panel_configs,
                'default' => $default_method,
                'class' => 'ipsvp-checkout-payment-switcher',
            ));
        } else {
            echo '<div class="ipsvp-alert">افزونه مدیریت پرداخت‌ها فعال نیست.</div>';
        }
        echo '</div>';
        return ob_get_clean();
    }

    private function render_bank_box($settings)
    {
        if (class_exists('IPSPM_Payment_Manager')) {
            return IPSPM_Payment_Manager::render_bank_box();
        }
        $note = isset($settings['bank_note']) ? trim((string) $settings['bank_note']) : '';
        ob_start();
        echo '<div class="ipsvp-bank"><h4>اطلاعات کارت به کارت</h4>';
        echo '<p><strong>شماره کارت:</strong> <code>' . esc_html($settings['bank_card']) . '</code></p>';
        echo '<p><strong>نام صاحب حساب:</strong> ' . esc_html($settings['bank_account_name']) . '</p>';
        echo '<p><strong>شبا:</strong> <code>' . esc_html($settings['bank_iban']) . '</code></p>';
        if ($note !== '') {
            echo '<div class="ipsvp-bank-note">' . nl2br(esc_html($note)) . '</div>';
        }
        echo '</div>';
        return ob_get_clean();
    }

    private function render_bank_details($settings, $summary = 'مشاهده اطلاعات کارت')
    {
        if (class_exists('IPSPM_Payment_Manager')) {
            return IPSPM_Payment_Manager::render_bank_details($summary);
        }
        ob_start();
        echo '<details class="ipsvp-bank-details"><summary><span class="ipsvp-bank-summary-text"><strong>' . esc_html($summary) . '</strong><small>برای نمایش شماره کارت و توضیحات پرداخت کلیک کنید</small></span><span class="ipsvp-bank-summary-arrow" aria-hidden="true">⌄</span></summary>';
        echo $this->render_bank_box($settings);
        echo '</details>';
        return ob_get_clean();
    }

    private function handle_receipt_submission()
    {
        $reseller_notice = IPSVP_Reseller::wallet_only_notice((int) ($_POST['plan_id'] ?? 0));
        if ($reseller_notice !== '') { return $reseller_notice; }
        if (!$this->payment_method_enabled('card')) {
            return '<div class="ipsvp-alert">پرداخت کارت به کارت در حال حاضر غیرفعال است.</div>';
        }
        if (!wp_verify_nonce(isset($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '', 'ipsvp_submit_receipt')) {
            return '<div class="ipsvp-alert">درخواست نامعتبر است.</div>';
        }
        $phone = $this->get_logged_phone();
        if (!$phone) {
            return $this->render_config_login_required_notice();
        }
        $plan_id = isset($_POST['plan_id']) ? (int) $_POST['plan_id'] : 0;
        $country_id = isset($_POST['country_id']) ? (int) $_POST['country_id'] : 0;
        $submission_key = isset($_POST['ipsvp_submission_key']) ? $this->db->sanitize_submission_key(wp_unslash($_POST['ipsvp_submission_key'])) : '';
        if ($submission_key) {
            $existing_order = $this->db->get_order_by_submission_key($submission_key);
            if ($existing_order) {
                return $this->redirect_or_script($this->current_page_url(array('ipsvp_order_done' => $existing_order->id)));
            }
        }
        if ($phone && $this->db->is_user_blocked($phone)) {
            return '<div class="ipsvp-alert">این شماره توسط مدیریت مسدود شده و امکان ثبت سفارش ندارد.</div>';
        }
        $user = $this->db->get_or_create_user($phone);
        $upload = $user ? IPSVP_Receipt_Uploader::uploaded_from_request('receipt', (int) $user->id) : null;
        if ($upload === null) {
            if (empty($_FILES['receipt']['name'])) {
                return '<div class="ipsvp-alert">لطفا فایل رسید را آپلود کنید.</div>';
            }
            $upload = $this->upload_receipt($_FILES['receipt'], 'receipt');
        }
        if (is_wp_error($upload)) {
            return '<div class="ipsvp-alert">' . esc_html($upload->get_error_message()) . '</div>';
        }
        $order = $this->db->create_order($phone, $plan_id, $country_id, $upload['attachment_id'], $upload['url'], $submission_key);
        if (is_wp_error($order)) {
            return '<div class="ipsvp-alert">' . esc_html($order->get_error_message()) . '</div>';
        }
        $this->set_login_cookie($phone);
        return $this->redirect_or_script($this->current_page_url(array('ipsvp_order_done' => $order->id)));
    }


    private function handle_wallet_order_payment()
    {
        $reseller = IPSVP_Reseller::legacy_wallet('purchase', $this->get_logged_phone(), 'ipsvp_submit_wallet_payment', array('plan_id' => (int) ($_POST['plan_id'] ?? 0), 'country_id' => (int) ($_POST['country_id'] ?? 0)));
        if ($reseller !== null) { return $reseller; }
        if (!$this->payment_method_enabled('wallet')) {
            return '<div class="ipsvp-alert">پرداخت کیف پول در حال حاضر غیرفعال است.</div>';
        }
        if (!wp_verify_nonce(isset($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '', 'ipsvp_submit_wallet_payment')) {
            return '<div class="ipsvp-alert">درخواست پرداخت کیف پول نامعتبر است.</div>';
        }
        $phone = $this->get_logged_phone();
        if (!$phone) {
            return $this->render_config_login_required_notice();
        }
        $plan_id = isset($_POST['plan_id']) ? (int) $_POST['plan_id'] : 0;
        $country_id = isset($_POST['country_id']) ? (int) $_POST['country_id'] : 0;
        $submission_key = isset($_POST['ipsvp_submission_key']) ? $this->db->sanitize_submission_key(wp_unslash($_POST['ipsvp_submission_key'])) : '';
        if ($submission_key) {
            $existing_order = $this->db->get_order_by_submission_key($submission_key);
            if ($existing_order) {
                return $this->redirect_or_script($this->current_page_url(array('ipsvp_order_done' => $existing_order->id)));
            }
        }
        $user = $this->db->get_user_by_phone($phone);
        if (!$user) {
            return '<div class="ipsvp-alert">کاربر پیدا نشد.</div>';
        }
        $plan = $this->db->get_plan($plan_id);
        if (!$plan) {
            return '<div class="ipsvp-alert">پلن انتخابی پیدا نشد.</div>';
        }
        $price = $this->db->is_all_countries_selection($country_id) ? $this->db->all_countries_price($plan) : $this->db->final_price($plan);
        $wallet = $this->wallet_payment_info($phone);
        if (empty($wallet['ok'])) {
            return '<div class="ipsvp-alert">' . esc_html(!empty($wallet['message']) ? $wallet['message'] : 'دریافت موجودی کیف پول ناموفق بود.') . '</div>';
        }
        if ((int) $wallet['balance'] < (int) $price) {
            return '<div class="ipsvp-alert">موجودی کیف پول برای این سفارش کافی نیست.</div>';
        }
        $wallet_effect = !empty($wallet['is_bot']) ? 'remote' : 'local';
        $order = $this->db->create_wallet_paid_order($phone, $plan_id, $country_id, $submission_key, $wallet_effect);
        if (is_wp_error($order)) {
            return '<div class="ipsvp-alert">' . esc_html($order->get_error_message()) . '</div>';
        }
        if (!empty($user->bot_tel_id)) {
            $debit = IPSVP_Bot_API::debit_wallet($user->bot_tel_id, (int) $order->price, $order->order_code, $phone);
            if (is_wp_error($debit) || empty($debit['ok'])) {
                $msg = is_wp_error($debit) ? $debit->get_error_message() : (!empty($debit['message']) ? $debit['message'] : 'موجودی کیف پول کافی نیست یا پرداخت کیف پول خطا داد.');
                $this->db->update_order($order->id, array('status' => 'failed', 'payment_status' => 'wallet_failed', 'admin_note' => $msg));
                $this->db->add_log('error', 'wallet_order_payment', $msg, array('order_id' => $order->id, 'bot_response' => $debit), $phone, $order->id, 0, $order->user_id);
                return '<div class="ipsvp-alert">' . esc_html($msg) . '</div>';
            }
        }
        if ($this->db->order_service_type($order) === 'dedicated') {
            $this->db->update_order($order->id, array(
                'status' => 'awaiting_assignment',
                'payment_status' => 'approved',
                'approved_at' => $this->db->now(),
            ));
            $this->db->create_user_notification((int) $order->user_id, $phone, 'پرداخت سفارش اختصاصی تایید شد', 'پرداخت سفارش شما تایید شد و سرویس در انتظار اتصال سرویس توسط مدیریت است.', 'order', (int) $order->id);
            IPSVP_Telegram_Service::send_telegram_order_success_report((int) $order->id, $this->db, 'wallet');
            $this->set_login_cookie($phone);
            return $this->redirect_or_script($this->current_page_url(array('ipsvp_order_done' => $order->id)));
        }
        $created = ((int) $order->country_id === 0) ? $this->api->create_users_for_all_countries_order($order, $this->db->ready_countries()) : $this->api->create_user_for_order($order);
        if (is_wp_error($created)) {
            $this->db->update_order($order->id, array('status' => 'failed', 'payment_status' => 'wallet_paid', 'admin_note' => $created->get_error_message(), 'approved_at' => $this->db->now()));
            $this->db->add_log('error', 'wallet_create_config', $created->get_error_message(), array('order_id' => $order->id), $phone, $order->id, 0, $order->user_id);
            return '<div class="ipsvp-alert">کیف پول کسر شد اما ساخت کانفیگ خطا داد. این مورد در لاگ ادمین ثبت شد: ' . esc_html($created->get_error_message()) . '</div>';
        }
        $this->db->update_order($order->id, array(
            'status' => !empty($created['status']) && (string) $created['status'] === 'active' ? 'active' : 'on_hold',
            'payment_status' => 'approved',
            'pg_username' => $created['username'],
            'pg_user_id' => $created['user_id'],
            'pg_status' => !empty($created['status']) ? $created['status'] : 'on_hold',
            'pg_subscription_url' => $created['subscription_url'],
            'pg_links' => wp_json_encode($created['links']),
            'pg_response' => wp_json_encode($created['raw']),
            'approved_at' => $this->db->now(),
        ));
        $imported = IPSVP_Bot_API::import_site_order($this->db->get_order($order->id));
        if (is_wp_error($imported)) {
            $this->db->add_log('warning', 'bot_import_site_order', $imported->get_error_message(), array('order_id' => $order->id), $phone, $order->id, 0, $order->user_id);
        }
        // Standard integration hook for add-ons. Fires only after wallet-paid service/config purchases are created.
        do_action('ips_config_order_approved', (int) $order->id, (int) $order->user_id, $this->db->get_order($order->id));
        IPSVP_Telegram_Service::send_telegram_order_success_report((int) $order->id, $this->db, 'wallet');
        $this->set_login_cookie($phone);
        return $this->redirect_or_script($this->current_page_url(array('ipsvp_order_done' => $order->id)));
    }


    private function handle_crypto_order_payment()
    {
        $reseller_notice = IPSVP_Reseller::wallet_only_notice((int) ($_POST['plan_id'] ?? 0));
        if ($reseller_notice !== '') { return $reseller_notice; }
        if (!$this->crypto_available()) { return '<div class="ipsvp-alert">درگاه کریپتو فعال نیست.</div>'; }
        if (!wp_verify_nonce(isset($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '', 'ipsvp_submit_crypto_payment')) {
            return '<div class="ipsvp-alert">درخواست پرداخت کریپتو نامعتبر است.</div>';
        }
        $phone = $this->get_logged_phone();
        if (!$phone) {
            return $this->render_config_login_required_notice();
        }
        $plan_id = isset($_POST['plan_id']) ? (int) $_POST['plan_id'] : 0;
        $country_id = isset($_POST['country_id']) ? (int) $_POST['country_id'] : 0;
        $submission_key = isset($_POST['ipsvp_submission_key']) ? $this->db->sanitize_submission_key(wp_unslash($_POST['ipsvp_submission_key'])) : '';
        $created = $this->db->create_crypto_pending_order($phone, $plan_id, $country_id, $submission_key);
        if (is_wp_error($created)) { return '<div class="ipsvp-alert">' . esc_html($created->get_error_message()) . '</div>'; }
        $order = $created['order']; $receipt = $created['receipt'];
        if (!$order || !$receipt) { return '<div class="ipsvp-alert">ثبت سفارش کریپتو ناموفق بود.</div>'; }
        $invoice = $this->ramzino_create_invoice_for_receipt($receipt, $order->order_code, 'IP Sabet order ' . $order->order_code, array('ipsvp_order_id' => (int) $order->id));
        if (is_wp_error($invoice)) {
            $this->db->update_order($order->id, array('status' => 'failed', 'payment_status' => 'crypto_failed', 'admin_note' => $invoice->get_error_message()));
            return '<div class="ipsvp-alert">' . esc_html($invoice->get_error_message()) . '</div>';
        }
        return $this->redirect_or_script($invoice['url']);
    }

    private function ramzino_request_param($keys)
    {
        static $json = null;
        if ($json === null) {
            $json = array();
            $raw = file_get_contents('php://input');
            if (is_string($raw) && trim($raw) !== '') {
                $decoded = json_decode($raw, true);
                $json = is_array($decoded) ? $decoded : array();
            }
        }
        foreach ((array) $keys as $key) {
            if (isset($_GET[$key])) {
                return sanitize_text_field(wp_unslash($_GET[$key]));
            }
            if (isset($_POST[$key])) {
                return sanitize_text_field(wp_unslash($_POST[$key]));
            }
            if (isset($json[$key]) && is_scalar($json[$key])) {
                return sanitize_text_field((string) $json[$key]);
            }
        }
        return '';
    }

    private function find_ramzino_receipt_from_request()
    {
        global $wpdb;
        $t = $this->db->tables();
        $receipt_id = (int) $this->ramzino_request_param(array('receipt_id', 'ipsvp_receipt_id'));
        if ($receipt_id > 0) {
            $receipt = $this->db->get_receipt($receipt_id);
            if ($receipt && $receipt->remote_source === 'ramzino') { return $receipt; }
        }
        $order_code = $this->ramzino_request_param(array('order_id', 'orderId', 'ipsvp_order_code'));
        if ($order_code !== '') {
            if (preg_match('/^(?:WALLET|RENEW|BOT-RENEW|EXTRA-VOLUME)-(\d+)$/i', $order_code, $m)) {
                $receipt = $this->db->get_receipt((int) $m[1]);
                if ($receipt && $receipt->remote_source === 'ramzino') { return $receipt; }
            }
            $receipt = $wpdb->get_row($wpdb->prepare("SELECT r.* FROM {$t['receipts']} r INNER JOIN {$t['orders']} o ON o.id=r.order_id WHERE o.order_code=%s AND r.remote_source='ramzino' ORDER BY r.id DESC LIMIT 1", $order_code));
            if ($receipt) { return $receipt; }
        }
        $uuid = $this->ramzino_request_param(array('uuid', 'invoice_uuid'));
        if ($uuid !== '') {
            $like = '%' . $wpdb->esc_like($uuid) . '%';
            $receipt = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['receipts']} WHERE remote_source='ramzino' AND remote_payload LIKE %s ORDER BY id DESC LIMIT 1", $like));
            if ($receipt) { return $receipt; }
        }
        return null;
    }

    private function merge_ramzino_payload($receipt, array $append)
    {
        global $wpdb;
        $t = $this->db->tables();
        $old = !empty($receipt->remote_payload) ? json_decode((string) $receipt->remote_payload, true) : array();
        if (!is_array($old)) { $old = array('previous_raw' => (string) $receipt->remote_payload); }
        $old['last_callback'] = $append;
        $wpdb->update($t['receipts'], array('remote_payload' => wp_json_encode($old, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)), array('id' => (int) $receipt->id));
    }

    private function render_crypto_result($success, $title, $message, $actions = array())
    {
        $success = (bool) $success;
        $icon = $success ? '✓' : '×';
        $class = $success ? 'is-success' : 'is-failed';
        ob_start();
        echo '<div class="ipsvp-crypto-result ' . esc_attr($class) . '" dir="rtl">';
        echo '<div class="ipsvp-crypto-result-icon">' . esc_html($icon) . '</div>';
        echo '<h2>' . esc_html($title) . '</h2>';
        echo '<p>' . esc_html($message) . '</p>';
        if (!empty($actions)) {
            echo '<div class="ipsvp-crypto-result-actions">';
            foreach ($actions as $a) {
                if (empty($a['url']) || empty($a['label'])) { continue; }
                $btn_class = !empty($a['secondary']) ? 'ipsvp-secondary ipsvp-link-btn' : 'ipsvp-btn';
                echo '<a class="' . esc_attr($btn_class) . '" href="' . esc_url($a['url']) . '">' . esc_html($a['label']) . '</a>';
            }
            echo '</div>';
        }
        echo '</div>';
        return ob_get_clean();
    }

    private function handle_crypto_failed()
    {
        $receipt = $this->find_ramzino_receipt_from_request();
        if (!$receipt || $receipt->remote_source !== 'ramzino') {
            return $this->render_crypto_result(false, 'پرداخت ناموفق بود', 'پرداخت کریپتو پیدا نشد یا اطلاعات بازگشت ناقص است.', array(
                array('label' => 'بازگشت به خرید', 'url' => $this->shop_page_url()),
            ));
        }
        if ((string) $receipt->status === 'approved') {
            return $this->render_crypto_result(true, 'پرداخت قبلاً تایید شده است', 'این پرداخت قبلاً تأیید و درخواست مربوط به آن انجام شده است.', array(
                array('label' => 'ورود به پنل کاربری', 'url' => $this->panel_page_url()),
            ));
        }
        global $wpdb;
        $t = $this->db->tables();
        $incoming_status = $this->ramzino_request_param(array('status', 'payment_status', 'final'));
        $payload = !empty($receipt->remote_payload) ? json_decode((string) $receipt->remote_payload, true) : array();
        $uuid = is_array($payload) ? $this->array_find($payload, array('_ipsvp.uuid','uuid','data.uuid')) : '';
        if ($uuid === '') {
            $uuid = $this->ramzino_request_param(array('uuid', 'invoice_uuid'));
        }
        if ($uuid === '') {
            return $this->render_crypto_result(false, 'بررسی پرداخت ممکن نیست', 'شناسه فاکتور رمزینو پیدا نشد و وضعیت رسید تغییر نکرد.', array(
                array('label' => 'بازگشت به خرید', 'url' => $this->shop_page_url()),
            ));
        }
        $detail = $this->ramzino_payment_detail($uuid);
        if (is_wp_error($detail)) {
            return $this->render_crypto_result(false, 'بررسی پرداخت ممکن نیست', 'ارتباط با رمزینو برای تأیید وضعیت انجام نشد؛ وضعیت رسید تغییر نکرد.', array(
                array('label' => 'بررسی دوباره', 'url' => $this->current_page_url(array('ipsvp_crypto_success' => 1, 'receipt_id' => (int) $receipt->id))),
            ));
        }
        $status = class_exists('IPSPM_Payment_Manager')
            ? IPSPM_Payment_Manager::payment_status($detail)
            : ((class_exists('RCG_Helpers') && method_exists('RCG_Helpers', 'normalize_payment_status'))
                ? RCG_Helpers::normalize_payment_status($detail)
                : $this->array_find(is_array($detail) ? $detail : array(), array('payment_status','data.payment_status','status','data.status')));
        $this->merge_ramzino_payload($receipt, array(
            'type' => 'fail',
            'status' => $incoming_status,
            'verified_status' => $status,
            'detail' => $detail,
            'uuid' => $uuid,
            'order_id' => $this->ramzino_request_param(array('order_id', 'orderId')),
            'at' => $this->db->now(),
        ));
        if ($this->crypto_status_is_paid($status)) {
            $approved = IPSVP_Receipt_Manager::approve((int) $receipt->id, $this->db, $this->api);
            if (empty($approved['ok'])) {
                return '<div class="ipsvp-alert">پرداخت تایید شد اما بروزرسانی درخواست خطا داد: ' . esc_html(!empty($approved['message']) ? $approved['message'] : 'خطای نامشخص') . '</div>';
            }
            return $this->render_crypto_result(true, 'پرداخت موفق بود', 'وضعیت پرداخت مستقیماً از رمزینو تأیید و درخواست شما انجام شد.', array(
                array('label' => 'ورود به پنل کاربری', 'url' => $this->panel_page_url()),
            ));
        }
        if (!$this->crypto_status_is_failed($status)) {
            return $this->render_crypto_result(false, 'پرداخت هنوز نهایی نشده است', 'رمزینو هنوز پرداخت را ناموفق یا موفق اعلام نکرده است؛ وضعیت رسید تغییر نکرد.', array(
                array('label' => 'بررسی دوباره', 'url' => $this->current_page_url(array('ipsvp_crypto_success' => 1, 'receipt_id' => (int) $receipt->id))),
            ));
        }
        if ($receipt->status !== 'approved') {
            $wpdb->update($t['receipts'], array('status' => 'failed', 'reviewed_at' => $this->db->now(), 'admin_note' => 'پرداخت کریپتو ناموفق یا لغو شد.'), array('id' => (int) $receipt->id));
            if (!empty($receipt->order_id)) {
                $order = $this->db->get_order((int) $receipt->order_id);
                if ($order && in_array((string) $order->status, array('crypto_pending','pending_receipt','failed'), true)) {
                    $this->db->update_order((int) $order->id, array('status' => 'failed', 'payment_status' => 'crypto_failed', 'admin_note' => 'پرداخت کریپتو ناموفق یا لغو شد.'));
                }
            }
        }
        return $this->render_crypto_result(false, 'پرداخت ناموفق بود', 'پرداخت کریپتو لغو شد یا توسط رمزینو ناموفق اعلام شد. در صورت کسر وجه، با پشتیبانی در ارتباط باشید.', array(
            array('label' => 'تلاش مجدد / خرید جدید', 'url' => $this->shop_page_url()),
            array('label' => 'ورود به پنل کاربری', 'url' => $this->panel_page_url(), 'secondary' => true),
        ));
    }

    private function handle_crypto_return()
    {
        $receipt = $this->find_ramzino_receipt_from_request();
        if (!$receipt || $receipt->remote_source !== 'ramzino') {
            return '<div class="ipsvp-alert">پرداخت کریپتو پیدا نشد.</div>';
        }
        $receipt_id = (int) $receipt->id;
        $payload = !empty($receipt->remote_payload) ? json_decode((string) $receipt->remote_payload, true) : array();
        $uuid = '';
        if (is_array($payload)) {
            $uuid = $this->array_find($payload, array('_ipsvp.uuid','uuid','data.uuid'));
        }
        if (!$uuid) { $uuid = $this->ramzino_request_param(array('uuid', 'invoice_uuid')); }
        $incoming_status = $this->ramzino_request_param(array('status', 'payment_status', 'final'));
        $detail = $this->ramzino_payment_detail($uuid);
        if (is_wp_error($detail)) {
            return '<div class="ipsvp-alert">بررسی وضعیت پرداخت کریپتو ناموفق بود: ' . esc_html($detail->get_error_message()) . '</div>';
        }
        $status = class_exists('IPSPM_Payment_Manager')
            ? IPSPM_Payment_Manager::payment_status($detail)
            : ((class_exists('RCG_Helpers') && method_exists('RCG_Helpers', 'normalize_payment_status'))
                ? RCG_Helpers::normalize_payment_status($detail)
                : $this->array_find(is_array($detail) ? $detail : array(), array('payment_status','data.payment_status','status','data.status')));
        global $wpdb;
        $t = $this->db->tables();
        $stored = is_array($payload) ? $payload : array();
        $stored['detail'] = $detail;
        $stored['last_callback'] = array(
            'type' => 'success',
            'status' => $incoming_status,
            'uuid' => $uuid,
            'order_id' => $this->ramzino_request_param(array('order_id', 'orderId')),
            'at' => $this->db->now(),
        );
        $wpdb->update($t['receipts'], array('remote_payload' => wp_json_encode($stored, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)), array('id' => $receipt_id));
        if (!$this->crypto_status_is_paid($status)) {
            if ($this->crypto_status_is_failed($status)) {
                return $this->handle_crypto_failed();
            }
            return '<div class="ipsvp-box"><h3>پرداخت هنوز تایید نشده است</h3><div class="ipsvp-alert">وضعیت فعلی پرداخت: ' . esc_html($status ? $status : 'نامشخص') . '</div><a class="ipsvp-btn" href="' . esc_url($this->current_page_url(array('ipsvp_crypto_success' => 1, 'receipt_id' => $receipt_id))) . '">بررسی دوباره پرداخت</a></div>';
        }
        $approved = IPSVP_Receipt_Manager::approve($receipt_id, $this->db, $this->api);
        if (empty($approved['ok'])) {
            return '<div class="ipsvp-alert">پرداخت تایید شد اما بروزرسانی سفارش خطا داد: ' . esc_html(!empty($approved['message']) ? $approved['message'] : 'خطای نامشخص') . '</div>';
        }
        if (!empty($approved['order_id']) && !empty($approved['receipt_type']) && in_array($approved['receipt_type'], array('extra_volume','wallet_extra_volume'), true)) {
            return $this->redirect_or_script($this->current_page_url(array('ipsvp_tab' => 'detail', 'ipsvp_order_id' => (int) $approved['order_id'], 'ipsvp_extra_volume_done' => $receipt_id)));
        }
        if (!empty($approved['order_id'])) {
            return $this->redirect_or_script($this->current_page_url(array('ipsvp_order_done' => (int) $approved['order_id'])));
        }
        return $this->render_crypto_result(true, 'پرداخت موفق بود', 'پرداخت کریپتو تایید شد و درخواست شما با موفقیت انجام شد.', array(
            array('label' => 'ورود به پنل کاربری', 'url' => $this->panel_page_url()),
            array('label' => 'خرید جدید', 'url' => $this->shop_page_url(), 'secondary' => true),
        ));
    }

    private function upload_receipt($file, $input_name = 'receipt')
    {
        $phone = method_exists($this, 'get_logged_phone') ? $this->get_logged_phone() : '';
        if (!$phone && !empty($_POST['phone'])) {
            $phone = $this->db->normalize_phone(wp_unslash($_POST['phone']));
        }
        $user = $phone ? $this->db->get_user_by_phone($phone) : null;
        return IPSVP_Receipt_Uploader::upload(
            $file,
            $user ? (int) $user->id : 0,
            $phone,
            IPSVP_Receipt_Uploader::request_upload_key($input_name)
        );
    }

    private function set_login_cookie($phone)
    {
        IPSVP_Session::set($phone, $this->db);
    }

    private function clear_login_cookie()
    {
        IPSVP_Session::clear();
    }

    private function get_logged_phone()
    {
        return IPSVP_Session::get_phone($this->db);
    }

    private function localize_panel_notifications($phone)
    {
        wp_localize_script('ipsvp-front', 'IPSVP_PANEL_NOTIFICATIONS', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ipsvp_panel_notifications'),
            'poll_interval' => 30000,
            'unread_count' => $this->db->count_unread_notifications($phone),
            'notification_counts' => apply_filters('ipsvp_panel_notification_counts', array(
                'orders' => $this->db->count_unread_notifications($phone, 'order'),
            ), $phone, $this->db),
            'sound' => true,
            'min_created_at' => !empty($_GET['ipsvp_order_done']) ? current_time('timestamp') : 0,
        ));
    }

    private function localize_panel_login()
    {
        wp_localize_script('ipsvp-front', 'IPSVP_PANEL_LOGIN', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ipsvp_panel_login_ajax'),
            'loading' => 'لطفا صبر کنید...',
            'network_error' => 'ارتباط با سرور برقرار نشد. دوباره تلاش کنید.',
        ));
    }

    private function current_page_url($args = array())
    {
        $url = get_permalink(get_queried_object_id());
        if (!$url && !empty($_SERVER['REQUEST_URI'])) {
            $url = home_url(wp_unslash($_SERVER['REQUEST_URI']));
        }
        $url = remove_query_arg(array('ipsvp_tab', 'ipsvp_order_id', 'ipsvp_bot_order_id', 'ips_action', 'ipsvp_order_done', 'ipsvp_renewal_done', 'ipsvp_wallet_renewal_done', 'ipsvp_extra_volume_done', 'ipsvp_bot_wallet_renewal_done', 'ipsvp_receipt_id', 'ipsvp_type', 'ipsvp_selected_plan', 'ipsvp_crypto_return', 'ipsvp_crypto_status', 'ipsvp_crypto_success', 'ipsvp_crypto_fail', 'ipsvp_crypto_failed', 'receipt_id', 'uuid', 'order_id', 'status', 'final'), $url);
        return $args ? add_query_arg($args, $url) : $url;
    }

    private function new_submission_key($prefix = '')
    {
        return sanitize_key($prefix . wp_generate_uuid4());
    }

    private function redirect_or_script($url)
    {
        if (class_exists('IPSPM_Payment_Manager')) {
            $redirect = IPSPM_Payment_Manager::redirect_to_gateway($url);
            if (is_wp_error($redirect)) {
                return '<div class="ipsvp-alert">' . esc_html($redirect->get_error_message()) . '</div>';
            }
            return $redirect;
        }
        $url = esc_url_raw((string) $url);
        if (!$url || !preg_match('#^https?://#i', $url)) {
            return '<div class="ipsvp-alert">لینک انتقال معتبر نیست.</div>';
        }
        if (!headers_sent()) {
            wp_redirect($url, 302);
            exit;
        }
        return '<script>window.location.replace(' . wp_json_encode($url) . ');</script><noscript><div class="ipsvp-alert">برای ادامه <a href="' . esc_url($url) . '">اینجا کلیک کنید</a>.</div></noscript>';
    }

    private function render_order_success($order)
    {
        if (!$order) {
            return '<div class="ipsvp-alert">سفارش پیدا نشد.</div>';
        }
        $this->set_login_cookie($order->phone);
        $settings = IPSVP_Settings::get();
        $status_label = $this->db->status_label(!empty($order->status) ? $order->status : 'waiting_review');
        $payment_status = !empty($order->payment_status) ? (string) $order->payment_status : '';
        $order_status = !empty($order->status) ? (string) $order->status : '';
        $payment_method = (strpos($payment_status, 'wallet') !== false || strpos($order_status, 'wallet') !== false) ? 'پرداخت با کیف پول' : 'کارت به کارت';
        if ($payment_method === 'کارت به کارت' && !empty($order->approved_at)) {
            $payment_method = 'کارت به کارت تایید شده';
        }
        $country_text = trim((!empty($order->flag) ? $order->flag . ' ' : '') . (!empty($order->country_name) ? $order->country_name : '-'));
        $plan_text = !empty($order->plan_title) ? $order->plan_title : '-';
        if (!empty($order->gb) || !empty($order->days)) {
            $plan_text .= ' - ' . number_format_i18n((int) $order->gb) . ' گیگ / ' . number_format_i18n((int) $order->days) . ' روز';
        }
        $amount_text = number_format_i18n((int) $order->price) . ' تومان';
        $created_text = !empty($order->created_at) ? mysql2date('Y/m/d - H:i', $order->created_at) : date_i18n('Y/m/d - H:i');
        $orders_url = add_query_arg(array('ipsvp_tab' => 'orders'), $this->panel_page_url());
        $details_url = add_query_arg(array('ipsvp_tab' => 'detail', 'ipsvp_order_id' => (int) $order->id), $this->panel_page_url());
        $new_order_url = $this->shop_page_url();
        $support_url = '';
        if (!empty($settings['telegram_admin'])) {
            $telegram = trim((string) $settings['telegram_admin']);
            $telegram = str_replace(array('https://t.me/', 'http://t.me/', '@'), '', $telegram);
            if ($telegram !== '') {
                $support_url = 'https://t.me/' . rawurlencode($telegram);
            }
        }
        if (!$support_url && !empty($settings['whatsapp_admin'])) {
            $wa = preg_replace('/\D+/', '', (string) $settings['whatsapp_admin']);
            if ($wa) {
                $support_url = 'https://wa.me/' . $wa;
            }
        }
        ob_start();
        ?>
        <div class="ipsvp-order-done" dir="rtl">
            <section class="ipsvp-order-done-hero">
                <div class="ipsvp-order-done-art" aria-hidden="true">
                    <div class="ipsvp-done-stage">
                        <div class="ipsvp-done-spark s1"></div>
                        <div class="ipsvp-done-spark s2"></div>
                        <div class="ipsvp-done-orbit ipsvp-done-orbit-1"></div>
                        <div class="ipsvp-done-orbit ipsvp-done-orbit-2"></div>
                        <div class="ipsvp-done-shield"><span>✓</span></div>
                        <div class="ipsvp-done-platform"></div>
                    </div>
                </div>
                <div class="ipsvp-order-done-copy">
                    <div class="ipsvp-done-title-row">
                        <span class="ipsvp-done-check">✓</span>
                        <h2>سفارش شما ثبت شد</h2>
                    </div>
                    <p>سفارش شما با موفقیت ثبت شد. از اعتماد شما سپاسگزاریم. </p>
                    <div class="ipsvp-done-mini-meta">
                        <div><i>📅</i><span>تاریخ ثبت سفارش</span><strong><?php echo esc_html($created_text); ?></strong></div>
                        <div><i>#</i><span>شماره پیگیری</span><strong><?php echo esc_html($order->order_code); ?></strong></div>
                    </div>
                </div>
            </section>

            <section class="ipsvp-done-section ipsvp-done-summary">
                <div class="ipsvp-done-section-head"><span>خلاصه سفارش</span><i>📋</i></div>
                <div class="ipsvp-done-summary-grid">
                    <div class="ipsvp-done-stat"><span>⧉</span><em>کد سفارش</em><strong class="ltr"><?php echo esc_html($order->order_code); ?></strong></div>
                    <div class="ipsvp-done-stat"><span class="green-dot"></span><em>وضعیت سفارش</em><strong><?php echo esc_html($status_label); ?></strong></div>
                    <div class="ipsvp-done-stat"><span>💳</span><em>روش پرداخت</em><strong><?php echo esc_html($payment_method); ?></strong></div>
                    <div class="ipsvp-done-stat"><span>📦</span><em>پلن انتخابی</em><strong><?php echo esc_html($plan_text); ?></strong></div>
                    <div class="ipsvp-done-stat"><span>📍</span><em>کشور</em><strong><?php echo esc_html($country_text); ?></strong></div>
                    <div class="ipsvp-done-stat"><span>👛</span><em>مبلغ</em><strong><?php echo esc_html($amount_text); ?></strong></div>
                </div>
            </section>

            <div class="ipsvp-done-lower-grid">
                <section class="ipsvp-done-section ipsvp-done-steps">
                    <div class="ipsvp-done-section-head"><span>مراحل بعدی</span><i>☰</i></div>
                    <div class="ipsvp-done-steps-grid">
                        <div class="ipsvp-done-step step-green"><b>۱</b><strong>بررسی رسید</strong><p>رسید پرداخت شما توسط تیم پشتیبانی بررسی می شود.</p></div>
                        <div class="ipsvp-done-step step-blue"><b>۲</b><strong>تایید سفارش</strong><p>پس از تایید، سفارش شما فعال و آماده ارائه سرویس خواهد شد.</p></div>
                        <div class="ipsvp-done-step step-purple"><b>۳</b><strong>نمایش کانفیگ</strong><p>مشاهده کانفیگ، لینک ساب و QR داخل پنل کاربری.</p></div>
                    </div>
                </section>

                <section class="ipsvp-done-section ipsvp-done-notes">
                    <div class="ipsvp-done-section-head"><span>نکات مهم</span><i>ⓘ</i></div>
                    <ul>
                        <li>وضعیت سفارش خود را از بخش <strong>سفارشات من</strong> در پنل کاربری پیگیری کنید.</li>
                        <li>بعد از تایید رسید، کانفیگ و لینک اشتراک داخل جزییات سفارش قرار می گیرد.</li>
                        <li>در صورت نیاز به راهنمایی، از طریق پشتیبانی با ما در ارتباط باشید.</li>
                    </ul>
                </section>

                <section class="ipsvp-done-section ipsvp-done-help">
                    <div class="ipsvp-help-icon">🎧</div>
                    <h3>نیاز به کمک دارید؟</h3>
                    <p>تیم پشتیبانی آماده پاسخگویی به سوالات و راهنمایی شماست.</p>
                    <?php if ($support_url): ?>
                        <a class="ipsvp-btn" href="<?php echo esc_url($support_url); ?>" target="_blank" rel="noopener">تماس با پشتیبانی</a>
                    <?php else: ?>
                        <a class="ipsvp-btn" href="<?php echo esc_url($this->panel_page_url()); ?>">ورود به پنل کاربری</a>
                    <?php endif; ?>
                    <small>پاسخگویی ۲۴/۷</small>
                </section>
            </div>

            <div class="ipsvp-done-actions">
                <a class="ipsvp-btn ipsvp-done-primary" href="<?php echo esc_url($orders_url); ?>">مشاهده سفارشات</a>
                <a class="ipsvp-secondary ipsvp-done-action" href="<?php echo esc_url($new_order_url); ?>">خرید جدید</a>
                <a class="ipsvp-secondary ipsvp-done-action" href="<?php echo esc_url($details_url); ?>">جزییات همین سفارش</a>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    private function panel_page_url()
    {
        $settings = IPSVP_Settings::get();
        if (!empty($settings['dashboard_url'])) {
            return esc_url_raw($settings['dashboard_url']);
        }
        $page = get_page_by_title('پنل کاربری آی پی ثابت', OBJECT, 'page');
        if ($page) {
            return get_permalink($page->ID);
        }
        return $this->current_page_url(array('ipsvp_tab' => 'orders'));
    }

    private function dashboard_wallet_url()
    {
        return add_query_arg(array('ipsvp_tab' => 'wallet'), trailingslashit($this->panel_page_url()));
    }

    public function panel_shortcode()
    {
        wp_enqueue_style('ipsvp-front');
        wp_enqueue_script('ipsvp-front');
        $this->localize_panel_login();
        if (!empty($_GET['ipsvp_crypto_status']) || !empty($_GET['ipsvp_crypto_success']) || !empty($_GET['ipsvp_crypto_return'])) {
            return '<div class="ipsvp ipsvp-panel" dir="rtl">' . $this->handle_crypto_return() . '</div>';
        }
        if (!empty($_GET['ipsvp_crypto_fail']) || !empty($_GET['ipsvp_crypto_failed'])) {
            return '<div class="ipsvp ipsvp-panel" dir="rtl">' . $this->handle_crypto_failed() . '</div>';
        }
        $action = isset($_POST['ipsvp_action']) ? sanitize_key($_POST['ipsvp_action']) : '';
        $message = '';
        $detail_message = '';
        if (!empty($_GET['ipsvp_wallet_renewal_done'])) {
            $detail_message = '<div class="ipsvp-success">تمدید با کیف پول انجام شد و کانفیگ بروزرسانی شد.</div>';
        } elseif (!empty($_GET['ipsvp_extra_volume_done'])) {
            $detail_message = '<div class="ipsvp-success">خرید حجم اضافه با موفقیت ثبت شد و در صورت تایید پرداخت، حجم سرویس بروزرسانی شده است.</div>';
        } elseif (!empty($_GET['ipsvp_renewal_done'])) {
            $detail_message = '<div class="ipsvp-success">درخواست تمدید ثبت شد. بعد از تایید رسید توسط ادمین، همین کانفیگ تمدید می شود.</div>';
        }

        if ($action === 'panel_logout' && wp_verify_nonce(isset($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '', 'ipsvp_panel_logout')) {
            $this->clear_login_cookie();
            return '<div class="ipsvp ipsvp-panel" dir="rtl">' . $this->render_panel_hero() . $this->render_login_form('از حساب کاربری خارج شدید.') . '</div>';
        }
        if ($action === 'panel_login') {
            $login = $this->process_panel_login();
            if (!empty($login['html'])) {
                return '<div class="ipsvp ipsvp-panel" dir="rtl">' . $this->render_panel_hero() . $login['html'] . '</div>';
            }
            if (!empty($login['phone'])) {
                $this->set_login_cookie($login['phone']);
                $message = 'ورود با موفقیت انجام شد.';
            }
        }

        $phone = $this->get_logged_phone();
        if (!$phone) {
            return '<div class="ipsvp ipsvp-panel" dir="rtl">' . $this->render_panel_hero() . $this->render_login_form() . '</div>';
        }

        $panel_user = $this->db->get_or_create_user($phone);
        if ($panel_user && !empty($panel_user->is_blocked)) {
            $this->clear_login_cookie();
            return '<div class="ipsvp ipsvp-panel" dir="rtl">' . $this->render_panel_hero() . $this->render_login_form('حساب کاربری این شماره توسط مدیریت مسدود شده است.') . '</div>';
        }

        if ($action === 'set_panel_password') {
            $message = $this->handle_set_password($phone);
        }
        if ($action === 'generate_bot_link') {
            $message = $this->handle_generate_bot_link($phone);
            $_REQUEST['ipsvp_tab'] = 'profile';
        }
        if ($action === 'submit_wallet_charge') {
            $message = $this->handle_wallet_charge_submission($phone);
            $_REQUEST['ipsvp_tab'] = 'wallet';
        }
        if ($action === 'submit_crypto_wallet_charge') {
            $message = $this->handle_crypto_wallet_charge_submission($phone);
            $_REQUEST['ipsvp_tab'] = 'wallet';
        }

        if ($action === 'submit_renewal_receipt') {
            $detail_message = $this->handle_renewal_submission($phone);
            $_REQUEST['ipsvp_tab'] = 'detail';
        }
        if ($action === 'submit_wallet_renewal') {
            $detail_message = $this->handle_wallet_renewal_submission($phone);
            $_REQUEST['ipsvp_tab'] = 'detail';
        }
        if ($action === 'submit_crypto_renewal') {
            $detail_message = $this->handle_crypto_renewal_submission($phone);
            $_REQUEST['ipsvp_tab'] = 'detail';
        }
        if ($action === 'submit_extra_volume_receipt') {
            $detail_message = $this->handle_extra_volume_submission($phone);
            $_REQUEST['ipsvp_tab'] = 'detail';
        }
        if ($action === 'submit_wallet_extra_volume') {
            $detail_message = $this->handle_wallet_extra_volume_submission($phone);
            $_REQUEST['ipsvp_tab'] = 'detail';
        }
        if ($action === 'submit_crypto_extra_volume') {
            $detail_message = $this->handle_crypto_extra_volume_submission($phone);
            $_REQUEST['ipsvp_tab'] = 'detail';
        }

        if ($action === 'submit_bot_renewal_receipt') {
            $detail_message = $this->handle_bot_renewal_submission($phone);
            $_REQUEST['ipsvp_tab'] = 'bot_detail';
        }
        if ($action === 'submit_bot_wallet_renewal') {
            $detail_message = $this->handle_bot_wallet_renewal_submission($phone);
            $_REQUEST['ipsvp_tab'] = 'bot_detail';
        }
        if ($action === 'submit_bot_crypto_renewal') {
            $detail_message = $this->handle_bot_crypto_renewal_submission($phone);
            $_REQUEST['ipsvp_tab'] = 'bot_detail';
        }

        $tab = isset($_REQUEST['ipsvp_tab']) ? sanitize_key($_REQUEST['ipsvp_tab']) : 'dashboard';
        $tab = apply_filters('ipsvp_panel_current_tab', $tab, $phone);
        $order_id = !empty($_REQUEST['ipsvp_order_id']) ? (int) $_REQUEST['ipsvp_order_id'] : 0;
        $bot_order_id = !empty($_REQUEST['ipsvp_bot_order_id']) ? (int) $_REQUEST['ipsvp_bot_order_id'] : 0;
        if ($bot_order_id) {
            $tab = 'bot_detail';
        } elseif ($order_id) {
            $tab = 'detail';
        }
        if (in_array($tab, array('orders', 'detail', 'bot_detail'), true)) {
            $this->db->mark_notifications_seen($phone, 'order');
        } elseif ($tab === 'wallet') {
            $this->db->mark_notifications_seen($phone, 'wallet');
        } elseif ($tab === 'proxyline') {
            $this->db->mark_notifications_seen($phone, 'proxyline');
        }
        do_action('ipsvp_panel_mark_notifications_seen', $tab, $phone, $this->db);
        $allowed_tabs = apply_filters('ipsvp_panel_allowed_tabs', array('dashboard', 'profile', 'wallet', 'orders', 'detail', 'bot_detail'), $phone);
        if (!in_array($tab, $allowed_tabs, true)) {
            $tab = 'dashboard';
        }
        $this->localize_panel_notifications($phone);

        ob_start();
        echo '<div class="ipsvp ipsvp-panel" dir="rtl">';
        echo $this->render_panel_hero($phone);
        echo $this->render_panel_nav($tab, $phone);
        $panel_user = $this->db->get_user_by_phone($phone);
        if ($panel_user && empty($panel_user->password_hash)) {
            echo $this->render_force_password_modal($phone);
        }
        if (!IPSVP_Reseller::account_for_phone($phone)) { echo $this->render_service_warning_popup($phone); }
        if ($message) {
            echo '<div class="ipsvp-success">' . esc_html($message) . '</div>';
        }
        if ($tab === 'profile') {
            echo $this->render_user_profile($phone);
        } elseif ($tab === 'wallet') {
            echo $this->render_user_wallet($phone);
        } elseif ($tab === 'orders') {
            echo $this->render_user_orders($phone);
        } elseif ($tab === 'detail' && $order_id) {
            echo $this->render_user_order_detail($order_id, $phone, $detail_message);
        } elseif ($tab === 'bot_detail' && $bot_order_id) {
            echo $this->render_user_bot_order_detail($bot_order_id, $phone, $detail_message);
        } else {
            $addon_tab = apply_filters('ipsvp_panel_render_tab', '', $tab, $phone);
            echo $addon_tab !== '' ? $addon_tab : $this->render_user_dashboard($phone);
        }
        echo '</div>';
        return ob_get_clean();
    }

    private function render_panel_hero($phone = '')
    {
        $wallet_html = '';
        if ($phone !== '') {
            $user = $this->db->get_user_by_phone($phone);
            $wallet_label = 'کیف پول سایت';
            $balance_value = 0;
            if ($user) {
                $wallet = $this->wallet_payment_info($phone);
                $balance_value = isset($wallet['balance']) ? (int) $wallet['balance'] : 0;
                $wallet_label = !empty($wallet['label']) ? (string) $wallet['label'] : $wallet_label;
            }
            $wallet_html = '<div class="ipsvp-hero-wallet-card"><span>موجودی فعلی</span><strong>' . esc_html(number_format_i18n((int) $balance_value)) . ' تومان</strong><small>' . esc_html($wallet_label) . '</small><a class="ipsvp-btn" href="' . esc_url($this->current_page_url(array('ipsvp_tab' => 'wallet'))) . '">افزایش موجودی</a></div>';
        }
        $html = '<div class="ipsvp-hero">' . $wallet_html . '<div class="ipsvp-hero-content"><span>آی پی ثابت من</span><h2>حساب کاربری</h2><p>مدیریت سرویس‌ها و پرداخت‌ها</p></div></div>';
        return apply_filters('ipsvp_panel_hero', $html, $phone, $balance_value ?? 0, $wallet_label ?? 'کیف پول سایت');
    }

    private function otp_login_enabled()
    {
        $settings = IPSVP_Settings::get();
        return !empty($settings['otp_login_enabled']) && (string) $settings['otp_login_enabled'] === '1';
    }

    private function otp_login_ready()
    {
        $settings = IPSVP_Settings::get();
        return $this->otp_login_enabled()
            && !empty($settings['smsir_api_key'])
            && !empty($settings['smsir_template_id']);
    }

    private function normalize_digits($value)
    {
        $value = strtr((string) $value, array(
            '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
            '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
            '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
        ));
        return preg_replace('/\D+/', '', $value);
    }

    private function local_phone($phone)
    {
        $phone = $this->db->normalize_phone($phone);
        if (preg_match('/^\+98(9\d{9})$/', $phone, $matches)) {
            return '0' . $matches[1];
        }
        if (preg_match('/^09\d{9}$/', $phone)) {
            return $phone;
        }
        return $phone;
    }

    private function is_valid_iran_mobile($phone)
    {
        return (bool) preg_match('/^\+989\d{9}$/', $this->db->normalize_phone($phone));
    }

    private function otp_transient_key($phone)
    {
        return 'ipsvp_otp_' . md5($this->db->normalize_phone($phone) . '|' . wp_salt('auth'));
    }

    private function otp_resend_key($phone)
    {
        return 'ipsvp_otp_wait_' . md5($this->db->normalize_phone($phone) . '|' . wp_salt('nonce'));
    }

    private function otp_ttl_seconds()
    {
        $settings = IPSVP_Settings::get();
        $minutes = isset($settings['otp_expire_minutes']) ? (int) $settings['otp_expire_minutes'] : 5;
        return max(1, min(30, $minutes)) * MINUTE_IN_SECONDS;
    }

    private function otp_resend_seconds()
    {
        $settings = IPSVP_Settings::get();
        $seconds = isset($settings['otp_resend_seconds']) ? (int) $settings['otp_resend_seconds'] : 60;
        return max(20, min(600, $seconds));
    }

    private function otp_code_length()
    {
        $settings = IPSVP_Settings::get();
        $length = isset($settings['otp_code_length']) ? (int) $settings['otp_code_length'] : 6;
        return max(4, min(8, $length));
    }

    private function create_otp_code()
    {
        $length = $this->otp_code_length();
        $min = (int) pow(10, $length - 1);
        $max = ((int) pow(10, $length)) - 1;
        return (string) wp_rand($min, $max);
    }

    private function send_panel_otp($phone)
    {
        if (!$this->otp_login_ready()) {
            return new WP_Error('otp_not_ready', 'ارسال کد یکبار مصرف فعلا در دسترس نیست. در صورت داشتن رمز عبور، با رمز وارد شوید.');
        }
        if (get_transient($this->otp_resend_key($phone))) {
            return new WP_Error('otp_too_soon', 'کد قبلا ارسال شده است. لطفا کمی بعد دوباره تلاش کنید.');
        }

        $code = $this->create_otp_code();
        $sent = IPSVP_SMS_IR::send_verify_code($phone, $code);
        if (is_wp_error($sent)) {
            return $sent;
        }

        $ttl = $this->otp_ttl_seconds();
        set_transient($this->otp_transient_key($phone), array(
            'hash' => wp_hash_password($code),
            'attempts' => 0,
            'expires' => time() + $ttl,
        ), $ttl);
        set_transient($this->otp_resend_key($phone), 1, $this->otp_resend_seconds());
        return true;
    }

    private function verify_panel_otp($phone, $code)
    {
        $code = $this->normalize_digits($code);
        $record = get_transient($this->otp_transient_key($phone));
        if (!$record || !is_array($record) || empty($record['hash'])) {
            return new WP_Error('otp_expired', 'کد یکبار مصرف منقضی شده است. لطفا کد جدید بگیرید.');
        }
        $attempts = isset($record['attempts']) ? (int) $record['attempts'] : 0;
        if ($attempts >= 5) {
            delete_transient($this->otp_transient_key($phone));
            return new WP_Error('otp_attempts', 'تعداد تلاش برای این کد بیش از حد مجاز است. لطفا کد جدید بگیرید.');
        }
        if ($code === '' || !wp_check_password($code, $record['hash'])) {
            $record['attempts'] = $attempts + 1;
            $remaining = !empty($record['expires']) ? max(1, (int) $record['expires'] - time()) : $this->otp_ttl_seconds();
            if ($record['attempts'] >= 5) {
                delete_transient($this->otp_transient_key($phone));
            } else {
                set_transient($this->otp_transient_key($phone), $record, $remaining);
            }
            return new WP_Error('otp_invalid', 'کد وارد شده صحیح نیست.');
        }

        delete_transient($this->otp_transient_key($phone));
        return true;
    }

    private function render_login_form($message = '', $phone = '', $need_password = false, $context = 'panel', $captcha_pass = '')
    {
        ob_start();
        $context = IPSVP_Captcha_Service::normalize_context($context);
        $captcha_pass = preg_match('/^[a-f0-9]{48,64}$/', (string) $captcha_pass) ? (string) $captcha_pass : '';
        $state = $need_password ? 'password' : 'phone';
        $otp_ready = $this->otp_login_ready();
        $otp_enabled = $this->otp_login_enabled();
        $message_class = $message ? ' is-visible' : '';
        $title = $state === 'password' ? 'ورود با رمز عبور' : 'ورود به پنل کاربری';
        $display_phone = $this->local_phone($phone);
        echo '<div class="ipsvp-auth-shell" data-ipsvp-auth>';
        echo '<div class="ipsvp-auth-card">';
        echo '<div class="ipsvp-auth-head"><div class="ipsvp-auth-mark">IP</div><div><h3>' . esc_html($title) . '</h3></div></div>';
        if ($message) {
            echo '<div class="ipsvp-auth-message ipsvp-auth-error' . esc_attr($message_class) . '">' . esc_html($message) . '</div>';
        }
        if ($state === 'password') {
            echo '<form method="post" class="ipsvp-auth-form" data-ipsvp-auth-form>';
            wp_nonce_field('ipsvp_panel_login');
            echo '<input type="hidden" name="ipsvp_action" value="panel_login"><input type="hidden" name="ipsvp_login_method" value="password"><input type="hidden" name="step" value="password"><input type="hidden" name="ipsvp_panel_phone" value="' . esc_attr($display_phone) . '"><input type="hidden" name="ipsvp_captcha_context" value="' . esc_attr($context) . '"><input type="hidden" name="ipsvp_captcha_pass" value="' . esc_attr($captcha_pass) . '">';
            echo '<div class="ipsvp-auth-phone-pill"><span>شماره موبایل</span><strong>' . esc_html($display_phone) . '</strong></div>';
            echo '<label class="ipsvp-auth-field"><span>رمز عبور</span><input required name="ipsvp_password" type="password" placeholder="رمز عبور حساب کاربری" autocomplete="current-password"></label>';
            echo '<button class="ipsvp-auth-primary" type="submit">ورود با رمز عبور</button>';
            echo '</form>';
            if ($otp_ready) {
                echo '<form method="post" class="ipsvp-auth-inline-form" data-ipsvp-auth-form>';
                wp_nonce_field('ipsvp_panel_login');
                echo '<input type="hidden" name="ipsvp_action" value="panel_login"><input type="hidden" name="ipsvp_login_method" value="otp_request"><input type="hidden" name="step" value="otp_request"><input type="hidden" name="ipsvp_panel_phone" value="' . esc_attr($display_phone) . '"><input type="hidden" name="ipsvp_captcha_context" value="' . esc_attr($context) . '"><input type="hidden" name="ipsvp_captcha_pass" value="' . esc_attr($captcha_pass) . '">';
                echo '<button class="ipsvp-auth-link-btn" type="submit">ورود با رمز یکبار مصرف</button>';
                echo '</form>';
            }
            echo '<button class="ipsvp-auth-back" type="button" data-ipsvp-auth-back>تغییر شماره موبایل</button>';
        } else {
            if ($otp_enabled && !$otp_ready) {
                echo '<div class="ipsvp-auth-message ipsvp-auth-error is-visible">ارسال کد یکبار مصرف فعلا در دسترس نیست. مسیر رمز عبور همچنان فعال است.</div>';
            }
            echo '<form method="post" class="ipsvp-auth-form" data-ipsvp-auth-form>';
            wp_nonce_field('ipsvp_panel_login');
            echo '<input type="hidden" name="ipsvp_action" value="panel_login"><input type="hidden" name="ipsvp_login_method" value="phone"><input type="hidden" name="step" value="phone"><input type="hidden" name="ipsvp_captcha_context" value="' . esc_attr($context) . '"><input type="hidden" name="ipsvp_captcha_pass" value="' . esc_attr($captcha_pass) . '">';
            echo '<label class="ipsvp-auth-field"><span>شماره موبایل</span><input required name="ipsvp_panel_phone" type="tel" value="' . esc_attr($display_phone) . '" placeholder="09123456789" autocomplete="tel" inputmode="numeric" pattern="09[0-9]{9}" maxlength="11"></label>';
            if ($captcha_pass === '') {
                echo IPSVP_Captcha_Service::render_captcha_field($context, 'phone', $otp_ready);
            }
            echo '<button class="ipsvp-auth-primary" type="submit">' . esc_html($otp_ready ? 'ادامه' : 'ورود / مشاهده سفارشات') . '</button>';
            echo '</form>';
        }
        echo '</div></div>';
        return ob_get_clean();
    }

    private function render_otp_verify_form($message, $phone, $type = 'success', $context = 'panel', $captcha_pass = '')
    {
        ob_start();
        $context = IPSVP_Captcha_Service::normalize_context($context);
        $captcha_pass = preg_match('/^[a-f0-9]{48,64}$/', (string) $captcha_pass) ? (string) $captcha_pass : '';
        $length = $this->otp_code_length();
        $message_class = $message ? ' is-visible' : '';
        $display_phone = $this->local_phone($phone);
        $resend_seconds = $this->otp_resend_seconds();
        echo '<div class="ipsvp-auth-shell" data-ipsvp-auth>';
        echo '<div class="ipsvp-auth-card ipsvp-auth-card-otp">';
        echo '<div class="ipsvp-auth-head"><div class="ipsvp-auth-mark">OTP</div><div><h3>تایید کد ورود</h3></div></div>';
        if ($message) {
            $class = $type === 'error' ? 'ipsvp-auth-error' : 'ipsvp-auth-success';
            echo '<div class="ipsvp-auth-message ' . esc_attr($class . $message_class) . '">' . esc_html($message) . '</div>';
        }
        echo '<form method="post" class="ipsvp-auth-form" data-ipsvp-auth-form data-ipsvp-otp-form>';
        wp_nonce_field('ipsvp_panel_login');
        echo '<input type="hidden" name="ipsvp_action" value="panel_login"><input type="hidden" name="ipsvp_login_method" value="otp_verify"><input type="hidden" name="step" value="otp_verify"><input type="hidden" name="ipsvp_captcha_context" value="' . esc_attr($context) . '"><input type="hidden" name="ipsvp_captcha_pass" value="' . esc_attr($captcha_pass) . '">';
        echo '<input type="hidden" name="ipsvp_panel_phone" value="' . esc_attr($display_phone) . '"><input type="hidden" name="ipsvp_otp_code" value="">';
        echo '<div class="ipsvp-auth-phone-pill"><span>شماره موبایل</span><strong>' . esc_html($display_phone) . '</strong></div>';
        echo '<div class="ipsvp-otp-digits" dir="ltr" style="--ipsvp-otp-cols:' . esc_attr($length) . '">';
        for ($i = 0; $i < $length; $i++) {
            echo '<input data-ipsvp-otp-digit type="text" inputmode="numeric" pattern="[0-9]*" maxlength="1" autocomplete="' . ($i === 0 ? 'one-time-code' : 'off') . '" aria-label="' . esc_attr('رقم ' . ($i + 1) . ' کد ورود') . '">';
        }
        echo '</div>';
        echo '<button class="ipsvp-auth-primary" type="submit">تایید و ورود</button>';
        echo '</form>';
        echo '<form method="post" class="ipsvp-auth-inline-form" data-ipsvp-auth-form>';
        wp_nonce_field('ipsvp_panel_login');
        echo '<input type="hidden" name="ipsvp_action" value="panel_login"><input type="hidden" name="ipsvp_login_method" value="otp_request"><input type="hidden" name="step" value="otp_request"><input type="hidden" name="ipsvp_from_otp_verify" value="1"><input type="hidden" name="ipsvp_captcha_context" value="' . esc_attr($context) . '"><input type="hidden" name="ipsvp_captcha_pass" value="' . esc_attr($captcha_pass) . '">';
        echo '<input type="hidden" name="ipsvp_panel_phone" value="' . esc_attr($display_phone) . '">';
        echo '<div class="ipsvp-auth-resend-row"><div class="ipsvp-auth-timer" data-ipsvp-otp-timer data-seconds="' . esc_attr($resend_seconds) . '" aria-live="polite"><span data-ipsvp-otp-countdown></span></div><button class="ipsvp-auth-link-btn" data-ipsvp-resend-button type="submit" disabled>ارسال مجدد کد</button></div>';
        echo '</form>';
        echo '<button class="ipsvp-auth-back" type="button" data-ipsvp-auth-back>تغییر شماره موبایل</button>';
        echo '</div></div>';
        return ob_get_clean();
    }

    private function process_panel_login()
    {
        $context = IPSVP_Captcha_Service::normalize_context(isset($_POST['ipsvp_captcha_context']) ? wp_unslash($_POST['ipsvp_captcha_context']) : 'panel');
        if (!wp_verify_nonce(isset($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '', 'ipsvp_panel_login')) {
            return array('html' => $this->render_login_form('درخواست ورود نامعتبر است.', '', false, $context));
        }
        $method = isset($_POST['ipsvp_login_method']) ? sanitize_key(wp_unslash($_POST['ipsvp_login_method'])) : '';
        $step = in_array($method, array('otp_request', 'otp_verify', 'password'), true) ? $method : 'phone';
        $phone = $this->db->normalize_phone(isset($_POST['ipsvp_panel_phone']) ? wp_unslash($_POST['ipsvp_panel_phone']) : '');
        if (!$phone || !$this->is_valid_iran_mobile($phone)) {
            return array('html' => $this->render_login_form('شماره موبایل نامعتبر است.', '', false, $context));
        }
        $captcha_pass = isset($_POST['ipsvp_captcha_pass']) ? strtolower(trim((string) wp_unslash($_POST['ipsvp_captcha_pass']))) : '';
        $is_first_step = $step === 'phone' && $captcha_pass === '';
        $security = $is_first_step
            ? IPSVP_Captcha_Service::validate_request($context, 'phone', $this->otp_login_ready())
            : IPSVP_Captcha_Service::validate_pass($captcha_pass, $phone, $context);
        if (is_wp_error($security)) {
            return array('html' => $this->render_login_form($security->get_error_message(), '', false, $context));
        }
        if ($is_first_step) {
            $captcha_pass = IPSVP_Captcha_Service::create_pass($phone, $context);
        }
        $_POST['ipsvp_captcha_pass'] = $captcha_pass;
        $existing_user = $this->db->get_user_by_phone($phone);
        // Extension point for add-ons that need an intermediate login/registration step.
        $addon_login = apply_filters('ipsvp_panel_login_process_result', null, $phone, $existing_user);
        if (is_array($addon_login)) {
            return $addon_login;
        }
        if ($this->otp_login_enabled() && $method === '') {
            $method = 'otp_request';
        }
        if (!in_array($method, array('otp_request', 'otp_verify', 'password'), true)) {
            $method = 'password';
        }

        $user = $method === 'password' ? $this->db->get_or_create_user($phone) : $this->db->get_user_by_phone($phone);
        if ($user && !empty($user->is_blocked)) {
            IPSVP_Captcha_Service::delete_pass($captcha_pass);
            return array('html' => $this->render_login_form('حساب کاربری این شماره توسط مدیریت مسدود شده است.', $phone, false, $context));
        }
        if ($method === 'otp_request') {
            if (!$this->otp_login_ready()) {
                return array('html' => $this->render_login_form('ارسال کد یکبار مصرف فعلا در دسترس نیست. در صورت داشتن رمز عبور، با رمز وارد شوید.', $phone, !empty($user->password_hash), $context, $captcha_pass));
            }
            $sent = $this->send_panel_otp($phone);
            if (is_wp_error($sent)) {
                if (!empty($_POST['ipsvp_from_otp_verify'])) {
                    return array('html' => $this->render_otp_verify_form($sent->get_error_message(), $phone, 'error', $context, $captcha_pass));
                }
                return array('html' => $this->render_login_form($sent->get_error_message(), $phone, !empty($user->password_hash), $context, $captcha_pass));
            }
            return array('html' => $this->render_otp_verify_form('کد ورود برای شما ارسال شد.', $phone, 'success', $context, $captcha_pass));
        }
        if ($method === 'otp_verify') {
            if (!$this->otp_login_ready()) {
                return array('html' => $this->render_login_form('ورود با کد یکبار مصرف فعال نیست.', $phone, false, $context, $captcha_pass));
            }
            $code = isset($_POST['ipsvp_otp_code']) ? wp_unslash($_POST['ipsvp_otp_code']) : '';
            $verified = $this->verify_panel_otp($phone, $code);
            if (is_wp_error($verified)) {
                return array('html' => $this->render_otp_verify_form($verified->get_error_message(), $phone, 'error', $context, $captcha_pass));
            }
            $user = $this->db->get_or_create_user($phone);
            if ($user && !empty($user->is_blocked)) {
                IPSVP_Captcha_Service::delete_pass($captcha_pass);
                return array('html' => $this->render_login_form('حساب کاربری این شماره توسط مدیریت مسدود شده است.', $phone, false, $context));
            }
            IPSVP_Captcha_Service::delete_pass($captcha_pass);
            return array('phone' => $phone);
        }

        if ($this->otp_login_enabled() && empty($user->password_hash)) {
            return array('html' => $this->render_login_form('برای این شماره هنوز رمز عبور تعریف نشده است. لطفا با کد یکبار مصرف وارد شوید یا از پشتیبانی رمز دریافت کنید.', $phone, false, $context, $captcha_pass));
        }
        if (!empty($user->password_hash)) {
            $password = isset($_POST['ipsvp_password']) ? (string) wp_unslash($_POST['ipsvp_password']) : '';
            if ($password === '') {
                return array('html' => $this->render_login_form('برای این شماره رمز تعریف شده است. لطفا رمز عبور را وارد کنید.', $phone, true, $context, $captcha_pass));
            }
            if (!wp_check_password($password, $user->password_hash)) {
                return array('html' => $this->render_login_form('رمز عبور اشتباه است.', $phone, true, $context, $captcha_pass));
            }
        }
        IPSVP_Captcha_Service::delete_pass($captcha_pass);
        return array('phone' => $phone);
    }

    private function render_panel_nav($active, $phone = '')
    {
        $items = array(
            'dashboard' => 'داشبورد',
            'profile' => 'اطلاعات کاربری',
            'wallet' => 'کیف پول',
            'orders' => 'سفارشات',
        );
        $items = apply_filters('ipsvp_panel_nav_items', $items, $active, $phone);
        ob_start();
        echo '<nav aria-label="منوی حساب کاربری" class="ipsvp-panel-nav' . (IPSVP_Reseller::account_for_phone($phone) ? ' ipsvp-reseller-nav' : '') . '">';
        $notification_counts = $phone ? apply_filters('ipsvp_panel_notification_counts', array(
            'orders' => $this->db->count_unread_notifications($phone, 'order'),
        ), $phone, $this->db) : array();
        foreach ($items as $key => $label) {
            $tab_unread_count = isset($notification_counts[$key]) ? (int) $notification_counts[$key] : 0;
            $bell = $tab_unread_count > 0 ? '<span class="ipsvp-nav-bell" aria-label="اعلان جدید">🔔<em>' . esc_html(number_format_i18n($tab_unread_count)) . '</em></span>' : '';
            echo '<a class="' . esc_attr(($active === $key || ($key === 'orders' && in_array($active, array('detail', 'bot_detail'), true))) ? 'is-active' : '') . '" href="' . esc_url($this->current_page_url(array('ipsvp_tab' => $key))) . '">' . esc_html($label) . $bell . '</a>';
        }
        echo '<form method="post">';
        wp_nonce_field('ipsvp_panel_logout');
        echo '<input type="hidden" name="ipsvp_action" value="panel_logout"><button type="submit">خروج</button></form>';
        echo '</nav>';
        echo '<p class="ipsvp-panel-nav-hint"><span aria-hidden="true">↔</span> برای دیدن بقیه بخش‌ها، منو را به چپ و راست بکشید.</p>';
        return ob_get_clean();
    }

    private function render_user_dashboard($phone)
    {
        $orders = $this->db->get_user_orders($phone);
        $total = count($orders);
        $active = 0;
        $pending = 0;
        foreach ($orders as $order) {
            if (in_array($order->status, array('created','active','on_hold'), true)) {
                $active++;
            }
            if (in_array($order->status, array('waiting_review', 'pending_receipt'), true)) {
                $pending++;
            }
        }
        $user = $this->db->get_user_by_phone($phone);
        $wallet_label = 'کیف پول سایت';
        $balance_value = 0;
        if ($user) {
            $wallet = $this->wallet_payment_info($phone);
            $balance_value = isset($wallet['balance']) ? (int) $wallet['balance'] : 0;
            $wallet_label = !empty($wallet['label']) ? (string) $wallet['label'] : $wallet_label;
        }
        $balance_text = number_format_i18n((int) $balance_value) . ' تومان';
        $settings = IPSVP_Settings::get();
        $announcement = isset($settings['announcement_text']) ? trim((string) $settings['announcement_text']) : '';
        ob_start();
        echo '<div class="ipsvp-user-card"><h3>داشبورد حساب</h3><div class="ipsvp-live-grid">';
        echo '<div><span>شماره موبایل</span><b>' . esc_html($phone) . '</b></div>';
        echo '<div><span>کل سفارشات</span><b>' . esc_html(number_format_i18n($total)) . '</b></div>';
        echo '<div><span>کانفیگ های فعال</span><b>' . esc_html(number_format_i18n($active)) . '</b></div>';
        echo '<div><span>در انتظار بررسی</span><b>' . esc_html(number_format_i18n($pending)) . '</b></div>';
        echo '</div>';
        if ($announcement !== '') {
            echo '<div class="ipsvp-announcement-box ipsvp-announcement-box--dashboard"><div><span>اطلاعیه</span><strong>پیام مدیریت</strong></div><p>' . wp_kses_post(nl2br($announcement)) . '</p></div>';
        }
        echo '</div>';
        return ob_get_clean();
    }

    private function render_user_profile($phone)
    {
        $user = $this->db->get_user_by_phone($phone);
        ob_start();
        echo '<div class="ipsvp-user-card ipsvp-profile-card"><h3>اطلاعات کاربری</h3>';
        echo '<div class="ipsvp-invoice-grid"><div><span>شماره موبایل</span><b>' . esc_html($phone) . '</b></div><div><span>وضعیت رمز</span><b>' . (!empty($user->password_hash) ? 'رمز تعریف شده' : 'بدون رمز') . '</b></div></div>';
        echo '<div class="ipsvp-profile-grid">';
        echo '<form method="post" class="ipsvp-profile-form">';
        wp_nonce_field('ipsvp_set_panel_password');
        echo '<input type="hidden" name="ipsvp_action" value="set_panel_password"><input type="hidden" name="ipsvp_tab" value="profile">';
        if (!empty($user->password_hash)) {
            echo '<label class="ipsvp-label">رمز فعلی<input name="current_password" type="password" placeholder="رمز فعلی"></label>';
        }
        echo '<label class="ipsvp-label">رمز جدید<input required name="new_password" type="password" placeholder="حداقل ۴ کاراکتر"></label>';
        echo '<label class="ipsvp-label">تکرار رمز جدید<input required name="new_password_repeat" type="password" placeholder="تکرار رمز جدید"></label>';
        echo '<button class="ipsvp-btn" type="submit">ذخیره رمز عبور</button></form>';
        echo '<div class="ipsvp-bot-link-card"><h3>اتصال حساب سایت به ربات تلگرام</h3>';
        if (!empty($user->bot_tel_id)) {
            echo '<div class="ipsvp-success">این حساب به ربات متصل است. شناسه تلگرام: <code>' . esc_html($user->bot_tel_id) . '</code></div>';
            echo '<p>برای قطع اتصال، فقط مدیریت سایت از بخش جزییات کاربر در پنل ادمین می تواند اقدام کند.</p>';
        } else {
            echo '<p>برای نمایش سفارش های سایت در ربات و سفارش های ربات در سایت، وارد ربات شوید، به بخش <strong>حساب کاربری</strong> بروید، دکمه <strong>اتصال به سایت</strong> را بزنید و کد زیر را ارسال کنید.</p>';
            if (!empty($user->bot_link_code)) {
                echo '<div class="ipsvp-bot-code"><span>کد اتصال</span><strong>' . esc_html($user->bot_link_code) . '</strong></div>';
            } else {
                echo '<div class="ipsvp-alert">هنوز کد اتصال ساخته نشده است.</div>';
            }
            echo '<form method="post">';
            wp_nonce_field('ipsvp_generate_bot_link');
            echo '<input type="hidden" name="ipsvp_action" value="generate_bot_link"><input type="hidden" name="ipsvp_tab" value="profile"><button class="ipsvp-btn" type="submit">ساخت کد اتصال ربات</button></form>';
        }
        echo '</div></div></div>';
        return ob_get_clean();
    }

    private function render_force_password_modal($phone)
    {
        ob_start();
        echo '<div class="ipsvp-modal ipsvp-force-password-modal" id="ipsvp-force-password-modal">';
        echo '<a class="ipsvp-modal-bg" href="#"></a><div class="ipsvp-modal-card ipsvp-force-password-card">';
        echo '<a class="ipsvp-modal-close" href="#">×</a>';
        echo '<h3>برای امنیت حساب، رمز عبور تعریف کنید</h3>';
        echo '<p>شما با شماره موبایل وارد شده اید. تا زمانی که رمز عبور تعیین نکنید، این پیام در ورودهای بعدی هم نمایش داده می شود.</p>';
        echo '<div class="ipsvp-login-phone"><span>شماره موبایل</span><strong>' . esc_html($phone) . '</strong></div>';
        echo '<form method="post" class="ipsvp-profile-form ipsvp-force-password-form">';
        wp_nonce_field('ipsvp_set_panel_password');
        echo '<input type="hidden" name="ipsvp_action" value="set_panel_password"><input type="hidden" name="ipsvp_tab" value="profile">';
        echo '<label class="ipsvp-label">رمز عبور جدید<input required name="new_password" type="password" placeholder="حداقل ۴ کاراکتر"></label>';
        echo '<label class="ipsvp-label">تکرار رمز عبور<input required name="new_password_repeat" type="password" placeholder="تکرار رمز عبور"></label>';
        echo '<button class="ipsvp-btn" type="submit">ذخیره رمز عبور</button>';
        echo '</form></div></div>';
        return ob_get_clean();
    }

    private function handle_set_password($phone)
    {
        if (!wp_verify_nonce(isset($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '', 'ipsvp_set_panel_password')) {
            return 'درخواست ذخیره رمز نامعتبر است.';
        }
        $user = $this->db->get_user_by_phone($phone);
        $current = isset($_POST['current_password']) ? (string) wp_unslash($_POST['current_password']) : '';
        $new = isset($_POST['new_password']) ? (string) wp_unslash($_POST['new_password']) : '';
        $repeat = isset($_POST['new_password_repeat']) ? (string) wp_unslash($_POST['new_password_repeat']) : '';
        if (!empty($user->password_hash) && !wp_check_password($current, $user->password_hash)) {
            return 'رمز فعلی اشتباه است.';
        }
        if (strlen($new) < 4) {
            return 'رمز جدید باید حداقل ۴ کاراکتر باشد.';
        }
        if ($new !== $repeat) {
            return 'تکرار رمز جدید با رمز جدید یکسان نیست.';
        }
        $this->db->set_user_password($phone, $new);
        return 'رمز عبور حساب کاربری ذخیره شد.';
    }


    private function handle_generate_bot_link($phone)
    {
        if (!wp_verify_nonce(isset($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '', 'ipsvp_generate_bot_link')) {
            return 'درخواست ساخت کد اتصال نامعتبر است.';
        }
        $created = $this->db->create_bot_link_code($phone);
        if (is_wp_error($created)) {
            return $created->get_error_message();
        }
        return 'کد اتصال ساخته شد. داخل ربات ارسال کنید: /connectAccount ' . $created['code'];
    }

    private function handle_wallet_charge_submission($phone)
    {
        if (!$this->payment_method_enabled('card')) {
            return '<div class="ipsvp-alert">شارژ کیف پول با کارت به کارت در حال حاضر غیرفعال است.</div>';
        }
        if (!wp_verify_nonce(isset($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '', 'ipsvp_submit_wallet_charge')) {
            return 'درخواست شارژ کیف پول نامعتبر است.';
        }
        $amount = isset($_POST['wallet_amount']) ? (int) preg_replace('/[^0-9]/', '', (string) wp_unslash($_POST['wallet_amount'])) : 0;
        $submission_key = isset($_POST['ipsvp_submission_key']) ? $this->db->sanitize_submission_key(wp_unslash($_POST['ipsvp_submission_key'])) : '';
        $user = $this->db->get_user_by_phone($phone);
        $upload = $user ? IPSVP_Receipt_Uploader::uploaded_from_request('wallet_receipt', (int) $user->id) : null;
        if ($upload === null) {
            if (empty($_FILES['wallet_receipt']['name'])) {
                return 'لطفا تصویر رسید شارژ کیف پول را آپلود کنید.';
            }
            $upload = $this->upload_receipt($_FILES['wallet_receipt'], 'wallet_receipt');
        }
        if (is_wp_error($upload)) {
            return $upload->get_error_message();
        }
        $receipt = $this->db->create_wallet_receipt($phone, $amount, $upload['attachment_id'], $upload['url'], $submission_key);
        if (is_wp_error($receipt)) {
            return $receipt->get_error_message();
        }
        return 'درخواست شارژ کیف پول ثبت شد. بعد از تایید ادمین، موجودی کیف پول شارژ می شود.';
    }


    private function handle_crypto_wallet_charge_submission($phone)
    {
        if (!$this->crypto_available()) { return '<div class="ipsvp-alert">درگاه کریپتو فعال نیست.</div>'; }
        if (!wp_verify_nonce(isset($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '', 'ipsvp_submit_crypto_wallet_charge')) {
            return 'درخواست شارژ کریپتو کیف پول نامعتبر است.';
        }
        $amount = isset($_POST['wallet_amount']) ? (int) preg_replace('/[^0-9]/', '', (string) wp_unslash($_POST['wallet_amount'])) : 0;
        $submission_key = isset($_POST['ipsvp_submission_key']) ? $this->db->sanitize_submission_key(wp_unslash($_POST['ipsvp_submission_key'])) : '';
        $receipt = $this->db->create_crypto_wallet_receipt($phone, $amount, $submission_key);
        if (is_wp_error($receipt)) { return $receipt->get_error_message(); }
        $invoice = $this->ramzino_create_invoice_for_receipt($receipt, 'WALLET-' . (int) $receipt->id, 'IP Sabet wallet charge #' . (int) $receipt->id, array('ipsvp_tab' => 'wallet'));
        if (is_wp_error($invoice)) { return $invoice->get_error_message(); }
        return $this->redirect_or_script($invoice['url']);
    }

    private function render_user_wallet($phone)
    {
        $user = $this->db->get_or_create_user($phone);
        $settings = IPSVP_Settings::get();
        ob_start();
        echo '<div class="ipsvp-user-card ipsvp-wallet-page"><h3>کیف پول</h3>';
        if (!$user) {
            echo '<div class="ipsvp-alert">کاربر پیدا نشد.</div></div>';
            return ob_get_clean();
        }
        $wallet_info = $this->wallet_payment_info($phone);
        $balance = isset($wallet_info['balance']) ? (int) $wallet_info['balance'] : $this->db->get_local_wallet_balance($user->id);
        $wallet_mode = 'کیف پول مستقل سایت';
        $wallet_hint = 'این موجودی بدون اتصال به ربات هم برای خرید از سایت قابل استفاده است.';
        if (!empty($user->bot_tel_id)) {
            if (!empty($wallet_info['ok'])) {
                $wallet_mode = 'کیف پول مشترک ربات و سایت';
                $wallet_hint = 'موجودی سایت و ربات ادغام شده و خرید از هر کدام، مانده هر دو طرف را بروزرسانی می کند.';
            } else {
                $wallet_mode = 'کیف پول مشترک (نیازمند همگام سازی)';
                $wallet_hint = !empty($wallet_info['message']) ? $wallet_info['message'] : 'اتصال ربات ثبت شده اما همگام سازی موجودی ناموفق بود.';
            }
        }
        echo '<div class="ipsvp-wallet-hero"><div class="ipsvp-wallet-stat"><span>موجودی فعلی</span><strong>' . esc_html(number_format_i18n($balance)) . ' تومان</strong><small>' . esc_html($wallet_mode) . '</small></div><div class="ipsvp-wallet-actions"><p>' . esc_html($wallet_hint) . '</p><a class="ipsvp-btn" href="#ipsvp-wallet-charge-modal">شارژ کیف پول</a></div></div>';
        echo '<div class="ipsvp-modal" id="ipsvp-wallet-charge-modal"><a class="ipsvp-modal-bg" href="#"></a><div class="ipsvp-modal-card"><a class="ipsvp-modal-close" href="#">×</a><h3>شارژ کیف پول</h3>';
        $wallet_charge_methods = array();
        if ($this->payment_method_enabled('card')) { $wallet_charge_methods[] = array('id' => 'card', 'title' => 'کارت به کارت', 'desc' => 'ارسال رسید شارژ'); }
        if ($this->crypto_available()) { $wallet_charge_methods[] = array('id' => 'crypto', 'title' => 'کریپتو', 'desc' => 'پرداخت رمزینو'); }
        if (!$wallet_charge_methods) {
            echo '<div class="ipsvp-alert">هیچ روش پرداختی برای شارژ کیف پول فعال نیست.</div></div></div>';
        } else {
            $default_method = $wallet_charge_methods[0]['id'];
            $charge_panel_configs = array();
            $charge_amount_summary = '<span data-ipspm-amount-output>ابتدا مبلغ شارژ را وارد کنید</span>';
            if ($this->payment_method_enabled('card')) {
                ob_start();
                echo '<form method="post" enctype="multipart/form-data" class="ipsvp-profile-form">';
                wp_nonce_field('ipsvp_submit_wallet_charge');
                echo '<input type="hidden" name="ipsvp_action" value="submit_wallet_charge"><input type="hidden" name="ipsvp_tab" value="wallet"><input type="hidden" name="ipsvp_submission_key" value="' . esc_attr($this->new_submission_key('wallet-')) . '">';
                echo '<label class="ipsvp-label">مبلغ شارژ کیف پول به تومان<input required name="wallet_amount" type="number" min="1000" step="1000" placeholder="مثلا 500000" data-ipspm-amount-input></label>';
                echo $this->render_bank_box($settings);
                echo IPSVP_Receipt_Uploader::render_field('wallet_receipt', 'رسید شارژ کیف پول', true);
                echo '<button class="ipsvp-btn" type="submit">ثبت رسید شارژ کیف پول</button></form>';
                $charge_panel_configs['card'] = array(
                    'description' => 'مبلغ موردنظر را وارد کنید، واریز را انجام دهید و تصویر رسید را ارسال کنید.',
                    'summary' => array(array('label' => 'مبلغ شارژ', 'value_html' => $charge_amount_summary)),
                    'content_html' => ob_get_clean(),
                );
            }
            if ($this->crypto_available()) {
                ob_start();
                echo '<form method="post" class="ipsvp-profile-form">';
                wp_nonce_field('ipsvp_submit_crypto_wallet_charge');
                echo '<input type="hidden" name="ipsvp_action" value="submit_crypto_wallet_charge"><input type="hidden" name="ipsvp_tab" value="wallet"><input type="hidden" name="ipsvp_submission_key" value="' . esc_attr($this->new_submission_key('crypto-wallet-')) . '">';
                echo '<label class="ipsvp-label">مبلغ شارژ کیف پول به تومان<input required name="wallet_amount" type="number" min="1000" step="1000" placeholder="مثلا 500000" data-ipspm-amount-input></label>';
                echo '<button class="ipsvp-btn" type="submit">پرداخت کریپتو و شارژ کیف پول</button></form>';
                $charge_panel_configs['crypto'] = array(
                    'description' => 'بعد از ثبت، به صفحه پرداخت رمزینو منتقل می‌شوید. پس از پرداخت موفق، کیف پول شارژ می‌شود.',
                    'summary' => array(
                        array('label' => 'مبلغ شارژ', 'value_html' => $charge_amount_summary),
                        array('label' => 'درگاه', 'value' => 'Ramzino Crypto'),
                    ),
                    'content_html' => ob_get_clean(),
                );
            }
            if (class_exists('IPSPM_Payment_Manager')) {
                echo IPSPM_Payment_Manager::render_payment_box(array(
                    'context' => 'wallet-charge',
                    'input_name' => 'ipsvp_wallet_charge_method',
                    'methods' => $wallet_charge_methods,
                    'panel_configs' => $charge_panel_configs,
                    'default' => $default_method,
                    'class' => 'ipsvp-wallet-charge-switcher',
                    'aria_label' => 'روش شارژ کیف پول',
                ));
            } else {
                echo '<div class="ipsvp-alert">افزونه مدیریت پرداخت‌ها فعال نیست.</div>';
            }
            echo '</div></div>';
        }
        $transactions = $this->db->get_wallet_transactions($user->id, 30);
        echo '<div class="ipsvp-payments"><h3>تراکنش های کیف پول</h3><div class="ipsvp-payment-list ipsvp-wallet-transactions">';
        if ($transactions) {
            foreach ($transactions as $tx) {
                $sign = $tx->kind === 'debit' ? '-' : '+';
                $class = $tx->kind === 'debit' ? 'ipsvp-wallet-debit' : 'ipsvp-wallet-credit';
                $receipt_link = IPSVP_Receipt_Uploader::link_html(isset($tx->attachment_id) ? (int) $tx->attachment_id : 0, !empty($tx->file_url) ? $tx->file_url : '', 'مشاهده رسید');
                echo '<div class="ipsvp-payment-row ' . esc_attr($class) . '"><div><strong>' . esc_html($tx->title) . '</strong><span>' . esc_html($tx->ref) . ' · ' . esc_html($this->db->status_label($tx->status)) . '</span><small>' . esc_html($tx->date) . '</small></div><div><b>' . esc_html($sign . number_format_i18n((int) $tx->amount)) . ' تومان</b>' . ($receipt_link !== '' ? '<br>' . $receipt_link : '') . '</div></div>';
            }
        } else {
            echo '<div class="ipsvp-alert">هنوز تراکنشی برای کیف پول ثبت نشده است.</div>';
        }
        echo '</div></div></div>';
        return ob_get_clean();
    }

    private function get_user_bot_orders($phone)
    {
        $user = $this->db->get_user_by_phone($phone);
        if (!$user || empty($user->bot_tel_id)) {
            return array();
        }
        $full = IPSVP_Bot_API::sync_user_full($user->bot_tel_id, $user->phone);
        if (!is_wp_error($full) && !empty($full['ok']) && !empty($full['orders']) && is_array($full['orders'])) {
            if (!empty($full['orders']['items']) && is_array($full['orders']['items'])) {
                return $full['orders']['items'];
            }
            if (!empty($full['orders']['orders']) && is_array($full['orders']['orders'])) {
                return $full['orders']['orders'];
            }
        }
        $res = IPSVP_Bot_API::bot_orders($user->bot_tel_id, 1, 200);
        if (!is_wp_error($res) && !empty($res['ok']) && !empty($res['orders']) && is_array($res['orders'])) {
            return $res['orders'];
        }
        return array();
    }

    private function find_user_bot_order($phone, $bot_order_id)
    {
        $bot_order_id = (int) $bot_order_id;
        if ($bot_order_id <= 0) {
            return null;
        }
        $user = $this->db->get_user_by_phone($phone);
        if ($user && !empty($user->bot_tel_id)) {
            $direct = IPSVP_Bot_API::find_bot_order($user->bot_tel_id, $bot_order_id);
            if (!is_wp_error($direct) && is_array($direct) && !empty($direct)) {
                return $direct;
            }
        }
        foreach ($this->get_user_bot_orders($phone) as $order) {
            if ((int) ($order['id'] ?? 0) === $bot_order_id) {
                return $order;
            }
        }
        return null;
    }

    private function normalize_bot_order_detail($order)
    {
        $order = is_array($order) ? $order : array();
        $detail = isset($order['detail']) ? $order['detail'] : array();
        if (is_string($detail)) {
            $decoded = json_decode($detail, true);
            $detail = is_array($decoded) ? $decoded : array('raw' => $detail);
        }
        if (!is_array($detail)) {
            $detail = array();
        }
        if (empty($detail['code']) && !empty($order['remark'])) {
            $detail['code'] = $order['remark'];
        }
        if (empty($detail['pg_user_id']) && !empty($order['uid'])) {
            $detail['pg_user_id'] = $order['uid'];
        }
        if (empty($detail['subscription_url']) && !empty($order['sub_id'])) {
            $detail['subscription_url'] = $order['sub_id'];
        }
        if (empty($detail['pg_status']) && isset($order['status'])) {
            $detail['pg_status'] = $order['status'];
        }
        return $detail;
    }

    private function bot_order_status_label($order)
    {
        if (is_array($order) && !empty($order['status_label'])) {
            return (string) $order['status_label'];
        }
        $status = is_array($order) && isset($order['status']) ? (string) $order['status'] : '';
        return $this->db->status_label($status);
    }

    private function normalize_traffic_number($value)
    {
        if (is_array($value) || is_object($value) || $value === null || $value === '') {
            return null;
        }
        if (is_numeric($value)) {
            return (float) $value;
        }
        $text = trim(strtr((string) $value, array(
            '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
            '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
            '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
            ',' => '',
            '٬' => '',
        )));
        if ($text === '') {
            return null;
        }
        if (preg_match('/([0-9]+(?:\.[0-9]+)?)\s*(tb|ترا|terabyte|gb|گیگ|gigabyte|mb|مگ|megabyte|kb|کیلو|kilobyte|b|byte)?/iu', $text, $m)) {
            $number = (float) $m[1];
            $unit = isset($m[2]) ? mb_strtolower($m[2]) : '';
            if (in_array($unit, array('tb','ترا','terabyte'), true)) {
                return $number * 1024 * 1024 * 1024 * 1024;
            }
            if (in_array($unit, array('gb','گیگ','gigabyte'), true)) {
                return $number * 1024 * 1024 * 1024;
            }
            if (in_array($unit, array('mb','مگ','megabyte'), true)) {
                return $number * 1024 * 1024;
            }
            if (in_array($unit, array('kb','کیلو','kilobyte'), true)) {
                return $number * 1024;
            }
            return $number;
        }
        return null;
    }

    private function find_traffic_key($data, $keys)
    {
        if (!is_array($data)) {
            return null;
        }
        foreach ($data as $key => $value) {
            $key_norm = strtolower((string) $key);
            if (in_array($key_norm, $keys, true)) {
                $num = $this->normalize_traffic_number($value);
                if ($num !== null) {
                    return $num;
                }
            }
        }
        if (!empty($data['after']) && is_array($data['after'])) {
            $found = $this->find_traffic_key($data['after'], $keys);
            if ($found !== null) {
                return $found;
            }
        }
        foreach ($data as $key => $value) {
            if ((string) $key === 'after') {
                continue;
            }
            if (is_array($value)) {
                $found = $this->find_traffic_key($value, $keys);
                if ($found !== null) {
                    return $found;
                }
            }
        }
        return null;
    }

    private function find_string_key($data, $keys)
    {
        if (!is_array($data)) {
            return '';
        }
        foreach ($data as $key => $value) {
            $key_norm = strtolower((string) $key);
            if (in_array($key_norm, $keys, true) && !is_array($value) && !is_object($value) && $value !== '') {
                return (string) $value;
            }
        }
        if (!empty($data['after']) && is_array($data['after'])) {
            $found = $this->find_string_key($data['after'], $keys);
            if ($found !== '') {
                return $found;
            }
        }
        foreach ($data as $key => $value) {
            if ((string) $key === 'after') {
                continue;
            }
            if (is_array($value)) {
                $found = $this->find_string_key($value, $keys);
                if ($found !== '') {
                    return $found;
                }
            }
        }
        return '';
    }

    private function traffic_expire_timestamp($value)
    {
        if ($value === '' || $value === null || is_array($value) || is_object($value)) {
            return 0;
        }
        if (is_numeric($value)) {
            $n = (float) $value;
            if ($n > 1000000000000) {
                return (int) floor($n / 1000);
            }
            if ($n > 1000000000) {
                return (int) $n;
            }
        }
        $ts = strtotime((string) $value);
        return $ts ? (int) $ts : 0;
    }

    private function format_expiry_datetime($value)
    {
        if ($value === '' || $value === null || is_array($value) || is_object($value)) {
            return '-';
        }

        $value = trim((string) $value);
        if (preg_match('/\A(\d{4}-\d{2}-\d{2})[T\s](\d{2}:\d{2}(?::\d{2})?)(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?\z/i', $value, $matches)) {
            return $matches[1] . ' ' . $matches[2];
        }

        $timestamp = $this->traffic_expire_timestamp($value);
        return $timestamp ? wp_date('Y-m-d H:i:s', $timestamp) : '-';
    }

    private function traffic_sync_cache_key($order_id)
    {
        return 'ipsvp_traffic_sync_' . (int) $order_id;
    }

    private function refresh_site_order_traffic_snapshot($order, $force = false, $context = 'frontend_order_list')
    {
        if (!$order || !is_object($order) || empty($order->id) || (empty($order->pg_username) && empty($order->pg_user_id))) {
            return false;
        }
        $order_id = (int) $order->id;
        $cache_key = $this->traffic_sync_cache_key($order_id);
        if (!$force && get_transient($cache_key)) {
            return false;
        }
        if ((int) ($order->country_id ?? 0) === 0) {
            $this->api->ensure_all_countries_groups_for_order($order, $this->db->ready_countries());
        }
        $snapshot = $this->api->user_snapshot($order->pg_username, $order->pg_user_id, $order);
        if (!is_array($snapshot)) {
            set_transient($cache_key, 1, 5 * MINUTE_IN_SECONDS);
            $this->db->add_log('warning', $context . '_traffic_sync_failed', 'دریافت اطلاعات به‌روز مصرف از PasarGuard ناموفق بود.', array('order_id' => $order_id, 'error' => 'invalid_snapshot'), $order->phone, $order_id, 0, $order->user_id);
            return false;
        }
        if (!empty($snapshot['error']) && empty($snapshot['live'])) {
            set_transient($cache_key, 1, 5 * MINUTE_IN_SECONDS);
            $this->db->add_log('warning', $context . '_traffic_sync_failed', 'دریافت اطلاعات به‌روز مصرف از PasarGuard ناموفق بود.', array('order_id' => $order_id, 'error' => (string) $snapshot['error']), $order->phone, $order_id, 0, $order->user_id);
            return false;
        }

        $live = (!empty($snapshot['live']) && is_array($snapshot['live'])) ? $snapshot['live'] : array();
        $status = isset($snapshot['status']) ? (string) $snapshot['status'] : '';
        $sub = !empty($snapshot['subscription_url']) ? (string) $snapshot['subscription_url'] : '';
        $links = (!empty($snapshot['links']) && is_array($snapshot['links'])) ? $snapshot['links'] : array();
        $user_id = (!empty($snapshot['user_id']) ? (string) $snapshot['user_id'] : ((!empty($order->pg_user_id) && ctype_digit((string) $order->pg_user_id)) ? (string) $order->pg_user_id : ''));
        $update = array();

        if ($user_id && (string) $user_id !== (string) $order->pg_user_id) {
            $update['pg_user_id'] = $user_id;
        }
        if ($status && (string) $status !== (string) $order->pg_status) {
            $update['pg_status'] = $status;
        }
        if ($sub && (string) $sub !== (string) $order->pg_subscription_url) {
            $update['pg_subscription_url'] = $sub;
        }
        if ($links) {
            $links_json = wp_json_encode(array_values($links), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($links_json && $links_json !== (string) $order->pg_links) {
                $update['pg_links'] = $links_json;
            }
        }
        if ($live) {
            $live_for_save = $live;
            if (!empty($order->pg_response)) {
                $old_raw = json_decode((string) $order->pg_response, true);
                if (is_array($old_raw) && !empty($old_raw['_all_countries'])) {
                    $live_for_save['_all_countries'] = $old_raw['_all_countries'];
                }
            }
            $update['pg_response'] = wp_json_encode($live_for_save, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $update['pg_synced_at'] = $this->db->now();
        }
        if ($update) {
            $this->db->update_order($order_id, $update);
            unset($this->traffic_summary_cache['site:' . $order_id]);
        }
        $before_lifecycle = $this->db->get_order($order_id);
        $after_lifecycle = $this->db->apply_order_lifecycle_snapshot($before_lifecycle, $snapshot);
        if ($after_lifecycle && (string) $after_lifecycle->status === 'cancelled' && (string) $before_lifecycle->status !== 'cancelled') {
            $remote_status = $this->api->update_user_status_for_order($after_lifecycle, 'cancelled');
            if (is_wp_error($remote_status)) {
                $this->db->add_log('warning', $context . '_auto_cancel_pg_status', $remote_status->get_error_message(), array('order_id' => $order_id), $order->phone, $order_id, 0, $order->user_id);
            }
        }
        set_transient($cache_key, 1, 10 * MINUTE_IN_SECONDS);
        return true;
    }

    private function sync_user_orders_traffic_for_list($phone, $orders = null)
    {
        if ($orders === null) {
            $orders = $this->db->get_user_orders($phone);
        }
        if (!$orders) {
            return;
        }
        $attempts = 0;
        foreach ($orders as $order) {
            if (!$this->active_order_for_service_warning($order, 'site')) {
                continue;
            }
            if (empty($order->pg_username) && empty($order->pg_user_id)) {
                continue;
            }
            if (!empty($order->id) && get_transient($this->traffic_sync_cache_key((int) $order->id))) {
                continue;
            }
            $this->refresh_site_order_traffic_snapshot($order, false, 'frontend_orders_tab');
            $attempts++;
            if ($attempts >= 3) {
                break;
            }
        }
    }

    private function service_warning_expired_beyond_grace($summary)
    {
        if (empty($summary['expire_ts'])) {
            return false;
        }
        return time() > ((int) $summary['expire_ts'] + (7 * DAY_IN_SECONDS));
    }

    private function active_order_for_service_warning($order, $source = 'site')
    {
        $bad = array('pending','pending_receipt','waiting_review','rejected','cancelled','canceled','failed','deleted','expired');
        if ($source === 'bot' && is_array($order)) {
            $detail = $this->normalize_bot_order_detail($order);
            $status = strtolower(trim((string) ($detail['pg_status'] ?? ($order['status'] ?? ''))));
            return $status === '' || !in_array($status, $bad, true);
        }
        $status = strtolower(trim((string) ($order->status ?? '')));
        return $status !== '' && !in_array($status, $bad, true);
    }

    private function get_order_traffic_summary($order, $source = 'site', $allow_live = true)
    {
        $cache_id = '';
        if ($source === 'bot' && is_array($order) && !empty($order['id'])) {
            $cache_id = 'bot:' . (int) $order['id'];
        } elseif ($source !== 'bot' && is_object($order) && !empty($order->id)) {
            $cache_id = 'site:' . (int) $order->id;
        }
        if ($allow_live && $cache_id !== '' && isset($this->traffic_summary_cache[$cache_id])) {
            return $this->traffic_summary_cache[$cache_id];
        }
        $used_keys = array('used_traffic','used','data_usage','used_data','used_bytes','usage','current_usage','traffic_used','usedtraffic');
        $limit_keys = array('data_limit','total','total_traffic','limit','total_bytes','traffic_limit','volume_limit','totaltraffic');
        $expire_keys = array('expire','expired_at','expiry_time','expire_at','expires_at','expiration','expiry');
        $raw = array();
        $username = '';
        $user_id = '';
        $fallback_limit = null;
        $fallback_expire = '';

        if ($source === 'bot' && is_array($order)) {
            $detail = $this->normalize_bot_order_detail($order);
            $raw = array_merge($order, $detail);
            $username = isset($detail['code']) && !preg_match('#^(vless|vmess|trojan|ss|hysteria2)://#i', (string) $detail['code']) ? (string) $detail['code'] : (string) ($order['remark'] ?? '');
            $user_id = !empty($detail['pg_user_id']) ? (string) $detail['pg_user_id'] : (!empty($order['uid']) ? (string) $order['uid'] : '');
        } else {
            if (!empty($order->pg_response)) {
                $decoded = json_decode((string) $order->pg_response, true);
                if (is_array($decoded)) {
                    $raw = $decoded;
                }
            }
            $username = !empty($order->pg_username) ? (string) $order->pg_username : '';
            $user_id = !empty($order->pg_user_id) ? (string) $order->pg_user_id : '';
            if (isset($order->gb) && $order->gb !== null && $order->gb !== '') {
                $fallback_limit = (float) $order->gb * 1024 * 1024 * 1024;
            }
            if (!empty($order->approved_at) && !empty($order->days)) {
                $approved_ts = strtotime((string) $order->approved_at);
                if ($approved_ts) {
                    $fallback_expire = gmdate('Y-m-d H:i:s', $approved_ts + ((int) $order->days * DAY_IN_SECONDS));
                }
            }
        }

        $used = $this->find_traffic_key($raw, $used_keys);
        $limit = $this->find_traffic_key($raw, $limit_keys);
        $expire = $this->find_string_key($raw, $expire_keys);
        $snapshot_error = '';

        $live_fallback_allowed = $allow_live && ($used === null || $limit === null || $expire === '') && ($username !== '' || $user_id !== '') && $this->active_order_for_service_warning($order, $source);
        if ($live_fallback_allowed && $source !== 'bot' && is_object($order) && !empty($order->id) && get_transient($this->traffic_sync_cache_key((int) $order->id))) {
            $live_fallback_allowed = false;
        }
        if ($live_fallback_allowed) {
            $snapshot = $this->api->user_snapshot($username, $user_id, $source === 'bot' ? null : $order);
            if (is_array($snapshot)) {
                $snapshot_error = !empty($snapshot['error']) ? (string) $snapshot['error'] : '';
                if ($used === null && isset($snapshot['used'])) {
                    $used = $this->normalize_traffic_number($snapshot['used']);
                }
                if ($limit === null && isset($snapshot['limit'])) {
                    $limit = $this->normalize_traffic_number($snapshot['limit']);
                }
                if ($expire === '' && !empty($snapshot['expire'])) {
                    $expire = (string) $snapshot['expire'];
                }
            }
        }

        if ($limit === null && $fallback_limit !== null) {
            $limit = $fallback_limit;
        }
        if ($expire === '' && $fallback_expire !== '') {
            $expire = $fallback_expire;
        }

        $expire_ts = $this->traffic_expire_timestamp($expire);
        if ($limit !== null && $limit <= 0) {
            $summary = array(
                'state' => 'unlimited',
                'used_bytes' => max(0, (float) ($used ?: 0)),
                'total_bytes' => 0,
                'remaining_bytes' => null,
                'percent' => 0,
                'expire' => $expire,
                'expire_ts' => $expire_ts,
                'error' => $snapshot_error,
            );
            if ($allow_live && $cache_id !== '') { $this->traffic_summary_cache[$cache_id] = $summary; }
            return $summary;
        }
        if ($used === null && $limit === null) {
            $summary = array(
                'state' => 'missing',
                'used_bytes' => null,
                'total_bytes' => null,
                'remaining_bytes' => null,
                'percent' => null,
                'expire' => $expire,
                'expire_ts' => $expire_ts,
                'error' => $snapshot_error,
            );
            if ($allow_live && $cache_id !== '') { $this->traffic_summary_cache[$cache_id] = $summary; }
            return $summary;
        }
        $used = max(0, (float) ($used ?: 0));
        $limit = max(0, (float) ($limit ?: 0));
        if ($limit <= 0) {
            $summary = array(
                'state' => 'missing',
                'used_bytes' => $used,
                'total_bytes' => null,
                'remaining_bytes' => null,
                'percent' => null,
                'expire' => $expire,
                'expire_ts' => $expire_ts,
                'error' => $snapshot_error,
            );
            if ($allow_live && $cache_id !== '') { $this->traffic_summary_cache[$cache_id] = $summary; }
            return $summary;
        }
        $remaining = max(0, $limit - $used);
        $percent = min(100, max(0, ($used / $limit) * 100));
        $summary = array(
            'state' => 'limited',
            'used_bytes' => $used,
            'total_bytes' => $limit,
            'remaining_bytes' => $remaining,
            'percent' => $percent,
            'expire' => $expire,
            'expire_ts' => $expire_ts,
            'error' => $snapshot_error,
        );
        if ($allow_live && $cache_id !== '') { $this->traffic_summary_cache[$cache_id] = $summary; }
        return $summary;
    }

    private function format_traffic_size($bytes)
    {
        if ($bytes === '' || $bytes === null) {
            return '-';
        }
        $bytes = max(0, (float) $bytes);
        $gb = $bytes / 1024 / 1024 / 1024;
        if ($gb >= 1) {
            return number_format_i18n($gb, 2) . ' GB';
        }
        $mb = $bytes / 1024 / 1024;
        return number_format_i18n($mb, $mb >= 10 ? 0 : 2) . ' MB';
    }

    private function render_order_traffic_bar($order, $source = 'site')
    {
        $summary = $this->get_order_traffic_summary($order, $source, true);
        if ($summary['state'] === 'unlimited') {
            return '<div class="ipsvp-order-traffic ipsvp-order-traffic-unlimited"><span>حجم سرویس</span><strong>حجم نامحدود</strong></div>';
        }
        if ($summary['state'] !== 'limited') {
            return '<div class="ipsvp-order-traffic ipsvp-order-traffic-missing"><span>وضعیت مصرف</span><strong>اطلاعات مصرف در دسترس نیست</strong></div>';
        }
        $percent = (float) $summary['percent'];
        $remaining = $summary['remaining_bytes'];
        ob_start();
        echo '<div class="ipsvp-order-traffic" aria-label="وضعیت مصرف حجم">';
        echo '<div class="ipsvp-traffic-meta"><span class="ipsvp-traffic-used">مصرف‌شده: ' . esc_html($this->format_traffic_size($summary['used_bytes'])) . '</span><b class="ipsvp-traffic-percent">' . esc_html(number_format_i18n(round($percent))) . '%</b></div>';
        echo '<div class="ipsvp-traffic-bar"><i style="width:' . esc_attr(number_format($percent, 2, '.', '')) . '%"></i></div>';
        echo '<div class="ipsvp-traffic-remaining">باقی‌مانده: ' . esc_html($this->format_traffic_size($remaining)) . ' از ' . esc_html($this->format_traffic_size($summary['total_bytes'])) . '</div>';
        echo '</div>';
        return ob_get_clean();
    }

    private function service_warning_action_url($source, $order_id, $action)
    {
        $args = array('ips_action' => $action);
        if ($source === 'bot') {
            $args['ipsvp_tab'] = 'bot_detail';
            $args['ipsvp_bot_order_id'] = (int) $order_id;
        } else {
            $args['ipsvp_tab'] = 'detail';
            $args['ipsvp_order_id'] = (int) $order_id;
        }
        return $this->current_page_url($args);
    }

    private function build_service_warning_items($phone)
    {
        $settings = IPSVP_Settings::get();
        if (empty($settings['service_warnings_enabled']) || (string) $settings['service_warnings_enabled'] !== '1') {
            return array();
        }
        $items = array();
        $expiry_enabled = !empty($settings['warning_expiry_enabled']) && (string) $settings['warning_expiry_enabled'] === '1';
        $traffic_enabled = !empty($settings['warning_traffic_enabled']) && (string) $settings['warning_traffic_enabled'] === '1';
        $expiry_days = isset($settings['warning_expiry_days']) ? max(0, (int) $settings['warning_expiry_days']) : 1;
        $traffic_threshold = isset($settings['warning_traffic_gb']) ? max(0, (float) $settings['warning_traffic_gb']) * 1024 * 1024 * 1024 : 1024 * 1024 * 1024;
        $combine = !empty($settings['warning_combine_enabled']) && (string) $settings['warning_combine_enabled'] === '1';
        $now = time();

        $this->sync_user_orders_traffic_for_list($phone);
        $orders = $this->db->get_user_orders($phone);
        foreach ($orders as $order) {
            if (!$this->active_order_for_service_warning($order, 'site')) {
                continue;
            }
            $summary = $this->get_order_traffic_summary($order, 'site', true);
            if ($this->service_warning_expired_beyond_grace($summary)) {
                continue;
            }
            $warnings = array();
            $is_dedicated = $this->db->order_service_type($order) === 'dedicated';
            if (($expiry_enabled || $is_dedicated) && !empty($summary['expire_ts'])) {
                $seconds_left = (int) $summary['expire_ts'] - $now;
                $warning_days = $is_dedicated ? 5 : $expiry_days;
                if ($seconds_left <= ($warning_days * DAY_IN_SECONDS)) {
                    $is_critical = $is_dedicated && $seconds_left <= DAY_IN_SECONDS;
                    if ($is_dedicated) {
                        $expiry_title = $is_critical ? 'کمتر از ۲۴ ساعت تا پایان سرویس اختصاصی' : 'تمدید فوری سرویس اختصاصی';
                        $expiry_message = $seconds_left <= 0
                            ? 'مهلت سرویس اختصاصی شما به پایان رسیده است. سرویس و IP اختصاصی ممکن است از دسترس خارج شده باشند و قابل بازگشت نیستند.'
                            : ($is_critical
                                ? 'کمتر از ۲۴ ساعت تا پایان سرویس باقی مانده است. همین حالا تمدید کنید؛ در غیر این صورت سرویس و IP اختصاصی از دسترس خارج می‌شوند و قابل بازگشت نیستند.'
                                : 'این سرور به‌صورت اختصاصی برای شما تهیه شده است. حتماً پیش از تاریخ پایان آن را تمدید کنید؛ در غیر این صورت سرویس و IP از دسترس خارج می‌شوند و قابل بازگشت نیستند.');
                    } else {
                        $expiry_title = !empty($settings['warning_expiry_title']) ? (string) $settings['warning_expiry_title'] : 'تمدید سرویس نزدیک است';
                        $expiry_message = $seconds_left <= 0 ? 'سرویس شما منقضی شده یا در آستانه انقضا است.' : (!empty($settings['warning_expiry_message']) ? (string) $settings['warning_expiry_message'] : 'اعتبار سرویس شما رو به پایان است.');
                    }
                    $warnings['expiry'] = array(
                        'title' => $expiry_title,
                        'message' => $expiry_message,
                        'button' => !empty($settings['warning_expiry_button']) ? (string) $settings['warning_expiry_button'] : 'تمدید سرویس',
                        'url' => $this->service_warning_action_url('site', $order->id, 'renew'),
                        'severity' => $is_critical ? 'critical' : 'warning',
                    );
                }
            }
            if ($traffic_enabled && $summary['state'] === 'limited' && $summary['remaining_bytes'] !== null && (float) $summary['remaining_bytes'] <= $traffic_threshold) {
                $warnings['traffic'] = array(
                    'title' => !empty($settings['warning_traffic_title']) ? (string) $settings['warning_traffic_title'] : 'حجم سرویس رو به پایان است',
                    'message' => (float) $summary['remaining_bytes'] <= 0 ? 'حجم سرویس شما تمام شده است.' : (!empty($settings['warning_traffic_message']) ? (string) $settings['warning_traffic_message'] : 'حجم باقی‌مانده سرویس شما کم است.'),
                    'button' => !empty($settings['warning_traffic_button']) ? (string) $settings['warning_traffic_button'] : 'خرید حجم اضافه',
                    'url' => $this->service_warning_action_url('site', $order->id, 'extra_volume'),
                );
            }
            if ($warnings) {
                $base = array(
                    'source' => 'site',
                    'order_id' => (int) $order->id,
                    'order_code' => (string) $order->order_code,
                    'plan' => (string) $order->plan_title,
                    'country' => trim((string) $order->flag . ' ' . (string) $order->country_name),
                    'summary' => $summary,
                    'severity' => !empty($warnings['expiry']['severity']) ? (string) $warnings['expiry']['severity'] : 'warning',
                );
                if ($combine || count($warnings) === 1) {
                    $items[] = array_merge($base, array('type' => implode('_', array_keys($warnings)), 'warnings' => $warnings));
                } else {
                    foreach ($warnings as $type => $warning) {
                        $items[] = array_merge($base, array('type' => $type, 'warnings' => array($type => $warning)));
                    }
                }
            }
        }

        $bot_orders = $this->get_user_bot_orders($phone);
        foreach ($bot_orders as $order) {
            $bot_id = (int) ($order['id'] ?? 0);
            if ($bot_id <= 0 || !$this->active_order_for_service_warning($order, 'bot')) {
                continue;
            }
            $summary = $this->get_order_traffic_summary($order, 'bot', true);
            if ($this->service_warning_expired_beyond_grace($summary)) {
                continue;
            }
            $detail = $this->normalize_bot_order_detail($order);
            $warnings = array();
            if ($expiry_enabled && !empty($summary['expire_ts'])) {
                $seconds_left = (int) $summary['expire_ts'] - $now;
                $days_left = (int) ceil($seconds_left / DAY_IN_SECONDS);
                if ($days_left <= $expiry_days) {
                    $warnings['expiry'] = array(
                        'title' => !empty($settings['warning_expiry_title']) ? (string) $settings['warning_expiry_title'] : 'تمدید سرویس نزدیک است',
                        'message' => $seconds_left <= 0 ? 'سرویس شما منقضی شده یا در آستانه انقضا است.' : (!empty($settings['warning_expiry_message']) ? (string) $settings['warning_expiry_message'] : 'اعتبار سرویس شما رو به پایان است.'),
                        'button' => !empty($settings['warning_expiry_button']) ? (string) $settings['warning_expiry_button'] : 'تمدید سرویس',
                        'url' => $this->service_warning_action_url('bot', $bot_id, 'renew'),
                    );
                }
            }
            if ($traffic_enabled && $summary['state'] === 'limited' && $summary['remaining_bytes'] !== null && (float) $summary['remaining_bytes'] <= $traffic_threshold) {
                $warnings['traffic'] = array(
                    'title' => !empty($settings['warning_traffic_title']) ? (string) $settings['warning_traffic_title'] : 'حجم سرویس رو به پایان است',
                    'message' => (float) $summary['remaining_bytes'] <= 0 ? 'حجم سرویس شما تمام شده است.' : (!empty($settings['warning_traffic_message']) ? (string) $settings['warning_traffic_message'] : 'حجم باقی‌مانده سرویس شما کم است.'),
                    'button' => !empty($settings['warning_traffic_button']) ? (string) $settings['warning_traffic_button'] : 'خرید حجم اضافه',
                    'url' => $this->service_warning_action_url('bot', $bot_id, 'extra_volume'),
                );
            }
            if ($warnings) {
                $base = array(
                    'source' => 'bot',
                    'order_id' => $bot_id,
                    'order_code' => (string) ($order['remark'] ?? ('سفارش #' . $bot_id)),
                    'plan' => (string) ($order['plan'] ?? ''),
                    'country' => (string) ($detail['country'] ?? ''),
                    'summary' => $summary,
                );
                if ($combine || count($warnings) === 1) {
                    $items[] = array_merge($base, array('type' => implode('_', array_keys($warnings)), 'warnings' => $warnings));
                } else {
                    foreach ($warnings as $type => $warning) {
                        $items[] = array_merge($base, array('type' => $type, 'warnings' => array($type => $warning)));
                    }
                }
            }
        }

        return $items;
    }

    private function render_service_warning_popup($phone)
    {
        $items = $this->build_service_warning_items($phone);
        if (!$items) {
            return '';
        }
        $settings = IPSVP_Settings::get();
        $repeat = isset($settings['warning_popup_repeat_mode']) ? (string) $settings['warning_popup_repeat_mode'] : 'daily';
        if (!in_array($repeat, array('session','daily','always'), true)) {
            $repeat = 'daily';
        }
        $once_after_login = !empty($settings['warning_once_after_login']) && (string) $settings['warning_once_after_login'] === '1';
        ob_start();
        echo '<div class="ipsvp-service-warning-popup" data-service-warning-popup data-repeat-mode="' . esc_attr($repeat) . '" data-once-after-login="' . esc_attr($once_after_login ? '1' : '0') . '" hidden>';
        echo '<div class="ipsvp-service-warning-overlay" data-service-warning-close></div>';
        echo '<section class="ipsvp-service-warning-card" role="dialog" aria-modal="true" aria-label="هشدارهای سرویس">';
        echo '<button type="button" class="ipsvp-service-warning-close" data-service-warning-close aria-label="بستن">×</button>';
        echo '<div class="ipsvp-service-warning-head"><span>هشدار حساب کاربری</span><h3>سرویس‌های نیازمند توجه</h3><p>برای جلوگیری از قطع سرویس، وضعیت سفارش‌های زیر را بررسی کنید.</p></div>';
        echo '<div class="ipsvp-service-warning-list">';
        foreach ($items as $item) {
            $summary = $item['summary'];
            $days_left_text = !empty($summary['expire_ts']) ? human_time_diff(time(), (int) $summary['expire_ts']) : '-';
            if (!empty($summary['expire_ts']) && (int) $summary['expire_ts'] <= time()) {
                $days_left_text = 'منقضی شده';
            }
            $severity = !empty($item['severity']) ? (string) $item['severity'] : 'warning';
            $key = md5($phone . '|' . $item['source'] . '|' . $item['order_id'] . '|' . $item['type'] . '|' . $severity);
            echo '<article class="ipsvp-service-warning-item ipsvp-service-warning-' . esc_attr($severity) . '" data-warning-key="' . esc_attr($key) . '">';
            echo '<div class="ipsvp-service-warning-item-top"><strong>' . esc_html($item['order_code']) . '</strong><span>' . esc_html($item['plan'] ? $item['plan'] : '-') . '</span></div>';
            echo '<div class="ipsvp-service-warning-grid">';
            echo '<div><span>کشور/پلن</span><b>' . esc_html($item['country'] ? $item['country'] : '-') . '</b></div>';
            echo '<div><span>انقضا</span><b>' . esc_html(!empty($summary['expire']) ? (string) $summary['expire'] : '-') . '</b></div>';
            echo '<div><span>زمان باقی‌مانده</span><b>' . esc_html($days_left_text) . '</b></div>';
            if ($summary['state'] === 'limited') {
                echo '<div><span>حجم کل</span><b>' . esc_html($this->format_traffic_size($summary['total_bytes'])) . '</b></div>';
                echo '<div><span>مصرف‌شده</span><b>' . esc_html($this->format_traffic_size($summary['used_bytes'])) . '</b></div>';
                echo '<div><span>باقی‌مانده</span><b>' . esc_html($this->format_traffic_size($summary['remaining_bytes'])) . '</b></div>';
            } elseif ($summary['state'] === 'unlimited') {
                echo '<div><span>حجم</span><b>نامحدود</b></div>';
            }
            echo '</div>';
            echo '<div class="ipsvp-service-warning-messages">';
            foreach ($item['warnings'] as $warning) {
                echo '<p><strong>' . esc_html($warning['title']) . '</strong><br>' . esc_html($warning['message']) . '</p>';
            }
            echo '</div><div class="ipsvp-service-warning-actions">';
            foreach ($item['warnings'] as $type => $warning) {
                echo '<a class="ipsvp-btn" href="' . esc_url($warning['url']) . '">' . esc_html($warning['button']) . '</a>';
            }
            echo '</div></article>';
        }
        echo '</div></section></div>';
        return ob_get_clean();
    }

    private function render_site_order_row($o)
    {
        $source = '';
        if (property_exists($o, 'reseller_channel')) {
            $label = ($o->reseller_channel ?? '') === 'api' ? 'وب‌سرویس' : (($o->reseller_channel ?? '') === 'panel' ? 'ثبت دستی نماینده' : 'سایت');
            $source = '<span class="ipsr-order-meta">' . esc_html($label) . (!empty($o->reseller_reference) ? ' · ' . esc_html($o->reseller_reference) : '') . '</span>';
        }
        $payment_method_label = $this->db->get_order_payment_method_label($o);
        $service_label = $this->db->order_service_type($o) === 'dedicated' ? 'اختصاصی' : 'اشتراکی';
        return '<form method="post" class="ipsvp-order-row ipsvp-order-row-with-traffic"><input type="hidden" name="ipsvp_tab" value="detail"><input type="hidden" name="ipsvp_order_id" value="' . esc_attr($o->id) . '"><div class="ipsvp-order-row-main"><strong>' . esc_html($o->order_code) . '</strong><span>' . esc_html('آی پی ثابت ' . $service_label . ' / ' . $o->plan_title . ' / ' . $o->flag . ' ' . $o->country_name) . '</span><span>روش پرداخت: ' . esc_html($payment_method_label) . '</span>' . $source . '</div><div class="ipsvp-order-row-traffic">' . $this->render_order_traffic_bar($o, 'site') . '</div><div class="ipsvp-order-row-side"><span class="ipsvp-badge ipsvp-' . esc_attr($o->status) . '">' . esc_html($this->db->status_label($o->status)) . '</span><button type="submit">جزییات</button></div></form>';
    }

    private function render_reseller_orders($phone)
    {
        $user = $this->db->get_user_by_phone($phone);
        if (!$user || !empty($user->is_blocked)) { return '<div class="ipsvp-alert">حساب در دسترس نیست.</div>'; }
        $filters = IPSVP_Reseller_Reports::filters($_GET);
        $result = IPSVP_Reseller_Reports::orders($this->db, $user->id, $filters);
        // Refresh only the visible page, not every service owned by a large reseller.
        $this->sync_user_orders_traffic_for_list($phone, $result['items']);
        $result = IPSVP_Reseller_Reports::orders($this->db, $user->id, $filters);
        $bot_orders = $filters['source'] === '' ? $this->get_user_bot_orders($phone) : array();
        if ($filters['search'] !== '' || $filters['status'] !== '') {
            $bot_orders = array_filter($bot_orders, static function ($row) use ($filters) {
                $text = implode(' ', array($row['id'] ?? '', $row['remark'] ?? '', $row['plan'] ?? ''));
                return ($filters['search'] === '' || stripos($text, $filters['search']) !== false) && ($filters['status'] === '' || ($row['status'] ?? '') === $filters['status']);
            });
        }
        ob_start();
        include IPSVP_PLUGIN_DIR . 'templates/reseller-orders.php';
        return ob_get_clean();
    }

    private function render_user_orders($phone)
    {
        if (IPSVP_Reseller::account_for_phone($phone)) { return $this->render_reseller_orders($phone); }
        $orders = $this->db->get_user_orders($phone);
        $this->sync_user_orders_traffic_for_list($phone, $orders);
        $orders = $this->db->get_user_orders($phone);
        $user = $this->db->get_user_by_phone($phone);
        $bot_orders = $this->get_user_bot_orders($phone);
        ob_start();
        echo '<div class="ipsvp-user-card"><h3>سفارش های شما</h3>';
        if (!$orders && !$bot_orders) {
            echo '<p>هنوز سفارشی برای این شماره ثبت نشده است.</p>';
            if (!$user || empty($user->bot_tel_id)) {
                echo '<div class="ipsvp-alert">برای دیدن سفارش های ربات داخل سایت، از بخش اطلاعات کاربری، حساب سایت را به ربات وصل کنید.</div>';
            }
            echo '</div>';
            return ob_get_clean();
        }
        if ($orders) {
            echo '<h4>سفارش های سایت</h4><div class="ipsvp-order-list">';
            foreach ($orders as $o) {
                echo $this->render_site_order_row($o);
            }
            echo '</div>';
        }
        if ($bot_orders) {
            echo '<h4>سفارش های ربات</h4><div class="ipsvp-order-list ipsvp-bot-order-list">';
            foreach ($bot_orders as $bo) {
                $bot_id = (int) ($bo['id'] ?? 0);
                $title = isset($bo['remark']) ? $bo['remark'] : ('سفارش #' . $bot_id);
                $plan = isset($bo['plan']) ? $bo['plan'] : '';
                $status = $this->bot_order_status_label($bo);
                echo '<form method="post" class="ipsvp-order-row ipsvp-order-row-with-traffic"><input type="hidden" name="ipsvp_tab" value="bot_detail"><input type="hidden" name="ipsvp_bot_order_id" value="' . esc_attr($bot_id) . '"><div class="ipsvp-order-row-main"><strong>' . esc_html($title) . '</strong><span>' . esc_html($plan) . '</span></div><div class="ipsvp-order-row-traffic">' . $this->render_order_traffic_bar($bo, 'bot') . '</div><div class="ipsvp-order-row-side"><span class="ipsvp-badge ipsvp-' . esc_attr($bo['status'] ?? '') . '">' . esc_html($status) . '</span><button type="submit">جزییات</button></div></form>';
            }
            echo '</div>';
        } elseif ($user && !empty($user->bot_tel_id)) {
            echo '<div class="ipsvp-alert">سفارش فعالی از ربات برای این حساب دریافت نشد.</div>';
        }
        echo '</div>';
        return ob_get_clean();
    }

    private function render_user_bot_order_detail($bot_order_id, $phone, $message = '')
    {
        $order = $this->find_user_bot_order($phone, $bot_order_id);
        if (!$order) {
            return '<div class="ipsvp-alert">سفارش ربات پیدا نشد یا حساب شما به ربات متصل نیست.</div>';
        }
        $detail = $this->normalize_bot_order_detail($order);
        $title = isset($order['remark']) ? $order['remark'] : ('سفارش #' . (int) ($order['id'] ?? 0));
        $status = $this->bot_order_status_label($order);
        $status_raw = isset($order['status']) ? (string) $order['status'] : '';
        $source = isset($order['source']) ? $order['source'] : 'bot';
        $country = isset($detail['country']) ? $detail['country'] : '';
        $price = isset($detail['price']) ? (int) $detail['price'] : 0;
        $pg_username = isset($detail['code']) && !preg_match('#^(vless|vmess|trojan|ss|hysteria2)://#i', (string) $detail['code']) ? (string) $detail['code'] : $title;
        $pg_user_id = !empty($detail['pg_user_id']) ? (string) $detail['pg_user_id'] : (!empty($order['uid']) ? (string) $order['uid'] : '');
        $sub = isset($detail['subscription_url']) ? $detail['subscription_url'] : (!empty($order['sub_id']) ? (string) $order['sub_id'] : '');
        $links = isset($detail['links']) && is_array($detail['links']) ? $detail['links'] : array();
        if (!empty($order['links']) && is_array($order['links'])) {
            $links = array_values(array_unique(array_merge($links, $order['links'])));
        }
        $snapshot = $this->api->user_snapshot($pg_username, $pg_user_id);
        $live = (!empty($snapshot['live']) && is_array($snapshot['live'])) ? $snapshot['live'] : array();
        $used = isset($snapshot['used']) ? $snapshot['used'] : '';
        $limit = isset($snapshot['limit']) ? $snapshot['limit'] : '';
        $expire = isset($snapshot['expire']) ? $snapshot['expire'] : '';
        $panel_status = !empty($snapshot['status']) ? (string) $snapshot['status'] : '';
        if (!$panel_status && !empty($detail['pg_status'])) {
            $panel_status = (string) $detail['pg_status'];
        }
        if (!empty($snapshot['links']) && is_array($snapshot['links'])) {
            $links = array_values($snapshot['links']);
        }
        if (!empty($snapshot['subscription_url'])) {
            $sub = (string) $snapshot['subscription_url'];
        }
        if (!empty($snapshot['user_id'])) {
            $pg_user_id = (string) $snapshot['user_id'];
        }
        $subscription_content = !empty($snapshot['subscription_content']) ? (string) $snapshot['subscription_content'] : '';
        $subscription_error = !empty($snapshot['subscription_error']) ? (string) $snapshot['subscription_error'] : '';
        if ($live || $links || $sub || $panel_status) {
            $detail['pg_user_id'] = $pg_user_id;
            $detail['pg_status'] = $panel_status ? $panel_status : ($detail['pg_status'] ?? '');
            if ($sub) {
                $detail['subscription_url'] = $sub;
            }
            if ($links) {
                $detail['links'] = array_values($links);
            }
            if ($live) {
                $detail['latest_pasarguard'] = $live;
            }
            $linked_user = $this->db->get_user_by_phone($phone);
            if ($linked_user && !empty($linked_user->bot_tel_id) && !empty($order['id'])) {
                IPSVP_Bot_API::update_bot_order($linked_user->bot_tel_id, (int) $order['id'], array(
                    'uid' => $pg_user_id,
                    'sub_id' => $sub,
                    'status' => $panel_status ? $panel_status : ($order['status'] ?? ''),
                    'detail' => $detail,
                ));
            }
        }
        $renew_message = '';
        if (!empty($_GET['ipsvp_bot_wallet_renewal_done'])) {
            $renew_message = '<div class="ipsvp-success">تمدید سفارش ربات با کیف پول انجام شد و کانفیگ بروزرسانی شد.</div>';
        } elseif (!empty($_GET['ipsvp_bot_renewal_done'])) {
            $renew_message = '<div class="ipsvp-success">درخواست تمدید سفارش ربات ثبت شد. بعد از تایید رسید توسط ادمین، همین کانفیگ بروزرسانی می شود.</div>';
        }
        ob_start();
        echo '<div class="ipsvp-user-card ipsvp-detail-front"><h3>جزییات سفارش ربات #' . esc_html((string) ($order['id'] ?? '')) . '</h3>';
        if ($message) {
            echo $message;
        }
        echo $renew_message;
        echo '<div class="ipsvp-invoice-grid">';
        echo '<div><span>پلن</span><b>' . esc_html($order['plan'] ?? '-') . '</b></div>';
        echo '<div><span>کشور</span><b>' . esc_html($country ? $country : '-') . '</b></div>';
        echo '<div><span>وضعیت سفارش</span><b>' . esc_html($status) . '</b></div>';
        echo '<div><span>تاریخ ثبت</span><b>' . esc_html($order['created_at'] ?? '-') . '</b></div>';
        echo '<div><span>منبع</span><b>' . esc_html($source === 'wordpress' ? 'سایت' : 'ربات') . '</b></div>';
        echo '<div><span>مبلغ</span><b>' . esc_html($price ? number_format_i18n($price) . ' تومان' : '-') . '</b></div>';
        echo '</div>';
        echo '<div class="ipsvp-live-grid">';
        echo '<div><span>یوزرنیم</span><b>' . esc_html($pg_username ? $pg_username : '-') . '</b></div>';
        echo '<div><span>وضعیت پنل</span><b>' . esc_html($this->db->status_label($panel_status ? $panel_status : $status_raw)) . '</b></div>';
        echo '<div><span>حجم مصرف شده</span><b>' . esc_html($this->format_bytes($used)) . '</b></div>';
        echo '<div><span>حجم کل</span><b>' . esc_html($this->format_bytes($limit)) . '</b></div>';
        echo '<div><span>انقضا</span><b class="ipsvp-expiry-datetime" dir="ltr">' . esc_html($this->format_expiry_datetime($expire ? $expire : ($order['expire_at'] ?? ''))) . '</b></div>';
        echo '<div><span>شناسه پنل</span><b>' . esc_html($pg_user_id ? $pg_user_id : '-') . '</b></div>';
        $linked_user_for_tel = $this->db->get_user_by_phone($phone);
        if ($linked_user_for_tel && !empty($linked_user_for_tel->bot_tel_id)) {
            echo '<div><span>آیدی عددی تلگرام</span><b>' . esc_html($linked_user_for_tel->bot_tel_id) . '</b></div>';
        }
        echo '</div>';
        if ($links) {
            $i = 1;
            $all_country_items = $this->all_country_items_from_bot_order($order, $detail);
            foreach ($links as $link) {
                if (!is_string($link) || trim($link) === '') {
                    continue;
                }
                $config_label = $all_country_items ? $this->config_label_with_country('کد کانفیگ', $i, $link, $all_country_items) : ('کد کانفیگ ' . $i);
                $qr_label = $all_country_items ? $this->config_label_with_country('QR کانفیگ', $i, $link, $all_country_items) : ('QR کانفیگ ' . $i);
                echo $this->render_config_qr_pair($config_label, $link, $qr_label, 5);
                $i++;
            }
        } elseif ($subscription_content) {
            echo $this->render_config_qr_pair('محتوای ساب / کانفیگ', $subscription_content, 'QR کانفیگ', 7);
        } elseif ($sub) {
            echo $this->render_config_qr_pair('لینک ساب', $sub, 'QR لینک ساب', 2);
        } elseif ($subscription_error) {
            echo '<div class="ipsvp-alert">کانفیگ وجود دارد اما محتوای ساب دریافت نشد. چند لحظه دیگر دوباره جزییات را باز کنید.</div>';
        }
        echo '<div class="ipsvp-actions"><a class="ipsvp-btn" href="#ipsvp-bot-renew-modal">تمدید همین کانفیگ</a></div>';
        echo $this->render_bot_renewal_modal($order);
        echo $this->render_bot_order_payments((int) ($order['id'] ?? 0), $phone);
        echo '<div class="ipsvp-actions"><a class="ipsvp-secondary ipsvp-link-btn" href="' . esc_url($this->current_page_url(array('ipsvp_tab' => 'orders'))) . '">بازگشت به سفارشات</a></div>';
        echo '</div>';
        return ob_get_clean();
    }


    private function handle_crypto_renewal_submission($phone)
    {
        $reseller_notice = IPSVP_Reseller::wallet_only_notice(0, (int) ($_POST['ipsvp_order_id'] ?? 0));
        if ($reseller_notice !== '') { return $reseller_notice; }
        if (!$this->crypto_available()) { return '<div class="ipsvp-alert">درگاه کریپتو فعال نیست.</div>'; }
        if (!wp_verify_nonce(isset($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '', 'ipsvp_submit_crypto_renewal')) {
            return '<div class="ipsvp-alert">درخواست تمدید کریپتو نامعتبر است.</div>';
        }
        $order_id = isset($_POST['ipsvp_order_id']) ? (int) $_POST['ipsvp_order_id'] : 0;
        $plan_id = isset($_POST['renew_plan_id']) ? (int) $_POST['renew_plan_id'] : 0;
        $submission_key = isset($_POST['ipsvp_submission_key']) ? $this->db->sanitize_submission_key(wp_unslash($_POST['ipsvp_submission_key'])) : '';
        if ($phone && $this->db->is_user_blocked($phone)) { return '<div class="ipsvp-alert">این شماره توسط مدیریت مسدود شده و امکان تمدید ندارد.</div>'; }
        $receipt = $this->db->create_crypto_renewal_receipt($order_id, $phone, $plan_id, $submission_key);
        if (is_wp_error($receipt)) { return '<div class="ipsvp-alert">' . esc_html($receipt->get_error_message()) . '</div>'; }
        $invoice = $this->ramzino_create_invoice_for_receipt($receipt, 'RENEW-' . (int) $receipt->id, 'IP Sabet renewal #' . (int) $receipt->id, array('ipsvp_tab' => 'detail', 'ipsvp_order_id' => $order_id));
        if (is_wp_error($invoice)) { return '<div class="ipsvp-alert">' . esc_html($invoice->get_error_message()) . '</div>'; }
        return $this->redirect_or_script($invoice['url']);
    }

    private function sanitize_extra_volume_gb_from_post()
    {
        $raw = isset($_POST['extra_volume_gb']) ? $this->normalize_digits(wp_unslash($_POST['extra_volume_gb'])) : '';
        $gb = (int) $raw;
        return max(0, $gb);
    }

    private function handle_extra_volume_submission($phone)
    {
        $reseller_notice = IPSVP_Reseller::wallet_only_notice(0, (int) ($_POST['ipsvp_order_id'] ?? 0));
        if ($reseller_notice !== '') { return $reseller_notice; }
        if (!$this->payment_method_enabled('card')) {
            return '<div class="ipsvp-alert">پرداخت کارت به کارت در حال حاضر غیرفعال است.</div>';
        }
        if (!wp_verify_nonce(isset($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '', 'ipsvp_submit_extra_volume_receipt')) {
            return '<div class="ipsvp-alert">درخواست خرید حجم اضافه نامعتبر است.</div>';
        }
        $order_id = isset($_POST['ipsvp_order_id']) ? (int) $_POST['ipsvp_order_id'] : 0;
        $gb = $this->sanitize_extra_volume_gb_from_post();
        $submission_key = isset($_POST['ipsvp_submission_key']) ? $this->db->sanitize_submission_key(wp_unslash($_POST['ipsvp_submission_key'])) : '';
        if ($submission_key) {
            $existing_receipt = $this->db->get_receipt_by_submission_key($submission_key);
            if ($existing_receipt) {
                return $this->redirect_or_script($this->current_page_url(array('ipsvp_tab' => 'detail', 'ipsvp_order_id' => $order_id, 'ipsvp_extra_volume_done' => $existing_receipt->id)));
            }
        }
        if ($phone && $this->db->is_user_blocked($phone)) {
            return '<div class="ipsvp-alert">این شماره توسط مدیریت مسدود شده و امکان خرید حجم اضافه ندارد.</div>';
        }
        if ($gb < 1) {
            return '<div class="ipsvp-alert">مقدار حجم اضافه باید عدد صحیح مثبت باشد.</div>';
        }
        $user = $this->db->get_user_by_phone($phone);
        $upload = $user ? IPSVP_Receipt_Uploader::uploaded_from_request('extra_volume_receipt', (int) $user->id) : null;
        if ($upload === null) {
            if (empty($_FILES['extra_volume_receipt']['name'])) {
                return '<div class="ipsvp-alert">لطفا فایل رسید خرید حجم اضافه را آپلود کنید.</div>';
            }
            $upload = $this->upload_receipt($_FILES['extra_volume_receipt'], 'extra_volume_receipt');
        }
        if (is_wp_error($upload)) {
            return '<div class="ipsvp-alert">' . esc_html($upload->get_error_message()) . '</div>';
        }
        $receipt = $this->db->create_extra_volume_receipt($order_id, $phone, $gb, 'card', $upload['attachment_id'], $upload['url'], $submission_key);
        if (is_wp_error($receipt)) {
            return '<div class="ipsvp-alert">' . esc_html($receipt->get_error_message()) . '</div>';
        }
        return $this->redirect_or_script($this->current_page_url(array('ipsvp_tab' => 'detail', 'ipsvp_order_id' => $order_id, 'ipsvp_extra_volume_done' => $receipt->id)));
    }

    private function handle_wallet_extra_volume_submission($phone)
    {
        $reseller = IPSVP_Reseller::legacy_wallet('extra-volume', $phone, 'ipsvp_submit_wallet_extra_volume', array('order_id' => (int) ($_POST['ipsvp_order_id'] ?? 0), 'gb' => $this->sanitize_extra_volume_gb_from_post()));
        if ($reseller !== null) { return $reseller; }
        if (!$this->payment_method_enabled('wallet')) {
            return '<div class="ipsvp-alert">پرداخت کیف پول در حال حاضر غیرفعال است.</div>';
        }
        if (!wp_verify_nonce(isset($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '', 'ipsvp_submit_wallet_extra_volume')) {
            return '<div class="ipsvp-alert">درخواست خرید حجم اضافه با کیف پول نامعتبر است.</div>';
        }
        $order_id = isset($_POST['ipsvp_order_id']) ? (int) $_POST['ipsvp_order_id'] : 0;
        $gb = $this->sanitize_extra_volume_gb_from_post();
        $submission_key = isset($_POST['ipsvp_submission_key']) ? $this->db->sanitize_submission_key(wp_unslash($_POST['ipsvp_submission_key'])) : '';
        if ($submission_key) {
            $existing_receipt = $this->db->get_receipt_by_submission_key($submission_key);
            if ($existing_receipt) {
                return $this->redirect_or_script($this->current_page_url(array('ipsvp_tab' => 'detail', 'ipsvp_order_id' => $order_id, 'ipsvp_extra_volume_done' => $existing_receipt->id)));
            }
        }
        if ($phone && $this->db->is_user_blocked($phone)) {
            return '<div class="ipsvp-alert">این شماره توسط مدیریت مسدود شده و امکان خرید حجم اضافه ندارد.</div>';
        }
        if ($gb < 1) {
            return '<div class="ipsvp-alert">مقدار حجم اضافه باید عدد صحیح مثبت باشد.</div>';
        }
        $order = $this->db->get_order_by_phone($order_id, $phone);
        if (!$order) {
            return '<div class="ipsvp-alert">سفارش برای خرید حجم اضافه پیدا نشد.</div>';
        }
        $price_info = $this->db->calculate_extra_volume_price($order, $gb);
        if (is_wp_error($price_info)) {
            return '<div class="ipsvp-alert">' . esc_html($price_info->get_error_message()) . '</div>';
        }
        $price = (int) $price_info['total_amount'];
        $wallet = $this->wallet_payment_info($phone);
        if (empty($wallet['ok'])) {
            return '<div class="ipsvp-alert">' . esc_html($wallet['message']) . '</div>';
        }
        if ((int) $wallet['balance'] < (int) $price) {
            return '<div class="ipsvp-alert">موجودی کیف پول برای خرید حجم اضافه کافی نیست.</div>';
        }
        $receipt = $this->db->create_extra_volume_receipt($order_id, $phone, $gb, 'wallet', 0, '', $submission_key);
        if (is_wp_error($receipt)) {
            return '<div class="ipsvp-alert">' . esc_html($receipt->get_error_message()) . '</div>';
        }
        $debited_remote = false;
        if (!empty($wallet['is_bot']) && !empty($wallet['user']->bot_tel_id)) {
            $debit = IPSVP_Bot_API::debit_wallet($wallet['user']->bot_tel_id, (int) $price, 'EV-' . (int) $receipt->id, $phone);
            if (is_wp_error($debit) || empty($debit['ok'])) {
                $msg = is_wp_error($debit) ? $debit->get_error_message() : (!empty($debit['message']) ? $debit['message'] : 'کسر کیف پول ربات ناموفق بود.');
                global $wpdb;
                $t = $this->db->tables();
                $wpdb->update($t['receipts'], array('status' => 'failed', 'reviewed_at' => $this->db->now(), 'admin_note' => $msg), array('id' => (int) $receipt->id));
                return '<div class="ipsvp-alert">' . esc_html($msg) . '</div>';
            }
            $debited_remote = true;
            $this->db->set_receipt_wallet_effect((int) $receipt->id, 'remote');
        }
        $approved = IPSVP_Receipt_Manager::approve((int) $receipt->id, $this->db, $this->api);
        if (empty($approved['ok'])) {
            if ($debited_remote && !empty($wallet['user']->bot_tel_id)) {
                IPSVP_Bot_API::credit_wallet($wallet['user']->bot_tel_id, (int) $price, (int) $receipt->id, $phone);
            }
            $msg = !empty($approved['message']) ? $approved['message'] : 'خرید حجم اضافه با کیف پول ناموفق بود.';
            return '<div class="ipsvp-alert">' . esc_html($msg) . '</div>';
        }
        return $this->redirect_or_script($this->current_page_url(array('ipsvp_tab' => 'detail', 'ipsvp_order_id' => $order_id, 'ipsvp_extra_volume_done' => (int) $receipt->id)));
    }

    private function handle_crypto_extra_volume_submission($phone)
    {
        $reseller_notice = IPSVP_Reseller::wallet_only_notice(0, (int) ($_POST['ipsvp_order_id'] ?? 0));
        if ($reseller_notice !== '') { return $reseller_notice; }
        if (!$this->crypto_available()) { return '<div class="ipsvp-alert">درگاه کریپتو فعال نیست.</div>'; }
        if (!wp_verify_nonce(isset($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '', 'ipsvp_submit_crypto_extra_volume')) {
            return '<div class="ipsvp-alert">درخواست خرید حجم اضافه با کریپتو نامعتبر است.</div>';
        }
        $order_id = isset($_POST['ipsvp_order_id']) ? (int) $_POST['ipsvp_order_id'] : 0;
        $gb = $this->sanitize_extra_volume_gb_from_post();
        $submission_key = isset($_POST['ipsvp_submission_key']) ? $this->db->sanitize_submission_key(wp_unslash($_POST['ipsvp_submission_key'])) : '';
        if ($phone && $this->db->is_user_blocked($phone)) { return '<div class="ipsvp-alert">این شماره توسط مدیریت مسدود شده و امکان خرید حجم اضافه ندارد.</div>'; }
        if ($gb < 1) { return '<div class="ipsvp-alert">مقدار حجم اضافه باید عدد صحیح مثبت باشد.</div>'; }
        $receipt = $this->db->create_extra_volume_receipt($order_id, $phone, $gb, 'crypto', 0, '', $submission_key);
        if (is_wp_error($receipt)) { return '<div class="ipsvp-alert">' . esc_html($receipt->get_error_message()) . '</div>'; }
        $invoice = $this->ramzino_create_invoice_for_receipt($receipt, 'EXTRA-VOLUME-' . (int) $receipt->id, 'IP Sabet extra volume #' . (int) $receipt->id, array('ipsvp_tab' => 'detail', 'ipsvp_order_id' => $order_id));
        if (is_wp_error($invoice)) { return '<div class="ipsvp-alert">' . esc_html($invoice->get_error_message()) . '</div>'; }
        return $this->redirect_or_script($invoice['url']);
    }

    private function handle_bot_crypto_renewal_submission($phone)
    {
        if (!$this->crypto_available()) { return '<div class="ipsvp-alert">درگاه کریپتو فعال نیست.</div>'; }
        if (!wp_verify_nonce(isset($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '', 'ipsvp_submit_bot_crypto_renewal')) {
            return '<div class="ipsvp-alert">درخواست تمدید کریپتو سفارش ربات نامعتبر است.</div>';
        }
        $bot_order_id = isset($_POST['ipsvp_bot_order_id']) ? (int) $_POST['ipsvp_bot_order_id'] : 0;
        $plan_id = isset($_POST['renew_plan_id']) ? (int) $_POST['renew_plan_id'] : 0;
        $submission_key = isset($_POST['ipsvp_submission_key']) ? $this->db->sanitize_submission_key(wp_unslash($_POST['ipsvp_submission_key'])) : '';
        if ($phone && $this->db->is_user_blocked($phone)) { return '<div class="ipsvp-alert">این شماره توسط مدیریت مسدود شده و امکان تمدید ندارد.</div>'; }
        $bot_order = $this->find_user_bot_order($phone, $bot_order_id);
        if (!$bot_order) { return '<div class="ipsvp-alert">سفارش ربات پیدا نشد یا حساب به ربات متصل نیست.</div>'; }
        $receipt = $this->db->create_crypto_bot_renewal_receipt($bot_order, $phone, $plan_id, $submission_key);
        if (is_wp_error($receipt)) { return '<div class="ipsvp-alert">' . esc_html($receipt->get_error_message()) . '</div>'; }
        $invoice = $this->ramzino_create_invoice_for_receipt($receipt, 'BOT-RENEW-' . (int) $receipt->id, 'IP Sabet bot renewal #' . (int) $receipt->id, array('ipsvp_tab' => 'bot_detail', 'ipsvp_bot_order_id' => $bot_order_id));
        if (is_wp_error($invoice)) { return '<div class="ipsvp-alert">' . esc_html($invoice->get_error_message()) . '</div>'; }
        return $this->redirect_or_script($invoice['url']);
    }

    private function handle_bot_renewal_submission($phone)
    {
        if (!$this->payment_method_enabled('card')) {
            return '<div class="ipsvp-alert">پرداخت کارت به کارت در حال حاضر غیرفعال است.</div>';
        }
        if (!wp_verify_nonce(isset($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '', 'ipsvp_submit_bot_renewal_receipt')) {
            return '<div class="ipsvp-alert">درخواست تمدید سفارش ربات نامعتبر است.</div>';
        }
        $bot_order_id = isset($_POST['ipsvp_bot_order_id']) ? (int) $_POST['ipsvp_bot_order_id'] : 0;
        $plan_id = isset($_POST['renew_plan_id']) ? (int) $_POST['renew_plan_id'] : 0;
        $submission_key = isset($_POST['ipsvp_submission_key']) ? $this->db->sanitize_submission_key(wp_unslash($_POST['ipsvp_submission_key'])) : '';
        if ($submission_key) {
            $existing_receipt = $this->db->get_receipt_by_submission_key($submission_key);
            if ($existing_receipt) {
                return $this->redirect_or_script($this->current_page_url(array('ipsvp_tab' => 'bot_detail', 'ipsvp_bot_order_id' => $bot_order_id, 'ipsvp_bot_renewal_done' => $existing_receipt->id)));
            }
        }
        if ($phone && $this->db->is_user_blocked($phone)) {
            return '<div class="ipsvp-alert">این شماره توسط مدیریت مسدود شده و امکان تمدید ندارد.</div>';
        }
        $bot_order = $this->find_user_bot_order($phone, $bot_order_id);
        if (!$bot_order) {
            return '<div class="ipsvp-alert">سفارش ربات پیدا نشد یا حساب به ربات متصل نیست.</div>';
        }
        $user = $this->db->get_user_by_phone($phone);
        $upload = $user ? IPSVP_Receipt_Uploader::uploaded_from_request('renew_receipt', (int) $user->id) : null;
        if ($upload === null) {
            if (empty($_FILES['renew_receipt']['name'])) {
                return '<div class="ipsvp-alert">لطفا فایل رسید تمدید را آپلود کنید.</div>';
            }
            $upload = $this->upload_receipt($_FILES['renew_receipt'], 'renew_receipt');
        }
        if (is_wp_error($upload)) {
            return '<div class="ipsvp-alert">' . esc_html($upload->get_error_message()) . '</div>';
        }
        $receipt = $this->db->create_bot_renewal_receipt($bot_order, $phone, $plan_id, $upload['attachment_id'], $upload['url'], $submission_key);
        if (is_wp_error($receipt)) {
            return '<div class="ipsvp-alert">' . esc_html($receipt->get_error_message()) . '</div>';
        }
        return $this->redirect_or_script($this->current_page_url(array('ipsvp_tab' => 'bot_detail', 'ipsvp_bot_order_id' => $bot_order_id, 'ipsvp_bot_renewal_done' => $receipt->id)));
    }

    private function handle_renewal_submission($phone)
    {
        $reseller_notice = IPSVP_Reseller::wallet_only_notice(0, (int) ($_POST['ipsvp_order_id'] ?? 0));
        if ($reseller_notice !== '') { return $reseller_notice; }
        if (!$this->payment_method_enabled('card')) {
            return '<div class="ipsvp-alert">پرداخت کارت به کارت در حال حاضر غیرفعال است.</div>';
        }
        if (!wp_verify_nonce(isset($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '', 'ipsvp_submit_renewal_receipt')) {
            return '<div class="ipsvp-alert">درخواست تمدید نامعتبر است.</div>';
        }
        $order_id = isset($_POST['ipsvp_order_id']) ? (int) $_POST['ipsvp_order_id'] : 0;
        $plan_id = isset($_POST['renew_plan_id']) ? (int) $_POST['renew_plan_id'] : 0;
        $submission_key = isset($_POST['ipsvp_submission_key']) ? $this->db->sanitize_submission_key(wp_unslash($_POST['ipsvp_submission_key'])) : '';
        if ($submission_key) {
            $existing_receipt = $this->db->get_receipt_by_submission_key($submission_key);
            if ($existing_receipt) {
                return $this->redirect_or_script($this->current_page_url(array('ipsvp_tab' => 'detail', 'ipsvp_order_id' => $order_id, 'ipsvp_renewal_done' => $existing_receipt->id)));
            }
        }
        if ($phone && $this->db->is_user_blocked($phone)) {
            return '<div class="ipsvp-alert">این شماره توسط مدیریت مسدود شده و امکان تمدید ندارد.</div>';
        }
        $user = $this->db->get_user_by_phone($phone);
        $upload = $user ? IPSVP_Receipt_Uploader::uploaded_from_request('renew_receipt', (int) $user->id) : null;
        if ($upload === null) {
            if (empty($_FILES['renew_receipt']['name'])) {
                return '<div class="ipsvp-alert">لطفا فایل رسید تمدید را آپلود کنید.</div>';
            }
            $upload = $this->upload_receipt($_FILES['renew_receipt'], 'renew_receipt');
        }
        if (is_wp_error($upload)) {
            return '<div class="ipsvp-alert">' . esc_html($upload->get_error_message()) . '</div>';
        }
        $receipt = $this->db->create_renewal_receipt($order_id, $phone, $plan_id, $upload['attachment_id'], $upload['url'], $submission_key);
        if (is_wp_error($receipt)) {
            return '<div class="ipsvp-alert">' . esc_html($receipt->get_error_message()) . '</div>';
        }
        return $this->redirect_or_script($this->current_page_url(array('ipsvp_tab' => 'detail', 'ipsvp_order_id' => $order_id, 'ipsvp_renewal_done' => $receipt->id)));
    }


    private function wallet_payment_info($phone)
    {
        $cache_key = $this->db->normalize_phone($phone);
        if ($cache_key !== '' && isset($this->wallet_info_cache[$cache_key])) {
            return $this->wallet_info_cache[$cache_key];
        }
        $user = $this->db->get_or_create_user($phone);
        if (!$user) {
            return array('ok' => false, 'user' => null, 'label' => 'کیف پول', 'balance' => 0, 'is_bot' => false, 'message' => 'کاربر پیدا نشد.');
        }
        $info = array(
            'ok' => true,
            'user' => $user,
            'label' => 'کیف پول سایت',
            'balance' => $this->db->get_local_wallet_balance($user->id),
            'is_bot' => false,
            'message' => '',
        );
        if (!empty($user->bot_tel_id)) {
            $wallet = IPSVP_Bot_API::unified_wallet($user, $this->db, true);
            if (is_wp_error($wallet) || empty($wallet['ok']) || !isset($wallet['balance'])) {
                $info['ok'] = false;
                $info['label'] = 'کیف پول مشترک ربات و سایت';
                $info['is_bot'] = true;
                if (is_wp_error($wallet)) {
                    $error_data = $wallet->get_error_data();
                    if (is_array($error_data) && isset($error_data['remote_balance'])) {
                        $info['balance'] = (int) $error_data['remote_balance'] + (int) ($error_data['local_balance'] ?? 0);
                    }
                    $info['message'] = $wallet->get_error_message();
                } else {
                    $info['message'] = !empty($wallet['message']) ? $wallet['message'] : 'دریافت موجودی کیف پول ربات ناموفق بود.';
                }
                if ($cache_key !== '') {
                    $this->wallet_info_cache[$cache_key] = $info;
                }
                return $info;
            }
            $info['label'] = 'کیف پول مشترک ربات و سایت';
            $info['balance'] = (int) $wallet['balance'];
            $info['is_bot'] = true;
        }
        if ($cache_key !== '') {
            $this->wallet_info_cache[$cache_key] = $info;
        }
        return $info;
    }

    private function handle_wallet_renewal_submission($phone)
    {
        $reseller = IPSVP_Reseller::legacy_wallet('renew', $phone, 'ipsvp_submit_wallet_renewal', array('order_id' => (int) ($_POST['ipsvp_order_id'] ?? 0), 'plan_id' => (int) ($_POST['renew_plan_id'] ?? 0)));
        if ($reseller !== null) { return $reseller; }
        if (!$this->payment_method_enabled('wallet')) {
            return '<div class="ipsvp-alert">پرداخت کیف پول در حال حاضر غیرفعال است.</div>';
        }
        if (!wp_verify_nonce(isset($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '', 'ipsvp_submit_wallet_renewal')) {
            return '<div class="ipsvp-alert">درخواست تمدید با کیف پول نامعتبر است.</div>';
        }
        $order_id = isset($_POST['ipsvp_order_id']) ? (int) $_POST['ipsvp_order_id'] : 0;
        $plan_id = isset($_POST['renew_plan_id']) ? (int) $_POST['renew_plan_id'] : 0;
        $submission_key = isset($_POST['ipsvp_submission_key']) ? $this->db->sanitize_submission_key(wp_unslash($_POST['ipsvp_submission_key'])) : '';
        if ($submission_key) {
            $existing_receipt = $this->db->get_receipt_by_submission_key($submission_key);
            if ($existing_receipt) {
                return $this->redirect_or_script($this->current_page_url(array('ipsvp_tab' => 'detail', 'ipsvp_order_id' => $order_id, 'ipsvp_renewal_done' => $existing_receipt->id)));
            }
        }
        if ($phone && $this->db->is_user_blocked($phone)) {
            return '<div class="ipsvp-alert">این شماره توسط مدیریت مسدود شده و امکان تمدید ندارد.</div>';
        }
        $order = $this->db->get_order_by_phone($order_id, $phone);
        if (!$order) {
            return '<div class="ipsvp-alert">سفارش برای تمدید پیدا نشد.</div>';
        }
        $plan = $this->db->get_plan($plan_id);
        if (!$plan) {
            return '<div class="ipsvp-alert">پلن تمدید پیدا نشد.</div>';
        }
        $price = $this->db->calculate_renewal_plan_price($plan, $order);
        $wallet = $this->wallet_payment_info($phone);
        if (empty($wallet['ok'])) {
            return '<div class="ipsvp-alert">' . esc_html($wallet['message']) . '</div>';
        }
        if ((int) $wallet['balance'] < (int) $price) {
            return '<div class="ipsvp-alert">موجودی کیف پول برای تمدید این سفارش کافی نیست.</div>';
        }
        $receipt = $this->db->create_wallet_renewal_receipt($order_id, $phone, $plan_id, $submission_key);
        if (is_wp_error($receipt)) {
            return '<div class="ipsvp-alert">' . esc_html($receipt->get_error_message()) . '</div>';
        }
        $debited_remote = false;
        if (!empty($wallet['is_bot']) && !empty($wallet['user']->bot_tel_id)) {
            $debit = IPSVP_Bot_API::debit_wallet($wallet['user']->bot_tel_id, (int) $price, 'WR-' . (int) $receipt->id, $phone);
            if (is_wp_error($debit) || empty($debit['ok'])) {
                $msg = is_wp_error($debit) ? $debit->get_error_message() : (!empty($debit['message']) ? $debit['message'] : 'کسر کیف پول ربات ناموفق بود.');
                global $wpdb;
                $t = $this->db->tables();
                $wpdb->update($t['receipts'], array('status' => 'failed', 'reviewed_at' => $this->db->now(), 'admin_note' => $msg), array('id' => (int) $receipt->id));
                return '<div class="ipsvp-alert">' . esc_html($msg) . '</div>';
            }
            $debited_remote = true;
            $this->db->set_receipt_wallet_effect((int) $receipt->id, 'remote');
        }
        $approved = IPSVP_Receipt_Manager::approve((int) $receipt->id, $this->db, $this->api);
        if (empty($approved['ok'])) {
            if ($debited_remote && !empty($wallet['user']->bot_tel_id)) {
                IPSVP_Bot_API::credit_wallet($wallet['user']->bot_tel_id, (int) $price, (int) $receipt->id, $phone);
            }
            $msg = !empty($approved['message']) ? $approved['message'] : 'تمدید با کیف پول ناموفق بود.';
            return '<div class="ipsvp-alert">' . esc_html($msg) . '</div>';
        }
        return $this->redirect_or_script($this->current_page_url(array('ipsvp_tab' => 'detail', 'ipsvp_order_id' => $order_id, 'ipsvp_wallet_renewal_done' => (int) $receipt->id)));
    }

    private function handle_bot_wallet_renewal_submission($phone)
    {
        if (!$this->payment_method_enabled('wallet')) {
            return '<div class="ipsvp-alert">پرداخت کیف پول در حال حاضر غیرفعال است.</div>';
        }
        if (!wp_verify_nonce(isset($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '', 'ipsvp_submit_bot_wallet_renewal')) {
            return '<div class="ipsvp-alert">درخواست تمدید سفارش ربات با کیف پول نامعتبر است.</div>';
        }
        $bot_order_id = isset($_POST['ipsvp_bot_order_id']) ? (int) $_POST['ipsvp_bot_order_id'] : 0;
        $plan_id = isset($_POST['renew_plan_id']) ? (int) $_POST['renew_plan_id'] : 0;
        $submission_key = isset($_POST['ipsvp_submission_key']) ? $this->db->sanitize_submission_key(wp_unslash($_POST['ipsvp_submission_key'])) : '';
        if ($submission_key) {
            $existing_receipt = $this->db->get_receipt_by_submission_key($submission_key);
            if ($existing_receipt) {
                return $this->redirect_or_script($this->current_page_url(array('ipsvp_tab' => 'bot_detail', 'ipsvp_bot_order_id' => $bot_order_id, 'ipsvp_bot_renewal_done' => $existing_receipt->id)));
            }
        }
        if ($phone && $this->db->is_user_blocked($phone)) {
            return '<div class="ipsvp-alert">این شماره توسط مدیریت مسدود شده و امکان تمدید ندارد.</div>';
        }
        $bot_order = $this->find_user_bot_order($phone, $bot_order_id);
        if (!$bot_order) {
            return '<div class="ipsvp-alert">سفارش ربات پیدا نشد یا حساب به ربات متصل نیست.</div>';
        }
        $plan = $this->db->get_plan($plan_id);
        if (!$plan) {
            return '<div class="ipsvp-alert">پلن تمدید پیدا نشد.</div>';
        }
        $price = $this->db->calculate_renewal_plan_price($plan, $bot_order);
        $wallet = $this->wallet_payment_info($phone);
        if (empty($wallet['ok'])) {
            return '<div class="ipsvp-alert">' . esc_html($wallet['message']) . '</div>';
        }
        if (empty($wallet['is_bot']) || empty($wallet['user']->bot_tel_id)) {
            return '<div class="ipsvp-alert">برای تمدید سفارش ربات با کیف پول، اتصال سایت و ربات باید فعال باشد.</div>';
        }
        if ((int) $wallet['balance'] < (int) $price) {
            return '<div class="ipsvp-alert">موجودی کیف پول مشترک برای تمدید این سفارش کافی نیست.</div>';
        }
        $receipt = $this->db->create_wallet_bot_renewal_receipt($bot_order, $phone, $plan_id, $submission_key);
        if (is_wp_error($receipt)) {
            return '<div class="ipsvp-alert">' . esc_html($receipt->get_error_message()) . '</div>';
        }
        $debit = IPSVP_Bot_API::debit_wallet($wallet['user']->bot_tel_id, (int) $price, 'BWR-' . (int) $receipt->id, $phone);
        if (is_wp_error($debit) || empty($debit['ok'])) {
            $msg = is_wp_error($debit) ? $debit->get_error_message() : (!empty($debit['message']) ? $debit['message'] : 'کسر کیف پول ربات ناموفق بود.');
            global $wpdb;
            $t = $this->db->tables();
            $wpdb->update($t['receipts'], array('status' => 'failed', 'reviewed_at' => $this->db->now(), 'admin_note' => $msg), array('id' => (int) $receipt->id));
            return '<div class="ipsvp-alert">' . esc_html($msg) . '</div>';
        }
        $this->db->set_receipt_wallet_effect((int) $receipt->id, 'remote');
        $approved = IPSVP_Receipt_Manager::approve((int) $receipt->id, $this->db, $this->api);
        if (empty($approved['ok'])) {
            IPSVP_Bot_API::credit_wallet($wallet['user']->bot_tel_id, (int) $price, (int) $receipt->id, $phone);
            $msg = !empty($approved['message']) ? $approved['message'] : 'تمدید سفارش ربات با کیف پول ناموفق بود.';
            return '<div class="ipsvp-alert">' . esc_html($msg) . '</div>';
        }
        return $this->redirect_or_script($this->current_page_url(array('ipsvp_tab' => 'bot_detail', 'ipsvp_bot_order_id' => $bot_order_id, 'ipsvp_bot_wallet_renewal_done' => (int) $receipt->id)));
    }

    private function render_user_order_detail($order_id, $phone, $message = '')
    {
        $o = $this->db->get_order_by_phone($order_id, $phone);
        if (!$o) {
            return '<div class="ipsvp-alert">سفارش پیدا نشد.</div>';
        }
        if ((int) $o->country_id === 0) {
            $this->api->ensure_all_countries_groups_for_order($o, $this->db->ready_countries());
        }
        $snapshot = $this->api->user_snapshot($o->pg_username, $o->pg_user_id, $o);
        $live = (!empty($snapshot['live']) && is_array($snapshot['live'])) ? $snapshot['live'] : array();
        $used = isset($snapshot['used']) ? $snapshot['used'] : '';
        $limit = isset($snapshot['limit']) ? $snapshot['limit'] : '';
        $expire = isset($snapshot['expire']) ? $snapshot['expire'] : '';
        $status = isset($snapshot['status']) ? $snapshot['status'] : '';
        $links = json_decode($o->pg_links, true);
        if (!is_array($links)) {
            $links = array();
        }
        $sub = $o->pg_subscription_url;
        if (!empty($snapshot['subscription_url'])) {
            $sub = $snapshot['subscription_url'];
        }
        if (!empty($snapshot['links']) && is_array($snapshot['links'])) {
            $links = $snapshot['links'];
        }
        $user_id = (!empty($snapshot['user_id']) ? (string) $snapshot['user_id'] : ((!empty($o->pg_user_id) && ctype_digit((string) $o->pg_user_id)) ? (string) $o->pg_user_id : ''));
        $subscription_content = !empty($snapshot['subscription_content']) ? (string) $snapshot['subscription_content'] : '';
        $subscription_error = !empty($snapshot['subscription_error']) ? (string) $snapshot['subscription_error'] : '';
        $update = array();
        if ($user_id && (string) $user_id !== (string) $o->pg_user_id) {
            $update['pg_user_id'] = $user_id;
        }
        if ($status && (string) $status !== (string) $o->pg_status) {
            $update['pg_status'] = (string) $status;
        }
        if ($sub && (string) $sub !== (string) $o->pg_subscription_url) {
            $update['pg_subscription_url'] = (string) $sub;
        }
        if ($links) {
            $links_json = wp_json_encode(array_values($links), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($links_json && $links_json !== (string) $o->pg_links) {
                $update['pg_links'] = $links_json;
            }
        }
        if ($live) {
            $live_for_save = $live;
            if (!empty($o->pg_response)) {
                $old_raw = json_decode((string) $o->pg_response, true);
                if (is_array($old_raw) && !empty($old_raw['_all_countries'])) {
                    $live_for_save['_all_countries'] = $old_raw['_all_countries'];
                }
            }
            $update['pg_response'] = wp_json_encode($live_for_save, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $update['pg_synced_at'] = $this->db->now();
        }
        if ($update) {
            $this->db->update_order($o->id, $update);
        }
        if (!empty($snapshot['live'])) {
            $before_lifecycle = $this->db->get_order($o->id);
            $o = $this->db->apply_order_lifecycle_snapshot($before_lifecycle, $snapshot);
            if ($o && (string) $o->status === 'cancelled' && (string) $before_lifecycle->status !== 'cancelled') {
                $remote_status = $this->api->update_user_status_for_order($o, 'cancelled');
                if (is_wp_error($remote_status)) {
                    $this->db->add_log('warning', 'frontend_auto_cancel_pg_status', $remote_status->get_error_message(), array('order_id' => $o->id), $o->phone, $o->id, 0, $o->user_id);
                }
            }
        } else {
            $o = $this->db->get_order($o->id);
        }
        $payment_approved = in_array((string) $o->payment_status, array('approved','wallet_paid','crypto_paid','paid'), true) || !empty($o->approved_at);
        $has_config = $payment_approved && (!empty($o->pg_username) || !empty($user_id) || !empty($sub) || !empty($links) || !empty($subscription_content));
        $can_manage_service = $has_config && $this->db->order_can_renew($o);
        $current_limit_numeric = ($limit !== '' && is_numeric($limit)) ? (float) $limit : 0;
        $can_buy_extra_volume = $can_manage_service && $user_id !== '' && $current_limit_numeric > 0;
        $extra_volume_price_info = null;
        $extra_volume_price_error = '';
        if ($can_buy_extra_volume) {
            $extra_volume_price_info = $this->db->calculate_extra_volume_price($o, 1);
            if (is_wp_error($extra_volume_price_info)) {
                $extra_volume_price_error = $extra_volume_price_info->get_error_message();
                $can_buy_extra_volume = false;
            }
        }
        ob_start();
        echo '<div class="ipsvp-user-card ipsvp-detail-front"><h3>جزییات سفارش ' . esc_html($o->order_code) . '</h3>';
        if ($message) {
            echo $message;
            echo '<script>if(window.location.hash){history.replaceState(null, document.title, window.location.pathname + window.location.search);}</script>';
        }
        if ($can_manage_service) {
            echo '<div class="ipsvp-order-action-card"><div><span>عملیات سفارش</span><strong>مدیریت همین کانفیگ</strong><small>تمدید یا افزایش حجم سرویس فعلی</small></div><div class="ipsvp-order-action-buttons">';
            echo '<a class="ipsvp-btn" href="#ipsvp-renew-modal">تمدید</a>';
            if ($can_buy_extra_volume) {
                echo '<a class="ipsvp-btn ipsvp-btn-extra-volume" href="#ipsvp-extra-volume-modal">خرید حجم اضافه</a>';
            }
            echo '</div></div>';
            if (!$can_buy_extra_volume && $has_config && ($limit !== '' && is_numeric($limit) && (float) $limit <= 0)) {
                echo '<div class="ipsvp-alert">این سرویس نامحدود است و نیازی به خرید حجم اضافه ندارد.</div>';
            }
            if ($extra_volume_price_error !== '') {
                echo '<div class="ipsvp-alert">' . esc_html($extra_volume_price_error) . '</div>';
            }
        } elseif ($has_config && (string) $o->status === 'cancelled') {
            echo '<div class="ipsvp-alert">مهلت ۷ روزه تمدید یا خرید حجم این سرویس پایان یافته و سفارش لغو شده است.</div>';
        } elseif ($has_config && in_array((string) $o->status, array('volume_finished','time_finished'), true)) {
            echo '<div class="ipsvp-alert">این سرویس پایان یافته است؛ تا پایان مهلت ۷ روزه می‌توانید آن را تمدید کنید یا حجم اضافه بخرید.</div>';
        }
        echo '<div class="ipsvp-invoice-grid"><div><span>نوع سرویس</span><b>' . ($this->db->order_service_type($o) === 'dedicated' ? 'آی پی ثابت اختصاصی' : 'آی پی ثابت اشتراکی') . '</b></div><div><span>پلن</span><b>' . esc_html($o->plan_title) . '</b></div><div><span>کشور</span><b>' . esc_html($o->flag . ' ' . $o->country_name) . '</b></div><div><span>وضعیت سفارش</span><b>' . esc_html($this->db->status_label($o->status)) . '</b></div><div><span>تاریخ ثبت</span><b>' . esc_html($o->created_at) . '</b></div></div>';
        if (!$has_config) {
            echo '<div class="ipsvp-alert">بعد از تایید رسید توسط ادمین، کانفیگ اینجا نمایش داده می شود.</div>';
        } else {
            echo '<div class="ipsvp-live-grid">';
            echo '<div><span>یوزرنیم</span><b>' . esc_html($o->pg_username) . '</b></div>';
            echo '<div><span>وضعیت پنل</span><b>' . esc_html($this->db->status_label($status ? $status : $o->pg_status)) . '</b></div>';
            echo '<div><span>حجم مصرف شده</span><b>' . esc_html($this->format_bytes($used)) . '</b></div>';
            echo '<div><span>حجم کل</span><b>' . esc_html(IPSVP_Sanaei_API::is_order($o) && $limit !== '' && (float) $limit === 0.0 ? 'نامحدود' : $this->format_bytes($limit ? $limit : ((int)$o->gb * 1024 * 1024 * 1024))) . '</b></div>';
            echo '<div><span>انقضا</span><b class="ipsvp-expiry-datetime" >' . esc_html($this->format_expiry_datetime($expire)) . '</b></div>';
            echo '</div>';
            if ($sub) {
                echo $this->render_config_qr_pair('لینک ساب', $sub, 'QR لینک ساب', 2);
            }
            if ($links) {
                $i = 1;
                $all_country_items = ((int) $o->country_id === 0) ? $this->all_country_items_from_order($o) : array();
                foreach ($links as $link) {
                    $config_label = $all_country_items ? $this->config_label_with_country('کد کانفیگ', $i, $link, $all_country_items) : ('کد کانفیگ ' . $i);
                    $qr_label = $all_country_items ? $this->config_label_with_country('QR کانفیگ', $i, $link, $all_country_items) : ('QR کانفیگ ' . $i);
                    echo $this->render_config_qr_pair($config_label, $link, $qr_label, 5);
                    $i++;
                }
            } elseif ($subscription_content) {
                echo $this->render_config_qr_pair('محتوای ساب / کانفیگ', $subscription_content, 'QR کانفیگ', 7);
            } elseif ($subscription_error) {
                $this->db->add_log('warning', 'frontend_get_subscription', $subscription_error, array('order_id' => $o->id, 'pg_username' => $o->pg_username, 'pg_user_id' => $user_id), $o->phone, $o->id, 0, $o->user_id);
                echo '<div class="ipsvp-alert">کانفیگ ساخته شده اما لینک قابل نمایش هنوز دریافت نشد. این خطا برای ادمین در لاگ ثبت شد؛ چند لحظه دیگر دوباره جزییات سفارش را باز کنید.</div>';
            } else {
                echo '<div class="ipsvp-alert">کانفیگ ساخته شده اما هنوز لینک قابل نمایش برنگردانده است. چند لحظه دیگر دوباره جزییات سفارش را باز کنید.</div>';
            }
            if ($can_manage_service) {
                echo $this->render_renewal_modal($o);
            }
            if ($can_buy_extra_volume) {
                echo $this->render_extra_volume_modal($o, $extra_volume_price_info);
            }
        }
        echo $this->render_order_payments($o->id);
        echo '<div class="ipsvp-actions"><a class="ipsvp-secondary ipsvp-link-btn" href="' . esc_url($this->current_page_url(array('ipsvp_tab' => 'orders'))) . '">بازگشت به سفارشات</a></div>';
        echo '</div>';
        return ob_get_clean();
    }

    private function all_country_items_from_order($order)
    {
        $items = array();
        if (!$order || (int) ($order->country_id ?? -1) !== 0) {
            return $items;
        }
        if (!empty($order->pg_response)) {
            $raw = json_decode((string) $order->pg_response, true);
            if (is_array($raw)) {
                if (!empty($raw['_all_countries']['countries']) && is_array($raw['_all_countries']['countries'])) {
                    $items = $raw['_all_countries']['countries'];
                } elseif (!empty($raw['raw']['_all_countries']['countries']) && is_array($raw['raw']['_all_countries']['countries'])) {
                    $items = $raw['raw']['_all_countries']['countries'];
                }
            }
        }
        if (!$items) {
            $items = $this->db->ready_countries();
        }
        return is_array($items) ? array_values($items) : array();
    }

    private function all_country_items_from_bot_order($order, $detail = array())
    {
        $detail = is_array($detail) ? $detail : array();
        $items = array();
        if (!empty($detail['_all_countries']['countries']) && is_array($detail['_all_countries']['countries'])) {
            $items = $detail['_all_countries']['countries'];
        } elseif (!empty($detail['raw']['_all_countries']['countries']) && is_array($detail['raw']['_all_countries']['countries'])) {
            $items = $detail['raw']['_all_countries']['countries'];
        } elseif (!empty($order['_all_countries']['countries']) && is_array($order['_all_countries']['countries'])) {
            $items = $order['_all_countries']['countries'];
        }
        if (!$items) {
            $settings = IPSVP_Settings::get();
            $all_group_id = !empty($settings['all_countries_group_id']) ? (int) $settings['all_countries_group_id'] : 0;
            $detail_country_id = !empty($detail['country_id']) ? (int) $detail['country_id'] : 0;
            $group_ids = self::bot_order_group_ids($detail);
            $is_all_countries = (!empty($detail['is_all_countries']))
                || (!empty($detail['country']) && strpos((string) $detail['country'], 'همه') !== false)
                || ($all_group_id > 0 && ($detail_country_id === $all_group_id || in_array($all_group_id, array_map('intval', $group_ids), true)));
            if ($is_all_countries) {
                $items = $this->db->ready_countries();
            }
        }
        return is_array($items) ? array_values($items) : array();
    }

    private function country_item_value($item, $keys)
    {
        foreach ((array) $keys as $key) {
            if (is_array($item) && isset($item[$key]) && $item[$key] !== '') {
                return (string) $item[$key];
            }
            if (is_object($item) && isset($item->{$key}) && $item->{$key} !== '') {
                return (string) $item->{$key};
            }
        }
        return '';
    }

    private function country_aliases_for_item($item)
    {
        $name = $this->country_item_value($item, array('country_name', 'name'));
        $group = $this->country_item_value($item, array('pg_group_name', 'group_name'));
        $flag = $this->country_item_value($item, array('country_flag', 'flag'));
        $aliases = array_filter(array($name, $group));

        $map = array(
            'آلمان' => array('DE', 'DE1', 'ADE', 'ADE1', 'GER', 'GERMANY', 'ALMAN'),
            'امریکا' => array('US', 'USA', 'US1', 'AUS1', 'AMERICA', 'UNITED STATES'),
            'آمریکا' => array('US', 'USA', 'US1', 'AUS1', 'AMERICA', 'UNITED STATES'),
            'امارات' => array('AE', 'AE1', 'UAE', 'UAE1', 'AAE', 'AAE1', 'EMIRATES'),
            'ترکیه' => array('TR', 'TR1', 'ATR', 'ATR1', 'TUR', 'TURKEY'),
            'انگلیس' => array('GB', 'GB1', 'AGB', 'AGB1', 'UK', 'UK1', 'AUK', 'AUK1', 'EN', 'ENG', 'ENGLAND', 'UNITED KINGDOM'),
            'فرانسه' => array('FR', 'FR1', 'AFR', 'AFR1', 'FRANCE'),
            'هلند' => array('NL', 'NL1', 'ANL', 'ANL1', 'NETHERLANDS', 'HOLLAND'),
        );
        foreach ($map as $fa => $latin) {
            if ($name && mb_strpos($name, $fa) !== false) {
                $aliases = array_merge($aliases, $latin);
            }
            if ($group && mb_strpos($group, $fa) !== false) {
                $aliases = array_merge($aliases, $latin);
            }
        }

        $flag_map = array(
            '🇩🇪' => array('DE', 'DE1', 'ADE', 'ADE1', 'GERMANY'),
            '🇺🇸' => array('US', 'USA', 'US1', 'AUS1', 'AMERICA'),
            '🇦🇪' => array('AE', 'AE1', 'UAE', 'UAE1', 'AAE', 'AAE1'),
            '🇹🇷' => array('TR', 'TR1', 'ATR', 'ATR1', 'TUR', 'TURKEY'),
            '🇬🇧' => array('GB', 'GB1', 'AGB', 'AGB1', 'UK', 'UK1', 'AUK', 'AUK1', 'EN', 'ENG', 'ENGLAND'),
            '🇫🇷' => array('FR', 'FR1', 'AFR', 'AFR1', 'FRANCE'),
            '🇳🇱' => array('NL', 'NL1', 'ANL', 'ANL1', 'NETHERLANDS'),
        );
        if ($flag && isset($flag_map[$flag])) {
            $aliases = array_merge($aliases, $flag_map[$flag]);
        }
        if ($flag) {
            $aliases[] = $flag;
        }

        $clean = array();
        foreach ($aliases as $alias) {
            $alias = trim((string) $alias);
            if ($alias !== '') {
                $clean[] = $alias;
            }
        }
        return array_values(array_unique($clean));
    }

    private function country_code_aliases_for_item($item)
    {
        $codes = array();
        foreach ($this->country_aliases_for_item($item) as $alias) {
            $code = strtoupper(preg_replace('/[^A-Z0-9]/', '', (string) $alias));
            if ($code !== '' && preg_match('/[A-Z]/', $code)) {
                $codes[] = $code;
            }
        }
        return array_values(array_unique($codes));
    }

    private function config_link_country_tokens($link)
    {
        $decoded = rawurldecode(html_entity_decode((string) $link, ENT_QUOTES, 'UTF-8'));
        $parts = array($decoded, (string) $link);
        $hash = strpos($decoded, '#');
        if ($hash !== false) {
            $parts[] = substr($decoded, $hash + 1);
        }
        $tokens = array();
        foreach ($parts as $part) {
            $part = strtoupper((string) $part);
            if (preg_match_all('/([A-Z]{1,6}[0-9]{0,3})\s*[-_]?\s*IPS[0-9A-Z_]*/u', $part, $m)) {
                foreach ($m[1] as $token) {
                    $tokens[] = $token;
                }
            }
            if (preg_match_all('/(?:^|[^A-Z0-9])([A-Z]{1,6}[0-9]{0,3})(?:[-_][A-Z0-9]+)?(?:$|[^A-Z0-9])/u', $part, $m2)) {
                foreach ($m2[1] as $token) {
                    if (!in_array($token, array('VLESS','HTTP','HTTPS','TLS','WS','SNI','HOST','PATH','TYPE','NONE','CHROME','ALPN','VIP','IP'), true)) {
                        $tokens[] = $token;
                    }
                }
            }
        }
        return array_values(array_unique(array_map(function ($token) {
            return strtoupper(preg_replace('/[^A-Z0-9]/', '', (string) $token));
        }, $tokens)));
    }

    private function config_country_label($link, $items, $index = 1)
    {
        if (!$items) {
            return '';
        }
        $decoded = rawurldecode(html_entity_decode((string) $link, ENT_QUOTES, 'UTF-8'));

        // First match by the actual flag emoji inside the config remark. This is the safest
        // way to avoid cases like UAE being detected as USA because of short Latin codes.
        foreach ($items as $item) {
            $name = $this->country_item_value($item, array('country_name', 'name'));
            $flag = $this->country_item_value($item, array('country_flag', 'flag'));
            $label = trim(($flag ? $flag . ' ' : '') . $name);
            if ($flag && strpos($decoded, $flag) !== false) {
                return $label;
            }
        }

        // Then match exact country tokens that PasarGuard puts before the ips username part,
        // e.g. DE1-ips..., US-ips..., AAE1-ips..., NL-ips...
        $tokens = $this->config_link_country_tokens($link);
        if ($tokens) {
            foreach ($items as $item) {
                $name = $this->country_item_value($item, array('country_name', 'name'));
                $flag = $this->country_item_value($item, array('country_flag', 'flag'));
                $label = trim(($flag ? $flag . ' ' : '') . $name);
                $aliases = $this->country_code_aliases_for_item($item);
                if (array_intersect($tokens, $aliases)) {
                    return $label;
                }
            }
        }

        // Long aliases only. Avoid short aliases such as US/AE here; those are handled above.
        $hay = mb_strtoupper($decoded . ' ' . (string) $link);
        foreach ($items as $item) {
            $name = $this->country_item_value($item, array('country_name', 'name'));
            $flag = $this->country_item_value($item, array('country_flag', 'flag'));
            $label = trim(($flag ? $flag . ' ' : '') . $name);
            $aliases = $this->country_aliases_for_item($item);
            usort($aliases, function ($a, $b) { return strlen((string) $b) <=> strlen((string) $a); });
            foreach ($aliases as $alias) {
                $alias = (string) $alias;
                if (strlen($alias) > 3 && mb_strpos($hay, mb_strtoupper($alias)) !== false) {
                    return $label;
                }
            }
        }

        $fallback = isset($items[$index - 1]) ? $items[$index - 1] : null;
        if ($fallback) {
            $name = $this->country_item_value($fallback, array('country_name', 'name'));
            $flag = $this->country_item_value($fallback, array('country_flag', 'flag'));
            return trim(($flag ? $flag . ' ' : '') . $name);
        }
        return '';
    }

    private function config_label_with_country($base, $index, $link, $items)
    {
        $label = $base . ' ' . number_format_i18n((int) $index);
        $country = $this->config_country_label($link, $items, $index);
        return $country ? ($label . ' - ' . $country) : $label;
    }

    private function render_config_qr_pair($label, $value, $qr_label, $rows = 4)
    {
        ob_start();
        echo '<div class="ipsvp-config-pair">';
        echo '<div class="ipsvp-copy"><label>' . esc_html($label) . '</label><textarea readonly rows="' . esc_attr($rows) . '">' . esc_textarea($value) . '</textarea><button type="button" data-copy>کپی</button></div>';
        echo '<div class="ipsvp-qr ipsvp-qr-card"><img alt="QR" src="' . esc_url($this->qr_url($value)) . '"><span>' . esc_html($qr_label) . '</span></div>';
        echo '</div>';
        return ob_get_clean();
    }

    private function render_renewal_plan_options($plans, $order = null)
    {
        ob_start();
        echo '<div class="ipsvp-renew-plan-grid">';
        foreach ($plans as $p) {
            if (!$p) {
                continue;
            }
            $price = $order ? $this->db->calculate_renewal_plan_price($p, $order) : $this->db->final_price($p);
            echo '<label class="ipsvp-renew-plan-option">';
            echo '<input required type="radio" name="renew_plan_id" value="' . esc_attr($p->id) . '">';
            echo '<strong>' . esc_html($p->title) . '</strong>';
            echo '<span>' . esc_html(number_format_i18n((int) $p->gb)) . ' گیگ / ' . esc_html(number_format_i18n((int) $p->days)) . ' روز</span>';
            echo '<b>' . esc_html(number_format_i18n($price)) . ' تومان</b>';
            echo '</label>';
        }
        echo '</div>';
        return ob_get_clean();
    }

    private function render_renewal_plan_picker($plans, $name = 'ipsvp_renew_plan_pick', $order = null)
    {
        ob_start();
        echo '<div class="ipsvp-renew-plan-grid ipsvp-renew-single-plan-grid" data-renew-plan-picker>';
        foreach ($plans as $p) {
            if (!$p) {
                continue;
            }
            $price = $order ? $this->db->calculate_renewal_plan_price($p, $order) : $this->db->final_price($p);
            echo '<label class="ipsvp-renew-plan-option ipsvp-renew-choice" data-plan-id="' . esc_attr($p->id) . '" data-plan-price="' . esc_attr((int) $price) . '" data-plan-title="' . esc_attr($p->title) . '">';
            echo '<input required type="radio" name="' . esc_attr($name) . '" value="' . esc_attr($p->id) . '" data-price="' . esc_attr((int) $price) . '">';
            echo '<strong>' . esc_html($p->title) . '</strong>';
            echo '<span>' . esc_html(number_format_i18n((int) $p->gb)) . ' گیگ / ' . esc_html(number_format_i18n((int) $p->days)) . ' روز</span>';
            echo '<b>' . esc_html(number_format_i18n($price)) . ' تومان</b>';
            echo '</label>';
        }
        echo '</div>';
        return ob_get_clean();
    }

    private function render_wallet_payment_method($phone, $hidden_fields, $action, $nonce_action, $title, $require_bot = false)
    {
        $wallet = $this->wallet_payment_info($phone);
        $balance = !empty($wallet['balance']) ? (int) $wallet['balance'] : 0;
        $label = !empty($wallet['label']) ? $wallet['label'] : 'کیف پول';
        $disabled_msg = '';
        if (empty($wallet['ok'])) {
            $disabled_msg = !empty($wallet['message']) ? $wallet['message'] : 'دریافت اطلاعات کیف پول ناموفق بود.';
        } elseif ($require_bot && empty($wallet['is_bot'])) {
            $disabled_msg = 'برای تمدید سفارش ربات با کیف پول، اتصال سایت و ربات باید فعال باشد.';
        }
        $charge_url = $this->dashboard_wallet_url();
        ob_start();
        if ($disabled_msg !== '') {
            echo '<div class="ipsvp-alert">' . esc_html($disabled_msg) . '</div>';
        }
        echo '<div class="ipsvp-alert ipsvp-renew-insufficient ipsvp-is-hidden">موجودی کیف پول برای این پلن کافی نیست. ابتدا کیف پول را شارژ کنید.</div>';
        echo '<form method="post" action="' . esc_url($this->current_page_url($hidden_fields)) . '" class="ipsvp-renew-payment-form ipsvp-wallet-renew-form">';
        wp_nonce_field($nonce_action);
        echo '<input type="hidden" name="ipsvp_action" value="' . esc_attr($action) . '">';
        echo '<input type="hidden" name="ipsvp_submission_key" value="' . esc_attr($this->new_submission_key($action === 'submit_bot_wallet_renewal' ? 'bot-wallet-renew-' : 'wallet-renew-')) . '">';
        echo '<input type="hidden" name="renew_plan_id" class="ipsvp-renew-plan-hidden" value="">';
        foreach ($hidden_fields as $key => $value) {
            echo '<input type="hidden" name="' . esc_attr($key) . '" value="' . esc_attr($value) . '">';
        }
        $disabled_attr = $disabled_msg !== '' ? ' disabled' : '';
        echo '<button class="ipsvp-btn ipsvp-renew-wallet-submit" type="submit"' . $disabled_attr . '>پرداخت و تمدید با کیف پول</button>';
        echo '<a class="ipsvp-secondary ipsvp-renew-charge-link" href="' . esc_url($charge_url) . '">شارژ کیف پول</a>';
        echo '</form>';
        $content = ob_get_clean();
        return class_exists('IPSPM_Payment_Manager') ? IPSPM_Payment_Manager::render_method_panel('wallet', array(
            'title' => $title,
            'class' => 'ipsvp-renew-wallet-method',
            'attributes' => array('data-wallet-balance' => $balance),
            'summary' => array(
                array('label' => $label, 'value' => number_format_i18n($balance) . ' تومان'),
                array('label' => 'مبلغ سفارش', 'value_html' => '<span class="ipsvp-renew-selected-price">ابتدا پلن را انتخاب کنید</span>'),
            ),
            'content_html' => $content,
        )) : '<div class="ipsvp-alert">افزونه مدیریت پرداخت‌ها فعال نیست.</div>';
    }

    private function render_card_renewal_method($hidden_fields, $action, $nonce_action, $submission_prefix, $settings, $file_input_name, $button_text, $description)
    {
        ob_start();
        echo '<form method="post" enctype="multipart/form-data" action="' . esc_url($this->current_page_url($hidden_fields)) . '" class="ipsvp-renew-payment-form ipsvp-card-renew-form">';
        wp_nonce_field($nonce_action);
        echo '<input type="hidden" name="ipsvp_action" value="' . esc_attr($action) . '">';
        echo '<input type="hidden" name="ipsvp_submission_key" value="' . esc_attr($this->new_submission_key($submission_prefix)) . '">';
        echo '<input type="hidden" name="renew_plan_id" class="ipsvp-renew-plan-hidden" value="">';
        foreach ($hidden_fields as $key => $value) {
            echo '<input type="hidden" name="' . esc_attr($key) . '" value="' . esc_attr($value) . '">';
        }
        echo $this->render_bank_details($settings);
        echo IPSVP_Receipt_Uploader::render_field($file_input_name, 'رسید تمدید کارت به کارت', true);
        echo '<button class="ipsvp-btn" type="submit">' . esc_html($button_text) . '</button>';
        echo '</form>';
        $content = ob_get_clean();
        return class_exists('IPSPM_Payment_Manager') ? IPSPM_Payment_Manager::render_method_panel('card', array(
            'description' => $description,
            'class' => 'ipsvp-renew-card-method',
            'summary' => array(array('label' => 'مبلغ سفارش', 'value_html' => '<span class="ipsvp-renew-selected-price">ابتدا پلن را انتخاب کنید</span>')),
            'content_html' => $content,
        )) : '<div class="ipsvp-alert">افزونه مدیریت پرداخت‌ها فعال نیست.</div>';
    }


    private function render_crypto_renewal_method($hidden_fields, $action, $nonce_action, $submission_prefix, $title, $description)
    {
        ob_start();
        echo '<form method="post" action="' . esc_url($this->current_page_url($hidden_fields)) . '" class="ipsvp-renew-payment-form ipsvp-crypto-renew-form">';
        wp_nonce_field($nonce_action);
        echo '<input type="hidden" name="ipsvp_action" value="' . esc_attr($action) . '">';
        echo '<input type="hidden" name="ipsvp_submission_key" value="' . esc_attr($this->new_submission_key($submission_prefix)) . '">';
        echo '<input type="hidden" name="renew_plan_id" class="ipsvp-renew-plan-hidden" value="">';
        foreach ($hidden_fields as $key => $value) {
            echo '<input type="hidden" name="' . esc_attr($key) . '" value="' . esc_attr($value) . '">';
        }
        echo '<button class="ipsvp-btn" type="submit">پرداخت کریپتو و ادامه</button>';
        echo '</form>';
        $content = ob_get_clean();
        return class_exists('IPSPM_Payment_Manager') ? IPSPM_Payment_Manager::render_method_panel('crypto', array(
            'title' => $title,
            'description' => $description,
            'class' => 'ipsvp-renew-crypto-method',
            'summary' => array(
                array('label' => 'مبلغ سفارش', 'value_html' => '<span class="ipsvp-renew-selected-price">ابتدا پلن را انتخاب کنید</span>'),
                array('label' => 'درگاه', 'value' => 'Ramzino Crypto'),
            ),
            'content_html' => $content,
        )) : '<div class="ipsvp-alert">افزونه مدیریت پرداخت‌ها فعال نیست.</div>';
    }

    private function render_extra_volume_hidden_fields($order_id, $action, $nonce_action, $submission_prefix)
    {
        wp_nonce_field($nonce_action);
        echo '<input type="hidden" name="ipsvp_action" value="' . esc_attr($action) . '">';
        echo '<input type="hidden" name="ipsvp_submission_key" value="' . esc_attr($this->new_submission_key($submission_prefix)) . '">';
        echo '<input type="hidden" name="ipsvp_order_id" value="' . esc_attr((int) $order_id) . '">';
        echo '<input type="hidden" name="extra_volume_gb" class="ipsvp-extra-volume-gb-hidden" value="1">';
    }

    private function render_extra_volume_modal($order, $price_info)
    {
        $settings = IPSVP_Settings::get();
        if (!is_array($price_info)) {
            $price_info = $this->db->calculate_extra_volume_price($order, 1);
        }
        if (is_wp_error($price_info)) {
            return '<div class="ipsvp-alert">' . esc_html($price_info->get_error_message()) . '</div>';
        }
        $unit_price = (int) $price_info['final_unit_price'];
        $is_all_countries = !empty($price_info['is_all_countries']);
        $methods = array();
        if ($this->payment_method_enabled('card')) { $methods[] = array('id'=>'card','title'=>'کارت به کارت','desc'=>'ارسال رسید خرید حجم'); }
        if ($this->payment_method_enabled('wallet')) { $methods[] = array('id'=>'wallet','title'=>'کیف پول','desc'=>'اعمال فوری بعد از کسر'); }
        if ($this->crypto_available()) { $methods[] = array('id'=>'crypto','title'=>'کریپتو','desc'=>'پرداخت رمزینو'); }
        ob_start();
        echo '<div id="ipsvp-extra-volume-modal" class="ipsvp-modal"><a class="ipsvp-modal-bg" href="#"></a><div class="ipsvp-modal-card ipsvp-extra-volume-modal-card" data-extra-volume-flow data-unit-price="' . esc_attr((int) $unit_price) . '"><a class="ipsvp-modal-close" href="#">×</a><h3>خرید حجم اضافه</h3>';
        echo '<p class="ipsvp-renew-help">مقدار حجم موردنظر را انتخاب کنید. پس از پرداخت موفق، حجم به سرویس فعلی شما اضافه می‌شود.</p>';
        if ($is_all_countries) {
            echo '<p class="ipsvp-extra-volume-all-note">قیمت حجم اضافه برای سرویس همه کشورها با ضریب همه کشورها محاسبه شده است.</p>';
        }
        echo '<div class="ipsvp-extra-volume-box">';
        echo '<div class="ipsvp-extra-volume-stepper" dir="ltr"><button type="button" data-extra-volume-minus>-</button><input type="number" inputmode="numeric" min="1" step="1" value="1" data-extra-volume-input><button type="button" data-extra-volume-plus>+</button></div>';
        echo '<div class="ipsvp-invoice-grid ipsvp-extra-volume-summary"><div><span>قیمت هر گیگ</span><b class="ipsvp-extra-volume-unit">' . esc_html(number_format_i18n((int) $unit_price)) . ' تومان</b></div><div><span>حجم انتخابی</span><span class="ipsvp-extra-volume-gb-label">۱</span></b></div><div><span>مبلغ کل</span><b class="ipsvp-extra-volume-total">' . esc_html(number_format_i18n((int) $unit_price)) . ' تومان</b></div></div>';
        echo '</div>';
        if (!$methods) {
            echo '<div class="ipsvp-alert">در حال حاضر هیچ روش پرداختی فعال نیست.</div><div class="ipsvp-actions"><a class="ipsvp-secondary ipsvp-link-btn" href="#">انصراف</a></div></div></div>';
            return ob_get_clean();
        }
        $default_method = $methods[0]['id'];
        echo '<div class="ipsvp-renew-step"><h4>روش پرداخت را انتخاب کنید</h4>';
        $volume_panel_configs = array();
        $dynamic_volume_total = '<span class="ipsvp-extra-volume-total">' . esc_html(number_format_i18n((int) $unit_price)) . ' تومان</span>';
        if ($this->payment_method_enabled('card')) {
            ob_start();
            echo '<form method="post" enctype="multipart/form-data" action="' . esc_url($this->current_page_url(array('ipsvp_tab' => 'detail', 'ipsvp_order_id' => $order->id))) . '" class="ipsvp-extra-volume-payment-form ipsvp-card-extra-volume-form">';
            $this->render_extra_volume_hidden_fields($order->id, 'submit_extra_volume_receipt', 'ipsvp_submit_extra_volume_receipt', 'extra-volume-');
            echo $this->render_bank_details($settings);
            echo IPSVP_Receipt_Uploader::render_field('extra_volume_receipt', 'رسید خرید حجم اضافه', true);
            echo '<button class="ipsvp-btn" type="submit">ادامه و پرداخت</button> <a class="ipsvp-secondary ipsvp-link-btn" href="#">انصراف</a>';
            echo '</form>';
            $volume_panel_configs['card'] = array(
                'description' => 'بعد از تایید رسید، حجم انتخاب‌شده به سرویس فعلی شما اضافه می‌شود.',
                'summary' => array(array('label' => 'مبلغ سفارش', 'value_html' => $dynamic_volume_total)),
                'content_html' => ob_get_clean(),
            );
        }
        if ($this->payment_method_enabled('wallet')) {
            $wallet = $this->wallet_payment_info($order->phone);
            $balance = !empty($wallet['balance']) ? (int) $wallet['balance'] : 0;
            $label = !empty($wallet['label']) ? $wallet['label'] : 'کیف پول';
            $disabled_msg = empty($wallet['ok']) ? (!empty($wallet['message']) ? $wallet['message'] : 'دریافت اطلاعات کیف پول ناموفق بود.') : '';
            ob_start();
            if ($disabled_msg !== '') {
                echo '<div class="ipsvp-alert">' . esc_html($disabled_msg) . '</div>';
            }
            echo '<div class="ipsvp-alert ipsvp-extra-volume-insufficient ipsvp-is-hidden">موجودی کیف پول برای این مقدار حجم کافی نیست.</div>';
            echo '<form method="post" action="' . esc_url($this->current_page_url(array('ipsvp_tab' => 'detail', 'ipsvp_order_id' => $order->id))) . '" class="ipsvp-extra-volume-payment-form ipsvp-wallet-extra-volume-form">';
            $this->render_extra_volume_hidden_fields($order->id, 'submit_wallet_extra_volume', 'ipsvp_submit_wallet_extra_volume', 'wallet-extra-volume-');
            echo '<button class="ipsvp-btn ipsvp-extra-volume-wallet-submit" type="submit"' . ($disabled_msg !== '' ? ' disabled' : '') . '>ادامه و پرداخت</button> <a class="ipsvp-secondary ipsvp-link-btn" href="#">انصراف</a>';
            echo '</form>';
            $volume_panel_configs['wallet'] = array(
                'class' => 'ipsvp-renew-wallet-method ipsvp-extra-volume-wallet-method',
                'attributes' => array('data-wallet-balance' => $balance),
                'summary' => array(
                    array('label' => $label, 'value' => number_format_i18n($balance) . ' تومان'),
                    array('label' => 'مبلغ سفارش', 'value_html' => '<span class="ipsvp-extra-volume-wallet-total">' . esc_html(number_format_i18n((int) $unit_price)) . ' تومان</span>'),
                ),
                'content_html' => ob_get_clean(),
            );
        }
        if ($this->crypto_available()) {
            ob_start();
            echo '<form method="post" action="' . esc_url($this->current_page_url(array('ipsvp_tab' => 'detail', 'ipsvp_order_id' => $order->id))) . '" class="ipsvp-extra-volume-payment-form ipsvp-crypto-extra-volume-form">';
            $this->render_extra_volume_hidden_fields($order->id, 'submit_crypto_extra_volume', 'ipsvp_submit_crypto_extra_volume', 'crypto-extra-volume-');
            echo '<button class="ipsvp-btn" type="submit">ادامه و پرداخت</button> <a class="ipsvp-secondary ipsvp-link-btn" href="#">انصراف</a>';
            echo '</form>';
            $volume_panel_configs['crypto'] = array(
                'description' => 'بعد از ثبت، به صفحه پرداخت رمزینو منتقل می‌شوید. پس از پرداخت موفق، حجم انتخاب‌شده اضافه می‌شود.',
                'summary' => array(
                    array('label' => 'مبلغ سفارش', 'value_html' => $dynamic_volume_total),
                    array('label' => 'درگاه', 'value' => 'Ramzino Crypto'),
                ),
                'content_html' => ob_get_clean(),
            );
        }
        if (class_exists('IPSPM_Payment_Manager')) {
            echo IPSPM_Payment_Manager::render_payment_box(array(
                'context' => 'extra-volume',
                'input_name' => 'ipsvp_extra_volume_payment_method',
                'methods' => $methods,
                'panel_configs' => $volume_panel_configs,
                'default' => $default_method,
                'class' => 'ipsvp-extra-volume-payment-switcher',
            ));
        } else {
            echo '<div class="ipsvp-alert">افزونه مدیریت پرداخت‌ها فعال نیست.</div>';
        }
        echo '</div></div></div>';
        return ob_get_clean();
    }

    private function render_renewal_wallet_form($phone, $hidden_fields, $action, $nonce_action, $title, $description = '')
    {
        // Backward-compatible wrapper. The new renewal UI uses one shared plan picker, so this helper
        // now renders only the wallet payment method without duplicating plan cards.
        return $this->render_wallet_payment_method($phone, $hidden_fields, $action, $nonce_action, $title, false);
    }

    private function render_renewal_modal($order)
    {
        $plans = $this->db->active_plans($this->db->order_service_type($order));
        $settings = IPSVP_Settings::get();
        ob_start();
        echo '<div id="ipsvp-renew-modal" class="ipsvp-modal"><a class="ipsvp-modal-bg" href="#"></a><div class="ipsvp-modal-card"><a class="ipsvp-modal-close" href="#">×</a><h3>تمدید سفارش ' . esc_html($order->order_code) . '</h3>';
        if (!$plans) {
            echo '<div class="ipsvp-alert">هیچ پلن فعالی برای تمدید وجود ندارد.</div></div></div>';
            return ob_get_clean();
        }
        $is_all_countries = $this->db->is_all_countries_order($order);
        echo '<div class="ipsvp-renew-flow" data-renew-flow>';
        echo '<div class="ipsvp-renew-step"><h4>۱. پلن تمدید را انتخاب کنید</h4>';
        if ($is_all_countries) {
            echo '<p class="ipsvp-renew-all-note">قیمت تمدید این سرویس با ضریب همه کشورها محاسبه شده است.</p>';
        }
        echo $this->render_renewal_plan_picker($plans, 'ipsvp_renew_plan_pick_site', $order) . '</div>';
        echo '<div class="ipsvp-renew-step"><h4>۲. روش پرداخت را انتخاب کنید</h4><p class="ipsvp-renew-help">ابتدا یک پلن انتخاب کنید؛ سپس روش پرداخت را انتخاب کنید.</p>';
        $renew_methods = array();
        if ($this->payment_method_enabled('card')) { $renew_methods[] = array('id'=>'card','title'=>'کارت به کارت','desc'=>'ارسال رسید تمدید'); }
        if ($this->payment_method_enabled('wallet')) { $renew_methods[] = array('id'=>'wallet','title'=>'کیف پول','desc'=>'تمدید فوری'); }
        if ($this->crypto_available()) { $renew_methods[] = array('id'=>'crypto','title'=>'کریپتو','desc'=>'پرداخت رمزینو'); }
        if (!$renew_methods) {
            echo '<div class="ipsvp-alert">هیچ روش پرداختی برای تمدید فعال نیست.</div></div></div></div></div>';
            return ob_get_clean();
        }
        $default_method = $renew_methods[0]['id'];
        $renew_panels = array();
        if ($this->payment_method_enabled('card')) {
            $renew_panels['card'] = $this->render_card_renewal_method(array('ipsvp_tab' => 'detail', 'ipsvp_order_id' => $order->id), 'submit_renewal_receipt', 'ipsvp_submit_renewal_receipt', 'renew-', $settings, 'renew_receipt', 'ثبت درخواست تمدید', 'بعد از تایید ادمین، همین کانفیگ تمدید می شود.');
        }
        if ($this->payment_method_enabled('wallet')) {
            $renew_panels['wallet'] = $this->render_wallet_payment_method($order->phone, array('ipsvp_tab' => 'detail', 'ipsvp_order_id' => $order->id), 'submit_wallet_renewal', 'ipsvp_submit_wallet_renewal', 'پرداخت فوری با کیف پول', false);
        }
        if ($this->crypto_available()) {
            $renew_panels['crypto'] = $this->render_crypto_renewal_method(array('ipsvp_tab' => 'detail', 'ipsvp_order_id' => $order->id), 'submit_crypto_renewal', 'ipsvp_submit_crypto_renewal', 'crypto-renew-', 'پرداخت کریپتو با رمزینو', 'بعد از پرداخت موفق، همین کانفیگ تمدید می‌شود.');
        }
        if (class_exists('IPSPM_Payment_Manager')) {
            echo IPSPM_Payment_Manager::render_payment_box(array(
                'context' => 'ip-sabet-renewal',
                'input_name' => 'ipsvp_renew_payment_method_site',
                'methods' => $renew_methods,
                'panels' => $renew_panels,
                'default' => $default_method,
                'class' => 'ipsvp-renew-payment-switcher',
            ));
        } else {
            echo '<div class="ipsvp-alert">افزونه مدیریت پرداخت‌ها فعال نیست.</div>';
        }
        echo '</div></div></div></div>';
        return ob_get_clean();
    }

    private function render_bot_renewal_modal($bot_order)
    {
        $plans = $this->db->active_plans();
        $settings = IPSVP_Settings::get();
        $bot_order_id = (int) ($bot_order['id'] ?? 0);
        ob_start();
        echo '<div id="ipsvp-bot-renew-modal" class="ipsvp-modal"><a class="ipsvp-modal-bg" href="#"></a><div class="ipsvp-modal-card"><a class="ipsvp-modal-close" href="#">×</a><h3>تمدید سفارش ربات #' . esc_html($bot_order_id) . '</h3>';
        if (!$plans) {
            echo '<div class="ipsvp-alert">هیچ پلن فعالی برای تمدید وجود ندارد.</div></div></div>';
            return ob_get_clean();
        }
        $phone = $this->get_logged_phone();
        $is_all_countries = $this->db->is_all_countries_order($bot_order);
        echo '<div class="ipsvp-renew-flow" data-renew-flow>';
        echo '<div class="ipsvp-renew-step"><h4>۱. پلن تمدید را انتخاب کنید</h4>';
        if ($is_all_countries) {
            echo '<p class="ipsvp-renew-all-note">قیمت تمدید این سرویس با ضریب همه کشورها محاسبه شده است.</p>';
        }
        echo $this->render_renewal_plan_picker($plans, 'ipsvp_renew_plan_pick_bot', $bot_order) . '</div>';
        echo '<div class="ipsvp-renew-step"><h4>۲. روش پرداخت را انتخاب کنید</h4><p class="ipsvp-renew-help">ابتدا یک پلن انتخاب کنید؛ سپس روش پرداخت را انتخاب کنید.</p>';
        $renew_methods = array();
        if ($this->payment_method_enabled('card')) { $renew_methods[] = array('id'=>'card','title'=>'کارت به کارت','desc'=>'ارسال رسید تمدید'); }
        if ($this->payment_method_enabled('wallet')) { $renew_methods[] = array('id'=>'wallet','title'=>'کیف پول','desc'=>'تمدید فوری'); }
        if ($this->crypto_available()) { $renew_methods[] = array('id'=>'crypto','title'=>'کریپتو','desc'=>'پرداخت رمزینو'); }
        if (!$renew_methods) {
            echo '<div class="ipsvp-alert">هیچ روش پرداختی برای تمدید فعال نیست.</div></div></div></div></div>';
            return ob_get_clean();
        }
        $default_method = $renew_methods[0]['id'];
        $renew_panels = array();
        if ($this->payment_method_enabled('card')) {
            $renew_panels['card'] = $this->render_card_renewal_method(array('ipsvp_tab' => 'bot_detail', 'ipsvp_bot_order_id' => $bot_order_id), 'submit_bot_renewal_receipt', 'ipsvp_submit_bot_renewal_receipt', 'botrenew-', $settings, 'renew_receipt', 'ثبت درخواست تمدید', 'بعد از تایید ادمین، همین کانفیگ تمدید و سفارش ربات بروزرسانی می شود.');
        }
        if ($this->payment_method_enabled('wallet')) {
            $renew_panels['wallet'] = $this->render_wallet_payment_method($phone, array('ipsvp_tab' => 'bot_detail', 'ipsvp_bot_order_id' => $bot_order_id), 'submit_bot_wallet_renewal', 'ipsvp_submit_bot_wallet_renewal', 'پرداخت فوری با کیف پول', true);
        }
        if ($this->crypto_available()) {
            $renew_panels['crypto'] = $this->render_crypto_renewal_method(array('ipsvp_tab' => 'bot_detail', 'ipsvp_bot_order_id' => $bot_order_id), 'submit_bot_crypto_renewal', 'ipsvp_submit_bot_crypto_renewal', 'bot-crypto-renew-', 'پرداخت کریپتو با رمزینو', 'بعد از پرداخت موفق، سفارش ربات تمدید و بروزرسانی می‌شود.');
        }
        if (class_exists('IPSPM_Payment_Manager')) {
            echo IPSPM_Payment_Manager::render_payment_box(array(
                'context' => 'bot-renewal',
                'input_name' => 'ipsvp_renew_payment_method_bot',
                'methods' => $renew_methods,
                'panels' => $renew_panels,
                'default' => $default_method,
                'class' => 'ipsvp-renew-payment-switcher',
            ));
        } else {
            echo '<div class="ipsvp-alert">افزونه مدیریت پرداخت‌ها فعال نیست.</div>';
        }
        echo '</div></div></div></div>';
        return ob_get_clean();
    }

    private function render_bot_order_payments($bot_order_id, $phone)
    {
        $receipts = $this->db->get_bot_order_renewal_receipts($bot_order_id, $phone);
        ob_start();
        echo '<div class="ipsvp-payments"><h3>لیست پرداختی های تمدید ربات</h3>';
        if (!$receipts) {
            echo '<div class="ipsvp-alert">هنوز پرداخت تمدیدی برای این سفارش ربات ثبت نشده است.</div></div>';
            return ob_get_clean();
        }
        echo '<div class="ipsvp-payment-list">';
        foreach ($receipts as $r) {
            $receipt_link = IPSVP_Receipt_Uploader::link_html(isset($r->attachment_id) ? (int) $r->attachment_id : 0, !empty($r->file_url) ? $r->file_url : '', 'مشاهده رسید');
            echo '<div class="ipsvp-payment-row"><div><strong>' . esc_html($this->db->status_label($r->type)) . ' #' . esc_html($r->id) . '</strong><span>' . esc_html($r->plan_title ? $r->plan_title : '-') . '</span><small>' . esc_html($r->created_at) . '</small></div><div><b>' . esc_html(number_format_i18n((int) $r->amount)) . ' تومان</b><br><span class="ipsvp-badge ipsvp-' . esc_attr($r->status) . '">' . esc_html($this->db->status_label($r->status)) . '</span>' . ($receipt_link !== '' ? '<br>' . $receipt_link : '') . '</div></div>';
        }
        echo '</div></div>';
        return ob_get_clean();
    }

    private function render_order_payments($order_id)
    {
        $receipts = $this->db->get_order_receipts($order_id);
        ob_start();
        echo '<div class="ipsvp-payments"><h3>لیست پرداختی ها</h3>';
        if (!$receipts) {
            echo '<p>هنوز پرداختی برای این سفارش ثبت نشده است.</p></div>';
            return ob_get_clean();
        }
        echo '<div class="ipsvp-payment-list">';
        foreach ($receipts as $r) {
            $payment_detail = ($r->plan_title ? $r->plan_title : '-') . ' - ' . number_format_i18n($r->amount) . ' تومان';
            if (in_array((string) $r->type, array('extra_volume','wallet_extra_volume'), true) && !empty($r->remote_payload)) {
                $payload = json_decode((string) $r->remote_payload, true);
                if (is_array($payload) && !empty($payload['gb'])) {
                    $payment_detail = number_format_i18n((int) $payload['gb']) . ' گیگ حجم اضافه - ' . number_format_i18n((int) $r->amount) . ' تومان';
                }
            }
            echo '<div class="ipsvp-payment-row"><div><strong>' . esc_html($this->db->status_label($r->type)) . ' #' . esc_html($r->id) . '</strong><span>' . esc_html($payment_detail) . '</span></div><div><span class="ipsvp-badge ipsvp-' . esc_attr($r->status) . '">' . esc_html($this->db->status_label($r->status)) . '</span><small>' . esc_html($r->created_at) . '</small></div></div>';
        }
        echo '</div></div>';
        return ob_get_clean();
    }

    private function find_key($array, $keys)
    {
        if (!is_array($array)) {
            return '';
        }
        foreach ($keys as $key) {
            $value = $this->find_key_recursive($array, $key);
            if ($value !== null && $value !== '') {
                return $value;
            }
        }
        return '';
    }

    private function find_key_recursive($array, $needle)
    {
        foreach ($array as $key => $value) {
            if ($key === $needle) {
                return $value;
            }
            if (is_array($value)) {
                $found = $this->find_key_recursive($value, $needle);
                if ($found !== null && $found !== '') {
                    return $found;
                }
            }
        }
        return null;
    }

    private function format_bytes($bytes)
    {
        if ($bytes === '' || $bytes === null) {
            return '-';
        }
        $bytes = (float) $bytes;
        if ($bytes <= 0) {
            return '0 GB';
        }
        return number_format_i18n($bytes / 1024 / 1024 / 1024, 2) . ' GB';
    }

    private function qr_url($text)
    {
        return 'https://api.qrserver.com/v1/create-qr-code/?size=260x260&data=' . rawurlencode($text);
    }
}

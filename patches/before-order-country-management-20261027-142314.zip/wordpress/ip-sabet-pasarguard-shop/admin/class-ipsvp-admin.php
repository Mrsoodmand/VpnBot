<?php
/**
 * WordPress administration screens and actions.
 *
 * @package IPSabet_PasarGuard_Shop
 */

defined('ABSPATH') || exit;

final class IPSVP_Admin
{
    private $db;
    private $api;

    public function __construct($db, $api)
    {
        $this->db = $db;
        $this->api = $api;
        add_action('admin_menu', array($this, 'menu'));
        add_action('admin_menu', array($this, 'organize_menu'), 999);
        add_action('admin_init', array($this, 'handle_actions'));
        add_action('admin_notices', array($this, 'dedicated_orders_notice'));
    }

    public function dedicated_orders_notice()
    {
        if (!current_user_can('manage_options')) { return; }
        global $wpdb;
        $t = $this->db->tables();
        $count = (int) $wpdb->get_var("SELECT COUNT(DISTINCT o.id)
            FROM {$t['orders']} o
            LEFT JOIN {$t['receipts']} r ON r.order_id=o.id AND r.status='pending'
            WHERE o.service_type='dedicated'
              AND (o.status='awaiting_assignment' OR r.id IS NOT NULL)");
        if ($count > 0) {
            $pending_receipts = (int) $wpdb->get_var("SELECT COUNT(DISTINCT o.id)
                FROM {$t['orders']} o
                INNER JOIN {$t['receipts']} r ON r.order_id=o.id AND r.status='pending'
                WHERE o.service_type='dedicated'");
            $awaiting_assignment = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$t['orders']} WHERE service_type='dedicated' AND status='awaiting_assignment'");
            echo '<div class="notice notice-warning ipsvp-dedicated-admin-notice"><p><strong>' . esc_html(number_format_i18n($count)) . ' سفارش اختصاصی نیازمند بررسی</strong> ';
            if ($pending_receipts > 0) {
                $receipts_url = admin_url('admin.php?page=ipsvp-receipts&service_type=dedicated&receipt_status=pending');
                echo '<a class="button button-primary" href="' . esc_url($receipts_url) . '">بررسی رسیدها (' . esc_html(number_format_i18n($pending_receipts)) . ')</a> ';
            }
            if ($awaiting_assignment > 0) {
                $orders_url = admin_url('admin.php?page=ipsvp-orders&service_type=dedicated');
                echo '<a class="button" href="' . esc_url($orders_url) . '">اتصال سفارش‌ها (' . esc_html(number_format_i18n($awaiting_assignment)) . ')</a>';
            }
            echo '</p></div>';
        }

        $expiring = array_values(array_filter($this->db->get_dedicated_expiring_orders(5), static function ($order) {
            return empty($order->renewal_pending);
        }));
        if (!$expiring) { return; }
        $critical = 0;
        foreach ($expiring as $order) {
            if ((int) $order->seconds_left <= DAY_IN_SECONDS) { $critical++; }
        }
        $notice_class = $critical > 0 ? 'notice-error' : 'notice-warning';
        $message = $critical > 0
            ? number_format_i18n($critical) . ' سرویس اختصاصی منقضی شده یا کمتر از ۲۴ ساعت فرصت دارد.'
            : number_format_i18n(count($expiring)) . ' سرور اختصاصی در ۵ روز آینده تمام می‌شود و تمدید در انتظاری ندارد.';
        echo '<div class="notice ' . esc_attr($notice_class) . ' ipsvp-dedicated-expiry-notice"><p><strong>' . esc_html($message) . '</strong> ';
        echo '<a class="button button-primary" href="' . esc_url(admin_url('admin.php?page=ipsvp-dedicated-expiring')) . '">بررسی تمدیدها</a></p></div>';
    }

    public function menu()
    {
        add_menu_page('آی پی ثابت من', 'آی پی ثابت من', 'manage_options', 'ipsvp', array($this, 'dashboard'), 'dashicons-shield-alt', 56);
        add_submenu_page('ipsvp', 'داشبورد', 'داشبورد', 'manage_options', 'ipsvp', array($this, 'dashboard'), 0);
        add_submenu_page('ipsvp', 'تنظیمات', 'تنظیمات', 'manage_options', 'ipsvp-settings', array($this, 'settings_page'));
        add_submenu_page('ipsvp', 'پلن ها', 'پلن ها', 'manage_options', 'ipsvp-plans', array($this, 'plans_page'));
        add_submenu_page('ipsvp', 'کشورها', 'کشورها', 'manage_options', 'ipsvp-countries', array($this, 'countries_page'));
        add_submenu_page('ipsvp', 'سفارشات', 'سفارشات', 'manage_options', 'ipsvp-orders', array($this, 'orders_page'));
        $due_count = count(array_filter($this->db->get_dedicated_expiring_orders(5), static function ($order) {
            return empty($order->renewal_pending);
        }));
        $due_label = 'پایان سرویس اختصاصی';
        if ($due_count > 0) {
            $due_label .= ' <span class="awaiting-mod count-' . (int) $due_count . '"><span class="pending-count">' . number_format_i18n($due_count) . '</span></span>';
        }
        add_submenu_page('ipsvp', 'پایان سرویس‌های اختصاصی', $due_label, 'manage_options', 'ipsvp-dedicated-expiring', array($this, 'dedicated_expiring_page'));
        add_submenu_page('ipsvp', 'رسیدها و تراکنش‌ها', 'رسیدها و تراکنش‌ها', 'manage_options', 'ipsvp-receipts', array($this, 'receipts_page'));
        add_submenu_page('ipsvp', 'کاربران', 'کاربران', 'manage_options', 'ipsvp-users', array($this, 'users_page'));
        add_submenu_page('ipsvp', 'گزارش ربات', 'گزارش ربات', 'manage_options', 'ipsvp-bot-reports', array($this, 'bot_reports_page'));
        add_submenu_page('ipsvp', 'لاگ خطاها', 'لاگ خطاها', 'manage_options', 'ipsvp-logs', array($this, 'logs_page'));
    }

    public function organize_menu()
    {
        global $submenu;
        if (empty($submenu['ipsvp'])) { return; }
        $groups = array(
            'مدیریت فروش' => array('ipsvp', 'ipsvp-orders', 'ipsvp-receipts', 'ipsvp-dedicated-expiring', 'ipspla-orders'),
            'مشتریان و همکاری' => array('ipsvp-users', 'ipsvp-resellers', 'ipsvp-loyalty', 'ipsra-settings'),
            'محصولات و تنظیمات' => array('ipsvp-plans', 'ipsvp-countries', 'ipsvp-settings', 'ipspla-settings'),
            'گزارش‌ها' => array('ipsvp-bot-reports', 'ipsvp-logs', 'ipspla-logs'),
        );
        $remaining = $submenu['ipsvp']; $ordered = array();
        foreach ($groups as $label => $slugs) {
            $first = true;
            foreach ($slugs as $slug) {
                foreach ($remaining as $key => $item) {
                    if ($item[2] !== $slug) { continue; }
                    if ($first) {
                        $item[0] = '<span class="ipsvp-menu-group">' . esc_html($label) . '</span>' . $item[0];
                        $first = false;
                    }
                    $ordered[] = $item; unset($remaining[$key]); break;
                }
            }
        }
        $submenu['ipsvp'] = array_merge($ordered, array_values($remaining));
    }

    public function handle_actions()
    {
        if (!current_user_can('manage_options')) {
            return;
        }
        $action = isset($_REQUEST['ipsvp_action']) ? sanitize_key($_REQUEST['ipsvp_action']) : '';
        $secondary_action = isset($_POST['ipsvp_secondary_action']) ? sanitize_key(wp_unslash($_POST['ipsvp_secondary_action'])) : '';
        if ($action === 'save_settings' && $secondary_action) {
            $action = $secondary_action;
        }
        if (!$action) {
            return;
        }

        if ($action === 'test_sanaei_connection') {
            check_admin_referer('ipsvp_save_settings');
            $settings = $this->save_sanaei_settings(IPSVP_Settings::get());
            IPSVP_Settings::update($settings);
            $result = (new IPSVP_Sanaei_API())->test_connection();
            $this->redirect_notice('ipsvp-settings', is_wp_error($result) ? $result->get_error_message() : 'اتصال به سنایی موفق بود.', is_wp_error($result) ? 'error' : 'success');
        }

        if ($action === 'refresh_dedicated_expiring') {
            check_admin_referer('ipsvp_refresh_dedicated_expiring');
            $updated = $this->refresh_dedicated_expiry_snapshots(100);
            $this->redirect_notice('ipsvp-dedicated-expiring', number_format_i18n($updated) . ' سرویس اختصاصی از پنل مربوط به خود به‌روزرسانی شد.');
        }

        if ($action === 'save_settings') {
            check_admin_referer('ipsvp_save_settings');
            $settings = IPSVP_Settings::get();
            $fields = array('brand_name','panel_url','panel_username','panel_password','announcement_text','client_type','order_prefix','telegram_admin','whatsapp_admin','buy_url','dashboard_url','telegram_bot_token','telegram_chat_id','telegram_webhook_secret','telegram_webhook_mode','telegram_existing_webhook_url','all_countries_enabled','all_countries_price_percent','all_countries_group_id','all_countries_group_name','extra_volume_price_per_gb','dedicated_extra_volume_price_per_gb','smsir_api_key','smsir_template_id','smsir_code_param','otp_code_length','otp_expire_minutes','otp_resend_seconds','warning_expiry_title','warning_expiry_message','warning_expiry_button','warning_traffic_title','warning_traffic_message','warning_traffic_button');
            foreach ($fields as $field) {
                $settings[$field] = isset($_POST[$field]) ? sanitize_text_field(wp_unslash($_POST[$field])) : '';
            }
            $settings['announcement_text'] = isset($_POST['announcement_text']) ? wp_kses_post(wp_unslash($_POST['announcement_text'])) : '';
            $settings['ssl_verify'] = !empty($_POST['ssl_verify']) ? '1' : '0';
            $settings['telegram_notifications'] = !empty($_POST['telegram_notifications']) ? '1' : '0';
            $settings['telegram_webhook_mode'] = isset($_POST['telegram_webhook_mode']) && $_POST['telegram_webhook_mode'] === 'wordpress' ? 'wordpress' : 'existing';
            $settings['telegram_existing_webhook_url'] = isset($_POST['telegram_existing_webhook_url']) ? esc_url_raw(wp_unslash($_POST['telegram_existing_webhook_url'])) : '';
            $settings['all_countries_enabled'] = !empty($_POST['all_countries_enabled']) ? '1' : '0';
            $settings['shared_sales_enabled'] = !empty($_POST['shared_sales_enabled']) ? '1' : '0';
            $settings['dedicated_sales_enabled'] = !empty($_POST['dedicated_sales_enabled']) ? '1' : '0';
            $settings['all_countries_price_percent'] = isset($_POST['all_countries_price_percent']) ? (string) max(0, min(500, (int) $_POST['all_countries_price_percent'])) : '30';
            $settings['all_countries_group_id'] = isset($_POST['all_countries_group_id']) ? (string) max(0, (int) $_POST['all_countries_group_id']) : '';
            $settings['all_countries_group_name'] = $this->pg_group_name_by_id((int) $settings['all_countries_group_id']);
            $settings['extra_volume_price_per_gb'] = isset($_POST['extra_volume_price_per_gb']) ? (string) max(1, (int) $_POST['extra_volume_price_per_gb']) : '10000';
            $settings['dedicated_extra_volume_price_per_gb'] = isset($_POST['dedicated_extra_volume_price_per_gb']) ? (string) max(1, (int) $_POST['dedicated_extra_volume_price_per_gb']) : '10000';
            $settings['otp_login_enabled'] = !empty($_POST['otp_login_enabled']) ? '1' : '0';
            $settings['smsir_template_id'] = isset($_POST['smsir_template_id']) ? (string) max(0, (int) $_POST['smsir_template_id']) : '';
            $settings['smsir_code_param'] = isset($_POST['smsir_code_param']) ? preg_replace('/[^a-zA-Z0-9_\-]/', '', (string) wp_unslash($_POST['smsir_code_param'])) : 'Code';
            if ($settings['smsir_code_param'] === '') { $settings['smsir_code_param'] = 'Code'; }
            $settings['otp_code_length'] = isset($_POST['otp_code_length']) ? (string) max(4, min(8, (int) $_POST['otp_code_length'])) : '6';
            $settings['otp_expire_minutes'] = isset($_POST['otp_expire_minutes']) ? (string) max(1, min(30, (int) $_POST['otp_expire_minutes'])) : '5';
            $settings['otp_resend_seconds'] = isset($_POST['otp_resend_seconds']) ? (string) max(20, min(600, (int) $_POST['otp_resend_seconds'])) : '60';
            $settings['captcha_enabled'] = !empty($_POST['captcha_enabled']) ? '1' : '0';
            $settings['captcha_length'] = isset($_POST['captcha_length']) && (int) $_POST['captcha_length'] === 5 ? '5' : '4';
            $settings['captcha_ttl_minutes'] = isset($_POST['captcha_ttl_minutes']) ? (string) max(1, min(60, (int) $_POST['captcha_ttl_minutes'])) : '10';
            $settings['captcha_show_panel'] = !empty($_POST['captcha_show_panel']) ? '1' : '0';
            $settings['captcha_show_config'] = !empty($_POST['captcha_show_config']) ? '1' : '0';
            $settings['captcha_show_proxy'] = !empty($_POST['captcha_show_proxy']) ? '1' : '0';
            $settings['captcha_show_otp'] = !empty($_POST['captcha_show_otp']) ? '1' : '0';
            $settings['captcha_max_attempts'] = isset($_POST['captcha_max_attempts']) ? (string) max(1, min(10, (int) $_POST['captcha_max_attempts'])) : '3';
            $captcha_color_mode = isset($_POST['captcha_color_mode']) ? sanitize_key(wp_unslash($_POST['captcha_color_mode'])) : 'auto';
            $settings['captcha_color_mode'] = in_array($captcha_color_mode, array('auto', 'light', 'dark'), true) ? $captcha_color_mode : 'auto';
            $settings['service_warnings_enabled'] = !empty($_POST['service_warnings_enabled']) ? '1' : '0';
            $settings['warning_expiry_enabled'] = !empty($_POST['warning_expiry_enabled']) ? '1' : '0';
            $settings['warning_expiry_days'] = isset($_POST['warning_expiry_days']) ? (string) max(0, min(365, (int) $_POST['warning_expiry_days'])) : '1';
            $settings['warning_traffic_enabled'] = !empty($_POST['warning_traffic_enabled']) ? '1' : '0';
            $settings['warning_traffic_gb'] = isset($_POST['warning_traffic_gb']) ? (string) max(0, min(102400, (float) wp_unslash($_POST['warning_traffic_gb']))) : '1';
            $repeat_mode = isset($_POST['warning_popup_repeat_mode']) ? sanitize_key(wp_unslash($_POST['warning_popup_repeat_mode'])) : 'daily';
            $settings['warning_popup_repeat_mode'] = in_array($repeat_mode, array('session','daily','always'), true) ? $repeat_mode : 'daily';
            $settings['warning_once_after_login'] = !empty($_POST['warning_once_after_login']) ? '1' : '0';
            $settings['warning_combine_enabled'] = !empty($_POST['warning_combine_enabled']) ? '1' : '0';
            $settings['warning_expiry_title'] = isset($_POST['warning_expiry_title']) ? sanitize_text_field(wp_unslash($_POST['warning_expiry_title'])) : '';
            $settings['warning_expiry_message'] = isset($_POST['warning_expiry_message']) ? sanitize_textarea_field(wp_unslash($_POST['warning_expiry_message'])) : '';
            $settings['warning_expiry_button'] = isset($_POST['warning_expiry_button']) ? sanitize_text_field(wp_unslash($_POST['warning_expiry_button'])) : '';
            $settings['warning_traffic_title'] = isset($_POST['warning_traffic_title']) ? sanitize_text_field(wp_unslash($_POST['warning_traffic_title'])) : '';
            $settings['warning_traffic_message'] = isset($_POST['warning_traffic_message']) ? sanitize_textarea_field(wp_unslash($_POST['warning_traffic_message'])) : '';
            $settings['warning_traffic_button'] = isset($_POST['warning_traffic_button']) ? sanitize_text_field(wp_unslash($_POST['warning_traffic_button'])) : '';
            $settings = $this->save_sanaei_settings($settings);
            IPSVP_Settings::update($settings);
            $this->redirect_notice('ipsvp-settings', 'تنظیمات ذخیره شد.');
        }

        if ($action === 'test_connection') {
            if ($secondary_action === 'test_connection') {
                check_admin_referer('ipsvp_save_settings');
                $settings = IPSVP_Settings::get();
                $fields = array('brand_name','panel_url','panel_username','panel_password','announcement_text','client_type','order_prefix','telegram_admin','whatsapp_admin','buy_url','dashboard_url','telegram_bot_token','telegram_chat_id','telegram_webhook_secret','telegram_webhook_mode','telegram_existing_webhook_url','all_countries_enabled','all_countries_price_percent','all_countries_group_id','all_countries_group_name','extra_volume_price_per_gb','smsir_api_key','smsir_template_id','smsir_code_param','otp_code_length','otp_expire_minutes','otp_resend_seconds');
                foreach ($fields as $field) {
                    $settings[$field] = isset($_POST[$field]) ? sanitize_text_field(wp_unslash($_POST[$field])) : '';
                }
                $settings['announcement_text'] = isset($_POST['announcement_text']) ? wp_kses_post(wp_unslash($_POST['announcement_text'])) : '';
                $settings['ssl_verify'] = !empty($_POST['ssl_verify']) ? '1' : '0';
                $settings['telegram_notifications'] = !empty($_POST['telegram_notifications']) ? '1' : '0';
                $settings['telegram_webhook_mode'] = isset($_POST['telegram_webhook_mode']) && $_POST['telegram_webhook_mode'] === 'wordpress' ? 'wordpress' : 'existing';
                $settings['telegram_existing_webhook_url'] = isset($_POST['telegram_existing_webhook_url']) ? esc_url_raw(wp_unslash($_POST['telegram_existing_webhook_url'])) : '';
            $settings['all_countries_enabled'] = !empty($_POST['all_countries_enabled']) ? '1' : '0';
            $settings['all_countries_price_percent'] = isset($_POST['all_countries_price_percent']) ? (string) max(0, min(500, (int) $_POST['all_countries_price_percent'])) : '30';
            $settings['all_countries_group_id'] = isset($_POST['all_countries_group_id']) ? (string) max(0, (int) $_POST['all_countries_group_id']) : '';
            $settings['all_countries_group_name'] = $this->pg_group_name_by_id((int) $settings['all_countries_group_id']);
            $settings['extra_volume_price_per_gb'] = isset($_POST['extra_volume_price_per_gb']) ? (string) max(1, (int) $_POST['extra_volume_price_per_gb']) : '10000';
            $settings['otp_login_enabled'] = !empty($_POST['otp_login_enabled']) ? '1' : '0';
            $settings['smsir_template_id'] = isset($_POST['smsir_template_id']) ? (string) max(0, (int) $_POST['smsir_template_id']) : '';
            $settings['smsir_code_param'] = isset($_POST['smsir_code_param']) ? preg_replace('/[^a-zA-Z0-9_\-]/', '', (string) wp_unslash($_POST['smsir_code_param'])) : 'Code';
            if ($settings['smsir_code_param'] === '') { $settings['smsir_code_param'] = 'Code'; }
            $settings['otp_code_length'] = isset($_POST['otp_code_length']) ? (string) max(4, min(8, (int) $_POST['otp_code_length'])) : '6';
            $settings['otp_expire_minutes'] = isset($_POST['otp_expire_minutes']) ? (string) max(1, min(30, (int) $_POST['otp_expire_minutes'])) : '5';
            $settings['otp_resend_seconds'] = isset($_POST['otp_resend_seconds']) ? (string) max(20, min(600, (int) $_POST['otp_resend_seconds'])) : '60';
                IPSVP_Settings::update($settings);
            } else {
                check_admin_referer('ipsvp_test_connection');
            }
            $res = $this->api->test_connection();
            if (is_wp_error($res)) {
                $this->redirect_notice('ipsvp-settings', $res->get_error_message(), 'error');
            }
            update_option('ipsvp_pg_groups_cache', $res, false);
            $this->redirect_notice('ipsvp-settings', 'اتصال موفق بود و لیست گروه ها دریافت شد.');
        }

        if ($action === 'set_telegram_webhook') {
            if ($secondary_action === 'set_telegram_webhook') {
                check_admin_referer('ipsvp_save_settings');
                $settings = IPSVP_Settings::get();
                $fields = array('brand_name','panel_url','panel_username','panel_password','announcement_text','client_type','order_prefix','telegram_admin','whatsapp_admin','buy_url','dashboard_url','telegram_bot_token','telegram_chat_id','telegram_webhook_secret','telegram_webhook_mode','telegram_existing_webhook_url','all_countries_enabled','all_countries_price_percent','all_countries_group_id','all_countries_group_name','extra_volume_price_per_gb','smsir_api_key','smsir_template_id','smsir_code_param','otp_code_length','otp_expire_minutes','otp_resend_seconds');
                foreach ($fields as $field) {
                    $settings[$field] = isset($_POST[$field]) ? sanitize_text_field(wp_unslash($_POST[$field])) : '';
                }
                $settings['announcement_text'] = isset($_POST['announcement_text']) ? wp_kses_post(wp_unslash($_POST['announcement_text'])) : '';
                $settings['ssl_verify'] = !empty($_POST['ssl_verify']) ? '1' : '0';
                $settings['telegram_notifications'] = !empty($_POST['telegram_notifications']) ? '1' : '0';
                $settings['telegram_webhook_mode'] = isset($_POST['telegram_webhook_mode']) && $_POST['telegram_webhook_mode'] === 'wordpress' ? 'wordpress' : 'existing';
                $settings['telegram_existing_webhook_url'] = isset($_POST['telegram_existing_webhook_url']) ? esc_url_raw(wp_unslash($_POST['telegram_existing_webhook_url'])) : '';
            $settings['all_countries_enabled'] = !empty($_POST['all_countries_enabled']) ? '1' : '0';
            $settings['all_countries_price_percent'] = isset($_POST['all_countries_price_percent']) ? (string) max(0, min(500, (int) $_POST['all_countries_price_percent'])) : '30';
            $settings['all_countries_group_id'] = isset($_POST['all_countries_group_id']) ? (string) max(0, (int) $_POST['all_countries_group_id']) : '';
            $settings['all_countries_group_name'] = $this->pg_group_name_by_id((int) $settings['all_countries_group_id']);
            $settings['extra_volume_price_per_gb'] = isset($_POST['extra_volume_price_per_gb']) ? (string) max(1, (int) $_POST['extra_volume_price_per_gb']) : '10000';
            $settings['otp_login_enabled'] = !empty($_POST['otp_login_enabled']) ? '1' : '0';
            $settings['smsir_template_id'] = isset($_POST['smsir_template_id']) ? (string) max(0, (int) $_POST['smsir_template_id']) : '';
            $settings['smsir_code_param'] = isset($_POST['smsir_code_param']) ? preg_replace('/[^a-zA-Z0-9_\-]/', '', (string) wp_unslash($_POST['smsir_code_param'])) : 'Code';
            if ($settings['smsir_code_param'] === '') { $settings['smsir_code_param'] = 'Code'; }
            $settings['otp_code_length'] = isset($_POST['otp_code_length']) ? (string) max(4, min(8, (int) $_POST['otp_code_length'])) : '6';
            $settings['otp_expire_minutes'] = isset($_POST['otp_expire_minutes']) ? (string) max(1, min(30, (int) $_POST['otp_expire_minutes'])) : '5';
            $settings['otp_resend_seconds'] = isset($_POST['otp_resend_seconds']) ? (string) max(20, min(600, (int) $_POST['otp_resend_seconds'])) : '60';
                IPSVP_Settings::update($settings);
            } else {
                check_admin_referer('ipsvp_set_telegram_webhook');
            }
            $res = IPSVP_Telegram_Service::set_webhook($this->db);
            if (is_wp_error($res)) {
                $this->redirect_notice('ipsvp-settings', $res->get_error_message(), 'error');
            }
            $this->redirect_notice('ipsvp-settings', 'وبهوک تلگرام طبق حالت انتخابی ثبت/حفظ شد.');
        }


        if ($action === 'save_plan') {
            check_admin_referer('ipsvp_save_plan');
            $this->save_plan();
        }
        if ($action === 'delete_plan') {
            check_admin_referer('ipsvp_delete_plan');
            $this->delete_row('plans', (int) $_GET['id'], 'ipsvp-plans');
        }
        if ($action === 'save_country') {
            check_admin_referer('ipsvp_save_country');
            $this->save_country();
        }
        if ($action === 'delete_country') {
            check_admin_referer('ipsvp_delete_country');
            $this->delete_row('countries', (int) $_GET['id'], 'ipsvp-countries');
        }
        if ($action === 'sync_groups') {
            check_admin_referer('ipsvp_sync_groups');
            $groups = $this->api->get_groups();
            if (is_wp_error($groups)) {
                $this->redirect_notice('ipsvp-countries', $groups->get_error_message(), 'error');
            }
            update_option('ipsvp_pg_groups_cache', $groups, false);
            $this->redirect_notice('ipsvp-countries', 'لیست گروه های پاسارگارد بروزرسانی شد.');
        }
        if ($action === 'review_order_receipt') {
            $order_id = (int) ($_POST['order_id'] ?? 0);
            $receipt_id = (int) ($_POST['receipt_id'] ?? 0);
            check_admin_referer('ipsvp_review_order_receipt_' . $order_id . '_' . $receipt_id);
            $receipt = $this->db->get_receipt($receipt_id);
            $decision = sanitize_key(wp_unslash($_POST['receipt_decision'] ?? ''));
            if (!$receipt || (int) $receipt->order_id !== $order_id || !in_array($decision, array('approve', 'reject'), true)) {
                $this->order_detail_redirect($order_id, 'رسید یا سفارش انتخاب‌شده معتبر نیست.', 'error');
            }
            if ((string) $receipt->status !== 'pending') {
                $this->order_detail_redirect($order_id, 'این رسید قبلاً بررسی شده است.', 'error');
            }
            $result = $decision === 'approve'
                ? IPSVP_Receipt_Manager::approve($receipt_id, $this->db, $this->api)
                : IPSVP_Receipt_Manager::reject($receipt_id, $this->db);
            $this->order_detail_redirect($order_id, $result['message'], $result['type']);
        }
        if ($action === 'approve_receipt') {
            check_admin_referer('ipsvp_approve_receipt');
            $this->approve_receipt((int) $_GET['id']);
        }
        if ($action === 'reject_receipt') {
            check_admin_referer('ipsvp_reject_receipt');
            $this->reject_receipt((int) $_GET['id']);
        }
        if ($action === 'admin_update_user') {
            check_admin_referer('ipsvp_admin_update_user');
            $this->admin_update_user();
        }
        if ($action === 'disconnect_bot_link') {
            check_admin_referer('ipsvp_disconnect_bot_link');
            $this->admin_disconnect_bot_link();
        }
        if ($action === 'admin_wallet_adjust') {
            check_admin_referer('ipsvp_admin_wallet_adjust');
            $this->admin_wallet_adjust();
        }
        if ($action === 'assign_pg_user') {
            check_admin_referer('ipsvp_assign_pg_user');
            $this->assign_pg_user();
        }
        if ($action === 'update_order_status') {
            check_admin_referer('ipsvp_update_order_status');
            $this->update_order_status();
        }
    }

    private function redirect_notice($page, $message, $type = 'success')
    {
        wp_safe_redirect(add_query_arg(array('page' => $page, 'ipsvp_msg' => rawurlencode($message), 'ipsvp_type' => $type), admin_url('admin.php')));
        exit;
    }

    private function notice()
    {
        if (!empty($_GET['ipsvp_msg'])) {
            $type = isset($_GET['ipsvp_type']) && $_GET['ipsvp_type'] === 'error' ? 'error' : 'success';
            echo '<div class="notice notice-' . esc_attr($type) . ' is-dismissible"><p>' . esc_html(wp_unslash($_GET['ipsvp_msg'])) . '</p></div>';
        }
    }

    private function save_plan()
    {
        global $wpdb;
        $t = $this->db->tables();
        $id = isset($_POST['id']) ? (int) $_POST['id'] : 0;
        $data = array(
            'service_type' => $this->db->normalize_service_type(isset($_POST['service_type']) ? wp_unslash($_POST['service_type']) : 'shared'),
            'title' => sanitize_text_field(wp_unslash($_POST['title'])),
            'gb' => (int) $_POST['gb'],
            'days' => (int) $_POST['days'],
            'price' => (int) $_POST['price'],
            'sale_price' => ($_POST['sale_price'] !== '') ? (int) $_POST['sale_price'] : null,
            'discount_label' => isset($_POST['discount_label']) ? sanitize_text_field(wp_unslash($_POST['discount_label'])) : '',
            'card_icon' => isset($_POST['card_icon']) ? sanitize_text_field(wp_unslash($_POST['card_icon'])) : '',
            'features' => isset($_POST['features']) ? sanitize_textarea_field(wp_unslash($_POST['features'])) : '',
            'status' => !empty($_POST['status']) ? 1 : 0,
            'sort_order' => (int) $_POST['sort_order'],
        );
        if ($id) {
            $wpdb->update($t['plans'], $data, array('id' => $id));
        } else {
            $data['created_at'] = $this->db->now();
            $wpdb->insert($t['plans'], $data);
        }
        wp_safe_redirect(add_query_arg(array('page' => 'ipsvp-plans', 'service_type' => $data['service_type'], 'ipsvp_msg' => rawurlencode('پلن ذخیره شد.'), 'ipsvp_type' => 'success'), admin_url('admin.php')));
        exit;
    }

    private function save_country()
    {
        global $wpdb;
        $t = $this->db->tables();
        $id = isset($_POST['id']) ? (int) $_POST['id'] : 0;
        $group_id = isset($_POST['pg_group_id']) ? (int) $_POST['pg_group_id'] : 0;
        $group_name = $this->group_name_by_id($group_id);
        $data = array(
            'service_type' => $this->db->normalize_service_type(isset($_POST['service_type']) ? wp_unslash($_POST['service_type']) : 'shared'),
            'name' => sanitize_text_field(wp_unslash($_POST['name'])),
            'flag' => sanitize_text_field(wp_unslash($_POST['flag'])),
            'pg_group_id' => $group_id,
            'pg_group_name' => $group_name,
            'status' => !empty($_POST['status']) ? 1 : 0,
            'sort_order' => (int) $_POST['sort_order'],
        );
        if ($id) {
            $wpdb->update($t['countries'], $data, array('id' => $id));
        } else {
            $data['created_at'] = $this->db->now();
            $wpdb->insert($t['countries'], $data);
        }
        wp_safe_redirect(add_query_arg(array('page' => 'ipsvp-countries', 'service_type' => $data['service_type'], 'ipsvp_msg' => rawurlencode('کشور ذخیره شد.'), 'ipsvp_type' => 'success'), admin_url('admin.php')));
        exit;
    }

    private function delete_row($table_key, $id, $page)
    {
        global $wpdb;
        $t = $this->db->tables();
        if ($id && isset($t[$table_key])) {
            $wpdb->delete($t[$table_key], array('id' => $id));
        }
        $this->redirect_notice($page, 'حذف شد.');
    }


    private function admin_update_user()
    {
        $user_id = isset($_POST['user_id']) ? (int) $_POST['user_id'] : 0;
        $user = $this->db->get_user_by_id($user_id);
        if (!$user) {
            $this->redirect_notice('ipsvp-users', 'کاربر پیدا نشد.', 'error');
        }
        $blocked = !empty($_POST['is_blocked']) ? 1 : 0;
        $blocked_note = isset($_POST['blocked_note']) ? wp_unslash($_POST['blocked_note']) : '';
        $this->db->set_user_blocked($user_id, $blocked, $blocked_note);

        $password_action = isset($_POST['password_action']) ? sanitize_key($_POST['password_action']) : '';
        $new_password = isset($_POST['new_password']) ? (string) wp_unslash($_POST['new_password']) : '';
        if ($password_action === 'set') {
            if (strlen($new_password) < 4) {
                $this->redirect_notice('ipsvp-users', 'رمز جدید باید حداقل ۴ کاراکتر باشد.', 'error');
            }
            $this->db->admin_set_user_password_by_id($user_id, $new_password);
        } elseif ($password_action === 'clear') {
            $this->db->clear_user_password_by_id($user_id);
        }
        wp_safe_redirect(add_query_arg(array('page' => 'ipsvp-users', 'view' => $user_id, 'ipsvp_msg' => rawurlencode('اطلاعات کاربر ذخیره شد.'), 'ipsvp_type' => 'success'), admin_url('admin.php')));
        exit;
    }

    private function order_detail_redirect($order_id, $message, $type = 'success')
    {
        wp_safe_redirect(add_query_arg(array(
            'page' => 'ipsvp-orders',
            'view' => (int) $order_id,
            'ipsvp_msg' => rawurlencode($message),
            'ipsvp_type' => $type,
        ), admin_url('admin.php')));
        exit;
    }

    private function assign_pg_user()
    {
        $order_id = isset($_POST['order_id']) ? (int) $_POST['order_id'] : 0;
        $identifier = isset($_POST['pg_identifier']) ? trim((string) wp_unslash($_POST['pg_identifier'])) : '';
        $order = $this->db->get_order($order_id);
        if (!$order || $this->db->order_service_type($order) !== 'dedicated') {
            $this->order_detail_redirect($order_id, 'سفارش اختصاصی پیدا نشد.', 'error');
        }
        if ($identifier === '') {
            $this->order_detail_redirect($order_id, 'یوزرنیم یا آیدی کاربر پنل را وارد کنید.', 'error');
        }
        $provider = isset($_POST['panel_provider']) ? sanitize_key(wp_unslash($_POST['panel_provider'])) : 'pasarguard';
        if (!in_array($provider, array('pasarguard', 'sanaei'), true)) {
            $this->order_detail_redirect($order_id, 'پنل انتخاب‌شده معتبر نیست.', 'error');
        }
        $linked = !empty($order->pg_user_id) || !empty($order->pg_username);
        $old_provider = !empty($order->panel_provider) ? (string) $order->panel_provider : 'pasarguard';
        if ($linked && $provider !== $old_provider) {
            $this->order_detail_redirect($order_id, 'پنل سفارش متصل‌شده قابل تغییر نیست؛ سرویس قبلی حفظ شد.', 'error');
        }
        $candidate = clone $order;
        $candidate->panel_provider = $provider;
        $candidate->panel_inbound_id = $provider === 'sanaei' ? max(0, (int) ($_POST['panel_inbound_id'] ?? 0)) : 0;
        if ($provider === 'sanaei') {
            if (strlen($identifier) > 64 || ($linked && ($identifier !== (string) $order->pg_username || $candidate->panel_inbound_id !== (int) $order->panel_inbound_id))) {
                $this->order_detail_redirect($order_id, 'نام کلاینت یا اینباند سفارش متصل‌شده قابل تغییر نیست؛ اطلاعات قبلی حفظ شد.', 'error');
            }
            $candidate->pg_username = $identifier;
            $manual_sub = trim((string) wp_unslash($_POST['sanaei_subscription_url'] ?? ''));
            $manual_configs = trim((string) wp_unslash($_POST['sanaei_configs'] ?? ''));
            if ($manual_sub !== '') {
                if (!preg_match('#^https?://#i', $manual_sub) || !filter_var($manual_sub, FILTER_VALIDATE_URL)) {
                    $this->order_detail_redirect($order_id, 'لینک ساب باید یک آدرس کامل HTTP یا HTTPS باشد.', 'error');
                }
                $candidate->pg_subscription_url = esc_url_raw($manual_sub);
            }
            if ($manual_configs !== '') {
                $manual_links = $this->api->extract_config_links($manual_configs);
                if (!$manual_links) { $this->order_detail_redirect($order_id, 'لینک کانفیگ معتبر وارد کنید.', 'error'); }
                $candidate->pg_links = wp_json_encode($manual_links, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            }
            $snapshot = $this->api->user_snapshot($identifier, $candidate->pg_user_id ?? '', $candidate);
        } else {
            $snapshot = ctype_digit($identifier)
                ? $this->api->user_snapshot('', $identifier)
                : $this->api->user_snapshot($identifier, '');
        }
        if (empty($snapshot['live']) || empty($snapshot['user_id'])) {
            $message = !empty($snapshot['error']) ? (string) $snapshot['error'] : 'یوزر واردشده در پنل وجود ندارد.';
            $this->order_detail_redirect($order_id, $message, 'error');
        }
        if ($provider === 'sanaei' && empty($snapshot['links']) && empty($snapshot['subscription_url'])) {
            $this->order_detail_redirect($order_id, 'لینک ساب یا کانفیگ سنایی را وارد کنید؛ پنل لینک قابل تحویل برنگرداند.', 'error');
        }
        $username = !empty($snapshot['username']) ? (string) $snapshot['username'] : (ctype_digit($identifier) ? '' : $identifier);
        $links = !empty($snapshot['links']) && is_array($snapshot['links']) ? array_values(array_unique($snapshot['links'])) : array();
        $payment_approved = in_array((string) $order->payment_status, array('approved','wallet_paid','crypto_paid','paid'), true) || !empty($order->approved_at);
        $data = array(
            'panel_provider' => $provider,
            'panel_inbound_id' => $candidate->panel_inbound_id,
            'pg_username' => $username,
            'pg_user_id' => (string) $snapshot['user_id'],
            'pg_status' => !empty($snapshot['status']) ? (string) $snapshot['status'] : 'active',
            'pg_subscription_url' => !empty($snapshot['subscription_url']) ? (string) $snapshot['subscription_url'] : '',
            'pg_links' => wp_json_encode($links, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'pg_response' => wp_json_encode($snapshot['live'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'pg_synced_at' => $this->db->now(),
            'status' => $payment_approved ? 'awaiting_assignment' : (string) $order->status,
        );
        if ($this->db->update_order($order_id, $data) === false) {
            $this->order_detail_redirect($order_id, 'ذخیره اطلاعات اتصال ناموفق بود؛ عملیات پنل انجام نشد.', 'error');
        }
        delete_transient('ipsvp_traffic_sync_' . $order_id);
        $fresh = $this->db->get_order($order_id);
        if ($payment_approved) {
            $remote = $this->api->update_user_status_for_order($fresh, 'active');
            if (is_wp_error($remote)) {
                $this->db->update_order($order_id, array('status' => 'awaiting_assignment', 'admin_note' => 'یوزر متصل شد اما فعال‌سازی پنل خطا داد: ' . $remote->get_error_message()));
                $this->order_detail_redirect($order_id, 'یوزر پیدا و متصل شد، اما فعال‌سازی آن در پنل خطا داد: ' . $remote->get_error_message(), 'error');
            }
            $this->db->update_order($order_id, array('status' => 'active', 'pg_status' => (string) $remote['pg_status'], 'admin_note' => ''));
            $fresh = $this->db->get_order($order_id);
            $active_snapshot = $this->api->user_snapshot($fresh->pg_username, $fresh->pg_user_id, $fresh);
            if (!empty($active_snapshot['live'])) {
                $snapshot = $active_snapshot;
            }
        }
        $fresh = $this->db->apply_order_lifecycle_snapshot($fresh, $snapshot);
        if ($payment_approved) {
            $imported = IPSVP_Bot_API::import_site_order($fresh);
            if (is_wp_error($imported)) {
                $this->db->add_log('warning', 'bot_import_dedicated_order', $imported->get_error_message(), array('order_id' => $order_id), $fresh->phone, $order_id, 0, $fresh->user_id);
            }
            $this->db->create_user_notification((int) $fresh->user_id, (string) $fresh->phone, 'سرویس اختصاصی فعال شد', 'یوزر پنل به سفارش شما متصل شد و اطلاعات سرویس آماده مشاهده است.', 'order', $order_id);
            do_action('ips_config_order_approved', $order_id, (int) $fresh->user_id, $fresh);
        }
        $this->order_detail_redirect($order_id, 'یوزر پنل با موفقیت متصل و اطلاعات سرویس دریافت شد.');
    }

    private function update_order_status()
    {
        $order_id = isset($_POST['order_id']) ? (int) $_POST['order_id'] : 0;
        $status = isset($_POST['order_status']) ? sanitize_key(wp_unslash($_POST['order_status'])) : '';
        $note = isset($_POST['admin_note']) ? sanitize_textarea_field(wp_unslash($_POST['admin_note'])) : '';
        $allowed = array('active','on_hold','disabled','volume_finished','time_finished','cancelled');
        $order = $this->db->get_order($order_id);
        if (!$order || !in_array($status, $allowed, true)) {
            $this->order_detail_redirect($order_id, 'سفارش یا وضعیت انتخاب‌شده معتبر نیست.', 'error');
        }
        if (!empty($order->pg_username) || !empty($order->pg_user_id)) {
            $remote = $this->api->update_user_status_for_order($order, $status);
            if (is_wp_error($remote)) {
                $this->order_detail_redirect($order_id, 'وضعیت ذخیره نشد؛ بروزرسانی پنل خطا داد: ' . $remote->get_error_message(), 'error');
            }
            $pg_status = (string) $remote['pg_status'];
        } else {
            $pg_status = '';
        }
        $data = array('status' => $status, 'admin_note' => $note);
        if ($pg_status !== '') { $data['pg_status'] = $pg_status; }
        if (in_array($status, array('volume_finished','time_finished'), true)) {
            $data['service_ended_at'] = !empty($order->service_ended_at) ? $order->service_ended_at : $this->db->now();
            $data['cancelled_at'] = null;
        } elseif ($status === 'cancelled') {
            $data['service_ended_at'] = !empty($order->service_ended_at) ? $order->service_ended_at : $this->db->now();
            $data['cancelled_at'] = $this->db->now();
        } else {
            $data['service_ended_at'] = null;
            $data['cancelled_at'] = null;
        }
        if (IPSVP_Sanaei_API::is_order($order) && !empty($remote['raw'])) {
            $data['pg_response'] = wp_json_encode($remote['raw'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $data['pg_synced_at'] = $this->db->now();
        }
        $confirmed = 0;
        if ($this->db->order_service_type($order) === 'dedicated' && in_array($status, array('active', 'on_hold'), true)) {
            $confirmed = IPSVP_Receipt_Manager::confirm_dedicated_payment($order, $data, $this->db);
            if (is_wp_error($confirmed)) { $this->order_detail_redirect($order_id, 'وضعیت پنل تغییر کرد اما ثبت سفارش و رسید ناموفق بود: ' . $confirmed->get_error_message(), 'error'); }
        } elseif ($this->db->update_order($order_id, $data) === false) {
            $this->order_detail_redirect($order_id, 'ذخیره وضعیت سفارش ناموفق بود.', 'error');
        }
        delete_transient('ipsvp_traffic_sync_' . $order_id);
        $this->db->create_user_notification((int) $order->user_id, (string) $order->phone, 'تغییر وضعیت سرویس', 'وضعیت سفارش ' . $order->order_code . ' به «' . $this->db->status_label($status) . '» تغییر کرد.', 'order', $order_id);
        $message = (!empty($order->pg_username) || !empty($order->pg_user_id))
            ? 'وضعیت سفارش و کاربر پنل بروزرسانی شد.'
            : 'وضعیت سفارش بروزرسانی شد؛ هنوز کاربری از پنل به این سفارش متصل نیست.';
        if ($confirmed > 0) { $message .= ' رسید خرید اولیهٔ سفارش هم تایید شد.'; }
        $this->order_detail_redirect($order_id, $message);
    }

    private function admin_disconnect_bot_link()
    {
        $user_id = isset($_POST['user_id']) ? (int) $_POST['user_id'] : 0;
        $user = $this->db->get_user_by_id($user_id);
        if (!$user) {
            $this->redirect_notice('ipsvp-users', 'کاربر پیدا نشد.', 'error');
        }
        if (!empty($user->bot_tel_id) || !empty($user->phone)) {
            $remote = IPSVP_Bot_API::disconnect_link($user->bot_tel_id, $user->phone);
            if (is_wp_error($remote)) {
                $this->db->add_log('warning', 'bot_disconnect_link', $remote->get_error_message(), array('user_id' => $user_id), $user->phone, 0, 0, $user_id);
            }
        }
        $this->db->disconnect_bot_link($user_id);
        wp_safe_redirect(add_query_arg(array('page' => 'ipsvp-users', 'view' => $user_id, 'ipsvp_tab' => 'account', 'ipsvp_msg' => rawurlencode('اتصال سایت و ربات برای این کاربر قطع شد.'), 'ipsvp_type' => 'success'), admin_url('admin.php')));
        exit;
    }

    private function admin_wallet_adjust()
    {
        $user_id = isset($_POST['user_id']) ? (int) $_POST['user_id'] : 0;
        $direction = isset($_POST['direction']) && sanitize_key($_POST['direction']) === 'debit' ? 'debit' : 'credit';
        $amount = isset($_POST['amount']) ? (int) str_replace(array(',', '٬', ' '), '', wp_unslash($_POST['amount'])) : 0;
        $note = isset($_POST['note']) ? sanitize_textarea_field(wp_unslash($_POST['note'])) : '';
        $user = $this->db->get_user_by_id($user_id);
        if (!$user) {
            $this->redirect_notice('ipsvp-users', 'کاربر پیدا نشد.', 'error');
        }
        if ($amount < 1000) {
            $this->redirect_notice('ipsvp-users', 'مبلغ باید حداقل ۱۰۰۰ تومان باشد.', 'error');
        }
        $adjusted = $this->db->admin_adjust_wallet($user_id, $direction, $amount, $note, !empty($user->bot_tel_id) ? 'remote' : 'local');
        if (is_wp_error($adjusted)) {
            $this->redirect_notice('ipsvp-users', $adjusted->get_error_message(), 'error');
        }
        if (!empty($user->bot_tel_id)) {
            $remote = $direction === 'debit'
                ? IPSVP_Bot_API::debit_wallet($user->bot_tel_id, $amount, 'ADMIN-' . (int) $adjusted->id, $user->phone)
                : IPSVP_Bot_API::credit_wallet($user->bot_tel_id, $amount, (int) $adjusted->id, $user->phone);
            if (is_wp_error($remote) || empty($remote['ok'])) {
                $remote_message = is_wp_error($remote) ? $remote->get_error_message() : (isset($remote['message']) ? $remote['message'] : 'خطا در تغییر کیف پول ربات.');
                global $wpdb;
                $t = $this->db->tables();
                $wpdb->update($t['receipts'], array(
                    'status' => 'failed',
                    'admin_note' => trim($note . "\nخطای همگام سازی ربات: " . $remote_message),
                    'reviewed_at' => $this->db->now(),
                ), array('id' => (int) $adjusted->id));
                $this->redirect_notice('ipsvp-users', $remote_message, 'error');
            }
            if (!$this->db->confirm_admin_wallet_adjustment((int) $adjusted->id)) {
                $this->redirect_notice('ipsvp-users', 'تغییر کیف پول ربات انجام شد اما ثبت تأیید ناموفق بود؛ تراکنش را بررسی کنید و دوباره شارژ نکنید.', 'error');
            }
        }
        $msg = $direction === 'debit' ? 'مبلغ از کیف پول کاربر کسر شد.' : 'کیف پول کاربر شارژ شد.';
        wp_safe_redirect(add_query_arg(array('page' => 'ipsvp-users', 'view' => $user_id, 'ipsvp_tab' => 'wallet', 'ipsvp_msg' => rawurlencode($msg), 'ipsvp_type' => 'success'), admin_url('admin.php')));
        exit;
    }

    private function approve_receipt($receipt_id)
    {
        $result = IPSVP_Receipt_Manager::approve($receipt_id, $this->db, $this->api);
        $this->redirect_notice('ipsvp-receipts', $result['message'], $result['type']);
    }

    private function reject_receipt($receipt_id)
    {
        $result = IPSVP_Receipt_Manager::reject($receipt_id, $this->db);
        $this->redirect_notice('ipsvp-receipts', $result['message'], $result['type']);
    }

    private function group_name_by_id($id)
    {
        foreach ((array) get_option('ipsvp_pg_groups_cache', array()) as $g) {
            if ((int) $g['id'] === (int) $id) {
                return $g['name'];
            }
        }
        return '';
    }

    private function header($title)
    {
        wp_enqueue_style('ipsvp-admin');
        echo '<div class="wrap ipsvp-admin" dir="rtl"><h1>' . esc_html($title) . '</h1>';
        $this->notice();
    }

    private function footer()
    {
        echo '</div>';
    }

    public function dashboard()
    {
        global $wpdb;
        $t = $this->db->tables();
        $this->header('داشبورد فروش آی پی ثابت');
        $orders = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$t['orders']}");
        $pending = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$t['receipts']} WHERE status='pending'");
        $created = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$t['orders']} WHERE status IN ('created','active','on_hold')");
        $users = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$t['users']}");
        echo '<div class="ipsvp-cards">';
        $this->stat_card('کل سفارشات', $orders);
        $this->stat_card('رسیدهای در انتظار', $pending);
        $this->stat_card('سرویس‌های فعال / در انتظار اتصال', $created);
        $this->stat_card('کاربران', $users);
        echo '</div>';

        $this->render_dashboard_month_charts();

        $pending_receipts = $wpdb->get_results("SELECT r.*, o.order_code, p.title plan_title, c.name country_name, c.flag
            FROM {$t['receipts']} r
            LEFT JOIN {$t['orders']} o ON o.id=r.order_id
            LEFT JOIN {$t['plans']} p ON p.id=COALESCE(r.plan_id, o.plan_id)
            LEFT JOIN {$t['countries']} c ON c.id=o.country_id
            WHERE r.status='pending'
            ORDER BY r.id DESC LIMIT 10");
        echo '<div class="ipsvp-admin-dash-grid"><div><h2>۱۰ رسید در انتظار آخر</h2>';
        $this->table_open(array('کد سفارش','نوع','موبایل','پلن/کشور','مبلغ','تاریخ','عملیات'));
        foreach ($pending_receipts as $r) {
            $plan_country_label = trim((string) $r->plan_title . ' / ' . $this->render_country_label($r->flag, $r->country_name));
            echo '<tr><td>' . esc_html($r->order_code) . '</td><td>' . esc_html($this->db->status_label($r->type)) . '</td><td>' . esc_html($r->phone) . '</td><td>' . esc_html($plan_country_label) . '</td><td>' . esc_html(number_format_i18n($r->amount)) . ' تومان</td><td>' . esc_html($r->created_at) . '</td><td><a class="button" href="' . esc_url(admin_url('admin.php?page=ipsvp-receipts&s=' . rawurlencode($r->order_code))) . '">بررسی</a></td></tr>';
        }
        if (!$pending_receipts) {
            echo '<tr><td colspan="7">رسید در انتظاری وجود ندارد.</td></tr>';
        }
        $this->table_close();
        echo '</div><div><h2>۱۰ کاربر آخر</h2>';
        $recent_users = $wpdb->get_results("SELECT u.*, COUNT(DISTINCT o.id) total_orders FROM {$t['users']} u LEFT JOIN {$t['orders']} o ON o.user_id=u.id GROUP BY u.id ORDER BY u.id DESC LIMIT 10");
        $this->table_open(array('موبایل','وضعیت','سفارشات','ثبت نام','عملیات'));
        foreach ($recent_users as $u) {
            $status = !empty($u->is_blocked) ? '<span class="ipsvp-badge ipsvp-rejected">مسدود</span>' : '<span class="ipsvp-badge ipsvp-created">فعال</span>';
            echo '<tr><td>' . esc_html($u->phone) . '</td><td>' . $status . '</td><td>' . esc_html(number_format_i18n((int) $u->total_orders)) . '</td><td>' . esc_html($u->created_at) . '</td><td><a class="button" href="' . esc_url(admin_url('admin.php?page=ipsvp-users&view=' . (int) $u->id)) . '">جزییات</a></td></tr>';
        }
        if (!$recent_users) {
            echo '<tr><td colspan="5">کاربری ثبت نشده است.</td></tr>';
        }
        $this->table_close();
        echo '</div></div>';
        echo '<div class="ipsvp-admin-shortcodes-bottom"><strong>شورت کدها:</strong> خرید <code>[ips_config_shop]</code> | پنل کاربری <code>[ips_config_panel]</code> | فقط پلن ها <code>[ips_config_plans]</code> | کشورهای فعال <code>[ipsvp_active_countries]</code></div>';
        $this->footer();
    }

    private function stat_card($title, $value)
    {
        echo '<div class="ipsvp-card"><span>' . esc_html($title) . '</span><strong>' . esc_html(number_format_i18n($value)) . '</strong></div>';
    }

    private function dashboard_selected_range()
    {
        $range = isset($_GET['ipsvp_range']) ? sanitize_key(wp_unslash($_GET['ipsvp_range'])) : 'last30';
        if (!in_array($range, array('last30', 'month', 'all'), true)) {
            $range = 'last30';
        }
        return $range;
    }

    private function dashboard_selected_month()
    {
        $month = isset($_GET['ipsvp_month']) ? sanitize_text_field(wp_unslash($_GET['ipsvp_month'])) : '';
        if (!preg_match('/^\d{4}\-\d{2}$/', $month)) {
            $month = date('Y-m', current_time('timestamp'));
        }
        $time = strtotime($month . '-01 00:00:00');
        if (!$time) {
            $month = date('Y-m', current_time('timestamp'));
        }
        return $month;
    }

    private function dashboard_month_options($selected)
    {
        global $wpdb;
        $t = $this->db->tables();
        $options = array();
        $date_expr = "COALESCE(NULLIF(NULLIF(r.reviewed_at, ''), '0000-00-00 00:00:00'), NULLIF(NULLIF(o.approved_at, ''), '0000-00-00 00:00:00'), r.created_at)";
        $rows = $wpdb->get_col("SELECT DISTINCT period_key FROM (
            SELECT DATE_FORMAT(created_at, '%Y-%m') period_key FROM {$t['users']} WHERE created_at IS NOT NULL AND created_at <> ''
            UNION ALL
            SELECT DATE_FORMAT(COALESCE(NULLIF(NULLIF(r.reviewed_at, ''), '0000-00-00 00:00:00'), NULLIF(NULLIF(o.approved_at, ''), '0000-00-00 00:00:00'), r.created_at), '%Y-%m') period_key FROM {$t['receipts']} r LEFT JOIN {$t['orders']} o ON o.id = r.order_id WHERE LOWER(TRIM(r.status)) IN ('approved','paid','completed','confirmed','delivered','wallet_paid','crypto_paid','over-paid','over_paid') AND COALESCE(NULLIF(r.type,''),'new') IN ('new','renewal','bot_renewal','extra_volume','wallet_renewal','wallet_bot_renewal','wallet_extra_volume','proxyline_card','proxyline_crypto','proxyline_renewal_card','proxyline_renewal_crypto') AND (r.order_id IS NULL OR r.order_id=0 OR LOWER(TRIM(COALESCE(o.status,''))) IN ('created','active','on_hold','disabled','volume_finished','time_finished','cancelled','completed','confirmed','delivered'))
        ) x WHERE period_key IS NOT NULL AND period_key <> '' ORDER BY period_key DESC");

        foreach ((array) $rows as $row) {
            if (preg_match('/^\d{4}\-\d{2}$/', (string) $row)) {
                $options[] = (string) $row;
            }
        }

        $base = strtotime(date('Y-m-01 00:00:00', current_time('timestamp')));
        for ($i = 0; $i < 12; $i++) {
            $ts = strtotime('-' . $i . ' months', $base);
            if ($ts) {
                $options[] = date('Y-m', $ts);
            }
        }
        if (!in_array($selected, $options, true)) {
            array_unshift($options, $selected);
        }
        return array_values(array_unique($options));
    }

    private function dashboard_date_range($range, $month)
    {
        global $wpdb;
        $t = $this->db->tables();
        $today_ts = current_time('timestamp');
        $today = date('Y-m-d', $today_ts);

        if ($range === 'month') {
            $month_time = strtotime($month . '-01 00:00:00');
            if (!$month_time) {
                $month_time = $today_ts;
                $month = date('Y-m', $month_time);
            }
            $start = date('Y-m-01', $month_time);
            $end = date('Y-m-t', $month_time);
            if ($end > $today) {
                $end = $today;
            }
            return array('start' => $start, 'end' => $end, 'label' => $month, 'range' => 'month', 'group' => 'day');
        }

        if ($range === 'all') {
            $date_expr = "COALESCE(NULLIF(NULLIF(r.reviewed_at, ''), '0000-00-00 00:00:00'), NULLIF(NULLIF(o.approved_at, ''), '0000-00-00 00:00:00'), r.created_at)";
            $first_user = $wpdb->get_var("SELECT MIN(DATE(created_at)) FROM {$t['users']} WHERE created_at IS NOT NULL AND created_at <> ''");
            $first_sale = $wpdb->get_var("SELECT MIN(DATE({$date_expr})) FROM {$t['receipts']} r LEFT JOIN {$t['orders']} o ON o.id = r.order_id WHERE LOWER(TRIM(r.status)) IN ('approved','paid','completed','confirmed','delivered','wallet_paid','crypto_paid','over-paid','over_paid') AND COALESCE(NULLIF(r.type,''),'new') IN ('new','renewal','bot_renewal','extra_volume','wallet_renewal','wallet_bot_renewal','wallet_extra_volume','proxyline_card','proxyline_crypto','proxyline_renewal_card','proxyline_renewal_crypto') AND (r.order_id IS NULL OR r.order_id=0 OR LOWER(TRIM(COALESCE(o.status,''))) IN ('created','active','on_hold','disabled','volume_finished','time_finished','cancelled','completed','confirmed','delivered')) AND {$date_expr} IS NOT NULL AND {$date_expr} <> ''");
            $dates = array_filter(array($first_user, $first_sale));
            sort($dates);
            $start = !empty($dates) ? reset($dates) : date('Y-m-01', $today_ts);
            if (!preg_match('/^\d{4}\-\d{2}\-\d{2}$/', (string) $start)) {
                $start = date('Y-m-01', $today_ts);
            }
            return array('start' => $start, 'end' => $today, 'label' => 'همه داده ها به تفکیک ماه', 'range' => 'all', 'group' => 'month');
        }

        $start = date('Y-m-d', strtotime('-29 days', $today_ts));
        return array('start' => $start, 'end' => $today, 'label' => '۳۰ روز اخیر', 'range' => 'last30', 'group' => 'day');
    }

    private function dashboard_make_date_series($start, $end, $group = 'day')
    {
        $series = array();
        $start_ts = strtotime($start . ' 00:00:00');
        $end_ts = strtotime($end . ' 00:00:00');
        if (!$start_ts || !$end_ts || $start_ts > $end_ts) {
            $start_ts = $end_ts = current_time('timestamp');
        }

        if ($group === 'month') {
            $cursor = strtotime(date('Y-m-01 00:00:00', $start_ts));
            $last = strtotime(date('Y-m-01 00:00:00', $end_ts));
            while ($cursor <= $last) {
                $key = date('Y-m', $cursor);
                $series[$key] = array(
                    'label' => date('Y/m', $cursor),
                    'sales' => 0,
                    'payments' => 0,
                    'registrations' => 0,
                );
                $cursor = strtotime('+1 month', $cursor);
            }
            return $series;
        }

        for ($ts = $start_ts; $ts <= $end_ts; $ts = strtotime('+1 day', $ts)) {
            $key = date('Y-m-d', $ts);
            $today_key = date('Y-m-d', current_time('timestamp'));
            $series[$key] = array(
                'label' => ($key === $today_key ? 'امروز' : date('m/d', $ts)),
                'sales' => 0,
                'payments' => 0,
                'registrations' => 0,
            );
        }
        return $series;
    }


    private function dashboard_analytics_data($range, $month, $source = 'site')
    {
        global $wpdb;
        $t = $this->db->tables();
        $range_data = $this->dashboard_date_range($range, $month);
        $start = $range_data['start'];
        $end = $range_data['end'];
        $group = isset($range_data['group']) ? $range_data['group'] : 'day';
        $series = $this->dashboard_make_date_series($start, $end, $group);

        if ($source === 'bot') {
            $remote = IPSVP_Bot_API::admin_stats($range, $month, $start, $end, $group);
            if (!is_wp_error($remote) && !empty($remote['ok']) && !empty($remote['series']) && is_array($remote['series'])) {
                foreach ($remote['series'] as $period => $row) {
                    if (isset($series[$period])) {
                        $series[$period]['sales'] = (int) ($row['sales'] ?? ($row['revenue'] ?? 0));
                        $series[$period]['payments'] = (int) ($row['payments'] ?? ($row['orders'] ?? 0));
                        $series[$period]['registrations'] = (int) ($row['registrations'] ?? 0);
                    }
                }
            }
        } else {
            $date_expr = "COALESCE(NULLIF(NULLIF(r.reviewed_at, ''), '0000-00-00 00:00:00'), NULLIF(NULLIF(o.approved_at, ''), '0000-00-00 00:00:00'), r.created_at)";
            $period_expr = $group === 'month' ? "DATE_FORMAT({$date_expr}, '%Y-%m')" : "DATE({$date_expr})";
            $user_period_expr = $group === 'month' ? "DATE_FORMAT(created_at, '%Y-%m')" : "DATE(created_at)";
            $amount_expr = "CAST(REPLACE(REPLACE(REPLACE(COALESCE(r.amount,0), ',', ''), '٬', ''), ' ', '') AS UNSIGNED)";

            $sales_rows = $wpdb->get_results($wpdb->prepare(
                "SELECT {$period_expr} period_key, COALESCE(SUM({$amount_expr}),0) total_amount, COUNT(*) total_count
                 FROM {$t['receipts']} r
                 LEFT JOIN {$t['orders']} o ON o.id = r.order_id
                 WHERE LOWER(TRIM(r.status)) IN ('approved','paid','completed','confirmed','delivered','wallet_paid','crypto_paid','over-paid','over_paid')
                   AND COALESCE(NULLIF(r.type,''),'new') IN ('new','renewal','bot_renewal','extra_volume','wallet_renewal','wallet_bot_renewal','wallet_extra_volume','proxyline_card','proxyline_crypto','proxyline_renewal_card','proxyline_renewal_crypto')
                   AND (r.order_id IS NULL OR r.order_id=0 OR LOWER(TRIM(COALESCE(o.status,''))) IN ('created','active','on_hold','disabled','volume_finished','time_finished','cancelled','completed','confirmed','delivered'))
                   AND {$date_expr} IS NOT NULL AND {$date_expr} <> ''
                   AND DATE({$date_expr}) BETWEEN %s AND %s
                 GROUP BY {$period_expr}
                 ORDER BY {$period_expr} ASC",
                $start,
                $end
            ));
            foreach ((array) $sales_rows as $row) {
                $key = (string) $row->period_key;
                if (isset($series[$key])) {
                    $series[$key]['sales'] = (int) $row->total_amount;
                    $series[$key]['payments'] = (int) $row->total_count;
                }
            }

            $user_rows = $wpdb->get_results($wpdb->prepare(
                "SELECT {$user_period_expr} period_key, COUNT(*) total_count
                 FROM {$t['users']}
                 WHERE created_at IS NOT NULL AND created_at <> ''
                   AND DATE(created_at) BETWEEN %s AND %s
                 GROUP BY {$user_period_expr}
                 ORDER BY {$user_period_expr} ASC",
                $start,
                $end
            ));
            foreach ((array) $user_rows as $row) {
                $key = (string) $row->period_key;
                if (isset($series[$key])) {
                    $series[$key]['registrations'] = (int) $row->total_count;
                }
            }
        }

        $sales = array();
        $payments = array();
        $registrations = array();
        foreach ($series as $period => $row) {
            $sales[$period] = array('label' => $row['label'], 'value' => (int) $row['sales']);
            $payments[$period] = array('label' => $row['label'], 'value' => (int) $row['payments']);
            $registrations[$period] = array('label' => $row['label'], 'value' => (int) $row['registrations']);
        }

        return array(
            'range' => $range_data['range'],
            'group' => $group,
            'label' => $range_data['label'],
            'start' => $start,
            'end' => $end,
            'source' => $source,
            'sales' => $sales,
            'payments' => $payments,
            'registrations' => $registrations,
            'total_sales' => array_sum(wp_list_pluck($sales, 'value')),
            'total_payments' => array_sum(wp_list_pluck($payments, 'value')),
            'total_registrations' => array_sum(wp_list_pluck($registrations, 'value')),
        );
    }


    private function dashboard_selected_source()
    {
        $source = isset($_GET['ipsvp_report_source']) ? sanitize_key(wp_unslash($_GET['ipsvp_report_source'])) : 'site';
        return in_array($source, array('site','bot'), true) ? $source : 'site';
    }


    private function render_dashboard_month_charts()
    {
        $selected_range = $this->dashboard_selected_range();
        $selected_month = $this->dashboard_selected_month();
        $selected_source = $this->dashboard_selected_source();
        $data = $this->dashboard_analytics_data($selected_range, $selected_month, $selected_source);
        $options = $this->dashboard_month_options($selected_month);
        $avg_sale = $data['total_payments'] > 0 ? floor($data['total_sales'] / max(1, $data['total_payments'])) : 0;
        $source_label = $selected_source === 'bot' ? 'ربات تلگرام' : 'سایت وردپرس';

        echo '<div class="ipsvp-admin-analytics">';
        echo '<div class="ipsvp-admin-analytics-head">';
        echo '<div><h2>گزارش فروش و ثبت نام</h2><p>منبع گزارش قابل انتخاب است: سایت یا ربات. درآمد نقدی از رسیدهای تایید شده محاسبه می شود؛ پرداخت های انجام شده با کیف پول دوباره در درآمد حساب نمی شوند.</p></div>';
        echo '<form method="get" class="ipsvp-admin-month-filter">';
        echo '<input type="hidden" name="page" value="ipsvp">';
        echo '<label>منبع گزارش<select name="ipsvp_report_source">';
        echo '<option value="site" ' . selected($selected_source, 'site', false) . '>سایت</option>';
        echo '<option value="bot" ' . selected($selected_source, 'bot', false) . '>ربات</option>';
        echo '</select></label>';
        echo '<label>بازه گزارش<select name="ipsvp_range">';
        echo '<option value="last30" ' . selected($selected_range, 'last30', false) . '>۳۰ روز اخیر</option>';
        echo '<option value="month" ' . selected($selected_range, 'month', false) . '>یک ماه مشخص</option>';
        echo '<option value="all" ' . selected($selected_range, 'all', false) . '>همه داده ها / ماهانه</option>';
        echo '</select></label>';
        echo '<label>ماه<select name="ipsvp_month">';
        foreach ($options as $month) {
            echo '<option value="' . esc_attr($month) . '" ' . selected($selected_month, $month, false) . '>' . esc_html($month) . '</option>';
        }
        echo '</select></label><button class="button button-primary" type="submit">نمایش</button></form>';
        echo '</div>';

        echo '<div class="ipsvp-admin-analytics-cards">';
        echo '<div><span>منبع گزارش</span><strong>' . esc_html($source_label) . '</strong><small>انتخاب شده</small></div>';
        echo '<div><span>درآمد تایید شده</span><strong>' . esc_html(number_format_i18n($data['total_sales'])) . '</strong><small>تومان</small></div>';
        echo '<div><span>تراکنش تایید شده</span><strong>' . esc_html(number_format_i18n($data['total_payments'])) . '</strong><small>مورد</small></div>';
        echo '<div><span>ثبت نامی</span><strong>' . esc_html(number_format_i18n($data['total_registrations'])) . '</strong><small>کاربر</small></div>';
        echo '</div>';

        echo '<div class="ipsvp-admin-chart-meta">بازه نمایش: <strong>' . esc_html($data['label']) . '</strong> از <code>' . esc_html($data['start']) . '</code> تا <code>' . esc_html($data['end']) . '</code> | منبع: <strong>' . esc_html($source_label) . '</strong></div>';
        echo '<div class="ipsvp-admin-chart-grid">';
        $this->render_dashboard_bar_chart('درآمد تایید شده', $data['sales'], ' تومان', true);
        $this->render_dashboard_bar_chart('ثبت نامی ها', $data['registrations'], ' کاربر', false);
        echo '</div>';
        echo '</div>';
        $this->render_dashboard_auto_refresh_script();
    }

    private function render_dashboard_auto_refresh_script()
    {
        echo '<script>(function(){if(window.ipsvpDashAutoRefresh)return;window.ipsvpDashAutoRefresh=true;var busy=false;var tip=null;function ensureTip(){if(!tip){tip=document.createElement("div");tip.className="ipsvp-admin-chart-tooltip";document.body.appendChild(tip);}return tip;}function showTip(text,x,y){var t=ensureTip();t.textContent=text;t.style.display="block";var pad=14;var left=x+pad;var top=y+pad;var rect=t.getBoundingClientRect();if(left+rect.width>window.innerWidth-8){left=x-rect.width-pad;}if(top+rect.height>window.innerHeight-8){top=y-rect.height-pad;}t.style.left=Math.max(8,left)+"px";t.style.top=Math.max(8,top)+"px";}function hideTip(){if(tip){tip.style.display="none";}}document.addEventListener("mousemove",function(e){var el=e.target.closest&&e.target.closest(".ipsvp-svg-bar-group");if(el){showTip(el.getAttribute("data-ipsvp-tooltip")||"",e.clientX,e.clientY);}else{hideTip();}});document.addEventListener("mouseleave",hideTip);function refreshAnalytics(){if(busy||document.hidden)return;var current=document.querySelector(".ipsvp-admin-analytics");if(!current)return;busy=true;var url=new URL(window.location.href);url.searchParams.set("ipsvp_refresh",Date.now().toString());fetch(url.toString(),{credentials:"same-origin",cache:"no-store"}).then(function(r){return r.text();}).then(function(html){var doc=new DOMParser().parseFromString(html,"text/html");var fresh=doc.querySelector(".ipsvp-admin-analytics");if(fresh&&current.parentNode){current.replaceWith(fresh);}}).catch(function(){}).finally(function(){busy=false;});}setInterval(refreshAnalytics,15000);})();</script>';
    }

    private function compact_number($value)
    {
        $value = (int) $value;
        if ($value >= 1000000000) {
            return number_format_i18n(round($value / 1000000000, 1)) . 'B';
        }
        if ($value >= 1000000) {
            return number_format_i18n(round($value / 1000000, 1)) . 'M';
        }
        if ($value >= 1000) {
            return number_format_i18n(round($value / 1000, 1)) . 'K';
        }
        return number_format_i18n($value);
    }

    private function render_dashboard_bar_chart($title, $series, $suffix = '', $is_money = false)
    {
        $values = array();
        foreach ($series as $item) {
            $values[] = is_array($item) ? (int) $item['value'] : (int) $item;
        }
        $max = max(1, (int) max($values));
        $has_data = array_sum($values) > 0;
        $count = max(1, count($series));
        $view_width = 1200;
        $view_height = 360;
        $chart_top = 38;
        $chart_bottom = 62;
        $chart_height = $view_height - $chart_top - $chart_bottom;
        $left_margin = 56;
        $right_margin = 38;
        $usable = $view_width - $left_margin - $right_margin;
        $step = $count > 1 ? ($usable / max(1, $count - 1)) : $usable;
        $bar_width = max(8, min(24, floor($step * 0.58)));
        $i = 0;
        $uid = 'ipsvpBarGrad' . wp_rand(1000, 999999);
        $shadow = 'ipsvpBarShadow' . wp_rand(1000, 999999);

        echo '<div class="ipsvp-admin-chart-box ipsvp-admin-svg-chart"><h3>' . esc_html($title) . '</h3>';
        echo '<div class="ipsvp-admin-svg-wrap">';
        echo '<svg viewBox="0 0 ' . esc_attr($view_width) . ' ' . esc_attr($view_height) . '" role="img" aria-label="' . esc_attr($title) . '">';
        echo '<defs><linearGradient id="' . esc_attr($uid) . '" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="#574EDA"/><stop offset="100%" stop-color="#8780FE"/></linearGradient><filter id="' . esc_attr($shadow) . '" x="-30%" y="-30%" width="160%" height="160%"><feDropShadow dx="0" dy="8" stdDeviation="7" flood-color="#5045F0" flood-opacity="0.20"/></filter></defs>';
        echo '<rect x="0" y="0" width="' . esc_attr($view_width) . '" height="' . esc_attr($view_height) . '" rx="24" fill="#fff"/>';
        for ($grid = 0; $grid <= 4; $grid++) {
            $y = $chart_top + ($chart_height / 4) * $grid;
            echo '<line x1="' . esc_attr($left_margin - 20) . '" y1="' . esc_attr($y) . '" x2="' . esc_attr($view_width - $right_margin + 12) . '" y2="' . esc_attr($y) . '" stroke="#EEF2F7" stroke-width="2"/>';
        }
        foreach ($series as $date => $item) {
            $value = is_array($item) ? (int) $item['value'] : (int) $item;
            $label = is_array($item) && isset($item['label']) ? (string) $item['label'] : (string) $date;
            $bar_h = $value > 0 ? max(8, round(($value / $max) * ($chart_height - 12))) : 4;
            $center = $count > 1 ? ($left_margin + ($i * $step)) : ($view_width / 2);
            $x = $center - ($bar_width / 2);
            $y = $chart_top + $chart_height - $bar_h;
            $full_value = number_format_i18n($value) . $suffix;
            $tooltip = $label . ' | ' . $full_value;
            $opacity = $value > 0 ? '1' : '.22';
            echo '<g class="ipsvp-svg-bar-group" data-ipsvp-tooltip="' . esc_attr($tooltip) . '" tabindex="0" aria-label="' . esc_attr($tooltip) . '">';
            echo '<rect class="ipsvp-svg-bar-hit" x="' . esc_attr($center - max(16, $step / 2)) . '" y="' . esc_attr($chart_top) . '" width="' . esc_attr(max(32, $step)) . '" height="' . esc_attr($chart_height + 28) . '" fill="transparent"/>';
            echo '<rect class="ipsvp-svg-bar" x="' . esc_attr($x) . '" y="' . esc_attr($y) . '" width="' . esc_attr($bar_width) . '" height="' . esc_attr($bar_h) . '" rx="' . esc_attr(min(10, floor($bar_width / 2))) . '" fill="url(#' . esc_attr($uid) . ')" opacity="' . esc_attr($opacity) . '" filter="url(#' . esc_attr($shadow) . ')"/>';
            if ($i % max(1, (int) ceil($count / 10)) === 0 || $i === $count - 1) {
                echo '<text x="' . esc_attr($center) . '" y="334" text-anchor="middle" font-size="13" font-weight="800" fill="#64748B">' . esc_html($label) . '</text>';
            }
            echo '</g>';
            $i++;
        }
        if (!$has_data) {
            echo '<text x="600" y="180" text-anchor="middle" font-size="22" font-weight="800" fill="#64748B">برای این بازه هنوز داده ای ثبت نشده است</text>';
        }
        echo '</svg>';
        echo '</div>';
        echo '</div>';
    }

    private function cached_pg_groups()
    {
        $groups = get_option('ipsvp_pg_groups_cache', array());
        return is_array($groups) ? $groups : array();
    }

    private function pg_group_name_by_id($group_id)
    {
        $group_id = (int) $group_id;
        if ($group_id <= 0) {
            return '';
        }
        foreach ($this->cached_pg_groups() as $group) {
            if (!is_array($group)) {
                continue;
            }
            $id = isset($group['id']) ? (int) $group['id'] : 0;
            if ($id === $group_id) {
                return isset($group['name']) ? sanitize_text_field($group['name']) : '';
            }
        }
        return '';
    }

    private function all_countries_group_field($settings)
    {
        $groups = $this->cached_pg_groups();
        $selected = !empty($settings['all_countries_group_id']) ? (int) $settings['all_countries_group_id'] : 0;
        echo '<label><span>گروه پاسارگارد برای فروش همه کشورها</span><select name="all_countries_group_id">';
        echo '<option value="0">انتخاب گروه مخصوص همه کشورها</option>';
        foreach ($groups as $group) {
            if (!is_array($group)) {
                continue;
            }
            $id = isset($group['id']) ? (int) $group['id'] : 0;
            $name = isset($group['name']) ? (string) $group['name'] : '';
            if ($id <= 0 || $name === '') {
                continue;
            }
            echo '<option value="' . esc_attr($id) . '" ' . selected($selected, $id, false) . '>' . esc_html($name . ' - ID: ' . $id) . '</option>';
        }
        echo '</select></label>';
        if (empty($groups)) {
            echo '<p class="description">برای نمایش لیست گروه‌ها، ابتدا در تب پاسارگارد روی «تست اتصال و دریافت گروه ها» بزنید.</p>';
        } else {
            echo '<p class="description">برای گزینه «همه کشورها»، به‌جای اتصال به همه گروه‌های کشورها، فقط همین گروه انتخاب‌شده در پاسارگارد برای کاربر ساخته می‌شود. مثلا گروه <code>all for vip</code>.</p>';
        }
    }

    private function save_sanaei_settings($settings)
    {
        foreach (array('sanaei_panel_url', 'sanaei_username', 'sanaei_password', 'sanaei_token') as $field) {
            if (!isset($_POST[$field]) || !is_string($_POST[$field])) { continue; }
            $value = (string) wp_unslash($_POST[$field]);
            if (in_array($field, array('sanaei_password', 'sanaei_token'), true)) {
                // An empty password field keeps the existing secret.
                if ($value !== '') { $settings[$field] = $value; }
            } else {
                $settings[$field] = $field === 'sanaei_panel_url' ? esc_url_raw(IPSVP_Sanaei_API::normalize_url($value)) : sanitize_text_field($value);
            }
        }
        if (!empty($_POST['sanaei_clear_token'])) { $settings['sanaei_token'] = ''; }
        $settings['sanaei_ssl_verify'] = !empty($_POST['sanaei_ssl_verify']) ? '1' : '0';
        return $settings;
    }

    public function settings_page()
    {
        $s = IPSVP_Settings::get();
        $this->header('تنظیمات');
        if (class_exists('IPSPM_Payment_Manager')) {
            echo '<div class="notice notice-info inline"><p>تنظیمات کارت به کارت، کیف پول و کریپتو به افزونه مستقل <a href="' . esc_url(admin_url('admin.php?page=ipspm-payments')) . '">مدیریت پرداخت‌ها</a> منتقل شده است.</p></div>';
        }
        echo '<form method="post" class="ipsvp-form ipsvp-settings-tabs-form">';
        wp_nonce_field('ipsvp_save_settings');
        echo '<input type="hidden" name="ipsvp_action" value="save_settings">';
        echo '<div class="ipsvp-settings-tabs ipsvp-settings-tabs-css" data-ipsvp-tabs>';
        echo '<input class="ipsvp-tab-radio" type="radio" name="ipsvp_settings_tab" id="ipsvp_tab_general" value="general" checked>';
        echo '<input class="ipsvp-tab-radio" type="radio" name="ipsvp_settings_tab" id="ipsvp_tab_pasarguard" value="pasarguard">';
        echo '<input class="ipsvp-tab-radio" type="radio" name="ipsvp_settings_tab" id="ipsvp_tab_otp" value="otp">';
        echo '<input class="ipsvp-tab-radio" type="radio" name="ipsvp_settings_tab" id="ipsvp_tab_security" value="security">';
        echo '<input class="ipsvp-tab-radio" type="radio" name="ipsvp_settings_tab" id="ipsvp_tab_links" value="links">';
        echo '<input class="ipsvp-tab-radio" type="radio" name="ipsvp_settings_tab" id="ipsvp_tab_telegram" value="telegram">';
        echo '<input class="ipsvp-tab-radio" type="radio" name="ipsvp_settings_tab" id="ipsvp_tab_warnings" value="warnings">';
        echo '<input class="ipsvp-tab-radio" type="radio" name="ipsvp_settings_tab" id="ipsvp_tab_announcement" value="announcement">';
        echo '<div class="ipsvp-tab-nav" aria-label="دسته‌بندی تنظیمات">';
        $settings_groups = array(
            'فروشگاه' => array('general' => 'تنظیمات عمومی', 'links' => 'لینک‌های سایت'),
            'اتصال سرویس' => array('pasarguard' => 'پاسارگارد و سنایی'),
            'ورود و امنیت' => array('otp' => 'ورود پیامکی', 'security' => 'کپچا و امنیت'),
            'ارتباط با کاربر' => array('telegram' => 'ربات تلگرام', 'warnings' => 'هشدارهای سرویس', 'announcement' => 'اطلاعیه پیشخوان'),
        );
        foreach ($settings_groups as $group => $tabs) {
            echo '<span class="ipsvp-settings-group">' . esc_html($group) . '</span>';
            foreach ($tabs as $key => $label) {
                echo '<label for="ipsvp_tab_' . esc_attr($key) . '" data-tab="' . esc_attr($key) . '">' . esc_html($label) . '</label>';
            }
        }
        echo '</div>';
        echo '<div class="ipsvp-tab-panels">';

        echo '<div class="ipsvp-tab-panel" data-panel="general"><h2>تنظیمات عمومی</h2>';
        echo '<p><a class="button" href="' . esc_url(admin_url('admin.php?page=ipsvp-loyalty')) . '">تنظیم سطح حساب و تخفیف پلکانی</a></p>';
        $this->field('brand_name', 'نام برند', $s['brand_name']);
        $this->field('order_prefix', 'پیشوند سفارش', $s['order_prefix']);
        echo '<div class="ipsvp-admin-callback-box"><h3>وضعیت فروش سایت</h3>';
        echo '<label class="ipsvp-check"><input type="checkbox" name="shared_sales_enabled" value="1" ' . checked(isset($s['shared_sales_enabled']) ? $s['shared_sales_enabled'] : '1', '1', false) . '> فروش آی پی ثابت اشتراکی فعال باشد</label>';
        echo '<label class="ipsvp-check"><input type="checkbox" name="dedicated_sales_enabled" value="1" ' . checked(isset($s['dedicated_sales_enabled']) ? $s['dedicated_sales_enabled'] : '1', '1', false) . '> فروش آی پی ثابت اختصاصی فعال باشد</label></div>';
        echo '<label class="ipsvp-check"><input type="checkbox" name="all_countries_enabled" value="1" ' . checked(isset($s['all_countries_enabled']) ? $s['all_countries_enabled'] : '1', '1', false) . '> گزینه خرید همه کشورها فعال باشد</label>';
        $this->field('all_countries_price_percent', 'درصد افزایش قیمت همه کشورها', isset($s['all_countries_price_percent']) ? $s['all_countries_price_percent'] : '30', 'مثلا 30', 'number');
        $this->field('extra_volume_price_per_gb', 'قیمت هر گیگ حجم اضافه', isset($s['extra_volume_price_per_gb']) ? $s['extra_volume_price_per_gb'] : '10000', '10000 تومان', 'number');
        $this->field('dedicated_extra_volume_price_per_gb', 'قیمت هر گیگ حجم اضافه اختصاصی', isset($s['dedicated_extra_volume_price_per_gb']) ? $s['dedicated_extra_volume_price_per_gb'] : '10000', '10000 تومان', 'number');
        $this->all_countries_group_field($s);
        $this->field('telegram_admin', 'تلگرام پشتیبانی', $s['telegram_admin'], '@ipsabet');
        $this->field('whatsapp_admin', 'واتساپ پشتیبانی', $s['whatsapp_admin']);
        echo '<label class="ipsvp-check"><input type="checkbox" name="ssl_verify" value="1" ' . checked($s['ssl_verify'], '1', false) . '> بررسی SSL فعال باشد</label>';
        echo '</div>';

        echo '<div class="ipsvp-tab-panel" data-panel="pasarguard"><h2>اتصال به پاسارگارد</h2>';
        $this->field('panel_url', 'آدرس پنل پاسارگارد', $s['panel_url'], 'https://panel.example.com:8000');
        $this->field('panel_username', 'یوزرنیم پنل', $s['panel_username']);
        $this->field('panel_password', 'پسورد پنل', $s['panel_password'], '', 'password');
        $this->field('client_type', 'نوع لینک/ساب', $s['client_type'], 'links یا v2ray');
        echo '<div class="ipsvp-tab-actions"><button class="button button-secondary" type="submit" name="ipsvp_secondary_action" value="test_connection">تست اتصال و دریافت گروه ها</button></div>';
        echo '<hr><h2>پنل سنایی — آی پی اختصاصی</h2><p class="description">آدرس کامل پنل همراه مسیر اختصاصی آن را وارد کنید. توکن API اولویت دارد؛ در نبود توکن، نام کاربری و رمز عبور استفاده می‌شود.</p>';
        $this->field('sanaei_panel_url', 'آدرس پنل سنایی', $s['sanaei_panel_url'], 'https://panel.example.com:2053/secret/');
        $this->field('sanaei_token', 'توکن API سنایی', '', !empty($s['sanaei_token']) ? 'ذخیره شده؛ خالی بگذارید تا حفظ شود' : 'API Token', 'password');
        echo '<label class="ipsvp-check"><input type="checkbox" name="sanaei_clear_token" value="1">حذف توکن ذخیره‌شده و استفاده از نام کاربری و رمز عبور</label>';
        $this->field('sanaei_username', 'نام کاربری سنایی', $s['sanaei_username']);
        $this->field('sanaei_password', 'رمز عبور سنایی', '', !empty($s['sanaei_password']) ? 'ذخیره شده؛ خالی بگذارید تا حفظ شود' : '', 'password');
        echo '<label class="ipsvp-check"><input type="checkbox" name="sanaei_ssl_verify" value="1" ' . checked($s['sanaei_ssl_verify'], '1', false) . '>بررسی گواهی SSL سنایی</label>';
        echo '<div class="ipsvp-tab-actions"><button class="button button-secondary" type="submit" name="ipsvp_secondary_action" value="test_sanaei_connection">ذخیره تنظیمات سنایی و تست اتصال</button></div>';

        echo '</div>';

        echo '<div class="ipsvp-tab-panel" data-panel="otp"><h2>ورود با کد یکبار مصرف</h2>';
        echo '<p class="description">با فعال شدن این بخش، فرم ورود پنل کاربری اول کد یکبار مصرف پیامکی ارسال می‌کند. ورود با رمز عبور برای کاربرانی که رمز دارند همچنان به عنوان مسیر جایگزین باقی می‌ماند.</p>';
        echo '<label class="ipsvp-check"><input type="checkbox" name="otp_login_enabled" value="1" ' . checked(isset($s['otp_login_enabled']) ? $s['otp_login_enabled'] : '0', '1', false) . '> ورود با کد یکبار مصرف فعال باشد</label>';
        $this->field('smsir_api_key', 'API Key پنل sms.ir', isset($s['smsir_api_key']) ? $s['smsir_api_key'] : '', 'کلید وب‌سرویس sms.ir', 'password');
        $this->field('smsir_template_id', 'Template ID قالب ارسال کد', isset($s['smsir_template_id']) ? $s['smsir_template_id'] : '', 'مثلا 123456', 'number');
        $this->field('smsir_code_param', 'نام پارامتر کد در قالب', isset($s['smsir_code_param']) ? $s['smsir_code_param'] : 'Code', 'Code');
        $this->field('otp_code_length', 'طول کد یکبار مصرف', isset($s['otp_code_length']) ? $s['otp_code_length'] : '6', '6', 'number');
        $this->field('otp_expire_minutes', 'اعتبار کد - دقیقه', isset($s['otp_expire_minutes']) ? $s['otp_expire_minutes'] : '5', '5', 'number');
        $this->field('otp_resend_seconds', 'فاصله مجاز ارسال مجدد - ثانیه', isset($s['otp_resend_seconds']) ? $s['otp_resend_seconds'] : '60', '60', 'number');
        echo '<div class="ipsvp-admin-note">برای sms.ir از endpoint <code>https://api.sms.ir/v1/send/verify</code> استفاده می‌شود. قالب پیامک باید یک متغیر برای کد داشته باشد؛ نام همان متغیر را در فیلد «نام پارامتر کد» وارد کنید.</div>';
        echo '</div>';

        echo '<div class="ipsvp-tab-panel" data-panel="security"><h2>امنیت ورود / کپچا</h2>';
        echo '<p class="description">کپچای عددی کاملاً روی همین سرور تولید می‌شود و به هیچ سرویس، تصویر، فونت یا CDN خارجی وابسته نیست.</p>';
        echo '<label class="ipsvp-check"><input type="checkbox" name="captcha_enabled" value="1" ' . checked(isset($s['captcha_enabled']) ? $s['captcha_enabled'] : '1', '1', false) . '> فعال‌سازی کپچای ورود</label>';
        $captcha_length = isset($s['captcha_length']) && (int) $s['captcha_length'] === 5 ? '5' : '4';
        echo '<label><span>طول کد کپچا</span><select name="captcha_length"><option value="4" ' . selected($captcha_length, '4', false) . '>۴ رقم</option><option value="5" ' . selected($captcha_length, '5', false) . '>۵ رقم</option></select></label>';
        $this->field('captcha_ttl_minutes', 'مدت اعتبار کپچا - دقیقه', isset($s['captcha_ttl_minutes']) ? $s['captcha_ttl_minutes'] : '10', '10', 'number');
        $this->field('captcha_max_attempts', 'تلاش ناموفق پیش از اجبار کد جدید', isset($s['captcha_max_attempts']) ? $s['captcha_max_attempts'] : '3', '3', 'number');
        echo '<div class="ipsvp-admin-callback-box"><h3>نمایش کپچا در</h3>';
        echo '<label class="ipsvp-check"><input type="checkbox" name="captcha_show_panel" value="1" ' . checked(isset($s['captcha_show_panel']) ? $s['captcha_show_panel'] : '1', '1', false) . '> ورود پنل کاربری</label>';
        echo '<label class="ipsvp-check"><input type="checkbox" name="captcha_show_config" value="1" ' . checked(isset($s['captcha_show_config']) ? $s['captcha_show_config'] : '1', '1', false) . '> ورود خرید کانفیگ</label>';
        echo '<label class="ipsvp-check"><input type="checkbox" name="captcha_show_proxy" value="1" ' . checked(isset($s['captcha_show_proxy']) ? $s['captcha_show_proxy'] : '1', '1', false) . '> ورود خرید پروکسی</label>';
        echo '<label class="ipsvp-check"><input type="checkbox" name="captcha_show_otp" value="1" ' . checked(isset($s['captcha_show_otp']) ? $s['captcha_show_otp'] : '1', '1', false) . '> مرحله اول ورود، پیش از ارسال OTP</label>';
        echo '</div>';
        $captcha_color_mode = isset($s['captcha_color_mode']) ? $s['captcha_color_mode'] : 'auto';
        echo '<label><span>رنگ‌بندی کپچا</span><select name="captcha_color_mode"><option value="auto" ' . selected($captcha_color_mode, 'auto', false) . '>خودکار بر اساس دارک/لایت</option><option value="light" ' . selected($captcha_color_mode, 'light', false) . '>روشن</option><option value="dark" ' . selected($captcha_color_mode, 'dark', false) . '>تیره</option></select></label>';
        $captcha_test = IPSVP_Captcha_Service::create();
        echo '<div class="ipsvp-admin-callback-box ipsvp-admin-captcha-preview"><h3>تست تولید کپچا</h3><div class="ips-captcha-box" data-ipsvp-captcha data-captcha-test="1" data-color-mode="' . esc_attr($captcha_color_mode) . '"><input type="hidden" value="' . esc_attr($captcha_test['token']) . '" data-ipsvp-captcha-token><div class="ips-captcha-image-wrap"><button type="button" class="ips-captcha-refresh" data-ipsvp-captcha-refresh><span aria-hidden="true">↻</span><span class="ips-captcha-refresh-text">کد جدید</span></button><img src="' . esc_url($captcha_test['image_url']) . '" alt="نمونه کد امنیتی" class="ips-captcha-image" width="152" height="54" data-ipsvp-captcha-image></div><div class="ips-captcha-error" role="alert" data-ipsvp-captcha-error></div></div><p class="description">برای بررسی endpoint تصویر و تولید token جدید، روی «کد جدید» بزنید.</p></div>';
        echo '</div>';


        echo '<div class="ipsvp-tab-panel" data-panel="links"><h2>لینک های مهم سایت</h2>';
        $this->field('buy_url', 'لینک صفحه خرید', $s['buy_url'], 'https://ip-sabet.me/buy');
        $this->field('dashboard_url', 'لینک داشبورد کاربر', $s['dashboard_url'], 'https://ip-sabet.me/dashboard');
        echo '</div>';

        echo '<div class="ipsvp-tab-panel" data-panel="telegram"><h2>ارسال رسیدها به ربات تلگرام</h2>';
        echo '<p class="description">تلگرام برای هر ربات فقط یک وبهوک قبول می کند. اگر همین ربات قبلا روی سیستم اصلی شما فعال است، حالت «حفظ وبهوک ربات اصلی» را انتخاب کنید تا آدرس فعلی ربات تغییر نکند.</p>';
        $this->field('telegram_bot_token', 'توکن ربات تلگرام', $s['telegram_bot_token'], '123456:ABC...', 'password');
        $this->field('telegram_chat_id', 'Chat ID ادمین یا گروه', $s['telegram_chat_id'], '123456789 یا -100...');
        $mode = isset($s['telegram_webhook_mode']) ? $s['telegram_webhook_mode'] : 'existing';
        echo '<label><span>حالت وبهوک ربات</span><select name="telegram_webhook_mode"><option value="existing" ' . selected($mode, 'existing', false) . '>حفظ وبهوک ربات اصلی / پروکسی</option><option value="wordpress" ' . selected($mode, 'wordpress', false) . '>وبهوک مستقیم وردپرس، فقط برای ربات جداگانه</option></select></label>';
        $this->field('telegram_existing_webhook_url', 'آدرس وبهوک فعلی ربات اصلی', isset($s['telegram_existing_webhook_url']) ? $s['telegram_existing_webhook_url'] : '', 'https://bot.ipsabet.app/api/telegram-webhook');
        $this->field('telegram_webhook_secret', 'کد امنیتی وبهوک وردپرس', $s['telegram_webhook_secret']);
        echo '<div class="ipsvp-admin-note"><strong>آدرس پردازش تایید/رد در وردپرس:</strong><br><code>' . esc_html(IPSVP_Telegram_Service::webhook_url()) . '</code><p>در حالت حفظ وبهوک ربات اصلی، دکمه ثبت وبهوک، آدرس فعلی ربات را دوباره روی تلگرام ثبت می کند و وبهوک ربات را خراب نمی کند. برای کار کردن دکمه های تایید/رد، ربات اصلی باید فقط callback هایی که <code>type=ipsvp</code> دارند را به آدرس پردازش وردپرس فوروارد کند.</p></div>';
        echo '<label class="ipsvp-check"><input type="checkbox" name="telegram_notifications" value="1" ' . checked($s['telegram_notifications'], '1', false) . '> ارسال رسید کارت به کارت به تلگرام فعال باشد</label>';
        echo '<div class="ipsvp-tab-actions"><button class="button button-secondary" type="submit" name="ipsvp_secondary_action" value="set_telegram_webhook">ثبت/حفظ وبهوک تلگرام</button></div>';
        echo '</div>';

        echo '<div class="ipsvp-tab-panel" data-panel="warnings"><h2>هشدارهای سرویس</h2>';
        echo '<p class="description">این هشدارها بعد از ورود کاربر به حساب کاربری نمایش داده می‌شوند و کاربر را به جزئیات همان سفارش برای تمدید یا خرید حجم اضافه هدایت می‌کنند.</p>';
        echo '<label class="ipsvp-check"><input type="checkbox" name="service_warnings_enabled" value="1" ' . checked(isset($s['service_warnings_enabled']) ? $s['service_warnings_enabled'] : '1', '1', false) . '> فعال‌سازی هشدارهای حساب کاربری</label>';
        echo '<div class="ipsvp-admin-callback-box"><h3>هشدار نزدیک پایان زمان</h3>';
        echo '<label class="ipsvp-check"><input type="checkbox" name="warning_expiry_enabled" value="1" ' . checked(isset($s['warning_expiry_enabled']) ? $s['warning_expiry_enabled'] : '1', '1', false) . '> هشدار پایان زمان فعال باشد</label>';
        $this->field('warning_expiry_days', 'تعداد روز مانده تا انقضا', isset($s['warning_expiry_days']) ? $s['warning_expiry_days'] : '1', '1', 'number');
        $this->field('warning_expiry_title', 'عنوان popup پایان زمان', isset($s['warning_expiry_title']) ? $s['warning_expiry_title'] : '', 'تمدید سرویس نزدیک است');
        $this->textarea_field('warning_expiry_message', 'متن popup پایان زمان', isset($s['warning_expiry_message']) ? $s['warning_expiry_message'] : '', 'اعتبار سرویس شما رو به پایان است.');
        $this->field('warning_expiry_button', 'متن دکمه تمدید', isset($s['warning_expiry_button']) ? $s['warning_expiry_button'] : '', 'تمدید سرویس');
        echo '</div>';
        echo '<div class="ipsvp-admin-callback-box"><h3>هشدار نزدیک پایان حجم</h3>';
        echo '<label class="ipsvp-check"><input type="checkbox" name="warning_traffic_enabled" value="1" ' . checked(isset($s['warning_traffic_enabled']) ? $s['warning_traffic_enabled'] : '1', '1', false) . '> هشدار حجم فعال باشد</label>';
        $this->field('warning_traffic_gb', 'آستانه حجم باقی‌مانده - GB', isset($s['warning_traffic_gb']) ? $s['warning_traffic_gb'] : '1', '1', 'number');
        $this->field('warning_traffic_title', 'عنوان popup حجم', isset($s['warning_traffic_title']) ? $s['warning_traffic_title'] : '', 'حجم سرویس رو به پایان است');
        $this->textarea_field('warning_traffic_message', 'متن popup حجم', isset($s['warning_traffic_message']) ? $s['warning_traffic_message'] : '', 'حجم باقی‌مانده سرویس شما کم است.');
        $this->field('warning_traffic_button', 'متن دکمه خرید حجم اضافه', isset($s['warning_traffic_button']) ? $s['warning_traffic_button'] : '', 'خرید حجم اضافه');
        echo '</div>';
        echo '<div class="ipsvp-admin-callback-box"><h3>کنترل نمایش popup</h3>';
        $repeat_mode = isset($s['warning_popup_repeat_mode']) ? $s['warning_popup_repeat_mode'] : 'daily';
        echo '<label><span>تکرار نمایش popup</span><select name="warning_popup_repeat_mode">';
        echo '<option value="session" ' . selected($repeat_mode, 'session', false) . '>یک بار در هر ورود</option>';
        echo '<option value="daily" ' . selected($repeat_mode, 'daily', false) . '>یک بار در روز برای هر سفارش</option>';
        echo '<option value="always" ' . selected($repeat_mode, 'always', false) . '>همیشه تا رفع وضعیت</option>';
        echo '</select></label>';
        echo '<label class="ipsvp-check"><input type="checkbox" name="warning_once_after_login" value="1" ' . checked(isset($s['warning_once_after_login']) ? $s['warning_once_after_login'] : '0', '1', false) . '> نمایش پاپ‌آپ فقط یک بار بعد از ورود</label>';
        echo '<p class="description">اگر فعال باشد، هشدارهای تمدید و حجم فقط یک بار در همان نشست ورود کاربر نمایش داده می‌شوند و با جابه‌جایی بین تب‌ها یا refresh دوباره باز نمی‌شوند.</p>';
        echo '<label class="ipsvp-check"><input type="checkbox" name="warning_combine_enabled" value="1" ' . checked(isset($s['warning_combine_enabled']) ? $s['warning_combine_enabled'] : '1', '1', false) . '> هشدار زمان و حجم یک سفارش در یک کارت ترکیب شود</label>';
        echo '</div></div>';

        echo '<div class="ipsvp-tab-panel" data-panel="announcement"><h2>ارسال پیام یا اطلاعیه</h2>';
        echo '<p class="description">این متن در پیشخوان پنل کاربری نمایش داده می شود. برای حذف اطلاعیه، فیلد را خالی ذخیره کنید.</p>';
        $this->textarea_field('announcement_text', 'متن اطلاعیه پیشخوان کاربر', isset($s['announcement_text']) ? $s['announcement_text'] : '', 'مثلا: کاربران عزیز، قبل از تمدید سرویس وضعیت لوکیشن ها را بررسی کنید.');
        echo '</div>';

        echo '</div>';
        echo '</div>';
        echo '<div class="ipsvp-settings-save">';
        submit_button('ذخیره تنظیمات');
        echo '</div>';
        echo '</form>';
        echo '<script>(function(){document.querySelectorAll("[data-ipsvp-tabs]").forEach(function(w){var btns=w.querySelectorAll("[data-tab]");var panels=w.querySelectorAll("[data-panel]");btns.forEach(function(b){b.addEventListener("click",function(){btns.forEach(function(x){x.classList.remove("is-active")});panels.forEach(function(p){p.classList.remove("is-active")});b.classList.add("is-active");var p=w.querySelector("[data-panel=\\\""+b.getAttribute("data-tab")+"\\\"]");if(p){p.classList.add("is-active")}})})})})();</script>';
        $this->footer();
    }


    private function field($name, $label, $value, $placeholder = '', $type = 'text')
    {
        echo '<label class="ipsvp-setting-field"><span>' . esc_html($label) . '</span><input type="' . esc_attr($type) . '" name="' . esc_attr($name) . '" value="' . esc_attr($value) . '" placeholder="' . esc_attr($placeholder) . '"></label>';
    }

    private function textarea_field($name, $label, $value, $placeholder = '')
    {
        echo '<label class="ipsvp-setting-field"><span>' . esc_html($label) . '</span><textarea class="ipsvp-admin-textarea" name="' . esc_attr($name) . '" rows="6" placeholder="' . esc_attr($placeholder) . '">' . esc_textarea($value) . '</textarea></label>';
    }

    public function plans_page()
    {
        global $wpdb;
        $t = $this->db->tables();
        $service_type = $this->db->normalize_service_type(isset($_GET['service_type']) ? wp_unslash($_GET['service_type']) : 'shared');
        $edit = null;
        if (!empty($_GET['edit'])) {
            $edit = $this->db->get_plan((int) $_GET['edit']);
            if ($edit) { $service_type = $this->db->normalize_service_type($edit->service_type ?? 'shared'); }
        }
        list($paged, $offset, $per_page) = $this->pagination_vars(10);
        $total_plans = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['plans']} WHERE service_type=%s", $service_type));
        $plans = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['plans']} WHERE service_type=%s ORDER BY sort_order ASC, id DESC LIMIT %d OFFSET %d", $service_type, $per_page, $offset));
        $this->header('پلن ها');
        echo '<div class="ipsvp-admin-report-tabs"><a class="button ' . ($service_type === 'shared' ? 'button-primary' : '') . '" href="' . esc_url(admin_url('admin.php?page=ipsvp-plans&service_type=shared')) . '">آی پی ثابت اشتراکی</a> ';
        echo '<a class="button ' . ($service_type === 'dedicated' ? 'button-primary' : '') . '" href="' . esc_url(admin_url('admin.php?page=ipsvp-plans&service_type=dedicated')) . '">آی پی ثابت اختصاصی</a></div>';
        echo '<div class="ipsvp-grid"><form method="post" class="ipsvp-form">';
        wp_nonce_field('ipsvp_save_plan');
        echo '<input type="hidden" name="ipsvp_action" value="save_plan"><input type="hidden" name="service_type" value="' . esc_attr($service_type) . '"><input type="hidden" name="id" value="' . esc_attr($edit ? $edit->id : 0) . '">';
        echo '<div class="ipsvp-admin-note">نوع سرویس: <strong>' . ($service_type === 'dedicated' ? 'آی پی ثابت اختصاصی' : 'آی پی ثابت اشتراکی') . '</strong></div>';
        $this->field('title', 'عنوان پلن', $edit ? $edit->title : '', '۳۰ گیگ ۳۰ روزه');
        $this->field('gb', 'حجم GB', $edit ? $edit->gb : '30', '', 'number');
        $this->field('days', 'مدت روز', $edit ? $edit->days : '30', '', 'number');
        $this->field('price', 'قیمت تومان', $edit ? $edit->price : '', '', 'number');
        $this->field('sale_price', 'قیمت تخفیفی تومان', $edit ? $edit->sale_price : '', '', 'number');
        $this->field('discount_label', 'متن برچسب تخفیف', $edit && isset($edit->discount_label) ? $edit->discount_label : '', 'مثلا: ۱۵ درصد تخفیف - اگر خالی باشد خودکار محاسبه می شود');
        $this->field('card_icon', 'آیکن کارت پلن', $edit && isset($edit->card_icon) ? $edit->card_icon : '', 'خالی بگذارید تا خودکار مثل سایت نمایش داده شود. یا کلید/آدرس تصویر بزنید: almas, 3month, 6month, 1year');
        $this->textarea_field('features', 'ویژگی های کارت پلن', $edit && isset($edit->features) ? $edit->features : '', 'هر ویژگی را در یک خط بنویسید. اگر خالی باشد ویژگی های پیشفرض نمایش داده می شود.');
        $this->field('sort_order', 'ترتیب نمایش', $edit ? $edit->sort_order : '0', '', 'number');
        echo '<label class="ipsvp-check"><input type="checkbox" name="status" value="1" ' . checked(!$edit || $edit->status, true, false) . '> فعال</label>';
        submit_button($edit ? 'ویرایش پلن' : 'افزودن پلن');
        echo '</form><div>';
        $this->table_open(array('ID','عنوان','حجم','روز','قیمت','وضعیت','عملیات'));
        foreach ($plans as $p) {
            $edit_url = admin_url('admin.php?page=ipsvp-plans&service_type=' . $service_type . '&edit=' . $p->id);
            $del_url = wp_nonce_url(admin_url('admin.php?page=ipsvp-plans&ipsvp_action=delete_plan&id=' . $p->id), 'ipsvp_delete_plan');
            echo '<tr><td>' . esc_html($p->id) . '</td><td>' . esc_html($p->title) . '</td><td>' . esc_html($p->gb) . '</td><td>' . esc_html($p->days) . '</td><td>' . esc_html(number_format_i18n($this->db->final_price($p))) . '</td><td>' . ($p->status ? 'فعال' : 'غیرفعال') . '</td><td><a href="' . esc_url($edit_url) . '">ویرایش</a> | <a href="' . esc_url($del_url) . '" onclick="return confirm(\'حذف شود؟\')">حذف</a></td></tr>';
        }
        $this->table_close();
        $this->render_admin_pagination('ipsvp-plans', $total_plans, $per_page, array('service_type' => $service_type));
        echo '</div></div>';
        $this->footer();
    }

    public function countries_page()
    {
        global $wpdb;
        $t = $this->db->tables();
        $service_type = $this->db->normalize_service_type(isset($_GET['service_type']) ? wp_unslash($_GET['service_type']) : 'shared');
        $edit = null;
        if (!empty($_GET['edit'])) {
            $edit = $this->db->get_country((int) $_GET['edit']);
            if ($edit) { $service_type = $this->db->normalize_service_type($edit->service_type ?? 'shared'); }
        }
        list($paged, $offset, $per_page) = $this->pagination_vars(10);
        $total_countries = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t['countries']} WHERE service_type=%s", $service_type));
        $countries = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['countries']} WHERE service_type=%s ORDER BY sort_order ASC, id DESC LIMIT %d OFFSET %d", $service_type, $per_page, $offset));
        $groups = (array) get_option('ipsvp_pg_groups_cache', array());
        $this->header('کشورها');
        echo '<div class="ipsvp-admin-report-tabs"><a class="button ' . ($service_type === 'shared' ? 'button-primary' : '') . '" href="' . esc_url(admin_url('admin.php?page=ipsvp-countries&service_type=shared')) . '">کشورهای اشتراکی</a> ';
        echo '<a class="button ' . ($service_type === 'dedicated' ? 'button-primary' : '') . '" href="' . esc_url(admin_url('admin.php?page=ipsvp-countries&service_type=dedicated')) . '">کشورهای اختصاصی</a></div>';
        if ($service_type === 'shared') {
        echo '<form method="post" class="ipsvp-admin-inline-form">';
        wp_nonce_field('ipsvp_sync_groups');
        echo '<input type="hidden" name="ipsvp_action" value="sync_groups">';
        submit_button('دریافت/بروزرسانی گروه های پاسارگارد', 'secondary', '', false);
        echo '</form>';
        }
        echo '<div class="ipsvp-grid"><form method="post" class="ipsvp-form">';
        wp_nonce_field('ipsvp_save_country');
        echo '<input type="hidden" name="ipsvp_action" value="save_country"><input type="hidden" name="service_type" value="' . esc_attr($service_type) . '"><input type="hidden" name="id" value="' . esc_attr($edit ? $edit->id : 0) . '">';
        $this->field('name', 'نام کشور', $edit ? $edit->name : '', 'آلمان');
        $this->field('flag', 'پرچم/ایموجی', $edit ? $edit->flag : '', '🇩🇪');
        if ($service_type === 'shared') {
        echo '<label><span>گروه پاسارگارد</span><select name="pg_group_id"><option value="0">انتخاب گروه</option>';
        foreach ($groups as $g) {
            echo '<option value="' . esc_attr($g['id']) . '" ' . selected($edit && (int) $edit->pg_group_id === (int) $g['id'], true, false) . '>' . esc_html($g['name'] . ' #' . $g['id']) . '</option>';
        }
        echo '</select></label>';
        } else {
            echo '<input type="hidden" name="pg_group_id" value="0"><div class="ipsvp-admin-note">در سرویس اختصاصی، کاربر از قبل در پاسارگارد یا سنایی ساخته می‌شود و از جزئیات سفارش به آن متصل خواهد شد؛ بنابراین انتخاب گروه لازم نیست.</div>';
        }
        $this->field('sort_order', 'ترتیب نمایش', $edit ? $edit->sort_order : '0', '', 'number');
        echo '<label class="ipsvp-check"><input type="checkbox" name="status" value="1" ' . checked(!$edit || $edit->status, true, false) . '> فعال</label>';
        submit_button($edit ? 'ویرایش کشور' : 'افزودن کشور');
        echo '</form><div>';
        $this->table_open(array('ID','کشور','گروه پاسارگارد','وضعیت','عملیات'));
        foreach ($countries as $c) {
            $edit_url = admin_url('admin.php?page=ipsvp-countries&service_type=' . $service_type . '&edit=' . $c->id);
            $del_url = wp_nonce_url(admin_url('admin.php?page=ipsvp-countries&ipsvp_action=delete_country&id=' . $c->id), 'ipsvp_delete_country');
            echo '<tr><td>' . esc_html($c->id) . '</td><td>' . esc_html($c->flag . ' ' . $c->name) . '</td><td>' . esc_html($c->pg_group_name . ' #' . $c->pg_group_id) . '</td><td>' . ($c->status ? 'فعال' : 'غیرفعال') . '</td><td><a href="' . esc_url($edit_url) . '">ویرایش</a> | <a href="' . esc_url($del_url) . '" onclick="return confirm(\'حذف شود؟\')">حذف</a></td></tr>';
        }
        $this->table_close();
        $this->render_admin_pagination('ipsvp-countries', $total_countries, $per_page, array('service_type' => $service_type));
        echo '</div></div>';
        $this->footer();
    }

    public function orders_page()
    {
        global $wpdb;
        $t = $this->db->tables();
        $this->header('سفارشات');
        if (!empty($_GET['view'])) {
            $this->order_detail((int) $_GET['view']);
            $this->footer();
            return;
        }
        $search = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
        $service_filter = isset($_GET['service_type']) ? sanitize_key(wp_unslash($_GET['service_type'])) : 'all';
        if (!in_array($service_filter, array('all','shared','dedicated'), true)) { $service_filter = 'all'; }
        echo '<div class="ipsvp-admin-report-tabs"><a class="button ' . ($service_filter === 'all' ? 'button-primary' : '') . '" href="' . esc_url(admin_url('admin.php?page=ipsvp-orders')) . '">همه سفارش‌ها</a> ';
        echo '<a class="button ' . ($service_filter === 'shared' ? 'button-primary' : '') . '" href="' . esc_url(admin_url('admin.php?page=ipsvp-orders&service_type=shared')) . '">اشتراکی</a> ';
        echo '<a class="button ' . ($service_filter === 'dedicated' ? 'button-primary' : '') . '" href="' . esc_url(admin_url('admin.php?page=ipsvp-orders&service_type=dedicated')) . '">اختصاصی</a></div>';
        echo '<form method="get" class="ipsvp-admin-search"><input type="hidden" name="page" value="ipsvp-orders"><input type="hidden" name="service_type" value="' . esc_attr($service_filter) . '"><input type="search" name="s" value="' . esc_attr($search) . '" placeholder="جستجو کد سفارش، موبایل، یوزرنیم، پلن یا کشور"><button class="button button-primary">جستجو</button> <a class="button" href="' . esc_url(admin_url('admin.php?page=ipsvp-orders')) . '">نمایش همه</a></form>';
        $conditions = array();
        $params = array();
        if ($search !== '') {
            $like = '%' . $wpdb->esc_like($search) . '%';
            $conditions[] = '(o.order_code LIKE %s OR o.phone LIKE %s OR o.pg_username LIKE %s OR p.title LIKE %s OR c.name LIKE %s)';
            $params = array($like, $like, $like, $like, $like);
        }
        if ($service_filter !== 'all') {
            $conditions[] = 'o.service_type=%s';
            $params[] = $service_filter;
        }
        $where = $conditions ? ('WHERE ' . implode(' AND ', $conditions)) : '';
        list($paged, $offset, $per_page) = $this->pagination_vars(10);
        $count_sql = "SELECT COUNT(*) FROM {$t['orders']} o LEFT JOIN {$t['plans']} p ON p.id=o.plan_id LEFT JOIN {$t['countries']} c ON c.id=o.country_id {$where}";
        $total_orders = $params ? (int) $wpdb->get_var($wpdb->prepare($count_sql, $params)) : (int) $wpdb->get_var($count_sql);
        $sql = "SELECT o.*, p.title plan_title, CASE WHEN o.country_id=0 THEN 'همه کشورها' ELSE c.name END country_name, CASE WHEN o.country_id=0 THEN '🌍' ELSE c.flag END flag FROM {$t['orders']} o LEFT JOIN {$t['plans']} p ON p.id=o.plan_id LEFT JOIN {$t['countries']} c ON c.id=o.country_id {$where} ORDER BY o.id DESC LIMIT %d OFFSET %d";
        $query_params = array_merge($params, array($per_page, $offset));
        $orders = $wpdb->get_results($wpdb->prepare($sql, $query_params));
        $this->table_open(array('کد','نوع سرویس','موبایل','پلن','کشور','مبلغ','روش پرداخت','وضعیت','تاریخ','عملیات'));
        foreach ($orders as $o) {
            $payment_method_label = $this->db->get_order_payment_method_label($o);
            $service_label = $this->db->order_service_type($o) === 'dedicated' ? 'اختصاصی' : 'اشتراکی';
            echo '<tr><td>' . esc_html($o->order_code) . '</td><td>' . esc_html($service_label) . '</td><td>' . esc_html($o->phone) . '</td><td>' . esc_html($o->plan_title) . '</td><td>' . esc_html($this->render_country_label($o->flag, $o->country_name)) . '</td><td>' . esc_html(number_format_i18n($o->price)) . '</td><td>' . esc_html($payment_method_label) . '</td><td><span class="ipsvp-badge ipsvp-' . esc_attr($o->status) . '">' . esc_html($this->db->status_label($o->status)) . '</span></td><td>' . esc_html($o->created_at) . '</td><td><a href="' . esc_url(admin_url('admin.php?page=ipsvp-orders&view=' . $o->id)) . '">جزییات</a></td></tr>';
        }
        if (!$orders) {
            echo '<tr><td colspan="10">موردی پیدا نشد.</td></tr>';
        }
        $this->table_close();
        $pagination_args = array();
        if ($search !== '') { $pagination_args['s'] = $search; }
        if ($service_filter !== 'all') { $pagination_args['service_type'] = $service_filter; }
        $this->render_admin_pagination('ipsvp-orders', $total_orders, $per_page, $pagination_args);
        $this->footer();
    }

    private function refresh_dedicated_expiry_snapshots($limit = 100)
    {
        global $wpdb;
        $t = $this->db->tables();
        $rows = $wpdb->get_results($wpdb->prepare("SELECT id FROM {$t['orders']}
            WHERE service_type='dedicated'
              AND status IN ('created','active','on_hold','volume_finished','time_finished')
              AND (pg_username IS NOT NULL AND pg_username<>'' OR pg_user_id IS NOT NULL AND pg_user_id<>'')
            ORDER BY COALESCE(pg_synced_at,'1970-01-01 00:00:00') ASC, id ASC LIMIT %d", max(1, (int) $limit)));
        $updated = 0;
        foreach ($rows as $row) {
            $order = $this->db->get_order((int) $row->id);
            $snapshot = $order ? $this->refresh_site_order_snapshot($order) : array();
            if (!empty($snapshot['live'])) {
                $updated++;
            }
        }
        return $updated;
    }

    public function dedicated_expiring_page()
    {
        $this->header('پایان سرویس‌های اختصاصی');
        $orders = $this->db->get_dedicated_expiring_orders(5);
        $action_count = 0;
        $critical_count = 0;
        foreach ($orders as $order) {
            if (!empty($order->renewal_pending)) { continue; }
            $action_count++;
            if ((int) $order->seconds_left <= DAY_IN_SECONDS) { $critical_count++; }
        }

        echo '<div class="ipsvp-admin-note"><strong>مبنای این فهرست تاریخ پایان دریافتی از پنل هر سفارش است.</strong><p>سرویس‌های اختصاصی از ۵ روز مانده نمایش داده می‌شوند. موارد دارای تمدید در انتظار بررسی برای جلوگیری از غیرفعال‌سازی اشتباه مشخص شده‌اند.</p></div>';
        echo '<p><strong>نیازمند اقدام: ' . esc_html(number_format_i18n($action_count)) . '</strong> &nbsp; | &nbsp; بحرانی/منقضی: ' . esc_html(number_format_i18n($critical_count)) . '</p>';
        echo '<p><a class="button button-secondary" href="' . esc_url(wp_nonce_url(admin_url('admin.php?page=ipsvp-dedicated-expiring&ipsvp_action=refresh_dedicated_expiring'), 'ipsvp_refresh_dedicated_expiring')) . '">به‌روزرسانی مستقیم از پنل‌ها</a></p>';

        $this->table_open(array('سفارش','کاربر','کاربر پنل','پلن/کشور','تاریخ پایان سرویس','زمان باقی‌مانده','وضعیت تمدید','آخرین همگام‌سازی','عملیات'));
        foreach ($orders as $order) {
            $expired = (int) $order->seconds_left <= 0;
            $critical = (int) $order->seconds_left <= DAY_IN_SECONDS;
            if ($expired) {
                $remaining = human_time_diff((int) $order->pasarguard_expiry_ts, time()) . ' گذشته';
            } else {
                $remaining = human_time_diff(time(), (int) $order->pasarguard_expiry_ts) . ' مانده';
            }
            $expiry_class = $critical ? 'failed' : 'pending';
            $renewal = !empty($order->renewal_pending)
                ? '<span class="ipsvp-badge ipsvp-pending">رسید تمدید در انتظار بررسی</span>'
                : '<span class="ipsvp-badge ipsvp-failed">تمدید ثبت نشده</span>';
            echo '<tr>';
            echo '<td><strong>' . esc_html($order->order_code) . '</strong></td>';
            echo '<td><span dir="ltr">' . esc_html($order->phone) . '</span></td>';
            echo '<td>' . esc_html(!empty($order->pg_username) ? $order->pg_username : ('#' . $order->pg_user_id)) . '</td>';
            echo '<td>' . esc_html($order->plan_title . ' / ' . $this->render_country_label($order->flag, $order->country_name)) . '</td>';
            echo '<td><span dir="ltr">' . esc_html(wp_date('Y-m-d H:i:s', (int) $order->pasarguard_expiry_ts)) . '</span></td>';
            echo '<td><span class="ipsvp-badge ipsvp-' . esc_attr($expiry_class) . '">' . esc_html($remaining) . '</span></td>';
            echo '<td>' . $renewal . '</td>';
            echo '<td><span dir="ltr">' . esc_html(!empty($order->pg_synced_at) ? $order->pg_synced_at : '-') . '</span></td>';
            echo '<td><a class="button button-small" href="' . esc_url(admin_url('admin.php?page=ipsvp-orders&view=' . (int) $order->id)) . '">جزئیات</a> ';
            if (!empty($order->renewal_pending)) {
                echo '<a class="button button-small button-primary" href="' . esc_url(admin_url('admin.php?page=ipsvp-receipts&service_type=dedicated&receipt_status=pending')) . '">بررسی تمدید</a>';
            } elseif ($expired) {
                echo '<form method="post" style="display:inline-block;margin:0" onsubmit="return confirm(\'این سرور اختصاصی در پنل مربوط به خود غیرفعال شود؟\')">';
                wp_nonce_field('ipsvp_update_order_status');
                echo '<input type="hidden" name="ipsvp_action" value="update_order_status"><input type="hidden" name="order_id" value="' . esc_attr($order->id) . '"><input type="hidden" name="order_status" value="disabled"><input type="hidden" name="admin_note" value="غیرفعال‌سازی از فهرست پایان سرویس اختصاصی"><button type="submit" class="button button-small">غیرفعال‌سازی</button></form>';
            } else {
                echo '<span class="description">غیرفعال‌سازی پس از پایان</span>';
            }
            echo '</td></tr>';
        }
        if (!$orders) {
            echo '<tr><td colspan="9">در حال حاضر سرویس اختصاصی بدون تمدید در بازه ۵ روزه وجود ندارد.</td></tr>';
        }
        $this->table_close();
        $this->footer();
    }

    private function format_bytes_admin($value)
    {
        if ($value === '' || $value === null) {
            return '-';
        }
        $bytes = (float) $value;
        if ($bytes < 0) {
            $bytes = 0;
        }
        $units = array('B', 'KB', 'MB', 'GB', 'TB');
        $i = 0;
        while ($bytes >= 1024 && $i < count($units) - 1) {
            $bytes /= 1024;
            $i++;
        }
        return number_format_i18n($bytes, $i === 0 ? 0 : 2) . ' ' . $units[$i];
    }

    private function render_order_receipt_actions($receipt, $order_id)
    {
        if ((string) $receipt->status !== 'pending') { echo '<span>بررسی شده</span>'; return; }
        echo '<form method="post" class="ipsvp-order-receipt-actions">';
        wp_nonce_field('ipsvp_review_order_receipt_' . $order_id . '_' . (int) $receipt->id);
        echo '<input type="hidden" name="ipsvp_action" value="review_order_receipt"><input type="hidden" name="order_id" value="' . esc_attr($order_id) . '"><input type="hidden" name="receipt_id" value="' . esc_attr($receipt->id) . '">';
        echo '<button class="button button-primary" type="submit" name="receipt_decision" value="approve">تایید رسید</button> <button class="button" type="submit" name="receipt_decision" value="reject">رد رسید</button>';
        echo '</form>';
    }

    private function render_dedicated_assignment_form($order)
    {
        $is_sanaei = IPSVP_Sanaei_API::is_order($order);
        $provider = $is_sanaei ? 'sanaei' : 'pasarguard';
        $linked = !empty($order->pg_user_id) || !empty($order->pg_username);
        $identifier = $order->pg_username ? $order->pg_username : $order->pg_user_id;
        $saved_links = $is_sanaei ? json_decode((string) $order->pg_links, true) : array();

        echo '<section class="ipsvp-admin-callback-box ipsvp-dedicated-assignment" aria-labelledby="ipsvp-assignment-title">';
        echo '<h3 id="ipsvp-assignment-title">اتصال سرویس اختصاصی موجود</h3><p class="description">پنل و کاربری را که از قبل ساخته‌اید مشخص کنید. پنل سفارش پس از اتصال ثابت می‌ماند.</p>';
        echo '<form method="post" class="ipsvp-form ipsvp-assignment-form" data-ipsvp-assignment>';
        wp_nonce_field('ipsvp_assign_pg_user');
        echo '<input type="hidden" name="ipsvp_action" value="assign_pg_user"><input type="hidden" name="order_id" value="' . esc_attr($order->id) . '">';
        echo '<div class="ipsvp-assignment-grid">';
        echo '<label><span>پنل سرویس</span><select name="panel_provider" data-ipsvp-provider ' . ($linked ? 'disabled' : '') . '><option value="pasarguard" ' . selected($provider, 'pasarguard', false) . '>پاسارگارد</option><option value="sanaei" ' . selected($provider, 'sanaei', false) . '>سنایی (3x-ui)</option></select></label>';
        if ($linked) { echo '<input type="hidden" name="panel_provider" value="' . esc_attr($provider) . '">'; }
        echo '<label><span data-ipsvp-identifier-label>' . ($is_sanaei ? 'نام کلاینت سنایی (Email)' : 'نام کاربری یا آیدی پاسارگارد') . '</span><input type="text" name="pg_identifier" value="' . esc_attr($identifier) . '" placeholder="' . esc_attr($is_sanaei ? 'مثلاً client-123' : 'مثلاً ips-user-123 یا 4581') . '" dir="ltr" autocomplete="off" required ' . ($is_sanaei && $linked ? 'readonly' : '') . '></label>';
        echo '</div>';
        echo '<p class="description" data-ipsvp-provider-help="pasarguard" ' . ($is_sanaei ? 'hidden' : '') . '>نام کاربری یا آیدی عددی کاربر موجود در پاسارگارد را وارد کنید.</p>';
        echo '<fieldset class="ipsvp-assignment-sanaei" data-ipsvp-provider-fields="sanaei" ' . ($is_sanaei ? '' : 'hidden disabled') . '>';
        echo '<legend>اطلاعات اتصال سنایی</legend><p class="description">Email همان نام کلاینت در پنل است و لازم نیست آدرس ایمیل واقعی باشد.</p>';
        echo '<div class="ipsvp-assignment-grid">';
        echo '<label><span>آیدی اینباند</span><input type="number" name="panel_inbound_id" value="' . esc_attr(!empty($order->panel_inbound_id) ? $order->panel_inbound_id : '') . '" min="1" step="1" placeholder="مثلاً 1" dir="ltr" required ' . ($is_sanaei && $linked ? 'readonly' : '') . '></label>';
        echo '<label><span>لینک ساب</span><input type="url" name="sanaei_subscription_url" value="' . esc_attr($is_sanaei ? $order->pg_subscription_url : '') . '" placeholder="https://sub.example.com/sub/your-sub-id" dir="ltr"></label>';
        echo '<label class="ipsvp-assignment-wide"><span>کانفیگ‌ها</span><textarea name="sanaei_configs" rows="5" dir="ltr" spellcheck="false" placeholder="vless://...">' . esc_textarea(is_array($saved_links) ? implode("\n", $saved_links) : '') . '</textarea><small>هر لینک کانفیگ را در یک خط وارد کنید.</small></label>';
        echo '</div><p class="description">لینک ساب یا کانفیگ آماده را وارد کنید. اگر کانفیگ خالی باشد، در نسخه‌های جدید سنایی لینک‌ها از پنل دریافت می‌شوند.</p>';
        echo '</fieldset><div class="ipsvp-assignment-actions">';
        submit_button($order->pg_user_id ? 'دریافت مجدد و بروزرسانی اطلاعات' : 'بررسی و اتصال یوزر', 'primary', '', false);
        echo '</div></form></section>';
    }

    private function refresh_site_order_snapshot($o)
    {
        if (!$o || (empty($o->pg_username) && empty($o->pg_user_id))) {
            return array();
        }
        if ((int) $o->country_id === 0) {
            $this->api->ensure_all_countries_groups_for_order($o, $this->db->ready_countries());
        }
        $snapshot = $this->api->user_snapshot($o->pg_username, $o->pg_user_id, $o);
        if (!is_array($snapshot)) {
            return array();
        }
        $update = array();
        if (!empty($snapshot['user_id']) && (string) $snapshot['user_id'] !== (string) $o->pg_user_id) {
            $update['pg_user_id'] = (string) $snapshot['user_id'];
        }
        if (!empty($snapshot['status']) && (string) $snapshot['status'] !== (string) $o->pg_status) {
            $update['pg_status'] = (string) $snapshot['status'];
        }
        if (!empty($snapshot['subscription_url']) && (string) $snapshot['subscription_url'] !== (string) $o->pg_subscription_url) {
            $update['pg_subscription_url'] = (string) $snapshot['subscription_url'];
        }
        if (!empty($snapshot['links'])) {
            $links_json = wp_json_encode(array_values($snapshot['links']), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($links_json && $links_json !== (string) $o->pg_links) {
                $update['pg_links'] = $links_json;
            }
        }
        if (!empty($snapshot['live'])) {
            $live_for_save = $snapshot['live'];
            if (!empty($o->pg_response)) {
                $old_raw = json_decode((string) $o->pg_response, true);
                if (is_array($old_raw) && !empty($old_raw['_all_countries'])) {
                    $live_for_save['_all_countries'] = $old_raw['_all_countries'];
                }
            }
            $update['pg_response'] = wp_json_encode($live_for_save, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $update['pg_synced_at'] = $this->db->now();
        }
        if ($update) {
            $this->db->update_order($o->id, $update);
        }
        $fresh_order = $this->db->get_order($o->id);
        $lifecycle_order = $this->db->apply_order_lifecycle_snapshot($fresh_order, $snapshot);
        if ($lifecycle_order && (string) $lifecycle_order->status === 'cancelled' && (string) $fresh_order->status !== 'cancelled') {
            $remote_status = $this->api->update_user_status_for_order($lifecycle_order, 'cancelled');
            if (is_wp_error($remote_status)) {
                $this->db->add_log('warning', 'auto_cancel_pg_status', $remote_status->get_error_message(), array('order_id' => $o->id), $o->phone, $o->id, 0, $o->user_id);
            }
        }
        return $snapshot;
    }

    private function order_detail($id)
    {
        $o = $this->db->get_order($id);
        if (!$o) {
            echo '<p>سفارش پیدا نشد.</p>';
            return;
        }
        $is_proxy = class_exists('IPSPLA_Admin') && IPSPLA_Admin::is_base_proxyline_order($o);
        $snapshot = $is_proxy ? array() : $this->refresh_site_order_snapshot($o);
        if (!empty($snapshot)) {
            $o = $this->db->get_order($id);
        }
        $receipts = $this->db->get_order_receipts($id);
        echo '<div class="ipsvp-detail ipsvp-order-workspace">';
        echo '<p><a class="button" href="' . esc_url(admin_url('admin.php?page=ipsvp-orders')) . '">بازگشت به سفارشات</a></p>';
        echo '<header class="ips-ui-detail-heading"><div><small>مدیریت سفارش</small><h2 dir="ltr">' . esc_html($o->order_code) . '</h2></div><span class="ipsvp-badge ipsvp-' . esc_attr($o->status) . '">' . esc_html($this->db->status_label($o->status)) . '</span></header>';
        if ($is_proxy) {
            IPSPLA_Admin::render_base_order_proxy_detail($o);
        } else {
        echo '<div class="ipsvp-admin-detail-grid">';
        echo '<p><strong>موبایل:</strong><br>' . esc_html($o->phone) . '</p>';
        echo '<p><strong>پلن اصلی:</strong><br>' . esc_html($o->plan_title . ' - ' . $o->gb . 'GB / ' . $o->days . ' روز') . '</p>';
        echo '<p><strong>نوع سرویس:</strong><br>' . ($this->db->order_service_type($o) === 'dedicated' ? 'آی پی ثابت اختصاصی' : 'آی پی ثابت اشتراکی') . '</p>';
        echo '<p><strong>کشور:</strong><br>' . esc_html($this->render_country_label($o->flag, $o->country_name) . ' - گروه: ' . $o->pg_group_name . ' #' . $o->pg_group_id) . '</p>';
        echo '<p><strong>مبلغ سفارش اول:</strong><br>' . esc_html(number_format_i18n($o->price)) . ' تومان</p>';
        echo '<p><strong>وضعیت:</strong><br><span class="ipsvp-badge ipsvp-' . esc_attr($o->status) . '">' . esc_html($this->db->status_label($o->status)) . '</span></p>';
        echo '<p><strong>پنل سرویس:</strong><br>' . (IPSVP_Sanaei_API::is_order($o) ? 'سنایی' : 'پاسارگارد') . '</p>';
        echo '<p><strong>نام کاربر پنل:</strong><br><code>' . esc_html($o->pg_username) . '</code></p>';
        echo '<p><strong>شناسهٔ کاربر پنل:</strong><br><code>' . esc_html($o->pg_user_id) . '</code></p>';
        echo '<p><strong>تاریخ ثبت:</strong><br>' . esc_html($o->created_at) . '</p>';
        echo '</div>';
        echo '<div class="ipsvp-order-status-panel"><h3>وضعیت سفارش و سرویس</h3><form method="post" class="ipsvp-order-status-form">';
        wp_nonce_field('ipsvp_update_order_status');
        echo '<input type="hidden" name="ipsvp_action" value="update_order_status"><input type="hidden" name="order_id" value="' . esc_attr($o->id) . '">';
        $status_options = array('active'=>'فعال','on_hold'=>'در انتظار اتصال','disabled'=>'معلق','volume_finished'=>'اتمام حجم','time_finished'=>'اتمام زمان','cancelled'=>'لغو شده');
        if (IPSVP_Sanaei_API::is_order($o)) {
            unset($status_options['volume_finished'], $status_options['time_finished']);
            echo '<p class="description">اتمام حجم و زمان از سنایی تشخیص داده می‌شود. برای توقف دستی سرویس، معلق را انتخاب کنید.</p>';
        }
        $selected_status = (string) $o->status === 'created' ? 'active' : (string) $o->status;
        echo '<div class="ipsvp-order-status-row"><label><span>وضعیت سرویس</span><select name="order_status">';
        if (IPSVP_Sanaei_API::is_order($o) && !isset($status_options[$selected_status])) {
            echo '<option value="" selected disabled>' . esc_html($this->db->status_label($selected_status)) . ' (خودکار)</option>';
        }
        foreach ($status_options as $value => $label) {
            echo '<option value="' . esc_attr($value) . '" ' . selected($selected_status, $value, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select></label><button type="submit" class="button button-primary">تایید و همگام‌سازی</button></div>';
        echo '<label class="ipsvp-order-admin-note"><span>یادداشت مدیریت</span><textarea name="admin_note" rows="4" placeholder="یادداشت داخلی یا توضیح وضعیت">' . esc_textarea($o->admin_note) . '</textarea></label>';
        echo '</form></div>';
        if ($this->db->order_service_type($o) === 'dedicated') {
            $this->render_dedicated_assignment_form($o);
        }
        if (!empty($snapshot) && (!empty($snapshot['live']) || !empty($snapshot['status']) || !empty($snapshot['used']) || !empty($snapshot['limit']) || !empty($snapshot['expire']))) {
            echo '<h3>اطلاعات لحظه‌ای پنل</h3><div class="ipsvp-admin-detail-grid">';
            echo '<p><strong>وضعیت پنل:</strong><br>' . esc_html($this->db->status_label(!empty($snapshot['status']) ? $snapshot['status'] : $o->pg_status)) . '</p>';
            echo '<p><strong>حجم مصرف شده:</strong><br>' . esc_html($this->format_bytes_admin(!empty($snapshot['used']) ? $snapshot['used'] : 0)) . '</p>';
            echo '<p><strong>حجم کل:</strong><br>' . esc_html(IPSVP_Sanaei_API::is_order($o) && isset($snapshot['limit']) && (int) $snapshot['limit'] === 0 ? 'نامحدود' : $this->format_bytes_admin(!empty($snapshot['limit']) ? $snapshot['limit'] : ((int) $o->gb * 1024 * 1024 * 1024))) . '</p>';
            echo '<p><strong>انقضا:</strong><br>' . esc_html(!empty($snapshot['expire']) ? $snapshot['expire'] : '-') . '</p>';
            echo '</div>';
        }
        }
        $display_subscription_url = !empty($snapshot['subscription_url'])
            ? (string) $snapshot['subscription_url']
            : (string) $o->pg_subscription_url;
        if ($display_subscription_url) {
            echo '<h3>لینک ساب</h3><textarea class="ipsvp-admin-codebox" readonly rows="2">' . esc_textarea($display_subscription_url) . '</textarea>';
        }
        $links = !empty($snapshot['links']) && is_array($snapshot['links'])
            ? array_values($snapshot['links'])
            : json_decode($o->pg_links, true);
        if ($links) {
            echo '<h3>لینک های کانفیگ</h3><textarea class="ipsvp-admin-codebox" readonly rows="8">' . esc_textarea(implode("\n", $links)) . '</textarea>';
        }
        echo '<h3>لیست پرداختی ها و رسیدها</h3>';
        $this->table_open(array('شماره','نوع','پلن پرداخت','مبلغ','روش پرداخت','وضعیت','تاریخ ارسال','بررسی','رسید','عملیات'));
        foreach ($receipts as $r) {
            $receipt_plan_label = $r->plan_title ? ($r->plan_title . ' - ' . $r->gb . 'GB / ' . $r->days . ' روز') : '-';
            if (in_array((string) $r->type, array('extra_volume','wallet_extra_volume'), true) && !empty($r->remote_payload)) {
                $payload = json_decode((string) $r->remote_payload, true);
                if (is_array($payload) && !empty($payload['gb'])) {
                    $receipt_plan_label = number_format_i18n((int) $payload['gb']) . ' گیگ حجم اضافه';
                }
            }
            $payment_method_label = $this->db->get_payment_method_label($this->db->payment_method_from_receipt($r));
            $receipt_link = IPSVP_Receipt_Uploader::link_html(isset($r->attachment_id) ? (int) $r->attachment_id : 0, !empty($r->file_url) ? $r->file_url : '', 'مشاهده رسید', 'button');
            echo '<tr><td>#' . esc_html($r->id) . '</td><td>' . esc_html($this->db->status_label($r->type)) . '</td><td>' . esc_html($receipt_plan_label) . '</td><td>' . esc_html(number_format_i18n($r->amount)) . ' تومان</td><td>' . esc_html($payment_method_label) . '</td><td><span class="ipsvp-badge ipsvp-' . esc_attr($r->status) . '">' . esc_html($this->db->status_label($r->status)) . '</span></td><td>' . esc_html($r->created_at) . '</td><td>' . esc_html($r->reviewed_at ? $r->reviewed_at : '-') . '</td><td>' . ($receipt_link !== '' ? $receipt_link : '-') . '</td><td>';
            $this->render_order_receipt_actions($r, (int) $o->id);
            echo '</td></tr>';
        }
        if (!$receipts) {
            echo '<tr><td colspan="10">پرداختی ثبت نشده است.</td></tr>';
        }
        $this->table_close();
        if (!$is_proxy && $o->pg_response) {
            if (class_exists('IPSPLA_Admin') && method_exists('IPSPLA_Admin', 'is_base_proxyline_order') && IPSPLA_Admin::is_base_proxyline_order($o)) {
                IPSPLA_Admin::render_base_order_proxy_detail($o);
            } else {
                echo '<details><summary>جزئیات فنی سرویس</summary><pre class="ipsvp-raw">' . esc_html($o->pg_response) . '</pre></details>';
            }
        }
        echo '</div>';
    }

    public function receipts_page()
    {
        global $wpdb;
        $t = $this->db->tables();
        $this->header('رسیدها و تراکنش‌ها');
        $search = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
        $service_filter = isset($_GET['service_type']) ? sanitize_key(wp_unslash($_GET['service_type'])) : 'all';
        if (!in_array($service_filter, array('all','shared','dedicated'), true)) { $service_filter = 'all'; }
        $receipt_status_filter = isset($_GET['receipt_status']) ? sanitize_key(wp_unslash($_GET['receipt_status'])) : 'all';
        if (!in_array($receipt_status_filter, array('all','pending','approved','rejected','failed'), true)) { $receipt_status_filter = 'all'; }
        echo '<div class="ipsvp-admin-report-tabs"><a class="button ' . ($service_filter === 'all' ? 'button-primary' : '') . '" href="' . esc_url(admin_url('admin.php?page=ipsvp-receipts')) . '">همه رسیدها</a> ';
        echo '<a class="button ' . ($service_filter === 'shared' ? 'button-primary' : '') . '" href="' . esc_url(admin_url('admin.php?page=ipsvp-receipts&service_type=shared')) . '">اشتراکی</a> ';
        echo '<a class="button ' . ($service_filter === 'dedicated' ? 'button-primary' : '') . '" href="' . esc_url(admin_url('admin.php?page=ipsvp-receipts&service_type=dedicated&receipt_status=pending')) . '">اختصاصی در انتظار بررسی</a></div>';
        $status_options = '';
        foreach (array('all' => 'همه وضعیت‌ها', 'pending' => 'در انتظار بررسی', 'approved' => 'تأیید شده', 'rejected' => 'رد شده', 'failed' => 'ناموفق') as $value => $label) {
            $status_options .= '<option value="' . esc_attr($value) . '" ' . selected($receipt_status_filter, $value, false) . '>' . esc_html($label) . '</option>';
        }
        echo '<form method="get" class="ipsvp-admin-search"><input type="hidden" name="page" value="ipsvp-receipts"><input type="hidden" name="service_type" value="' . esc_attr($service_filter) . '"><select name="receipt_status" aria-label="وضعیت تراکنش">' . $status_options . '</select><input type="search" name="s" value="' . esc_attr($search) . '" placeholder="جستجو کد سفارش، موبایل، پلن، کشور یا نوع پرداخت"><button class="button button-primary">جستجو</button> <a class="button" href="' . esc_url(admin_url('admin.php?page=ipsvp-receipts')) . '">نمایش همه</a></form>';
        $conditions = array();
        $params = array();
        if ($search !== '') {
            $like = '%' . $wpdb->esc_like($search) . '%';
            $conditions[] = '(o.order_code LIKE %s OR r.phone LIKE %s OR p.title LIKE %s OR c.name LIKE %s OR r.type LIKE %s)';
            $params = array($like, $like, $like, $like, $like);
        }
        if ($service_filter !== 'all') {
            $conditions[] = 'o.service_type=%s';
            $params[] = $service_filter;
        }
        if ($receipt_status_filter !== 'all') {
            $conditions[] = 'r.status=%s';
            $params[] = $receipt_status_filter;
        }
        $where = $conditions ? ('WHERE ' . implode(' AND ', $conditions)) : '';
        list($paged, $offset, $per_page) = $this->pagination_vars(10);
        $count_sql = "SELECT COUNT(*)
            FROM {$t['receipts']} r
            LEFT JOIN {$t['orders']} o ON o.id=r.order_id
            LEFT JOIN {$t['plans']} p ON p.id=COALESCE(r.plan_id, o.plan_id)
            LEFT JOIN {$t['countries']} c ON c.id=o.country_id
            {$where}";
        $total_receipts = $params ? (int) $wpdb->get_var($wpdb->prepare($count_sql, $params)) : (int) $wpdb->get_var($count_sql);
        $sql = "SELECT r.*, o.order_code, o.status order_status, o.service_type, p.title plan_title, p.gb, p.days, c.name country_name, c.flag
            FROM {$t['receipts']} r
            LEFT JOIN {$t['orders']} o ON o.id=r.order_id
            LEFT JOIN {$t['plans']} p ON p.id=COALESCE(r.plan_id, o.plan_id)
            LEFT JOIN {$t['countries']} c ON c.id=o.country_id
            {$where}
            ORDER BY CASE WHEN r.status='pending' THEN 0 ELSE 1 END, r.id DESC LIMIT %d OFFSET %d";
        $query_params = array_merge($params, array($per_page, $offset));
        $receipts = $wpdb->get_results($wpdb->prepare($sql, $query_params));
        $this->table_open(array('کد سفارش','نوع سرویس','نوع تراکنش','موبایل','پلن/کشور','مبلغ','روش پرداخت','رسید','وضعیت','عملیات'));
        foreach ($receipts as $r) {
            $approve = wp_nonce_url(admin_url('admin.php?page=ipsvp-receipts&ipsvp_action=approve_receipt&id=' . $r->id), 'ipsvp_approve_receipt');
            $reject = wp_nonce_url(admin_url('admin.php?page=ipsvp-receipts&ipsvp_action=reject_receipt&id=' . $r->id), 'ipsvp_reject_receipt');
            $extra_payload = !empty($r->remote_payload) ? json_decode((string) $r->remote_payload, true) : array();
            $extra_label = '';
            if (is_array($extra_payload) && !empty($extra_payload['purpose']) && $extra_payload['purpose'] === 'extra_volume') {
                $extra_label = number_format_i18n((int) ($extra_payload['gb'] ?? 0)) . ' گیگ حجم اضافه';
            }
            if (!empty($r->service_type) && $r->service_type === 'dedicated' && $r->type === 'new') {
                $confirm = 'پرداخت سفارش آی پی ثابت اختصاصی تایید شود؟';
                $approve_text = 'تایید پرداخت';
            } elseif ($r->type === 'bot_renewal') {
                $confirm = 'رسید تایید و سفارش ربات تمدید شود؟';
                $approve_text = 'تایید و تمدید ربات';
            } elseif (in_array($r->type, array('extra_volume','wallet_extra_volume'), true)) {
                $confirm = 'رسید تایید و حجم اضافه به سرویس اعمال شود؟';
                $approve_text = 'تایید و اعمال حجم';
            } else {
                $confirm = ($r->type === 'renewal') ? 'رسید تایید و کانفیگ تمدید شود؟' : 'رسید تایید و کانفیگ ساخته شود؟';
                $approve_text = ($r->type === 'renewal') ? 'تایید و تمدید' : 'تایید و ساخت کانفیگ';
            }
            $plan_country_label = $extra_label ? $extra_label : ($r->plan_title . ' / ' . $this->render_country_label($r->flag, $r->country_name));
            $payment_method_label = $this->db->get_payment_method_label($this->db->payment_method_from_receipt($r));
            $receipt_link = IPSVP_Receipt_Uploader::link_html(isset($r->attachment_id) ? (int) $r->attachment_id : 0, !empty($r->file_url) ? $r->file_url : '', 'مشاهده');
            $service_label = empty($r->order_id) ? '—' : ((!empty($r->service_type) && $r->service_type === 'dedicated') ? 'اختصاصی' : 'اشتراکی');
            echo '<tr><td>' . esc_html($r->order_code) . '</td><td>' . esc_html($service_label) . '</td><td>' . esc_html($this->db->status_label($r->type)) . '</td><td>' . esc_html($r->phone) . '</td><td>' . esc_html($plan_country_label) . '</td><td>' . esc_html(number_format_i18n($r->amount)) . '</td><td>' . esc_html($payment_method_label) . '</td><td>' . ($receipt_link !== '' ? $receipt_link : '-') . '</td><td><span class="ipsvp-badge ipsvp-' . esc_attr($r->status) . '">' . esc_html($this->db->status_label($r->status)) . '</span></td><td>';
            if ($r->status === 'pending') {
                echo '<a class="button button-primary" href="' . esc_url($approve) . '" onclick="return confirm(\'' . esc_js($confirm) . '\')">' . esc_html($approve_text) . '</a> ';
                echo '<a class="button" href="' . esc_url($reject) . '" onclick="return confirm(\'رسید رد شود؟\')">رد</a>';
            } else {
                if ($r->type === 'bot_renewal') {
                    echo '<span>تمدید سفارش ربات #' . esc_html($r->remote_order_id ? $r->remote_order_id : '-') . '</span>';
                } elseif (!empty($r->order_id)) {
                    echo '<a href="' . esc_url(admin_url('admin.php?page=ipsvp-orders&view=' . $r->order_id)) . '">جزییات سفارش</a>';
                } else {
                    echo '-';
                }
            }
            echo '</td></tr>';
        }
        if (!$receipts) {
            echo '<tr><td colspan="10">موردی پیدا نشد.</td></tr>';
        }
        $this->table_close();
        $pagination_args = array();
        if ($search !== '') { $pagination_args['s'] = $search; }
        if ($service_filter !== 'all') { $pagination_args['service_type'] = $service_filter; }
        if ($receipt_status_filter !== 'all') { $pagination_args['receipt_status'] = $receipt_status_filter; }
        $this->render_admin_pagination('ipsvp-receipts', $total_receipts, $per_page, $pagination_args);
        $this->footer();
    }


    public function bot_reports_page()
    {
        $this->header('گزارش ربات');
        $tab = isset($_GET['ipsvp_bot_tab']) ? sanitize_key(wp_unslash($_GET['ipsvp_bot_tab'])) : 'orders';
        if (!in_array($tab, array('orders','payments','users'), true)) {
            $tab = 'orders';
        }
        $search = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
        $paged = isset($_GET['ipsvp_paged']) ? max(1, (int) $_GET['ipsvp_paged']) : 1;
        echo '<div class="ipsvp-admin-report-tabs"><a class="button ' . ($tab === 'orders' ? 'button-primary' : '') . '" href="' . esc_url(admin_url('admin.php?page=ipsvp-bot-reports&ipsvp_bot_tab=orders')) . '">سفارشات ربات</a> ';
        echo '<a class="button ' . ($tab === 'payments' ? 'button-primary' : '') . '" href="' . esc_url(admin_url('admin.php?page=ipsvp-bot-reports&ipsvp_bot_tab=payments')) . '">کارت به کارت های ربات</a> ';
        echo '<a class="button ' . ($tab === 'users' ? 'button-primary' : '') . '" href="' . esc_url(admin_url('admin.php?page=ipsvp-bot-reports&ipsvp_bot_tab=users')) . '">کاربران ربات</a></div>';
        echo '<form method="get" class="ipsvp-admin-search"><input type="hidden" name="page" value="ipsvp-bot-reports"><input type="hidden" name="ipsvp_bot_tab" value="' . esc_attr($tab) . '"><input type="search" name="s" value="' . esc_attr($search) . '" placeholder="جستجو در گزارش ربات"><button class="button button-primary">جستجو</button> <a class="button" href="' . esc_url(admin_url('admin.php?page=ipsvp-bot-reports&ipsvp_bot_tab=' . $tab)) . '">نمایش همه</a></form>';
        $remote = IPSVP_Bot_API::admin_list($tab, $paged, $search);
        if (is_wp_error($remote)) {
            echo '<div class="notice notice-error"><p>' . esc_html($remote->get_error_message()) . '</p></div>';
            $this->footer();
            return;
        }
        if (empty($remote['ok'])) {
            echo '<div class="notice notice-error"><p>' . esc_html($remote['message'] ?? 'دریافت اطلاعات ربات ناموفق بود.') . '</p></div>';
            $this->footer();
            return;
        }
        $items = isset($remote['items']) && is_array($remote['items']) ? $remote['items'] : array();
        if ($tab === 'orders') {
            $this->table_open(array('شماره','کاربر','نام کانفیگ','پلن','وضعیت','پنل','انقضا','تاریخ','جزییات'));
            foreach ($items as $row) {
                $status_label = !empty($row['status_label']) ? $row['status_label'] : $this->db->status_label($row['status'] ?? '');
                $user_label = '-';
                if (!empty($row['user']) && is_array($row['user'])) {
                    $user_label = trim(($row['user']['name'] ?? '') . ' ' . ($row['user']['username'] ?? ''));
                    if ($user_label === '') { $user_label = $row['user']['tel_id'] ?? '-'; }
                } elseif (!empty($row['user'])) {
                    $user_label = (string) $row['user'];
                }
                $panel_label = $row['panel_name'] ?? ($row['panel'] ?? '-');
                echo '<tr><td>#' . esc_html($row['id'] ?? '') . '</td><td>' . esc_html($user_label) . '</td><td>' . esc_html($row['remark'] ?? '') . '</td><td>' . esc_html($row['plan'] ?? '') . '</td><td><span class="ipsvp-badge ipsvp-' . esc_attr($row['status'] ?? '') . '">' . esc_html($status_label) . '</span></td><td>' . esc_html($panel_label) . '</td><td>' . esc_html($row['expire_at'] ?? '') . '</td><td>' . esc_html($row['created_at'] ?? '') . '</td><td>' . $this->render_admin_bot_order_details($row) . '</td></tr>';
            }
            if (!$items) echo '<tr><td colspan="9">موردی پیدا نشد.</td></tr>';
            $this->table_close();
        } elseif ($tab === 'payments') {
            $this->table_open(array('شماره','کاربر','نوع','روش','مبلغ','وضعیت','تاریخ'));
            foreach ($items as $row) {
                $user_label = '-';
                if (!empty($row['user']) && is_array($row['user'])) {
                    $user_label = trim(($row['user']['name'] ?? '') . ' ' . ($row['user']['username'] ?? ''));
                    if ($user_label === '') { $user_label = $row['user']['tel_id'] ?? '-'; }
                } elseif (!empty($row['user'])) {
                    $user_label = (string) $row['user'];
                }
                echo '<tr><td>#' . esc_html($row['id'] ?? '') . '</td><td>' . esc_html($user_label) . '</td><td>' . esc_html($row['type_label'] ?? ($row['type'] ?? '')) . '</td><td>' . esc_html($row['method_label'] ?? ($row['method'] ?? '')) . '</td><td>' . esc_html(number_format_i18n((int) ($row['price'] ?? 0))) . ' تومان</td><td>' . esc_html($row['status_label'] ?? ($row['status'] ?? '')) . '</td><td>' . esc_html($row['created_at'] ?? '') . '</td></tr>';
            }
            if (!$items) echo '<tr><td colspan="7">موردی پیدا نشد.</td></tr>';
            $this->table_close();
        } else {
            $this->table_open(array('شماره','تلگرام','نام','نام کاربری','موجودی','وضعیت','ثبت نام'));
            foreach ($items as $row) {
                echo '<tr><td>#' . esc_html($row['id'] ?? '') . '</td><td>' . esc_html($row['tel_id'] ?? '') . '</td><td>' . esc_html($row['name'] ?? '') . '</td><td>' . esc_html($row['username'] ?? '') . '</td><td>' . esc_html(number_format_i18n((int) ($row['balance'] ?? 0))) . ' تومان</td><td>' . esc_html($row['status'] ?? '') . '</td><td>' . esc_html($row['created_at'] ?? '') . '</td></tr>';
            }
            if (!$items) echo '<tr><td colspan="7">موردی پیدا نشد.</td></tr>';
            $this->table_close();
        }
        $total = isset($remote['total']) ? (int) $remote['total'] : 0;
        $this->render_admin_pagination('ipsvp-bot-reports', $total, 20, array('ipsvp_bot_tab' => $tab, 's' => $search));
        $this->footer();
    }

    public function logs_page()
    {
        global $wpdb;
        $t = $this->db->tables();
        $this->header('لاگ خطاها و رویدادها');
        $search = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
        echo '<form method="get" class="ipsvp-admin-search"><input type="hidden" name="page" value="ipsvp-logs"><input type="search" name="s" value="' . esc_attr($search) . '" placeholder="جستجو شماره موبایل، سفارش، رسید، متن خطا یا منبع"><button class="button button-primary">جستجو</button> <a class="button" href="' . esc_url(admin_url('admin.php?page=ipsvp-logs')) . '">نمایش همه</a></form>';
        $where = '';
        $params = array();
        if ($search !== '') {
            $like = '%' . $wpdb->esc_like($search) . '%';
            $where = "WHERE phone LIKE %s OR message LIKE %s OR source LIKE %s OR context LIKE %s OR order_id LIKE %s OR receipt_id LIKE %s";
            $params = array($like, $like, $like, $like, $like, $like);
        }
        list($paged, $offset, $per_page) = $this->pagination_vars(10);
        $count_sql = "SELECT COUNT(*) FROM {$t['logs']} {$where}";
        $total_logs = $params ? (int) $wpdb->get_var($wpdb->prepare($count_sql, $params)) : (int) $wpdb->get_var($count_sql);
        $sql = "SELECT * FROM {$t['logs']} {$where} ORDER BY id DESC LIMIT %d OFFSET %d";
        $query_params = array_merge($params, array($per_page, $offset));
        $logs = $wpdb->get_results($wpdb->prepare($sql, $query_params));
        $this->table_open(array('زمان','سطح','منبع','موبایل','سفارش','رسید','پیام','جزییات'));
        foreach ($logs as $log) {
            $ctx = trim((string) $log->context);
            echo '<tr><td>' . esc_html($log->created_at) . '</td><td><span class="ipsvp-badge ipsvp-' . esc_attr($log->level === 'error' ? 'failed' : 'pending') . '">' . esc_html($log->level) . '</span></td><td>' . esc_html($log->source) . '</td><td>' . esc_html($log->phone) . '</td><td>' . ($log->order_id ? '<a href="' . esc_url(admin_url('admin.php?page=ipsvp-orders&view=' . (int) $log->order_id)) . '">#' . esc_html($log->order_id) . '</a>' : '-') . '</td><td>' . esc_html($log->receipt_id ? '#' . $log->receipt_id : '-') . '</td><td>' . esc_html($log->message) . '</td><td>' . ($ctx ? '<details><summary>نمایش</summary><pre class="ipsvp-raw">' . esc_html($ctx) . '</pre></details>' : '-') . '</td></tr>';
        }
        if (!$logs) {
            echo '<tr><td colspan="8">لاگی پیدا نشد.</td></tr>';
        }
        $this->table_close();
        $this->render_admin_pagination('ipsvp-logs', $total_logs, $per_page, $search !== '' ? array('s' => $search) : array());
        $this->footer();
    }

    public function users_page()
    {
        global $wpdb;
        $t = $this->db->tables();
        $this->header('کاربران');
        $view = isset($_GET['view']) ? (int) $_GET['view'] : 0;
        if ($view) {
            $this->user_detail($view);
            $this->footer();
            return;
        }
        $search = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
        echo '<form method="get" class="ipsvp-admin-search"><input type="hidden" name="page" value="ipsvp-users"><input type="search" name="s" value="' . esc_attr($search) . '" placeholder="جستجو موبایل یا نام کاربر"><button class="button button-primary">جستجو</button> <a class="button" href="' . esc_url(admin_url('admin.php?page=ipsvp-users')) . '">نمایش همه</a></form>';
        $where = '';
        $params = array();
        if ($search !== '') {
            $like = '%' . $wpdb->esc_like($search) . '%';
            $where = "WHERE u.phone LIKE %s OR u.name LIKE %s";
            $params = array($like, $like);
        }
        list($paged, $offset, $per_page) = $this->pagination_vars(10);
        $count_sql = "SELECT COUNT(*) FROM {$t['users']} u {$where}";
        $total_users = $params ? (int) $wpdb->get_var($wpdb->prepare($count_sql, $params)) : (int) $wpdb->get_var($count_sql);
        $sql = "SELECT u.*, COUNT(DISTINCT o.id) total_orders, COUNT(DISTINCT r.id) total_receipts
            FROM {$t['users']} u
            LEFT JOIN {$t['orders']} o ON o.user_id=u.id
            LEFT JOIN {$t['receipts']} r ON r.user_id=u.id
            {$where}
            GROUP BY u.id ORDER BY u.id DESC LIMIT %d OFFSET %d";
        $query_params = array_merge($params, array($per_page, $offset));
        $users = $wpdb->get_results($wpdb->prepare($sql, $query_params));
        $this->table_open(array('ID','موبایل','وضعیت','رمز','تعداد سفارش','تراکنش ها','مبلغ تایید شده','ثبت نام','آخرین ورود','عملیات'));
        foreach ($users as $u) {
            $status = !empty($u->is_blocked) ? '<span class="ipsvp-badge ipsvp-rejected">مسدود</span>' : '<span class="ipsvp-badge ipsvp-created">فعال</span>';
            $confirmed_total = $this->db->get_user_confirmed_purchase_total((int) $u->id);
            echo '<tr><td>' . esc_html($u->id) . '</td><td>' . esc_html($u->phone) . '</td><td>' . $status . '</td><td>' . (!empty($u->password_hash) ? 'تعریف شده' : 'بدون رمز') . '</td><td>' . esc_html($u->total_orders) . '</td><td>' . esc_html($u->total_receipts) . '</td><td>' . esc_html(number_format_i18n($confirmed_total)) . ' تومان</td><td>' . esc_html($u->created_at) . '</td><td>' . esc_html($u->last_seen_at) . '</td><td><a class="button" href="' . esc_url(admin_url('admin.php?page=ipsvp-users&view=' . $u->id)) . '">جزییات</a></td></tr>';
        }
        if (!$users) {
            echo '<tr><td colspan="10">موردی پیدا نشد.</td></tr>';
        }
        $this->table_close();
        $this->render_admin_pagination('ipsvp-users', $total_users, $per_page, $search !== '' ? array('s' => $search) : array());
        $this->footer();
    }


    private function user_detail($id)
    {
        global $wpdb;
        $t = $this->db->tables();
        $u = $this->db->get_user_by_id($id);
        if (!$u) {
            echo '<p>کاربر پیدا نشد.</p>';
            return;
        }
        $user_tabs = apply_filters('ipsvp_admin_user_detail_tabs', array(
            'account' => 'اطلاعات و مدیریت',
            'orders' => 'سفارشات کاربر',
            'wallet' => 'کیف پول و تراکنش ها',
        ), $u);
        $active_tab = isset($_GET['ipsvp_tab']) ? sanitize_key(wp_unslash($_GET['ipsvp_tab'])) : 'account';
        if (!isset($user_tabs[$active_tab])) {
            $active_tab = 'account';
        }
        // Separate aggregates avoid multiplying orders by receipts in a many-to-many join.
        $stats = $wpdb->get_row($wpdb->prepare("SELECT COUNT(*) total_orders,
            COALESCE(SUM(status IN ('created','active','on_hold')),0) active_orders,
            COALESCE(SUM(status IN ('waiting_review','pending_receipt')),0) waiting_orders
            FROM {$t['orders']} WHERE user_id=%d", $id));
        $receipt_stats = $wpdb->get_row($wpdb->prepare("SELECT COUNT(*) total_receipts,
            COALESCE(SUM(CASE WHEN status='pending' THEN amount ELSE 0 END),0) pending_amount
            FROM {$t['receipts']} WHERE user_id=%d", $id));
        $stats = (object) array_merge((array) $stats, (array) $receipt_stats);
        $orders = $wpdb->get_results($wpdb->prepare("SELECT o.*, p.title plan_title, CASE WHEN o.country_id=0 THEN 'همه کشورها' ELSE c.name END country_name, CASE WHEN o.country_id=0 THEN '🌍' ELSE c.flag END flag
            FROM {$t['orders']} o
            LEFT JOIN {$t['plans']} p ON p.id=o.plan_id
            LEFT JOIN {$t['countries']} c ON c.id=o.country_id
            WHERE o.user_id=%d ORDER BY o.id DESC LIMIT 30", $id));
        $receipts = $wpdb->get_results($wpdb->prepare("SELECT r.*, o.order_code, p.title plan_title
            FROM {$t['receipts']} r
            LEFT JOIN {$t['orders']} o ON o.id=r.order_id
            LEFT JOIN {$t['plans']} p ON p.id=COALESCE(r.plan_id, o.plan_id)
            WHERE r.user_id=%d ORDER BY r.id DESC LIMIT 30", $id));
        $wallet_txs = $this->db->get_wallet_transactions($u->id, 50);
        $local_balance = $this->db->get_local_wallet_balance($u->id);
        $bot_balance = null;
        if (!empty($u->bot_tel_id)) {
            $remote_wallet = IPSVP_Bot_API::unified_wallet($u, $this->db, true);
            if (!is_wp_error($remote_wallet) && !empty($remote_wallet['ok'])) {
                $bot_balance = (int) ($remote_wallet['balance'] ?? 0);
                $local_balance = $this->db->get_local_wallet_balance($u->id);
            }
        }

        $reseller = IPSVP_Reseller_Store::account($u->id);
        echo '<div class="ipsvp-detail ipsvp-user-detail"><header class="ipsvp-user-heading"><div><span class="ipsvp-user-eyebrow">مدیریت حساب #' . (int) $u->id . '</span><h2>' . esc_html($u->name ?: $u->phone) . '</h2><div class="ipsvp-user-tags"><bdi>' . esc_html($u->phone) . '</bdi><span class="ipsvp-badge">' . ($reseller && $reseller->status === 'approved' ? 'نماینده فروش' : 'کاربر') . '</span><span class="ipsvp-badge ' . (!empty($u->is_blocked) ? 'ipsvp-rejected' : 'ipsvp-created') . '">' . (!empty($u->is_blocked) ? 'مسدود' : 'فعال') . '</span></div></div><a class="button" href="' . esc_url(admin_url('admin.php?page=ipsvp-users')) . '">بازگشت به کاربران ←</a></header>';
        echo '<div class="ipsvp-user-summary">';
        foreach (array('سفارش‌ها' => (int) $stats->total_orders, 'سرویس فعال' => (int) $stats->active_orders, 'در انتظار بررسی' => (int) $stats->waiting_orders, 'موجودی (تومان)' => $bot_balance !== null ? $bot_balance : $local_balance) as $label => $value) {
            echo '<div><span>' . esc_html($label) . '</span><strong>' . esc_html(number_format_i18n($value)) . '</strong></div>';
        }
        echo '</div><div class="ipsvp-admin-user-tabs ipsvp-settings-tabs-css">';
        // Generate the CSS fallback for every registered add-on tab as well.
        echo '<style>';
        foreach ($user_tabs as $key => $label) {
            $key = sanitize_key($key);
            echo '#ipsvp_user_tab_' . $key . ':checked~.ipsvp-tab-panels>[data-user-panel="' . $key . '"]{display:block!important}';
            echo '#ipsvp_user_tab_' . $key . ':checked~.ipsvp-tab-nav label[for="ipsvp_user_tab_' . $key . '"]{background:var(--ipsr-accent-soft)!important;color:var(--ipsr-accent)!important;border-color:var(--ipsr-accent)!important;box-shadow:none!important}';
        }
        echo '</style>';
        foreach ($user_tabs as $tab_key => $tab_label) {
            echo '<input class="ipsvp-tab-radio" type="radio" name="ipsvp_user_tab" id="ipsvp_user_tab_' . esc_attr($tab_key) . '" value="' . esc_attr($tab_key) . '" aria-label="' . esc_attr($tab_label) . '" ' . checked($active_tab, $tab_key, false) . '>';
        }
        echo '<div class="ipsvp-tab-nav" aria-label="بخش‌های حساب کاربر">';
        foreach ($user_tabs as $tab_key => $tab_label) {
            echo '<label id="ipsvp_user_label_' . esc_attr($tab_key) . '" for="ipsvp_user_tab_' . esc_attr($tab_key) . '">' . esc_html($tab_label) . '</label>';
        }
        echo '</div>';
        echo '<div class="ipsvp-tab-panels">';

        echo '<div class="ipsvp-tab-panel" data-user-panel="account">';
        echo '<div class="ipsvp-admin-detail-grid">';
        echo '<p><strong>موبایل:</strong><br>' . esc_html($u->phone) . '</p>';
        echo '<p><strong>نام:</strong><br>' . esc_html($u->name ? $u->name : '-') . '</p>';
        echo '<p><strong>وضعیت حساب:</strong><br>' . (!empty($u->is_blocked) ? '<span class="ipsvp-badge ipsvp-rejected">مسدود</span>' : '<span class="ipsvp-badge ipsvp-created">فعال</span>') . '</p>';
        echo '<p><strong>وضعیت رمز:</strong><br>' . (!empty($u->password_hash) ? 'رمز تعریف شده است' : 'بدون رمز') . '<br><small>ذخیره‌شده به صورت هش</small></p>';
        echo '<p><strong>تعداد سفارشات:</strong><br>' . esc_html(number_format_i18n((int) $stats->total_orders)) . '</p>';
        echo '<p><strong>سفارش فعال:</strong><br>' . esc_html(number_format_i18n((int) $stats->active_orders)) . '</p>';
        echo '<p><strong>در انتظار بررسی:</strong><br>' . esc_html(number_format_i18n((int) $stats->waiting_orders)) . '</p>';
        echo '<p><strong>تراکنش ها:</strong><br>' . esc_html(number_format_i18n((int) $stats->total_receipts)) . '</p>';
        echo '<p><strong>مبلغ تایید شده:</strong><br>' . esc_html(number_format_i18n($this->db->get_user_confirmed_purchase_total((int) $u->id))) . ' تومان</p>';
        echo '<p><strong>مبلغ در انتظار:</strong><br>' . esc_html(number_format_i18n((int) $stats->pending_amount)) . ' تومان</p>';
        echo '<p><strong>ثبت نام:</strong><br>' . esc_html($u->created_at) . '</p>';
        echo '<p><strong>آخرین ورود:</strong><br>' . esc_html($u->last_seen_at ? $u->last_seen_at : '-') . '</p>';
        echo '</div>';
        $bot_connected = trim((string) ($u->bot_tel_id ?? '')) !== '';
        echo '<div class="ipsvp-admin-bot-connection-box" style="margin:22px 0;padding:20px 22px;border:1px solid #e5e7eb;border-radius:18px;background:#f8fafc;box-shadow:0 10px 30px rgba(15,23,42,.04)">';
        echo '<h3 style="margin:0 0 12px;font-size:17px">اتصال ربات تلگرام</h3>';
        if ($bot_connected) {
            echo '<p style="margin:0 0 10px;color:#334155">این کاربر به ربات متصل است.</p>';
            echo '<div style="display:flex;flex-wrap:wrap;gap:10px;margin:0 0 14px">';
            echo '<span style="display:inline-flex;align-items:center;gap:6px;padding:8px 12px;border-radius:999px;background:#dcfce7;color:#166534;font-weight:700">وضعیت: متصل</span>';
            echo '<span style="display:inline-flex;align-items:center;gap:6px;padding:8px 12px;border-radius:999px;background:#eef2ff;color:#3730a3;font-weight:700">شناسه تلگرام: <code style="direction:ltr">' . esc_html($u->bot_tel_id) . '</code></span>';
            if (!empty($u->bot_username)) {
                echo '<span style="display:inline-flex;align-items:center;gap:6px;padding:8px 12px;border-radius:999px;background:#f1f5f9;color:#334155">یوزرنیم: @' . esc_html($u->bot_username) . '</span>';
            }
            if (!empty($u->bot_linked_at)) {
                echo '<span style="display:inline-flex;align-items:center;gap:6px;padding:8px 12px;border-radius:999px;background:#f1f5f9;color:#334155">تاریخ اتصال: ' . esc_html($u->bot_linked_at) . '</span>';
            }
            echo '</div>';
            echo '<form method="post" class="ipsvp-admin-inline-action" onsubmit="return confirm(\'اتصال این کاربر با ربات قطع شود؟ بعد از قطع اتصال، کاربر می تواند کد جدید بسازد و به ربات دیگری متصل شود.\')">';
            wp_nonce_field('ipsvp_disconnect_bot_link');
            echo '<input type="hidden" name="ipsvp_action" value="disconnect_bot_link"><input type="hidden" name="user_id" value="' . esc_attr($u->id) . '"><button class="button button-secondary" type="submit">قطع اتصال ربات و سایت</button></form>';
        } else {
            echo '<p style="margin:0;color:#64748b">هنوز متصل نشده است.</p>';
            if (!empty($u->bot_link_code)) {
                echo '<p style="margin:10px 0 0;color:#475569">کد اتصال فعال: <code style="direction:ltr">' . esc_html($u->bot_link_code) . '</code></p>';
            }
        }
        echo '</div>';
        echo '<h3>مدیریت حساب کاربر</h3><form method="post" class="ipsvp-admin-form">';
        wp_nonce_field('ipsvp_admin_update_user');
        echo '<input type="hidden" name="ipsvp_action" value="admin_update_user"><input type="hidden" name="user_id" value="' . esc_attr($u->id) . '">';
        echo '<p><label><input type="checkbox" name="is_blocked" value="1" ' . checked(!empty($u->is_blocked), true, false) . '> مسدود کردن این کاربر</label></p>';
        echo '<p><label>یادداشت مسدودی<br><textarea name="blocked_note" rows="3" style="width:100%;max-width:700px">' . esc_textarea($u->blocked_note) . '</textarea></label></p>';
        echo '<p><label>تغییر رمز عبور<br><input type="password" name="new_password" placeholder="رمز جدید، حداقل ۴ کاراکتر" style="width:320px;max-width:100%"></label></p>';
        echo '<p><label><input type="radio" name="password_action" value="none" checked> رمز تغییر نکند</label> &nbsp; <label><input type="radio" name="password_action" value="set"> رمز جدید ذخیره شود</label> &nbsp; <label><input type="radio" name="password_action" value="clear"> حذف رمز و ورود فقط با شماره</label></p>';
        echo '<p><button class="button button-primary" type="submit">ذخیره تغییرات کاربر</button></p></form>';
        echo '</div>';

        echo '<div class="ipsvp-tab-panel" data-user-panel="orders">';
        echo '<h3>سفارشات کاربر</h3>';
        $this->table_open(array('کد','پلن','کشور','مبلغ','وضعیت','تاریخ','عملیات'));
        foreach ($orders as $o) {
            echo '<tr><td>' . esc_html($o->order_code) . '</td><td>' . esc_html($o->plan_title) . '</td><td>' . esc_html($this->render_country_label($o->flag, $o->country_name)) . '</td><td>' . esc_html(number_format_i18n($o->price)) . ' تومان</td><td><span class="ipsvp-badge ipsvp-' . esc_attr($o->status) . '">' . esc_html($this->db->status_label($o->status)) . '</span></td><td>' . esc_html($o->created_at) . '</td><td><a href="' . esc_url(admin_url('admin.php?page=ipsvp-orders&view=' . $o->id)) . '">جزییات سفارش</a></td></tr>';
        }
        if (!$orders) {
            echo '<tr><td colspan="7">سفارشی ثبت نشده است.</td></tr>';
        }
        $this->table_close();
        if (!empty($u->bot_tel_id)) {
            $remote_orders = IPSVP_Bot_API::bot_orders($u->bot_tel_id);
            echo '<h3>سفارشات ربات متصل</h3>';
            if (is_wp_error($remote_orders)) {
                echo '<div class="notice notice-warning inline"><p>' . esc_html($remote_orders->get_error_message()) . '</p></div>';
            } elseif (!empty($remote_orders['ok']) && !empty($remote_orders['orders']) && is_array($remote_orders['orders'])) {
                $this->table_open(array('شماره','نام کانفیگ','پلن','وضعیت','انقضا','جزییات'));
                foreach ($remote_orders['orders'] as $bo) {
                    echo '<tr><td>#' . esc_html($bo['id'] ?? '') . '</td><td>' . esc_html($bo['remark'] ?? '') . '</td><td>' . esc_html($bo['plan'] ?? '') . '</td><td><span class="ipsvp-badge">' . esc_html($bo['status_label'] ?? ($bo['status'] ?? '')) . '</span></td><td>' . esc_html($bo['expire_at'] ?? '') . '</td><td>' . $this->render_admin_bot_order_details($bo) . '</td></tr>';
                }
                $this->table_close();
            } else {
                echo '<p>سفارشی از ربات برای این کاربر دریافت نشد.</p>';
            }
        }
        echo '</div>';

        echo '<div class="ipsvp-tab-panel" data-user-panel="wallet">';
        echo '<div class="ipsvp-wallet-admin-cards"><div><span>' . (!empty($u->bot_tel_id) ? 'مانده محلی در انتظار ادغام' : 'موجودی کیف پول سایت') . '</span><strong>' . esc_html(number_format_i18n($local_balance)) . '</strong><small>تومان</small></div>';
        echo '<div><span>موجودی مشترک سایت و ربات</span><strong>' . esc_html($bot_balance !== null ? number_format_i18n($bot_balance) : '-') . '</strong><small>' . (!empty($u->bot_tel_id) ? 'مرجع مشترک فعال' : 'متصل نیست') . '</small></div></div>';
        echo '<div class="ipsvp-admin-wallet-adjust"><h3>شارژ یا کسر کیف پول</h3><form method="post" class="ipsvp-admin-form">';
        wp_nonce_field('ipsvp_admin_wallet_adjust');
        echo '<input type="hidden" name="ipsvp_action" value="admin_wallet_adjust"><input type="hidden" name="user_id" value="' . esc_attr($u->id) . '">';
        echo '<p><label>نوع عملیات<br><select name="direction"><option value="credit">شارژ کیف پول</option><option value="debit">کسر از کیف پول</option></select></label></p>';
        echo '<p><label>مبلغ به تومان<br><input type="number" min="1000" step="1000" name="amount" style="width:260px" placeholder="مثلا 500000"></label></p>';
        echo '<p class="description">کسر دستی، اصلاح شارژ محسوب می‌شود و مبلغ معتبر سطح حساب را کاهش می‌دهد.</p>';
        echo '<p><label>یادداشت ادمین<br><textarea name="note" rows="2" style="width:100%;max-width:700px" placeholder="علت شارژ یا کسر"></textarea></label></p>';
        echo '<p><button class="button button-primary" type="submit">ثبت عملیات کیف پول</button></p></form></div>';
        echo '<h3>تراکنش های کیف پول</h3>';
        $this->table_open(array('نوع','مرجع','مبلغ','وضعیت','تاریخ','رسید/یادداشت'));
        foreach ($wallet_txs as $tx) {
            $sign = $tx->kind === 'debit' ? '-' : '+';
            $receipt_link = IPSVP_Receipt_Uploader::link_html(isset($tx->attachment_id) ? (int) $tx->attachment_id : 0, !empty($tx->file_url) ? $tx->file_url : '', 'مشاهده رسید');
            $extra = $receipt_link !== '' ? $receipt_link : esc_html($tx->note ? $tx->note : '-');
            echo '<tr><td>' . esc_html($tx->title) . '</td><td>' . esc_html($tx->ref) . '</td><td>' . esc_html($sign . number_format_i18n((int) $tx->amount)) . ' تومان</td><td><span class="ipsvp-badge ipsvp-' . esc_attr($tx->status) . '">' . esc_html($this->db->status_label($tx->status)) . '</span></td><td>' . esc_html($tx->date) . '</td><td>' . $extra . '</td></tr>';
        }
        if (!$wallet_txs) {
            echo '<tr><td colspan="6">تراکنش کیف پول ثبت نشده است.</td></tr>';
        }
        $this->table_close();

        echo '<h3>تراکنش ها و رسیدها</h3>';
        $this->table_open(array('شماره','کد سفارش','نوع','پلن','مبلغ','وضعیت','تاریخ','رسید'));
        foreach ($receipts as $r) {
            $receipt_link = IPSVP_Receipt_Uploader::link_html(isset($r->attachment_id) ? (int) $r->attachment_id : 0, !empty($r->file_url) ? $r->file_url : '', 'مشاهده');
            echo '<tr><td>#' . esc_html($r->id) . '</td><td>' . esc_html($r->order_code) . '</td><td>' . esc_html($this->db->status_label($r->type)) . '</td><td>' . esc_html($r->plan_title ? $r->plan_title : '-') . '</td><td>' . esc_html(number_format_i18n($r->amount)) . ' تومان</td><td><span class="ipsvp-badge ipsvp-' . esc_attr($r->status) . '">' . esc_html($this->db->status_label($r->status)) . '</span></td><td>' . esc_html($r->created_at) . '</td><td>' . ($receipt_link !== '' ? $receipt_link : '-') . '</td></tr>';
        }
        if (!$receipts) {
            echo '<tr><td colspan="8">تراکنشی ثبت نشده است.</td></tr>';
        }
        $this->table_close();
        echo '</div>';

        do_action('ipsvp_admin_user_detail_extra_panels', $u, $active_tab, $this->db);

        echo '</div></div></div>';
    }

    private function render_admin_bot_order_details($row)
    {
        $row = is_array($row) ? $row : array();
        $detail = isset($row['detail']) ? $row['detail'] : array();
        if (is_string($detail)) {
            $decoded = json_decode($detail, true);
            $detail = is_array($decoded) ? $decoded : array('raw' => $detail);
        }
        if (!is_array($detail)) {
            $detail = array();
        }
        if (empty($detail['code']) && !empty($row['remark'])) {
            $detail['code'] = $row['remark'];
        }
        if (empty($detail['pg_user_id']) && !empty($row['uid'])) {
            $detail['pg_user_id'] = $row['uid'];
        }
        if (empty($detail['subscription_url']) && !empty($row['sub_id'])) {
            $detail['subscription_url'] = $row['sub_id'];
        }
        $status_raw = isset($row['status']) ? (string) $row['status'] : '';
        $status_label = !empty($row['status_label']) ? (string) $row['status_label'] : $this->db->status_label($status_raw);
        $country = !empty($detail['country']) ? (string) $detail['country'] : '-';
        $price = !empty($detail['price']) ? number_format_i18n((int) $detail['price']) . ' تومان' : '-';
        $sub = !empty($detail['subscription_url']) ? (string) $detail['subscription_url'] : '';
        $links = !empty($detail['links']) && is_array($detail['links']) ? $detail['links'] : array();
        $code = !empty($detail['code']) ? (string) $detail['code'] : (!empty($row['remark']) ? (string) $row['remark'] : '-');
        $pg_user_id_for_live = !empty($detail['pg_user_id']) ? (string) $detail['pg_user_id'] : (!empty($row['uid']) ? (string) $row['uid'] : '');
        if ($code !== '-' || $pg_user_id_for_live !== '') {
            $snapshot = $this->api->user_snapshot(($code !== '-' && !preg_match('#^(vless|vmess|trojan|ss|hysteria2)://#i', $code)) ? $code : '', $pg_user_id_for_live);
            if (!empty($snapshot['links']) && is_array($snapshot['links'])) {
                $links = array_values($snapshot['links']);
            }
            if (!empty($snapshot['subscription_url'])) {
                $sub = (string) $snapshot['subscription_url'];
            }
            if (!empty($snapshot['user_id'])) {
                $detail['pg_user_id'] = (string) $snapshot['user_id'];
            }
            if (!empty($snapshot['status']) && empty($row['status_label'])) {
                $status_label = $this->db->status_label((string) $snapshot['status']);
            }
        }
        $html = '<details class="ipsvp-admin-bot-order-details"><summary>مشاهده جزییات</summary><div class="ipsvp-admin-bot-detail-card">';
        $html .= '<div class="ipsvp-admin-detail-grid">';
        $html .= '<p><strong>نام کانفیگ:</strong><br><code>' . esc_html($row['remark'] ?? '-') . '</code></p>';
        $html .= '<p><strong>پلن:</strong><br>' . esc_html($row['plan'] ?? '-') . '</p>';
        $html .= '<p><strong>وضعیت:</strong><br><span class="ipsvp-badge ipsvp-' . esc_attr($status_raw) . '">' . esc_html($status_label) . '</span></p>';
        $html .= '<p><strong>کشور:</strong><br>' . esc_html($country) . '</p>';
        $html .= '<p><strong>مبلغ:</strong><br>' . esc_html($price) . '</p>';
        $html .= '<p><strong>انقضا:</strong><br>' . esc_html($row['expire_at'] ?? '-') . '</p>';
        $html .= '<p><strong>شناسهٔ کاربر پنل:</strong><br><code>' . esc_html($detail['pg_user_id'] ?? '-') . '</code></p>';
        $html .= '<p><strong>منبع:</strong><br>' . esc_html((($row['source'] ?? 'bot') === 'wordpress') ? 'سایت' : 'ربات') . '</p>';
        if (!empty($row['tel_id'])) {
            $html .= '<p><strong>آیدی عددی تلگرام:</strong><br><code>' . esc_html($row['tel_id']) . '</code></p>';
        }
        $html .= '</div>';
        if ($code !== '-' && !preg_match('#^(vless|vmess|trojan|ss|hysteria2)://#i', $code)) {
            $html .= '<h4>ریمارک / نام کاربر</h4><textarea readonly rows="2" class="ipsvp-admin-codebox">' . esc_textarea($code) . '</textarea>';
        }
        if ($links) {
            $safe_links = array();
            foreach ($links as $link) {
                if (is_string($link) && trim($link) !== '') {
                    $safe_links[] = trim($link);
                }
            }
            if ($safe_links) {
                $html .= '<h4>لینک های کانفیگ</h4><textarea readonly rows="7" class="ipsvp-admin-codebox">' . esc_textarea(implode("\n", $safe_links)) . '</textarea>';
            }
        } elseif ($sub) {
            $html .= '<h4>لینک ساب</h4><textarea readonly rows="3" class="ipsvp-admin-codebox">' . esc_textarea($sub) . '</textarea>';
        }
        $html .= '</div></details>';
        return $html;
    }

    private function pagination_vars($per_page = 10)
    {
        $per_page = max(1, (int) $per_page);
        $paged = isset($_GET['ipsvp_paged']) ? max(1, (int) $_GET['ipsvp_paged']) : 1;
        $offset = ($paged - 1) * $per_page;
        return array($paged, $offset, $per_page);
    }

    private function render_admin_pagination($page_slug, $total, $per_page = 10, $extra = array())
    {
        $total = (int) $total;
        $per_page = max(1, (int) $per_page);
        $pages = (int) ceil($total / $per_page);
        if ($pages <= 1) {
            return;
        }

        $current = isset($_GET['ipsvp_paged']) ? max(1, (int) $_GET['ipsvp_paged']) : 1;
        $current = min($current, $pages);
        $extra = is_array($extra) ? $extra : array();
        $extra['page'] = $page_slug;

        $make_url = function ($page_number) use ($extra) {
            $args = $extra;
            $args['ipsvp_paged'] = max(1, (int) $page_number);
            return add_query_arg($args, admin_url('admin.php'));
        };

        $render_link = function ($page_number, $label = null, $class = '') use ($current, $make_url) {
            $page_number = max(1, (int) $page_number);
            $classes = trim($class . ' ' . ($page_number === $current ? 'is-current' : ''));
            $label = $label !== null ? $label : number_format_i18n($page_number);
            echo '<a class="' . esc_attr($classes) . '" href="' . esc_url($make_url($page_number)) . '">' . esc_html($label) . '</a>';
        };

        $shown = array();
        $add_page = function ($page_number) use (&$shown, $pages) {
            $page_number = (int) $page_number;
            if ($page_number >= 1 && $page_number <= $pages) {
                $shown[$page_number] = true;
            }
        };

        $add_page(1);
        $add_page($pages);
        for ($i = $current - 2; $i <= $current + 2; $i++) {
            $add_page($i);
        }
        if ($current <= 4) {
            for ($i = 1; $i <= min(6, $pages); $i++) {
                $add_page($i);
            }
        }
        if ($current >= $pages - 3) {
            for ($i = max(1, $pages - 5); $i <= $pages; $i++) {
                $add_page($i);
            }
        }

        $page_numbers = array_keys($shown);
        sort($page_numbers, SORT_NUMERIC);

        echo '<nav class="ipsvp-admin-pagination" aria-label="صفحه بندی">';
        echo '<span class="ipsvp-pagination-summary">صفحه ' . esc_html(number_format_i18n($current)) . ' از ' . esc_html(number_format_i18n($pages)) . '</span>';

        if ($current > 1) {
            $render_link($current - 1, 'قبلی', 'is-prev-next');
        }

        $last_printed = 0;
        foreach ($page_numbers as $page_number) {
            if ($last_printed && $page_number > $last_printed + 1) {
                echo '<span class="ipsvp-pagination-dots" aria-hidden="true">…</span>';
            }
            $render_link($page_number);
            $last_printed = $page_number;
        }

        if ($current < $pages) {
            $render_link($current + 1, 'بعدی', 'is-prev-next');
        }

        echo '</nav>';
    }

    private function table_open($headers)
    {
        echo '<table class="widefat striped ipsvp-table"><thead><tr>';
        foreach ($headers as $h) {
            echo '<th>' . esc_html($h) . '</th>';
        }
        echo '</tr></thead><tbody>';
    }

    private function table_close()
    {
        echo '</tbody></table>';
    }

    private function render_country_label($flag, $name)
    {
        $flag = trim(wp_strip_all_tags((string) $flag));
        $name = trim(wp_strip_all_tags((string) $name));
        if (preg_match('/https?:\\/\\//i', $flag) || preg_match('/\\.(svg|png|jpe?g|webp|gif)(\\?.*)?$/i', $flag)) {
            $flag = '';
        }
        return trim(($flag !== '' ? $flag . ' ' : '') . ($name !== '' ? $name : '-'));
    }
}

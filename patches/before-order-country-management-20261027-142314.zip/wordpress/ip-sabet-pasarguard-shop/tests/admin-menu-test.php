<?php
/** Run from this WordPress checkout: php tests/admin-menu-test.php. No DB, config or network. */
if (PHP_SAPI !== 'cli') { exit; }
define('ABSPATH', dirname(__DIR__, 4) . '/');
define('WP_PLUGIN_DIR', ABSPATH . 'wp-content/plugins');
define('WPMU_PLUGIN_DIR', ABSPATH . 'wp-content/mu-plugins');
set_error_handler(static function ($severity, $message, $file, $line) {
    throw new ErrorException($message, 0, $severity, $file, $line);
});
function wp_normalize_path($path) { return str_replace('\\', '/', $path); }
function sanitize_title($title) { return 'ips-main-menu'; }
function set_url_scheme($url) { return $url; }
function current_user_can($capability) { return $GLOBALS['test_admin_allowed']; }
function add_shortcode($name, $callback) {}
function number_format_i18n($number) { return number_format($number); }
class IPSVP_Session { public static function cookie_name() { return 'ips-menu-test-session'; } }
class MenuTestDB { public function get_dedicated_expiring_orders($days) { return array(); } }
function menu_test_callback() {}

// Use WordPress's actual hook and menu implementation; simple menu mocks miss this regression.
require ABSPATH . 'wp-includes/plugin.php';
require ABSPATH . 'wp-admin/includes/plugin.php';
require __DIR__ . '/../includes/class-ipsvp-reseller-service.php';
require __DIR__ . '/../includes/class-ipsvp-reseller-api.php';
require __DIR__ . '/../includes/class-ipsvp-reseller.php';
require __DIR__ . '/../admin/class-ipsvp-admin.php';

function menu_fixture($reseller_first)
{
    foreach (array('menu', 'submenu', 'admin_page_hooks', '_registered_pages', '_parent_pages', '_wp_real_parent_file', '_wp_menu_nopriv', '_wp_submenu_nopriv', 'wp_plugin_paths', 'wp_filter', 'wp_actions', 'wp_filters', 'wp_current_filter') as $key) { $GLOBALS[$key] = array(); }
    $GLOBALS['pagenow'] = 'admin.php';
    $GLOBALS['parent_file'] = '';
    unset($GLOBALS['plugin_page']);
    $db = new MenuTestDB();
    $api = new stdClass();
    if ($reseller_first) {
        $reseller = new IPSVP_Reseller($db, $api);
        $admin = new IPSVP_Admin($db, $api);
    } else {
        $admin = new IPSVP_Admin($db, $api);
        $reseller = new IPSVP_Reseller($db, $api);
    }
    // Match the existing referral/proxy add-ons' menu priorities.
    add_action('admin_menu', static function () { add_submenu_page('ipsvp', 'Referral', 'Referral', 'manage_options', 'ipsra-settings', 'menu_test_callback'); }, 30);
    add_action('admin_menu', static function () { add_submenu_page('ipsvp', 'Proxy', 'Proxy', 'manage_options', 'ipspla', 'menu_test_callback'); }, 35);
    do_action('admin_menu');
    return array($admin, $reseller);
}
$checks = 0;
function menu_check($condition, $message)
{
    global $checks;
    $checks++;
    if (!$condition) { throw new RuntimeException($message); }
}

$GLOBALS['test_admin_allowed'] = true;
foreach (array(true, false) as $reseller_first) {
    list($admin, $reseller) = menu_fixture($reseller_first);
    $slugs = array_column($GLOBALS['submenu']['ipsvp'], 2);
    menu_check($slugs[0] === 'ipsvp', 'Dashboard must remain the first submenu and main menu destination.');
    menu_check(count(array_keys($slugs, 'ipsvp', true)) === 1, 'Dashboard must occur exactly once.');
    $legacy = array('ipsvp', 'ipsvp-settings', 'ipsvp-plans', 'ipsvp-countries', 'ipsvp-orders', 'ipsvp-dedicated-expiring', 'ipsvp-receipts', 'ipsvp-users', 'ipsvp-bot-reports', 'ipsvp-logs');
    menu_check(array_values(array_intersect($slugs, $legacy)) === $legacy, 'Existing menu slugs and relative order must remain unchanged.');
    foreach (array_merge($legacy, array('ipsvp-resellers', 'ipsra-settings', 'ipspla')) as $slug) {
        $GLOBALS['plugin_page'] = $slug;
        $GLOBALS['parent_file'] = '';
        $parent = get_admin_page_parent();
        $hook = get_plugin_page_hook($slug, $parent);
        menu_check($parent === 'ipsvp', 'Unexpected parent for ' . $slug);
        menu_check($hook !== null && isset($GLOBALS['_registered_pages'][$hook]), 'WordPress cannot route admin.php?page=' . $slug);
        menu_check(user_can_access_admin_page(), 'WordPress denies the registered page ' . $slug);
    }
    menu_check(false !== has_action(get_plugin_page_hook('ipsvp', 'ipsvp'), array($admin, 'dashboard')), 'Original dashboard callback must remain registered.');
    menu_check(false !== has_action(get_plugin_page_hook('ipsvp-resellers', 'ipsvp'), array($reseller, 'admin_page')), 'Reseller callback must match the final parent hook.');
    menu_check(!has_action('admin_page_ipsvp-resellers'), 'Reseller callback must not be stranded on an unparented hook.');
}
$GLOBALS['test_admin_allowed'] = false;
menu_fixture(true);
menu_check(empty($GLOBALS['submenu']['ipsvp']), 'Users without manage_options must not receive admin submenus.');
echo "PASS: $checks admin menu assertions using WordPress core\n";

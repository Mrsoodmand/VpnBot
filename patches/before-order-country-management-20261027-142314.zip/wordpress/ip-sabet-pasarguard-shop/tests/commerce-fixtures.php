<?php
/** Local renderer fixtures: real templates with isolated services. Never load wp-config.php. */
if (PHP_SAPI !== 'cli' || !getenv('IPSR_RENDER_DIR')) { exit; }
require __DIR__.'/reseller-workspace-test.php';
define('HOUR_IN_SECONDS',3600); define('IPSPLA_OPTION_KEY','test_proxy_settings');
function shortcode_atts($defaults,$atts,$tag=''){return array_merge($defaults,$atts);}
function wp_parse_args($args,$defaults=array()){return array_merge($defaults,$args);}
function sanitize_html_class($s){return preg_replace('/[^a-zA-Z0-9_-]/','',$s);}
function wpautop($s){return '<p>'.$s.'</p>';}
function get_option($key,$default=false){return $default;}
function plugin_dir_url($f){return 'https://example.test/plugin/';}
function register_activation_hook(...$args){}
function wp_register_style(...$args){} function wp_register_script(...$args){}
function wp_enqueue_style(...$args){} function wp_enqueue_script(...$args){}
function wp_style_is(...$args){return true;} function wp_script_is(...$args){return true;}
function wp_max_upload_size(){return 2097152;}
function size_format($n){return '2 MB';}
function wp_create_nonce($s){return 'fixture';}
function wp_remote_get(...$args){throw new RuntimeException('No network in renderer');}
function wp_remote_post(...$args){throw new RuntimeException('No network in renderer');}
class IPSVP_Captcha_Service {
 public static function normalize_context($s){return $s;}
 public static function render_captcha_field(...$args){return '';}
}
require __DIR__.'/../includes/class-ipsvp-auth-renderer.php';
require dirname(__DIR__,2).'/ips-ip-location-widget/ips-ip-location-widget.php';
require dirname(__DIR__,2).'/ip-sabet-payment-manager/ip-sabet-payment-manager.php';
require dirname(__DIR__,2).'/ip-sabet-proxyline-addon/includes/class-proxyline-settings.php';
require dirname(__DIR__,2).'/ip-sabet-proxyline-addon/includes/class-proxyline-frontend.php';
require dirname(__DIR__,2).'/ip-sabet-proxyline-addon/includes/class-proxyline-orders.php';
class IPS_Server_Settings {public static function get(){return array('shop_intro'=>'انتخاب کشور، پلن و مدت سرویس','api_key'=>'fixture','terms_text'=>'قوانین استفاده از سرویس را می‌پذیرم.');}}
class IPS_Server_Admin_Servers {
 public static function enabled_frontend_plans(){return array((object)array('country_code'=>'DE','country_label'=>'آلمان'),(object)array('country_code'=>'FR','country_label'=>'فرانسه'));}
}
function ips_server_current_panel_phone(){return '09120000000';}
function ips_server_country_display_label($p){return $p->country_label;}
function ips_server_flag_for_country($code){return $code==='DE'?'🇩🇪':'🇫🇷';}
require dirname(__DIR__,2).'/ip-sabet-server-shop/includes/class-shortcodes.php';
$plugin=dirname(__DIR__);$plugins=dirname($plugin);$dir=rtrim(getenv('IPSR_RENDER_DIR'),'/');
$base=file_get_contents($dir.'/components.html');
$jquery=file_get_contents(dirname($plugins,2).'/wp-includes/js/jquery/jquery.min.js');
$frontScript=file_get_contents($plugin.'/assets/js/frontend.js');
$paymentCss=file_get_contents($plugins.'/ip-sabet-payment-manager/assets/public.css').file_get_contents($plugins.'/ip-sabet-payment-manager/assets/method-panel.css');
$paymentJs=file_get_contents($plugins.'/ip-sabet-payment-manager/assets/public.js');
function output_page($name,$html,$css='',$js=''){
 global $base,$dir,$jquery,$frontScript,$paymentCss,$paymentJs;
 $page=preg_replace_callback('~<main>.*?</main>~s',static function()use($html){return '<main>'.$html.'</main>';},$base);
 $page=str_replace('</head>','<style>'.$paymentCss.$css.'</style></head>',$page);
 $page=str_replace('</body>','<script>'.$jquery.'</script><script>'.$frontScript.'</script><script>'.$paymentJs.'</script><script>'.$js.'</script></body>',$page);
 file_put_contents($dir.'/'.$name.'.html',$page);
}
class CommerceShop extends WorkspaceShop { public function normalize_phone($phone){return $phone;} }
$frontend=new IPSVP_Frontend(new CommerceShop(),$provider);
output_page('login','<div class="ipsvp">'.private_call($frontend,'render_login_form','','',false).'</div>');
output_page('login-password','<div class="ipsvp">'.private_call($frontend,'render_login_form','','09120000000',true).'</div>');
$proxy=new ReflectionClass('IPSPLA_Frontend');$proxy=$proxy->newInstanceWithoutConstructor();
output_page('proxy-buy',private_call($proxy,'render_shop_form','',true),file_get_contents($plugins.'/ip-sabet-proxyline-addon/assets/css/proxyline-frontend.css'),'window.IPSPLA={ajax_url:"/ajax",nonce:"fixture",i18n:{loading:"در حال دریافت..."}};'.file_get_contents($plugins.'/ip-sabet-proxyline-addon/assets/js/proxyline-frontend.js'));
$location=new IPS_IP_Location_Widget();
output_page('location',$location->render_menu_shortcode().$location->render_shortcode(),file_get_contents($plugins.'/ips-ip-location-widget/assets/css/ips-ip-location-widget.css'),'window.IPSIPLocationWidget={ajaxUrl:"/ajax",nonce:"fixture"};'.file_get_contents($plugins.'/ips-ip-location-widget/assets/js/ips-ip-location-widget.js'));
$server=(new ReflectionClass('IPS_Server_Shortcodes'))->newInstanceWithoutConstructor();
output_page('server-buy','<div class="ipsvp ips-server-shop">'.private_call($server,'render_picker').'</div>',file_get_contents($plugins.'/ip-sabet-server-shop/assets/css/frontend.css'),'window.IPS_SERVER_FRONT={ajax_url:"/ajax",nonce:"fixture"};'.file_get_contents($plugins.'/ip-sabet-server-shop/assets/js/frontend.js'));
output_page('config-buy','<div class="ipsvp"><div class="ipsvp-hero"><div class="ipsvp-hero-content"><span>آی پی ثابت من</span><h2>انتخاب سرویس</h2></div></div>'.private_call($frontend,'render_plan_cards',array($db->get_plan(1)),'radio',array('checkout_url'=>'/checkout')).'</div>');
$adminCss=file_get_contents($plugin.'/assets/css/admin.css').file_get_contents($plugin.'/assets/css/admin-commerce.css').file_get_contents($plugins.'/ip-sabet-proxyline-addon/assets/css/proxyline-admin.css');
$sample='<div class="ipsvp-admin ipspla-admin"><h1>سفارشات پروکسی</h1><div class="ipsvp-cards"><div class="ipsvp-card"><span>سفارشات</span><strong>۲۴۸</strong></div><div class="ipsvp-card"><span>در انتظار بررسی</span><strong>۱۲</strong></div></div><form class="ipsvp-admin-search"><label>جستجوی سفارش<input type="search" placeholder="کد سفارش یا موبایل"></label><button class="button button-primary" type="button">جستجو</button></form><div class="ipsvp-detail"><header class="ips-ui-detail-heading"><div><small>مدیریت سفارش</small><h2>PROXY-1042</h2></div><span class="ipsvp-badge ipsvp-active">فعال</span></header><div class="ipsvp-admin-detail-grid"><p><strong>کاربر</strong><br>09120000000</p><p><strong>محصول</strong><br>پروکسی اختصاصی آلمان</p><p><strong>مبلغ</strong><br>۲۹۰٬۰۰۰ تومان</p></div><table class="widefat striped"><thead><tr><th>کد سفارش</th><th>کاربر</th><th>کشور</th><th>مبلغ</th><th>وضعیت</th><th>عملیات</th></tr></thead><tbody><tr><td>PROXY-1042</td><td>09120000000</td><td>آلمان</td><td>۲۹۰٬۰۰۰ تومان</td><td><span class="ipsvp-badge ipsvp-active">فعال</span></td><td><button type="button" class="button">جزئیات</button></td></tr></tbody></table><details><summary>جزئیات فنی سرویس</summary><pre>{"status":"active"}</pre></details></div></div>';
output_page('commerce-admin',$sample,$adminCss);
echo "PASS: commerce renderer fixtures generated.\n";

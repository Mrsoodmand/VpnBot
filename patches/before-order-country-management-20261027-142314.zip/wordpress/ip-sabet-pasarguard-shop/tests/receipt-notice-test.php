<?php
/** Queue semantics only. HTTP/file-send attempts are prohibited in this fixture. */
if(PHP_SAPI!=='cli')exit;
define('ABSPATH','/');
class WP_Error {}
function is_wp_error($x){return $x instanceof WP_Error;}
function wp_next_scheduled($hook,$args){return $GLOBALS['events'][$hook.json_encode($args)]??false;}
function wp_schedule_single_event($when,$hook,$args,$errors=false){$GLOBALS['events'][$hook.json_encode($args)]=$when;return true;}
function wp_remote_post(...$args){throw new RuntimeException('Network must not run during form submission');}
class IPSVP_Settings {public static function get(){return $GLOBALS['settings'];}}
class IPSVP_DB {
 public function get_receipt($id){return $GLOBALS['receipts'][$id]??null;}
 public function add_log(...$args){$GLOBALS['logs'][]=$args;}
}
class LockDouble {
 public $prefix='test_';public $lock=true;public $released=0;
 public function prepare($sql,...$args){return $sql;}
 public function get_var($sql){if(strpos($sql,'RELEASE_LOCK')!==false){$this->released++;return 1;}return $this->lock?1:0;}
}
require __DIR__.'/../includes/class-ipsvp-telegram-service.php';
$GLOBALS['events']=array();$GLOBALS['settings']=array('telegram_notifications'=>'1','telegram_bot_token'=>'test','telegram_chat_id'=>'test');
$GLOBALS['receipts']=array(1=>(object)array('id'=>1,'status'=>'pending','remote_payload'=>''));
$GLOBALS['wpdb']=new LockDouble();$db=new IPSVP_DB();$n=0;
function test($x,$msg){global $n;$n++;if(!$x)throw new RuntimeException($msg);}
test(IPSVP_Telegram_Service::queue_pending_payment_notice(1,$db),'Pending receipt queued without contacting Telegram');
test(count($GLOBALS['events'])===1,'Single durable event');
test(IPSVP_Telegram_Service::queue_pending_payment_notice(1,$db)&&count($GLOBALS['events'])===1,'Duplicate submission does not schedule duplicate event');
$GLOBALS['events']=array();$GLOBALS['receipts'][1]->status='approved';
test(!IPSVP_Telegram_Service::queue_pending_payment_notice(1,$db)&&!$GLOBALS['events'],'Reviewed receipt not queued');
IPSVP_Telegram_Service::deliver_pending_payment_notice(1);test($GLOBALS['wpdb']->released===1,'Worker skips already-reviewed receipt and releases lock');
$GLOBALS['receipts'][1]->status='pending';$GLOBALS['receipts'][1]->remote_payload=json_encode(array('telegram_pending_notice_sent'=>1));
test(IPSVP_Telegram_Service::queue_pending_payment_notice(1,$db)&&!$GLOBALS['events'],'Sent notification is not queued again');
IPSVP_Telegram_Service::deliver_pending_payment_notice(1);test($GLOBALS['wpdb']->released===2,'Worker skips already-delivered notice');
$GLOBALS['wpdb']->lock=false;IPSVP_Telegram_Service::deliver_pending_payment_notice(1);test(count($GLOBALS['events'])===1,'Busy worker schedules later instead of parallel send');
$GLOBALS['settings']['telegram_notifications']='0';test(!IPSVP_Telegram_Service::queue_pending_payment_notice(1,$db),'Disabled Telegram does not block receipt');
echo "PASS: $n receipt notification queue assertions.\n";

<?php
if (PHP_SAPI !== 'cli' || !getenv('IPSR_RENDER_DIR')) { exit; }
require __DIR__ . '/commerce-fixtures.php';
function wp_timezone() { return new DateTimeZone('Asia/Tehran'); }
function wp_date($format, $timestamp, $timezone = null) { return (new DateTimeImmutable('@' . $timestamp))->setTimezone($timezone ?: wp_timezone())->format($format); }
require __DIR__ . '/../includes/class-ipsvp-loyalty.php';
IPSVP_Loyalty::init($db);
$sql->sql->exec("UPDATE test_ipsvp_reseller_accounts SET discount_percent=NULL WHERE user_id=1");
$now=wp_date('Y-m-d H:i:s',time()-3*86400);
$insert=$sql->sql->prepare("INSERT INTO test_ipsvp_receipts (id,user_id,phone,type,amount,status,remote_source,submission_key,admin_note,created_at,reviewed_at) VALUES (99,1,?,'wallet',6000000,'approved','','demo-topup','',?,?)");$insert->execute(array($user->phone,$now,$now));
class LoyaltyHeroShop extends CommerceShop {public function get_or_create_user($phone){return $this->get_user_by_phone($phone);}}
function get_queried_object_id(){return 1;}
function get_permalink($id){return 'https://example.test/dashboard';}
function remove_query_arg($args,$url){return $url;}
$hero_db=new LoyaltyHeroShop();$hero_db->users[1]=$user;$frontend=new IPSVP_Frontend($hero_db,$provider);
$hero=IPSVP_Loyalty::hero($ui->hero('',$user->phone,6000000,''),$user->phone,6000000,'');
output_page('loyalty-reseller','<div class="ipsvp ipsvp-panel">'.$hero.$nav.$ui->panel('','dashboard',$user->phone).'</div>');
$sql->sql->exec("UPDATE test_ipsvp_reseller_accounts SET discount_percent=30 WHERE user_id=1");IPSVP_Loyalty::clear_cache();
$manual_hero=IPSVP_Loyalty::hero($ui->hero('',$user->phone,6000000,''),$user->phone,6000000,'');
output_page('loyalty-manual','<div class="ipsvp ipsvp-panel">'.$manual_hero.$nav.'</div>');
$sql->sql->exec("UPDATE test_ipsvp_reseller_accounts SET discount_percent=NULL WHERE user_id=1");IPSVP_Loyalty::clear_cache();
$GLOBALS['test_filters']['ipsvp_admin_user_detail_tabs']=static function($tabs)use($ui){return IPSVP_Loyalty::tabs($ui->tabs($tabs)+array('referral'=>'دعوت دوستان'));};
$_GET=array('ipsvp_tab'=>'loyalty');ob_start();private_call($admin,'user_detail',1);$loyal_admin=ob_get_clean();$_GET=array();
output_page('loyalty-admin','<div class="ipsvp-admin">'.$loyal_admin.'</div>',$admin_style,file_get_contents($plugin.'/assets/js/admin-user.js'));
ob_start();IPSVP_Loyalty::settings_page();$settings_html=ob_get_clean();output_page('loyalty-settings',$settings_html,$admin_style);
$sql->sql->exec('DELETE FROM test_ipsvp_reseller_accounts');IPSVP_Loyalty::clear_cache();
$normal_hero=private_call($frontend,'render_panel_hero',$user->phone);
output_page('loyalty-customer','<div class="ipsvp ipsvp-panel">'.IPSVP_Loyalty::hero($normal_hero,$user->phone,6000000,'').'</div>');
echo "PASS: real loyalty settings, customer/reseller headers and admin detail rendered.\n";

<?php
/** Real shop pricing, reseller service and admin review with isolated storage. */
if (PHP_SAPI !== 'cli') { exit; }
require __DIR__ . '/reseller-test.php';
function wp_timezone() { return new DateTimeZone('Asia/Tehran'); }
function wp_date($format, $timestamp, $timezone = null) { return (new DateTimeImmutable('@' . $timestamp))->setTimezone($timezone ?: wp_timezone())->format($format); }
function get_option($key, $default = false) { return $GLOBALS['loyalty_options'][$key] ?? $default; }
require __DIR__ . '/../includes/class-ipsvp-loyalty.php';
class LoyaltySql extends FakeWpdb {
    public $first_purchase = false;
    public $server_payments = array();
    public function get_row($q) {
        if (strpos($q[0], 'FROM test_ipsvp_users WHERE id=') !== false) { return (object) array('id'=>1,'phone'=>'+989123456789'); }
        if (strpos($q[0], 'FROM test_ipsvp_receipts WHERE id=') !== false) { return isset($this->rows['test_ipsvp_receipts'][$q[1][0]]) ? (object) $this->rows['test_ipsvp_receipts'][$q[1][0]] : null; }
        return parent::get_row($q);
    }
    public function get_results($q) {
        if (strpos($q[0], 'FROM test_server_payments') !== false) { return $this->server_payments; }
        if (strpos($q[0], 'SELECT id,type,amount,status,remote_source') === 0) {
            return array_values(array_map(static function ($r) { return (object) $r; }, array_filter($this->rows['test_ipsvp_receipts'] ?? array(), static function ($r) use ($q) { return (int) $r['user_id'] === (int) $q[1][0]; })));
        }
        return parent::get_results($q);
    }
    public function get_var($q) {
        if (strpos($q[0], 'SELECT id FROM test_ipsvp_orders WHERE user_id=') === 0) { return $this->first_purchase ? 1 : null; }
        return parent::get_var($q);
    }
}
list($db,$u,$api,$service,$ui)=fixture();
$sql=new LoyaltySql();$sql->rows=$GLOBALS['wpdb']->rows;$sql->ids=$GLOBALS['wpdb']->ids;$GLOBALS['wpdb']=$sql;
IPSVP_Loyalty::init($db);
$sql->rows['test_ipsvp_reseller_accounts'][1]['discount_percent']=null;
$at=wp_date('Y-m-d H:i:s',time()-86400);
$sql->rows['test_ipsvp_receipts'][100]=array('id'=>100,'user_id'=>1,'type'=>'wallet','amount'=>6000000,'status'=>'approved','wallet_effect'=>'local','remote_source'=>'','created_at'=>$at,'reviewed_at'=>$at);
$sql->rows['test_ipsvp_receipts'][101]=array_replace($sql->rows['test_ipsvp_receipts'][100],array('id'=>101,'user_id'=>2,'amount'=>99000000));
$db->credit=20000000;$GLOBALS['session_phone']=$u->phone;$real_db=new IPSVP_DB();
same(IPSVP_Reseller_Store::approved(1)->discount_percent,10.0,'Automatic reseller account returns current effective rate');
same(IPSVP_Reseller_Store::account(1)->discount_percent,null,'Reading current rate does not overwrite manual setting');
same($service->quote($u,'purchase',array('plan_id'=>1,'country_id'=>1))['amount'],90000,'Service quote uses automatic tier');
same($real_db->final_price($db->get_plan(1)),90000,'Storefront matches API quote');
$op=buy($service,$u);same((int)$op->amount,90000,'Actual operation records discounted amount');same((float)$op->discount_percent,10.0,'Actual operation snapshots rate');
IPSVP_Loyalty::clear_cache();same(IPSVP_Loyalty::profile(1)['percent'],10.0,'Service debit cannot reduce earned tier');
$sql->rows['test_ipsvp_receipts'][102]=array_replace($sql->rows['test_ipsvp_receipts'][100],array('id'=>102,'type'=>'wallet_admin_debit','amount'=>2000000,'remote_source'=>'admin_wallet_adjustment','created_at'=>wp_date('Y-m-d H:i:s',time()),'reviewed_at'=>wp_date('Y-m-d H:i:s',time())));
IPSVP_Loyalty::clear_cache();same($service->quote($u,'purchase',array('plan_id'=>1,'country_id'=>1))['amount'],95000,'Admin correction changes subsequent server-side quote');
error_is($service->execute($u,'purchase',array('plan_id'=>1,'country_id'=>1,'max_amount'=>90000),'second-new-key-1234567890'),'price_changed');
$replay=buy($service,$u);same((int)$replay->amount,90000,'Idempotent replay retains original price after tier changes');
$_POST=array('status'=>'approved','discount_percent'=>'0','review_note'=>'manual');
check(!is_wp_error(private_call($ui,'admin_action',$u,'review')),'Admin can explicitly set zero');same($real_db->final_price($db->get_plan(1)),100000,'Explicit zero overrides automatic pricing');
$_POST['discount_percent']='';check(!is_wp_error(private_call($ui,'admin_action',$u,'review')),'Admin can clear override');same(IPSVP_Reseller_Store::account(1)->discount_percent,null,'Blank persisted as SQL NULL');same($real_db->final_price($db->get_plan(1)),95000,'Blank restores automatic pricing');
$_POST['discount_percent']='17.5';check(!is_wp_error(private_call($ui,'admin_action',$u,'review')),'Manual decimal accepted');same($real_db->final_price($db->get_plan(1)),82500,'Manual decimal used exactly');
$_POST['discount_percent']='100.01';error_is(private_call($ui,'admin_action',$u,'review'),'invalid_review');
unset($sql->rows['test_ipsvp_reseller_accounts'][1]);IPSVP_Loyalty::clear_cache();
same($real_db->final_price($db->get_plan(1)),95000,'Ordinary customer tier applied at actual pricing entry');
same(IPSVP_Loyalty::profile(1)['largest'],4000000,'Another user deposit cannot affect level');
$GLOBALS['session_phone']='';same($real_db->final_price($db->get_plan(1)),100000,'Guest never inherits customer price');
$sql->rows['test_ipsvp_receipts']=array();$sql->first_purchase=true;IPSVP_Loyalty::clear_cache();same(IPSVP_Loyalty::profile(1)['stars'],1,'First-purchase badge reads successful purchase evidence');
$remote_adjustment=$real_db->admin_adjust_wallet(1,'credit',6000000,'manual','remote');
check(is_object($remote_adjustment) && !is_wp_error($remote_adjustment),'Remote manual adjustment stored');
same($remote_adjustment->remote_source,'admin_wallet_pending','Unconfirmed remote adjustment cannot qualify');
same(IPSVP_Loyalty::profile(1)['percent'],0.0,'Pending remote adjustment excluded from customer level');
$sql->fail_update='test_ipsvp_receipts';check(!$real_db->confirm_admin_wallet_adjustment($remote_adjustment->id),'Confirmation write failure reported');
same(IPSVP_Loyalty::profile(1)['percent'],0.0,'Failed confirmation does not grant level');
$sql->fail_update='';check($real_db->confirm_admin_wallet_adjustment($remote_adjustment->id),'Successful remote confirmation recorded');
same(IPSVP_Loyalty::profile(1)['percent'],10.0,'Only confirmed remote adjustment qualifies');
check(!$real_db->confirm_admin_wallet_adjustment($remote_adjustment->id),'Confirmation replay cannot refresh approval timestamp');
class OverrideShop extends ShopDouble {
    public function tables() { return parent::tables() + array('users'=>'test_ipsvp_users'); }
    public function get_user_by_id($id) { global $wpdb; return isset($wpdb->rows['test_ipsvp_users'][$id]) ? (object)$wpdb->rows['test_ipsvp_users'][$id] : null; }
}
$override_db=new OverrideShop();$sql->rows['test_ipsvp_users'][1]=(array)$u;IPSVP_Loyalty::init($override_db);
foreach(array('101','-1','1.001','bad',array('10')) as $bad){same(IPSVP_Loyalty::save_override(1,$bad)->get_error_code(),'invalid_discount','Invalid manual discount rejected');}
same(IPSVP_Loyalty::save_override(999,'20')->get_error_code(),'missing_user','Unknown user rejected');
check(IPSVP_Loyalty::save_override(1,'7.5')===true,'Customer fixed discount saved');
same(IPSVP_Loyalty::profile(1)['percent'],7.5,'Customer fixed discount read from persistent field');
same(IPSVP_Loyalty::profile(1)['source'],'manual','Customer fixed source');
same(IPSVP_Loyalty::profile(1)['stars'],2,'Customer manual stars match percentage');
$GLOBALS['session_phone']=$u->phone;same($real_db->final_price($db->get_plan(1)),92500,'Next customer purchase uses fixed discount');
$sql->fail_update='test_ipsvp_users';same(IPSVP_Loyalty::save_override(1,'20')->get_error_code(),'discount_save_failed','Write failure reported');same(IPSVP_Loyalty::profile(1)['percent'],7.5,'Failed save preserves old rate');$sql->fail_update='';
check(IPSVP_Loyalty::save_override(1,'0')===true,'Explicit customer zero saved');same($real_db->final_price($db->get_plan(1)),100000,'Zero overrides earned tier');
check(IPSVP_Loyalty::save_override(1,'')===true,'Clear customer override');same($sql->rows['test_ipsvp_users'][1]['manual_discount_percent'],null,'Empty stored as null');same(IPSVP_Loyalty::profile(1)['percent'],10.0,'Clear restores approved-deposit tier');
$sql->rows['test_ipsvp_reseller_accounts'][1]=array('id'=>1,'user_id'=>1,'status'=>'approved','discount_percent'=>null);
check(IPSVP_Loyalty::save_override(1,'30')===true,'Common form saves reseller override');same(IPSVP_Reseller_Store::account(1)->discount_percent,'30','Reseller forms share same field');same(IPSVP_Loyalty::profile(1)['stars'],4,'Existing reseller manual 30 earns all four stars');
unset($sql->rows['test_ipsvp_reseller_accounts'][1]);
$sql->rows['test_ipsvp_receipts'][999]=array('id'=>999,'user_id'=>1,'type'=>'renewal','amount'=>4000000,'status'=>'approved','remote_source'=>'','attachment_id'=>42,'remote_payload'=>'{"payment_method":"card"}','created_at'=>$at,'reviewed_at'=>$at);
IPSVP_Loyalty::clear_cache();same(IPSVP_Loyalty::profile(1)['total'],10000000,'Profile query includes approved direct renewal alongside topup');same($real_db->final_price($db->get_plan(1)),80000,'Ten million approved payments reaches twenty percent on next purchase');
function update_option($key,$value,$autoload=false){$GLOBALS['loyalty_options'][$key]=$value;}
$legacy=IPSVP_Loyalty::defaults();$legacy['customer'][1]['strict']=1;$legacy['customer'][3]['strict']=1;$GLOBALS['loyalty_options'][IPSVP_Loyalty::OPTION]=$legacy;
IPSVP_Loyalty::migrate_settings();same(IPSVP_Loyalty::settings()['customer'][1]['strict'],0,'Saved legacy two-million boundary migrated');same(IPSVP_Loyalty::settings()['customer'][3]['strict'],0,'Saved legacy ten-million boundary migrated');
$legacy['customer'][1]['percent']=6;$GLOBALS['loyalty_options'][IPSVP_Loyalty::OPTION]=$legacy;IPSVP_Loyalty::migrate_settings();same(IPSVP_Loyalty::settings()['customer'][1]['percent'],6.0,'Customized schedule preserved');
if (!function_exists('ips_server_tables')) { function ips_server_tables(){return array('orders'=>'test_server_orders','payments'=>'test_server_payments');} }
$sql->server_payments=array((object)array('id'=>1,'amount'=>2000000,'status'=>'approved','created_at'=>$at,'reviewed_at'=>$at));
IPSVP_Loyalty::clear_cache();same(IPSVP_Loyalty::profile(1)['total'],12000000,'Approved server card payment contributes once to customer activity');
echo "PASS: $checks total reseller and loyalty integration assertions.\n";

<?php
/** Run: php tests/sanaei-api-test.php. No WordPress database or network required. */
if (PHP_SAPI !== 'cli' && !defined('IPSVP_TEST_RUN')) { exit; }
define('ABSPATH', '/');
define('MINUTE_IN_SECONDS', 60);
define('DAY_IN_SECONDS', 86400);
set_error_handler(static function ($severity, $message, $file, $line) { throw new ErrorException($message, 0, $severity, $file, $line); });
class WP_Error {
    private $code; private $message; private $data;
    public function __construct($code, $message, $data = null) { $this->code = $code; $this->message = $message; $this->data = $data; }
    public function get_error_code() { return $this->code; }
    public function get_error_message() { return $this->message; }
    public function get_error_data() { return $this->data; }
}
class IPSVP_Settings { public static function get() { return $GLOBALS['settings']; } }
function is_wp_error($x) { return $x instanceof WP_Error; }
function wp_json_encode($x, $flags = 0) { return json_encode($x, $flags); }
function sanitize_key($x) { return strtolower(preg_replace('/[^a-zA-Z0-9_-]/', '', $x)); }
function sanitize_text_field($x) { return trim($x); }
function wp_parse_url($x) { return parse_url($x); }
function esc_url_raw($x) { return $x; }
function get_transient($key) { return $GLOBALS['cache'][$key] ?? false; }
function set_transient($key, $value, $ttl) { $GLOBALS['cache'][$key] = $value; }
function delete_transient($key) { unset($GLOBALS['cache'][$key]); }
function wp_remote_retrieve_response_code($x) { return $x['status']; }
function wp_remote_retrieve_body($x) { return $x['body']; }
function wp_remote_retrieve_cookies($x) { return $x['cookies'] ?? array(); }
function reply($obj = array(), $status = 200, $success = true) { return array('status' => $status, 'body' => json_encode(array('success' => $success, 'obj' => $obj))); }
function wp_remote_post($url, $args) { $args['method'] = 'POST'; return wp_remote_request($url, $args); }
function wp_remote_request($url, $args) {
    $GLOBALS['requests'][] = array($url, $args);
    return ($GLOBALS['http'])($url, $args);
}
require __DIR__ . '/../includes/class-ipsvp-pasarguard-api.php';
require __DIR__ . '/../includes/class-ipsvp-sanaei-api.php';
require __DIR__ . '/../includes/class-ipsvp-bot-api.php';
$checks = 0;
function check($condition, $message) { global $checks; $checks++; if (!$condition) { throw new RuntimeException($message); } }
function same($actual, $expected, $message) { check($actual === $expected, $message . ': ' . json_encode($actual)); }
function fixture($mode = 'legacy') {
    $GLOBALS['settings'] = array('sanaei_panel_url' => 'https://sanaei.example:2053/secret/panel/api/openapi.json', 'sanaei_token' => 'test-token', 'sanaei_username' => 'admin', 'sanaei_password' => 'secret', 'sanaei_ssl_verify' => '1', 'panel_url' => 'https://pg.example:8000', 'panel_username' => 'admin', 'panel_password' => 'pg-secret', 'ssl_verify' => '1', 'client_type' => 'links');
    $GLOBALS['cache'] = $GLOBALS['requests'] = $GLOBALS['writes'] = array();
    $GLOBALS['mode'] = $mode;
    $GLOBALS['client'] = array('id' => '11111111-1111-4111-8111-111111111111', 'email' => '12345', 'enable' => true, 'totalGB' => 10 * 1073741824, 'expiryTime' => (time() + 10 * DAY_IN_SECONDS) * 1000, 'subId' => 'stable-sub', 'flow' => 'xtls-rprx-vision', 'limitIp' => 2, 'tgId' => 0, 'reset' => 0, 'comment' => 'keep me', 'customField' => 'preserve');
    $GLOBALS['traffic'] = array('email' => '12345', 'inboundId' => 7, 'up' => 1073741824, 'down' => 2 * 1073741824, 'enable' => true);
    $GLOBALS['inbound_ids'] = array(7);
    $GLOBALS['inbound_enabled'] = true;
    $GLOBALS['http'] = static function ($url, $args) {
        $prefix = 'https://sanaei.example:2053/secret';
        check(strpos($url, $prefix) === 0, 'Sanaei order must never access PasarGuard');
        $path = substr($url, strlen($prefix));
        if ($path === '/login') { $r = reply(); $r['cookies'] = array('test-cookie'); return $r; }
        if ($path === '/csrf-token') { return $GLOBALS['mode'] === 'legacy' ? reply(null, 404, false) : reply('test-csrf'); }
        if ($path === '/panel/api/inbounds/get/7') { return reply(array('id' => 7, 'protocol' => 'vless', 'enable' => $GLOBALS['inbound_enabled'], 'settings' => json_encode(array('clients' => array($GLOBALS['client']))))); }
        if ($path === '/panel/api/clients/get/12345') {
            if ($GLOBALS['mode'] === 'legacy') { return reply(null, 404, false); }
            $c = $GLOBALS['client']; $c['uuid'] = $c['id']; $c['id'] = 99;
            $c['allowedIPs'] = isset($c['allowedIPs']) && is_array($c['allowedIPs']) ? implode(',', $c['allowedIPs']) : '';
            $c['reverse'] = empty($c['reverse']) ? '' : json_encode($c['reverse']);
            $c['createdAt'] = 1700000000000;
            return reply(array('client' => $c, 'inboundIds' => $GLOBALS['inbound_ids'], 'usedTraffic' => 3 * 1073741824));
        }
        if ($path === '/panel/api/inbounds/getClientTraffics/12345' || $path === '/panel/api/clients/traffic/12345') { return reply($GLOBALS['traffic']); }
        if ($path === '/panel/api/clients/subLinks/stable-sub') { return reply(array('vless://stable@host:443#sample')); }
        if (strpos($path, '/panel/api/inbounds/updateClient/') === 0 || $path === '/panel/api/clients/update/12345') {
            $payload = json_decode($args['body'], true);
            if (isset($payload['settings'])) {
                same($payload['id'], 7, 'Only assigned inbound may be updated');
                $payload = json_decode($payload['settings'], true)['clients'][0];
            }
            if ($GLOBALS['mode'] === 'modern') {
                // ClientRecord reads CSV/string fields; Go's write model rejects those shapes.
                if (!is_array($payload['allowedIPs'] ?? null) || (isset($payload['reverse']) && !is_array($payload['reverse']))) {
                    $r = reply(null, 200, false); $r['body'] = json_encode(array('success'=>false,'msg'=>'json: cannot unmarshal string into Go struct field Client.allowedIPs of type []string')); return $r;
                }
                same($payload['created_at'], 1700000000000, 'Creation time survives record-to-client conversion');
            }
            $GLOBALS['writes'][] = $payload; $GLOBALS['client'] = $payload;
            return reply();
        }
        throw new RuntimeException('Unexpected request: ' . $path);
    };
    return (object) array('id' => 1, 'service_type' => 'dedicated', 'panel_provider' => 'sanaei', 'panel_inbound_id' => 7, 'pg_username' => '12345', 'pg_user_id' => $GLOBALS['client']['id'], 'pg_subscription_url' => 'https://sub.example/stable-sub', 'pg_links' => json_encode(array('vless://stable@host:443#sample')));
}
$api = new IPSVP_PasarGuard_API();
same(IPSVP_Sanaei_API::normalize_url('https://host:2053/secret/panel/api/openapi.json?x=1#x'), 'https://host:2053/secret', 'Preserve secret base path');
same(IPSVP_Sanaei_API::normalize_url('host:2053/secret/'), 'https://host:2053/secret', 'Normalize base URL');
check(!IPSVP_Sanaei_API::is_order((object) array('service_type' => 'dedicated')), 'Legacy defaults to PG');
check(!IPSVP_Sanaei_API::is_order((object) array('service_type' => 'shared', 'panel_provider' => 'sanaei')), 'Shared stays PG');
foreach (array('legacy', 'modern') as $mode) {
    $o = fixture($mode); $original = $GLOBALS['client'];
    $s = $api->user_snapshot($o->pg_username, $o->pg_user_id, $o);
    same($s['used'], 3 * 1073741824, 'Upload plus download');
    same($s['limit'], 10 * 1073741824, 'totalGB is bytes');
    same($s['expire'], (int) ($original['expiryTime'] / 1000), 'Milliseconds to seconds');
    same($s['status'], 'active', 'Active status');
    same($s['username'], '12345', 'Numeric email stays an email');
    same(count($GLOBALS['writes']), 0, 'Snapshot is read-only');
    $r = $api->add_extra_volume_for_order($o, 5);
    same($r['new_limit'], 15 * 1073741824, 'Add quota');
    same($GLOBALS['client']['expiryTime'], $original['expiryTime'], 'Extra volume preserves expiry');
    foreach (array('id','email','subId','flow','limitIp','comment','customField') as $key) { same($GLOBALS['client'][$key], $original[$key], 'Preserve ' . $key); }
    same($r['subscription_url'], $o->pg_subscription_url, 'Keep subscription URL');
    same($r['links'], json_decode($o->pg_links, true), 'Keep config');
    $r = $api->extend_user_for_order($o, (object) array('days' => 30, 'gb' => 20));
    same($GLOBALS['client']['expiryTime'], $original['expiryTime'] + 30 * DAY_IN_SECONDS * 1000, 'Extend from future expiry');
    same($r['new_limit'], 35 * 1073741824, 'Renewal adds quota without resetting traffic');
    same($GLOBALS['traffic']['up'], 1073741824, 'Usage preserved');
    same($api->update_user_status_for_order($o, 'disabled')['pg_status'], 'disabled', 'Disable client');
    same($api->update_user_status_for_order($o, 'active')['pg_status'], 'active', 'Enable client');
    $GLOBALS['client']['expiryTime'] = -30 * DAY_IN_SECONDS * 1000;
    same($api->user_snapshot('', '', $o)['status'], 'on_hold', 'Negative expiry means first use');
    same($api->user_snapshot('', '', $o)['expire'], 0, 'On-hold must not appear expired');
    $api->extend_user_for_order($o, (object) array('days' => 10, 'gb' => 1));
    same($GLOBALS['client']['expiryTime'], -40 * DAY_IN_SECONDS * 1000, 'Renew on-hold without starting countdown');
    $GLOBALS['client']['expiryTime'] = (time() - DAY_IN_SECONDS) * 1000;
    $before = time(); $api->extend_user_for_order($o, (object) array('days' => 5, 'gb' => 1));
    check($GLOBALS['client']['expiryTime'] >= ($before + 5 * DAY_IN_SECONDS) * 1000, 'Expired renews from now');
    $GLOBALS['client']['totalGB'] = 0;
    same($api->user_snapshot('', '', $o)['limit'], 0, 'Unlimited quota remains zero');
    check(is_wp_error($api->add_extra_volume_for_order($o, 5)), 'Reject buying quota for unlimited');
    $api->extend_user_for_order($o, (object) array('days' => 5, 'gb' => 10));
    same($GLOBALS['client']['totalGB'], 0, 'Renewal preserves unlimited quota');
    $GLOBALS['client']['totalGB'] = 2 * 1073741824;
    same($api->user_snapshot('', '', $o)['status'], 'limited', 'Detect exhausted quota');
    $GLOBALS['client']['expiryTime'] = (time() - 1) * 1000;
    same($api->user_snapshot('', '', $o)['status'], 'expired', 'Detect expiry');
    $count = count($GLOBALS['writes']);
    check(is_wp_error($api->update_user_status_for_order($o, 'volume_finished')), 'Derived status cannot silently destroy quota');
    $o->pg_user_id = 'other-client';
    check(is_wp_error($api->add_extra_volume_for_order($o, 5)), 'Reject changed client identity');
    same(count($GLOBALS['writes']), $count, 'Invalid identity/status does not mutate');
}
$o = fixture('modern'); $o->pg_links = '[]';
same($api->user_snapshot('', '', $o)['links'], array('vless://stable@host:443#sample'), 'Read native subscription links');
$GLOBALS['inbound_ids'] = array(7, 8);
check(is_wp_error($api->extend_user_for_order($o, (object) array('days' => 30, 'gb' => 10))), 'Reject client spanning other inbounds');
same(count($GLOBALS['writes']), 0, 'Other inbounds never mutated');
$o = fixture(); $GLOBALS['traffic']['inboundId'] = 8;
check(is_wp_error($api->add_extra_volume_for_order($o, 1)), 'Reject traffic from another inbound');
$o = fixture('modern'); $GLOBALS['settings']['sanaei_token'] = '';
$api->add_extra_volume_for_order($o, 1);
$last = end($GLOBALS['requests']);
same($last[1]['headers']['X-CSRF-Token'], 'test-csrf', 'Cookie mutations use CSRF token');
same($last[1]['cookies'], array('test-cookie'), 'Cookie session retained');
$o = fixture(); $original_http = $GLOBALS['http'];
$GLOBALS['http'] = static function ($url, $args) use ($original_http) {
    if (($args['method'] ?? '') === 'POST') { $GLOBALS['writes'][] = 'timeout'; return new WP_Error('timeout', 'timeout'); }
    return $original_http($url, $args);
};
check(is_wp_error($api->add_extra_volume_for_order($o, 1)), 'Timeout returned to caller');
same(count($GLOBALS['writes']), 1, 'Mutation is not retried after timeout');
$o = fixture();
$GLOBALS['http'] = static function () { return reply(null, 200, false); };
check(!empty($api->user_snapshot('', '', $o)['error']), 'HTTP 200 success:false rejected');
same(count($GLOBALS['writes']), 0, 'Invalid response does not mutate');
$o = fixture();
same(IPSVP_Bot_API::import_site_order($o)['skipped'], 'sanaei_site_managed', 'Sanaei never imported into PG-only bot');
same(count($GLOBALS['requests']), 0, 'No bot request sent');
// Actual existing PasarGuard adapter: both missing and explicit provider use the original routes.
foreach (array(null, 'pasarguard') as $provider) {
    fixture();
    $o = (object) array('service_type' => 'dedicated', 'pg_username' => 'old-user', 'pg_user_id' => '42', 'order_code' => 'TEST-1', 'phone' => '09000000000');
    if ($provider !== null) { $o->panel_provider = $provider; }
    $GLOBALS['http'] = static function ($url, $args) {
        check(strpos($url, 'https://pg.example:8000/') === 0, 'Legacy order never calls Sanaei');
        if (strpos($url, '/api/admin/token') !== false) { return array('status' => 200, 'body' => json_encode(array('access_token' => 'pg-token'))); }
        if (strpos($url, '/subscription/') !== false) { return array('status' => 200, 'body' => 'vless://old@host:443'); }
        return array('status' => 200, 'body' => json_encode(array('id' => 42, 'username' => 'old-user', 'status' => 'active', 'used_traffic' => 100, 'data_limit' => 1000, 'expire' => time() + DAY_IN_SECONDS)));
    };
    same($api->user_snapshot('old-user', '42', $o)['user_id'], '42', 'Existing PG identity preserved');
    check(!is_wp_error($api->update_user_status_for_order($o, 'disabled')), 'Existing PG status endpoint works');
    check(!is_wp_error($api->add_extra_volume_for_order($o, 1)), 'Existing PG extra quota endpoint works');
    check(!is_wp_error($api->extend_user_for_order($o, (object) array('days' => 1, 'gb' => 1))), 'Existing PG renewal endpoint works');
}
// Exercise the real admin assignment handler with isolated storage and redirect stubs.
require __DIR__ . '/../admin/class-ipsvp-admin.php';
class TestRedirect extends RuntimeException {}
function add_action(...$args) {}
function wp_unslash($value) { return $value; }
function admin_url($path) { return 'https://site.example/' . $path; }
function add_query_arg($args, $url) { return $url . '?' . http_build_query($args); }
function wp_safe_redirect($url) { throw new TestRedirect($url); }
function current_user_can($capability) { return $GLOBALS['can_manage'] ?? true; }
function check_admin_referer($action) { if (empty($GLOBALS['nonce_valid'])) { throw new RuntimeException('bad_nonce'); } }
class TestOrderStorage {
    public $order; public $updates = array();
    public function __construct($order) { $this->order = clone $order; }
    public function get_order($id) { return clone $this->order; }
    public function order_service_type($order) { return $order->service_type; }
    public function now() { return '2026-09-09 12:00:00'; }
    public function update_order($id, $data) { $this->updates[] = $data; foreach ($data as $k => $v) { $this->order->$k = $v; } return 1; }
    public function apply_order_lifecycle_snapshot($order, $snapshot) { return $order; }
}
function assign_test($order, $post) {
    $db = new TestOrderStorage($order); $admin = new IPSVP_Admin($db, new IPSVP_PasarGuard_API());
    $_POST = $post; $_REQUEST = array('ipsvp_action' => 'assign_pg_user');
    $GLOBALS['nonce_valid'] = true;
    try { $admin->handle_actions(); } catch (TestRedirect $e) { $GLOBALS['redirect'] = urldecode($e->getMessage()); }
    return $db;
}
$o = fixture(); unset($o->panel_provider, $o->panel_inbound_id); $o->pg_username = 'old-user'; $o->pg_user_id = '42';
$db = assign_test($o, array('order_id'=>1, 'pg_identifier'=>'12345', 'panel_provider'=>'sanaei', 'panel_inbound_id'=>7));
same(count($db->updates), 0, 'Existing PG order cannot be switched to Sanaei');
same(count($GLOBALS['requests']), 0, 'Blocked reassignment never reaches any panel');
$o = fixture();
$db = assign_test($o, array('order_id'=>1, 'pg_identifier'=>'another-user', 'panel_provider'=>'sanaei', 'panel_inbound_id'=>7));
same(count($db->updates), 0, 'Existing Sanaei identity cannot be replaced');
same(count($GLOBALS['requests']), 0, 'Blocked identity change is read-only');
$o = fixture(); $o->pg_username = ''; $o->pg_user_id = ''; $o->payment_status = 'waiting_review'; $o->status = 'pending_receipt';
$db = assign_test($o, array('order_id'=>1, 'pg_identifier'=>'12345', 'panel_provider'=>'sanaei', 'panel_inbound_id'=>7, 'sanaei_configs'=>'vless://stable@host:443#sample'));
same($db->order->panel_provider, 'sanaei', 'New order persists selected provider');
same($db->order->panel_inbound_id, 7, 'New order persists inbound');
same($db->order->pg_user_id, $GLOBALS['client']['id'], 'Assignment uses resolved protocol identity');
same($db->order->status, 'pending_receipt', 'Unpaid assignment is not activated');
same(count($GLOBALS['writes']), 0, 'Unpaid assignment does not enable remote service');
$GLOBALS['requests'] = array(); $GLOBALS['can_manage'] = false;
$admin = new IPSVP_Admin($db, $api); $admin->handle_actions();
same(count($GLOBALS['requests']), 0, 'Non-admin cannot assign');
$GLOBALS['can_manage'] = true; $GLOBALS['nonce_valid'] = false;
try { $admin->handle_actions(); check(false, 'Missing nonce must be rejected'); } catch (RuntimeException $e) { same($e->getMessage(), 'bad_nonce', 'Assignment requires nonce'); }
same(count($GLOBALS['requests']), 0, 'Invalid nonce never reaches a panel');
$_POST = array('sanaei_token'=>'', 'sanaei_password'=>'', 'sanaei_ssl_verify'=>'1');
$save = new ReflectionMethod(IPSVP_Admin::class, 'save_sanaei_settings'); $save->setAccessible(true);
$saved = $save->invoke($admin, $GLOBALS['settings']);
same($saved['sanaei_token'], $GLOBALS['settings']['sanaei_token'], 'Blank token preserves secret');
same($saved['sanaei_password'], $GLOBALS['settings']['sanaei_password'], 'Blank password preserves secret');
same($saved['panel_password'], $GLOBALS['settings']['panel_password'], 'Sanaei settings leave PG credentials intact');
// Manual on-hold/active transitions use the remaining duration, retaining identity and quota.
foreach (array('legacy', 'modern') as $mode) {
    $o = fixture($mode); $before = $GLOBALS['client'];
    $hold = $api->update_user_status_for_order($o, 'on_hold');
    same($hold['pg_status'], 'on_hold', 'Future-dated client can be placed on hold');
    $remaining = abs($GLOBALS['client']['expiryTime']);
    check(abs($remaining - 10 * DAY_IN_SECONDS * 1000) < 3000, 'On hold preserves remaining time');
    same($GLOBALS['client']['totalGB'], $before['totalGB'], 'On hold preserves quota');
    same($api->user_snapshot('', '', $o)['status'], 'on_hold', 'Read after hold stays on hold');
    same($api->update_user_status_for_order($o, 'active')['pg_status'], 'active', 'Activate starts countdown');
    check(abs($GLOBALS['client']['expiryTime'] - time()*1000 - $remaining) < 3000, 'Activation uses preserved duration');
    same($api->update_user_status_for_order($o, 'disabled')['pg_status'], 'disabled', 'Suspend disables account');
    same($api->update_user_status_for_order($o, 'cancelled')['pg_status'], 'disabled', 'Cancel disables without deletion');
    same($GLOBALS['client']['id'], $before['id'], 'Status changes never replace identity');
    same($GLOBALS['client']['subId'], $before['subId'], 'Status changes keep subscription identity');
}
$o = fixture('modern'); $GLOBALS['client']['reverse'] = array('tag'=>'reverse-tag'); $GLOBALS['client']['allowedIPs'] = array('10.0.0.2/32');
check(!is_wp_error($api->update_user_status_for_order($o, 'disabled')), 'Realistic read model can be written');
same($GLOBALS['client']['reverse'], array('tag'=>'reverse-tag'), 'Reverse object retained');
same($GLOBALS['client']['allowedIPs'], array('10.0.0.2/32'), 'Allowed IP list retained');
$o = fixture('modern'); $http = $GLOBALS['http'];
$GLOBALS['http'] = static function ($url, $args) use ($http) {
    if (($args['method'] ?? '') === 'POST') { return array('status'=>200,'body'=>json_encode(array('success'=>false,'msg'=>'cannot unmarshal allowedIPs; test-token secret https://private.example/link'))); }
    return $http($url,$args);
};
$err = $api->update_user_status_for_order($o, 'disabled');
check(is_wp_error($err), 'Panel rejection remains a failure');
check(strpos($err->get_error_message(), 'cannot unmarshal allowedIPs') !== false, 'Error exposes actionable panel reason');
check(strpos($err->get_error_message(), 'test-token') === false && strpos($err->get_error_message(), 'https://private.example') === false, 'Error redacts credentials and links');
// Exercise receipt approval and status synchronization against the real DB transaction method.
require __DIR__ . '/../includes/class-ipsvp-db.php';
require __DIR__ . '/../includes/class-ipsvp-receipt-manager.php';
function current_time($type) { return '2026-09-10 12:00:00'; }
function sanitize_textarea_field($text) { return trim($text); }
function apply_filters($name, $value, ...$args) { return $value; }
function do_action($name, ...$args) { $GLOBALS['events'][] = $name; }
function home_url($path) { return 'https://site.example' . $path; }
class IPSVP_Telegram_Service { public static function send_telegram_success_payment_report($id, $db) { $GLOBALS['payment_reports'][] = $id; } }
class TestPaymentWpdb {
    public $prefix = 'test_'; public $order; public $receipts = array(); public $last_error = ''; public $queries = array(); public $fail_receipt = false; public $fail_order = false; private $backup;
    public function prepare($sql, ...$args) {
        if (count($args) === 1 && is_array($args[0])) { $args = $args[0]; }
        $i = 0; return preg_replace_callback('/%[ds]/', static function ($m) use ($args, &$i) { $value = $args[$i++]; return $m[0] === '%d' ? (string) (int) $value : "'" . addslashes($value) . "'"; }, $sql);
    }
    public function get_row($sql) { return clone $this->order; }
    public function get_results($sql) {
        check(strpos($sql, "type='new'") !== false && strpos($sql, "status='pending'") !== false, 'Automatic confirmation query only selects pending initial receipts');
        preg_match('/order_id=(\d+)/', $sql, $o); preg_match('/ AND id=(\d+)/', $sql, $id);
        return array_values(array_map(static function ($r) { return clone $r; }, array_filter($this->receipts, static function ($r) use ($o, $id) { return (int) $r->order_id === (int) $o[1] && $r->type === 'new' && $r->status === 'pending' && (!$id || (int) $r->id === (int) $id[1]); })));
    }
    public function query($sql) {
        $this->queries[] = $sql;
        if ($sql === 'START TRANSACTION') { $this->backup = array(clone $this->order, array_map(static function ($r) { return clone $r; }, $this->receipts)); }
        if ($sql === 'ROLLBACK') { $this->order = $this->backup[0]; $this->receipts = $this->backup[1]; }
        return 0;
    }
    public function update($table, $data, $where) {
        $is_order = substr($table, -12) === 'ipsvp_orders';
        if (($is_order && $this->fail_order) || (!$is_order && $this->fail_receipt)) { return false; }
        $row = $is_order ? $this->order : ($this->receipts[$where['id']] ?? null);
        if (!$row) { return 0; }
        foreach ($where as $key => $value) { if ((string) ($row->$key ?? '') !== (string) $value) { return 0; } }
        foreach ($data as $key => $value) { $row->$key = $value; }
        return 1;
    }
}
class TestPaymentStorage extends TestOrderStorage {
    public function tables() { return (new IPSVP_DB())->tables(); }
    public function get_receipt($id) { return isset($GLOBALS['wpdb']->receipts[$id]) ? clone $GLOBALS['wpdb']->receipts[$id] : null; }
    public function confirm_dedicated_order_payment($id, array $data, $receipt_id = 0) { return (new IPSVP_DB())->confirm_dedicated_order_payment($id, $data, $receipt_id); }
    public function create_user_notification(...$args) { $GLOBALS['notifications'][] = $args; }
    public function add_log(...$args) {}
    public function status_label($status) { return (new IPSVP_DB())->status_label($status); }
}
function payment_fixture() {
    $o = fixture('modern');
    foreach (array('payment_status'=>'waiting_review','status'=>'pending_receipt','approved_at'=>null,'phone'=>'09000000000','user_id'=>5,'order_code'=>'TEST-1','days'=>30,'pg_status'=>'active','admin_note'=>'') as $key=>$value) { $o->$key = $value; }
    $db = new TestPaymentStorage($o);
    $GLOBALS['wpdb'] = new TestPaymentWpdb(); $GLOBALS['wpdb']->order =& $db->order;
    foreach (array(10=>'new',11=>'renewal',12=>'extra_volume') as $id=>$type) {
        $GLOBALS['wpdb']->receipts[$id] = (object) array('id'=>$id,'order_id'=>1,'status'=>'pending','type'=>$type,'phone'=>$o->phone,'user_id'=>$o->user_id);
    }
    $GLOBALS['events'] = $GLOBALS['notifications'] = $GLOBALS['payment_reports'] = array();
    $GLOBALS['nonce_valid'] = $GLOBALS['can_manage'] = true;
    return $db;
}
function admin_action_test($db, $action, $post) {
    $_POST = $post; $_REQUEST = array('ipsvp_action'=>$action);
    try { (new IPSVP_Admin($db, new IPSVP_PasarGuard_API()))->handle_actions(); }
    catch (TestRedirect $e) { return urldecode($e->getMessage()); }
    return '';
}
foreach (array('active','on_hold') as $target) {
    $db = payment_fixture();
    $redirect = admin_action_test($db, 'update_order_status', array('order_id'=>1,'order_status'=>$target));
    same($db->order->status, $target, 'Manual status persisted');
    same($db->order->payment_status, 'approved', 'Manual activation confirms payment');
    same($GLOBALS['wpdb']->receipts[10]->status, 'approved', 'Initial receipt approved with status');
    same($GLOBALS['wpdb']->receipts[11]->status, 'pending', 'Renewal not silently approved without applying it');
    same($GLOBALS['wpdb']->receipts[12]->status, 'pending', 'Extra volume not silently approved');
    check(strpos($redirect, 'view=1') !== false, 'Status action returns to same order');
    check(in_array('COMMIT',$GLOBALS['wpdb']->queries,true), 'Local status and receipt transaction committed');
    $request_count_before = count($GLOBALS['requests']);
    $again = IPSVP_Receipt_Manager::approve(10,$db,$api);
    check($again['ok'], 'Already confirmed receipt returns success');
    same(count($GLOBALS['requests']),$request_count_before,'Already confirmed receipt never repeats panel effects');
}
foreach (array('disabled','cancelled') as $target) {
    $db = payment_fixture(); admin_action_test($db,'update_order_status',array('order_id'=>1,'order_status'=>$target));
    same($db->order->status,$target,'Suspend/cancel local status preserved');
    same($GLOBALS['client']['enable'],false,'Suspend/cancel disables remote');
    same($GLOBALS['wpdb']->receipts[10]->status,'pending','Suspend/cancel never approves payment');
}
$db = payment_fixture(); $GLOBALS['http'] = static function () { return reply(null,200,false); };
admin_action_test($db,'update_order_status',array('order_id'=>1,'order_status'=>'active'));
same($db->order->payment_status,'waiting_review','Panel failure leaves payment unchanged');
same($GLOBALS['wpdb']->receipts[10]->status,'pending','Panel failure leaves receipt pending');
same($db->order->status,'pending_receipt','Panel failure leaves local status unchanged');
$db = payment_fixture(); $GLOBALS['wpdb']->fail_receipt = true;
admin_action_test($db,'update_order_status',array('order_id'=>1,'order_status'=>'active'));
same($db->order->status,'pending_receipt','Receipt save failure rolls back local status');
same($db->order->payment_status,'waiting_review','Receipt save failure rolls back payment');
check(in_array('ROLLBACK',$GLOBALS['wpdb']->queries,true),'DB failure rolls back transaction');
$db = payment_fixture();
$redirect = admin_action_test($db,'review_order_receipt',array('order_id'=>1,'receipt_id'=>10,'receipt_decision'=>'approve'));
same($GLOBALS['wpdb']->receipts[10]->status,'approved','Inline approval updates receipt');
same($db->order->status,'active','Inline approval activates assigned order');
check(strpos($redirect,'view=1')!==false,'Inline approval stays on order detail');
$request_count_before = count($GLOBALS['requests']);
admin_action_test($db,'review_order_receipt',array('order_id'=>1,'receipt_id'=>10,'receipt_decision'=>'approve'));
same(count($GLOBALS['requests']),$request_count_before,'Stale inline approval does not repeat remote update');
check(!IPSVP_Receipt_Manager::reject(10,$db)['ok'],'Approved receipt cannot be rejected by stale action');
same($GLOBALS['wpdb']->receipts[10]->status,'approved','Approved payment retained');
$db = payment_fixture();
admin_action_test($db,'review_order_receipt',array('order_id'=>1,'receipt_id'=>10,'receipt_decision'=>'reject'));
same($GLOBALS['wpdb']->receipts[10]->status,'rejected','Inline reject updates receipt');
same($db->order->payment_status,'rejected','Inline reject updates initial order payment');
same(count($GLOBALS['requests']),0,'Rejection does not call an unrelated panel');
$db = payment_fixture();
admin_action_test($db,'review_order_receipt',array('order_id'=>999,'receipt_id'=>10,'receipt_decision'=>'approve'));
same($GLOBALS['wpdb']->receipts[10]->status,'pending','Receipt belonging to another order is rejected');
same(count($GLOBALS['requests']),0,'Cross-order action never calls API');
$db = payment_fixture(); $GLOBALS['nonce_valid'] = false;
try { admin_action_test($db,'review_order_receipt',array('order_id'=>1,'receipt_id'=>10,'receipt_decision'=>'approve')); check(false,'Nonce must be required'); }
catch (RuntimeException $e) { same($e->getMessage(),'bad_nonce','Inline action checks nonce'); }
same(count($GLOBALS['requests']),0,'Invalid nonce has no panel effects');
// An already applied renewal remains idempotent even if its order has since been cancelled.
$db = payment_fixture(); $db->order->status = 'cancelled'; $GLOBALS['wpdb']->receipts[11]->status = 'approved';
check(IPSVP_Receipt_Manager::approve(11,$db,$api)['ok'],'Finalized renewal recognized after cancellation');
same(count($GLOBALS['requests']),0,'Finalized renewal cannot grant time twice');

// Old dedicated PasarGuard orders retain their provider while sharing receipt confirmation.
foreach (array('active','on_hold') as $target) {
    $db = payment_fixture(); unset($db->order->panel_provider);
    $db->order->pg_username = 'old-user'; $db->order->pg_user_id = '42';
    $db->order->approved_at = '2026-08-01 12:00:00';
    $GLOBALS['http'] = static function ($url, $args) {
        check(strpos($url, 'https://pg.example:8000/') === 0, 'Old order payment action never reaches Sanaei');
        if (strpos($url, '/api/admin/token') !== false) { return array('status'=>200,'body'=>json_encode(array('access_token'=>'pg-token'))); }
        if (strpos($url, '/subscription/') !== false) { return array('status'=>200,'body'=>'vless://old@host:443'); }
        return array('status'=>200,'body'=>json_encode(array('id'=>42,'username'=>'old-user','status'=>'active','used_traffic'=>100,'data_limit'=>1000,'expire'=>time()+DAY_IN_SECONDS)));
    };
    admin_action_test($db,'update_order_status',array('order_id'=>1,'order_status'=>$target));
    same($db->order->status,$target,'Legacy order status updated');
    same($GLOBALS['wpdb']->receipts[10]->status,'approved','Legacy order initial receipt confirmed');
    same($db->order->pg_user_id,'42','Legacy panel identity retained');
    same($db->order->approved_at,'2026-08-01 12:00:00','Original payment timestamp retained');
}
$db = payment_fixture(); $GLOBALS['wpdb']->fail_order = true;
$result = IPSVP_Receipt_Manager::approve(10,$db,$api);
check(!$result['ok'],'Order save error cannot report payment success');
same($GLOBALS['wpdb']->receipts[10]->status,'pending','Order save error leaves receipt pending');
same(count($GLOBALS['payment_reports']),0,'Failed commit does not send success report');
$db = payment_fixture(); $GLOBALS['http'] = static function () { return reply(null,200,false); };
$result = IPSVP_Receipt_Manager::approve(10,$db,$api);
check(!$result['ok'],'Receipt approval reports panel failure');
check(strpos($result['message'],'پاسارگارد')===false,'Sanaei approval errors do not name PasarGuard');
same($GLOBALS['wpdb']->receipts[10]->status,'pending','Failed panel activation never confirms receipt');

echo "PASS: $checks assertions\n";

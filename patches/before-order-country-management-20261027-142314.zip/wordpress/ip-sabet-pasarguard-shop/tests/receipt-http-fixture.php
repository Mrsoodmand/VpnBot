<?php
/** Isolated local HTTP fixture. No WordPress config, database or external provider is loaded. */
if (PHP_SAPI !== 'cli-server' || !getenv('IPSR_RECEIPT_TEST_DIR')) { http_response_code(404); exit; }
define('ABSPATH', '/'); define('DAY_IN_SECONDS', 86400); define('WP_CONTENT_DIR', getenv('IPSR_RECEIPT_TEST_DIR'));
class WP_Error { private $code; private $message; public function __construct($code,$message){$this->code=$code;$this->message=$message;} public function get_error_code(){return $this->code;} public function get_error_message(){return $this->message;} }
function is_wp_error($x){return $x instanceof WP_Error;}
function add_action(...$a){} function add_filter(...$a){} function add_shortcode(...$a){}
function apply_filters($hook,$value){return $value;}
function sanitize_key($s){return preg_replace('/[^a-z0-9_-]/','',strtolower($s));}
function sanitize_text_field($s){return trim(strip_tags($s));}
function sanitize_file_name($s){return basename($s);}
function wp_unslash($s){return $s;}
function esc_url_raw($s){return $s;} function esc_attr($s){return htmlspecialchars((string)$s,ENT_QUOTES);}
function esc_html($s){return esc_attr($s);} function size_format($n){return (string)$n;}
function wp_max_upload_size(){return 2*1024*1024;}
function wp_salt($scheme){return 'local-fixture-only';}
function wp_date($format,$time=null){return gmdate($format,$time??time());}
function trailingslashit($s){return rtrim($s,'/').'/';} function untrailingslashit($s){return rtrim($s,'/');}
function wp_mkdir_p($dir){return is_dir($dir)||mkdir($dir,0700,true);}
function wp_json_encode($v){return json_encode($v);}
function wp_delete_file($p){if(is_file($p))unlink($p);}
function home_url($s){return 'https://example.test'.$s;}
function add_query_arg($key,$val,$url){return $url.'?'.http_build_query(array($key=>$val));}
function wp_get_image_mime($file){$info=getimagesize($file);return $info['mime']??false;}
function nocache_headers(){} function send_nosniff_header(){}
function current_user_can($cap){return false;}
function check_ajax_referer(...$args){return ($_POST['nonce']??'')==='test-nonce';}
function wp_send_json_error($data,$status=200){http_response_code($status);header('Content-Type: application/json');echo json_encode(array('success'=>false,'data'=>$data));exit;}
function wp_send_json_success($data){header('Content-Type: application/json');echo json_encode(array('success'=>true,'data'=>$data));exit;}
class IPSVP_Session {public static function get_phone($db){return isset($_COOKIE['fixture_owner'])&&$_COOKIE['fixture_owner']==='2'?'user2':'user1';}}
class ReceiptTestDB {public function get_user_by_phone($phone){return (object)array('id'=>$phone==='user2'?2:1,'is_blocked'=>0);} public function add_log(...$args){} }
require __DIR__.'/../includes/class-ipsvp-receipt-uploader.php';
require __DIR__.'/../public/class-ipsvp-frontend.php';
$db=new ReceiptTestDB();$front=new IPSVP_Frontend($db,null);
if(($_POST['action']??'')==='ipsvp_receipt_upload'){ $front->ajax_receipt_upload(); }
if(($_POST['action']??'')==='ipsvp_receipt_upload_status'){ $front->ajax_receipt_upload_status(); }
if(($_POST['action']??'')==='native-recovery'){
 $owner=$db->get_user_by_phone(IPSVP_Session::get_phone($db))->id;
 $r=IPSVP_Receipt_Uploader::uploaded_from_request('receipt',$owner);
 if(is_wp_error($r)) wp_send_json_error(array('code'=>$r->get_error_code()),403);
 wp_send_json_success($r);
}
if(($_GET['fixture']??'')==='html'){
 foreach(array('receipt','wallet_receipt','renew_receipt','extra_volume_receipt','server_receipt')as$name) echo '<form id="'.$name.'" method="post" enctype="multipart/form-data">'.IPSVP_Receipt_Uploader::render_field($name,'رسید پرداخت',true).'<button type="submit">ثبت رسید</button></form>';
 exit;
}
http_response_code(404);

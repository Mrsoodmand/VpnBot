<?php
/** Real report SQL against isolated in-memory SQLite; renderer fixtures never call live services. */
require __DIR__ . '/reseller-test.php';
require __DIR__ . '/../admin/class-ipsvp-admin.php';
require __DIR__ . '/../public/class-ipsvp-frontend.php';
require __DIR__ . '/../includes/class-ipsvp-receipt-uploader.php';
function wp_strip_all_tags($s) { return strip_tags($s); }
function current_user_can($cap) { return true; }
function admin_url($path) { return 'https://example.test/wp-admin/' . $path; }
function checked($a, $b, $echo = true) { $s = $a == $b ? 'checked' : ''; if ($echo) echo $s; return $s; }
function get_transient($key) { return true; }
function do_action($hook, ...$args) { if ($hook === 'ipsvp_admin_user_detail_extra_panels') { $GLOBALS['workspace_ui']->admin_user(...$args); if (class_exists('IPSVP_Loyalty')) { IPSVP_Loyalty::admin_user(...$args); } $user = $args[0]; $identity=(object)array('id'=>42); $summary=(object)array('total_referrals'=>0,'paid_commission'=>0); $code='DEMO42';$link='https://example.test/?ref=DEMO42';$bot_link='';$data=array();include dirname(__DIR__,2).'/ip-sabet-referral-addon/templates/admin-user-referral-tab.php'; } }
class WorkspaceSql extends FakeWpdb {
    public $sql; public $queries = array();
    public function __construct($tables) {
        $this->sql = new PDO('sqlite::memory:');
        $this->sql->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        foreach ($tables as $table => $rows) {
            $keys = array(); foreach ($rows as $row) $keys = array_unique(array_merge($keys, array_keys($row)));
            $columns = array_map(static function($k) { return '"'.$k.'" '.(in_array($k,array('id','user_id','order_id','plan_id','country_id','amount','base_amount','price','gb','days'),true)?'INTEGER':'TEXT'); }, $keys);
            $this->sql->exec('CREATE TABLE '.$table.' ('.implode(',', $columns).')');
            foreach ($rows as $row) { $q=$this->sql->prepare('INSERT INTO '.$table.' ('.implode(',',array_keys($row)).') VALUES ('.implode(',',array_fill(0,count($row),'?')).')'); $q->execute(array_values($row)); }
        }
    }
    public function esc_like($s) { return addcslashes($s, '_%\\'); }
    private function run($q) {
        $this->queries[] = $q; list($sql,$args) = $q;
        $sql=preg_replace('/%[dsf]/', '?', $sql);
        // MySQL's implicit LIKE escape character is explicit in SQLite.
        $sql=str_replace('LIKE ?', "LIKE ? ESCAPE '\\'", $sql);
        $stmt=$this->sql->prepare($sql); $stmt->execute($args); return $stmt;
    }
    public function get_row($q) { return $this->run($q)->fetchObject() ?: null; }
    public function get_results($q) { return $this->run($q)->fetchAll(PDO::FETCH_OBJ); }
    public function get_var($q) { if (strpos($q[0], 'RELEASE_LOCK') !== false) return 1; return $this->run($q)->fetchColumn(); }
}
class WorkspaceShop extends ShopDouble {
    public function tables() { return parent::tables()+array('plans'=>'test_ipsvp_plans','countries'=>'test_ipsvp_countries'); }
    public function get_plan($id) { $p=parent::get_plan($id); if($p) { $p->title='۵۰ گیگ · یک‌ماهه'; $p->gb=50; } return $p; }
    public function get_country($id) { $c=parent::get_country($id); if($c) { $c->name='آلمان'; $c->flag='🇩🇪'; } return $c; }
    public function get_local_wallet_balance($id) { return 3400000; }
    public function get_wallet_transactions($id, $limit) { return array((object)array('kind'=>'debit','title'=>'خرید کانفیگ','ref'=>'#601','amount'=>90000,'status'=>'approved','date'=>$this->now(),'note'=>'پرداخت از پنل نمایندگی')); }
    public function get_user_confirmed_purchase_total($id) { return 2250000; }
    public function get_order_payment_method_label($o) { return 'کیف پول'; }
    public function status_label($status) { return (new IPSVP_DB())->status_label($status); }
}
list($seeddb,$user,$provider,$service,$ui) = fixture();
$seedop = buy($service,$user); $seed = $GLOBALS['wpdb']->rows;
$db=new WorkspaceShop(); $db->users[1]=$user;
foreach(array('name'=>'فروشگاه نمونه','password_hash'=>'hashed','blocked_note'=>'','last_seen_at'=>$db->now(),'created_at'=>'2026-01-10 12:00:00') as $k=>$v) $user->$k=$v;
$orders=$ops=array();
for($i=1;$i<=25;$i++) {
    $day=date('Y-m-d',strtotime('-'.(($i*$i)%29).' days'));
    $orders[]=array_replace($seed['test_ipsvp_orders'][1],array('id'=>$i,'order_code'=>'IPS-'.(600+$i),'created_at'=>$day.' 12:00:00','status'=>$i===25?'disabled':'active','pg_username'=>'ips-client-'.$i,'pg_response'=>json_encode(array('used_traffic'=>($i%8)*1073741824,'data_limit'=>53687091200,'expire'=>time()+864000))));
    $ops[]=array_replace($seed['test_ipsvp_reseller_operations'][1],array('id'=>$i,'order_id'=>$i,'channel'=>$i%2?'api':'panel','created_at'=>$day.' 12:00:00','customer_reference'=>$i===3?'client_100%':'client-'.$i));
}
$ops[]=array_replace($ops[0],array('id'=>26,'action'=>'renew','order_id'=>1,'amount'=>90000,'created_at'=>$db->now()));
$ops[]=array_replace($ops[0],array('id'=>27,'state'=>'manual_review','order_id'=>0,'created_at'=>$db->now()));
$ops[]=array_replace($ops[0],array('id'=>28,'user_id'=>2,'order_id'=>99,'customer_reference'=>'SECRET-OTHER','amount'=>999999));
$orders[]=array_replace($orders[0],array('id'=>99,'user_id'=>2,'order_code'=>'OTHER-SECRET'));
$orders[]=array_replace($orders[0],array('id'=>26,'order_code'=>'OLD-SITE'));
$ops[]=array_replace($ops[0],array('id'=>29,'created_at'=>'2000-01-01 00:00:00','order_id'=>0));
$seed['test_ipsvp_orders']=$orders; $seed['test_ipsvp_reseller_operations']=$ops;
$seed['test_ipsvp_reseller_accounts'][1]['business_name']='فروشگاه نمونه';
$seed['test_ipsvp_plans']=array(array('id'=>1,'title'=>'۵۰ گیگ · یک‌ماهه','gb'=>50,'days'=>30));
$seed['test_ipsvp_countries']=array(array('id'=>1,'name'=>'آلمان','flag'=>'🇩🇪'));
$seed['test_ipsvp_receipts'][1]+=array('attachment_id'=>0,'file_url'=>'','plan_id'=>1,'remote_payload'=>'');
$seed['test_ipsvp_receipts'][]=array_replace($seed['test_ipsvp_receipts'][1],array('id'=>2,'status'=>'pending','amount'=>300000));
$GLOBALS['wpdb']=$sql=new WorkspaceSql($seed);
$ui=new IPSVP_Reseller($db,$provider); $GLOBALS['workspace_ui']=$ui;
$filters=IPSVP_Reseller_Reports::filters(array());
$result=IPSVP_Reseller_Reports::orders($db,1,$filters);
same($result['total'],26,'All owned orders, excluding foreign orders'); same(count($result['items']),20,'Orders paginated'); same((int)$result['items'][0]->id,26,'Newest order first');
$result=IPSVP_Reseller_Reports::orders($db,1,array_replace($filters,array('page'=>999)));same($result['page'],2,'Out-of-range page clamps');same(count($result['items']),6,'Last page size');
foreach(array('api'=>13,'panel'=>12,'site'=>1) as $source=>$expected) { $r=IPSVP_Reseller_Reports::orders($db,1,array_replace($filters,array('source'=>$source)));same($r['total'],$expected,'Source filter '.$source); }
foreach(array('client_100%'=>1,"' OR 1=1 --"=>0,'OTHER-SECRET'=>0,'SECRET-OTHER'=>0,'IPS-625'=>1,'ips-client-25'=>1,'آلمان'=>26,'۵۰ گیگ'=>26) as $search=>$expected) { $r=IPSVP_Reseller_Reports::orders($db,1,array_replace($filters,array('search'=>$search)));same($r['total'],$expected,'Search '.$search); }
$r=IPSVP_Reseller_Reports::orders($db,1,array_replace($filters,array('status'=>'disabled','source'=>'api')));same($r['total'],1,'Combined filters');
$bad=IPSVP_Reseller_Reports::filters(array('rs_search'=>array('x'),'rs_status'=>'untrusted','rs_source'=>'wallet','rs_page'=>-2));same($bad,$filters,'Malformed filters safely ignored');
$summary=IPSVP_Reseller_Reports::summary($db,1,30);same((int)$summary['totals']['sales'],25,'Only successful own in-period purchases count');same((int)$summary['totals']['renewals'],1,'Renewals separate');same((int)$summary['totals']['spent'],2340000,'Spent excludes failed foreign and old operations');same($summary['unresolved'],1,'Unresolved count');same(count($summary['days']),30,'Missing days zero-filled');same(array_sum(array_column($summary['days'],'sales')),25,'Daily chart agrees with totals');
same(count(IPSVP_Reseller_Reports::summary($db,1,7)['days']),7,'Week report');same(count(IPSVP_Reseller_Reports::summary($db,1,90)['days']),90,'Quarter report');
$history=IPSVP_Reseller_Reports::operations(1,999);same($history['page'],2,'Operation pagination');foreach($history['items'] as $op) check(!isset($op->provider_result,$op->key_hash),'Private fields excluded');
$frontend=new IPSVP_Frontend($db,$provider);
$_GET=array('rs_search'=>'IPS-625');$search_html=private_call($frontend,'render_reseller_orders',$user->phone);check(strpos($search_html,'IPS-625')!==false && strpos($search_html,'IPS-624')===false,'Real renderer respects order search');
$_GET=array();$orders_html=private_call($frontend,'render_reseller_orders',$user->phone);check(substr_count($orders_html,'name="ipsvp_order_id"')===20,'Existing detail links preserved for visible orders');check(strpos($orders_html,'OTHER-SECRET')===false,'Foreign orders never rendered');
$GLOBALS['test_filters']['ipsvp_admin_user_detail_tabs']=static function($tabs)use($ui){return $ui->tabs($tabs)+array('referral'=>'دعوت دوستان');};
$admin=new IPSVP_Admin($db,$provider);ob_start();private_call($admin,'user_detail',1);$admin_html=ob_get_clean();
check(strpos($admin_html,'پنل')===false || strpos($admin_html,'ipsvp-user-detail')!==false,'Admin renderer succeeds');
$queries=array_filter($sql->queries,static function($q){return strpos($q[0],'total_orders')!==false;});$aggregate=$sql->get_row(end($queries));same((int)$aggregate->active_orders,25,'Admin active count is not multiplied by receipt join');
check(strpos($admin_html,'name="discount_percent"')!==false,'Admin discount form remains present');
if(getenv('IPSR_RENDER_DIR')) {
    $dir=rtrim(getenv('IPSR_RENDER_DIR'),'/');$plugin=dirname(__DIR__);
    $base=file_get_contents($dir.'/approved.html');
    $nav='<nav class="ipsvp-panel-nav ipsvp-reseller-nav">'; foreach($ui->navigation(array(),'', $user->phone) as $key=>$label) $nav.='<a href="'.esc_url(IPSVP_Reseller::dashboard_url($key)).'">'.esc_html($label).'</a>'; $nav.='</nav>';
    foreach(array('approved'=>'dashboard','create'=>'reseller-create','api'=>'reseller-api','operations'=>'reseller-operations','orders'=>'orders') as $name=>$tab) {
        if($tab==='reseller-create') $sql->sql->exec("UPDATE test_ipsvp_reseller_operations SET state='failed' WHERE id=27");
        $html=$tab==='orders'?$orders_html:$ui->panel('',$tab,$user->phone);
        if($tab==='reseller-create') $sql->sql->exec("UPDATE test_ipsvp_reseller_operations SET state='manual_review' WHERE id=27");
        $content='<div class="ipsvp ipsvp-panel">'.$ui->hero('', $user->phone,3400000,'').$nav.$html.'</div>';
        file_put_contents($dir.'/'.$name.'.html',preg_replace_callback('~<main>.*?</main>~s',static function()use($content){return '<main>'.$content.'</main>';},$base));
    }
    $admin_style=file_get_contents($plugin.'/assets/css/admin.css').file_get_contents($plugin.'/assets/css/admin-commerce.css').file_get_contents(dirname($plugin).'/ip-sabet-referral-addon/assets/css/admin.css');
    $content='<main class="ipsvp-admin"><style>'.$admin_style.'</style>'.$admin_html.'<script>'.file_get_contents($plugin.'/assets/js/admin-user.js').'</script></main>';
    file_put_contents($dir.'/admin.html',preg_replace_callback('~<main>.*?</main>~s',static function()use($content){return $content;},$base));
}
echo "OK: $checks total reseller + workspace assertions passed.\n";

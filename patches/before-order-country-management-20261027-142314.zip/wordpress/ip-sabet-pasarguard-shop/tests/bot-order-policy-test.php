<?php
/** Run: php tests/bot-order-policy-test.php. No database or network required. */
define('ABSPATH', '/');
require __DIR__ . '/../includes/class-ipsvp-db.php';
require __DIR__ . '/../includes/class-ipsvp-bot-api.php';
class IPSVP_Sanaei_API {
    public static function is_order($order) { return ($order->panel_provider ?? '') === 'sanaei'; }
}
function check($value, $message) {
    if (!$value) { throw new RuntimeException($message); }
}
class BotPolicyDB extends IPSVP_DB {
    public $orders = array();
    public function get_user_orders($phone) { return $this->orders; }
    public function order_payload_for_bot($order) {
        return $this->order_is_bot_managed($order) ? array('site_order_id' => $order->id) : array();
    }
}
$db = new IPSVP_DB();
$shared = (object) array('id' => 1, 'plan_id' => 2, 'service_type' => 'shared', 'panel_provider' => 'pasarguard', 'phone' => '09120000000');
check($db->order_is_bot_managed($shared), 'Shared VPN must remain available to the bot');
$excluded = array();
foreach (array(
    array('service_type' => 'dedicated'),
    array('service_type' => 'proxyline'),
    array('plan_id' => 0), // Proxyline base orders inherit the shared default.
    array('panel_provider' => 'sanaei'),
    array('panel_provider' => 'other'),
) as $changes) {
    $order = (object) array_merge((array) $shared, $changes);
    $excluded[] = $order;
    check(!$db->order_is_bot_managed($order), 'Site managed order must be excluded');
    check($db->order_payload_for_bot($order) === array(), 'No payload may expose a site managed order');
    $result = IPSVP_Bot_API::import_site_order($order);
    check(!empty($result['skipped']), 'Single imports must skip site managed orders without HTTP');
}
$list = new BotPolicyDB();
$list->orders = array_merge(array($shared), $excluded);
check($list->get_site_orders_for_sync($shared->phone) === array(array('site_order_id' => 1)), 'Sync must omit excluded orders and empty payloads');
echo "Bot order policy checks passed\n";

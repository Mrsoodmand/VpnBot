<?php
/** Isolated financial policy tests. No database, network or WordPress configuration. */
if (PHP_SAPI !== 'cli') { exit; }
define('ABSPATH', '/');
class WP_Error { public function __construct($code, $message) {} }
function is_wp_error($x) { return $x instanceof WP_Error; }
function wp_timezone() { return new DateTimeZone('Asia/Tehran'); }
require __DIR__ . '/../includes/class-ipsvp-loyalty.php';
$n = 0;
function eq($actual, $expected, $message) { global $n; $n++; if ($actual !== $expected) { throw new RuntimeException($message . ': ' . json_encode(array($actual, $expected))); } }
$settings = IPSVP_Loyalty::defaults();
$now = (new DateTimeImmutable('2026-09-26 12:00:00', wp_timezone()))->getTimestamp();
function event($amount, $age = 0, $type = 'wallet', $extra = array()) {
    global $now; static $id = 0; $at = (new DateTimeImmutable('@' . ($now - $age * 86400)))->setTimezone(wp_timezone())->format('Y-m-d H:i:s');
    return (object) array_merge(array('id' => ++$id, 'type' => $type, 'status' => 'approved', 'amount' => $amount, 'reviewed_at' => $at, 'created_at' => $at, 'remote_source' => '', 'submission_key' => '', 'admin_note' => ''), $extra);
}
function calc($rows, $reseller = true, $manual = null, $first = false, $at = null) { global $settings, $now; return IPSVP_Loyalty::calculate($rows, $reseller, $manual, $first, $settings, $at ?? $now); }
foreach (array(0=>5,1000000=>5,2000000=>5,4999999=>5,5000000=>10,6000000=>10,9999999=>10,10000000=>20,10000001=>30,20000000=>30) as $amount=>$percent) {
    eq(calc(array(event($amount)))['percent'], (float) $percent, 'Single reseller charge boundary ' . $amount);
}
eq(calc(array_fill(0, 10, event(1000000)))['percent'], 5.0, 'Small reseller deposits never accumulate');
eq(calc(array(event(5000000, 29)))['percent'], 10.0, 'Day 29 active');
eq(calc(array(event(5000000, 30)))['percent'], 5.0, 'Exact expiry returns base');
eq(calc(array(event(11000000, 29),event(1000000)))['expires_at'], $now + 86400, 'Small deposit does not extend higher level');
eq(calc(array(event(11000000, 31),event(5000000, 2)))['percent'], 10.0, 'Expired highest charge falls back to a still-valid tier');
eq(calc(array(event(11000000, 10),event(11000000, 1)))['expires_at'], $now + 29*86400, 'New equivalent qualifying charge has its own expiry');
eq(calc(array(event(11000000)), true, '0')['percent'], 0.0, 'Explicit zero overrides automatic discount');
eq(calc(array(event(11000000)), true, '12.50')['percent'], 12.5, 'Manual override has priority');
eq(calc(array(event(11000000)), true, '12.50')['expires_at'], null, 'Manual discount does not expire with automatic level');
eq(calc(array(), true, '')['percent'], 5.0, 'Blank selects base automatically');
foreach (array(0=>0,2000000=>5,2000001=>5,4999999=>5,5000000=>10,6000000=>10,10000000=>20,10000001=>20) as $amount=>$percent) {
    eq(calc(array(event($amount)), false)['percent'], (float) $percent, 'Customer boundary ' . $amount);
}
eq(calc(array_fill(0, 5, event(1000000)), false)['percent'], 10.0, 'Customer deposits accumulate');
eq(calc(array(), false)['stars'], 0, 'No purchase: no earned star');
eq(calc(array(), false, null, true)['stars'], 1, 'First successful purchase earns one star');
eq(calc(array(event(3000000)), false)['stars'], 2, 'Customer funding tier earns two stars');
eq(calc(array(event(10000001)), false)['stars'], 4, 'Highest customer tier earns four stars');
eq(calc(array(event(10000001,31)), false, null, true)['stars'], 1, 'Expiry preserves first-purchase star');
eq(calc(array(event(3000000,29),event(3000000,1)), false)['expires_at'], $now+86400, 'Customer sum expires when threshold is no longer met');
foreach (array('pending','rejected','failed','reseller_pending') as $status) { eq(calc(array(event(20000000,0,'wallet',array('status'=>$status))))['percent'], 5.0, 'Unapproved receipt excluded: ' . $status); }
foreach (array('ramzino','bot_wallet_sync','reseller','service_payment','service_refund','admin_wallet_pending') as $source) { eq(calc(array(event(20000000,0,'wallet_admin_credit',array('remote_source'=>$source))))['percent'], 5.0, 'Non-deposit excluded: ' . $source); }
eq(calc(array(event(20000000,0,'wallet_admin_credit',array('submission_key'=>'referral-42-1'))))['percent'], 5.0, 'Referral commission is not a deposit');
eq(calc(array(event(6000000,0,'wallet_admin_credit',array('remote_source'=>'admin_wallet_adjustment'))))['percent'], 10.0, 'Explicit admin credit qualifies');
foreach (array('خرید سرور IPSS-42','پرداخت سفارش پروکسی #42','تمدید سفارش پروکسی #42','بازگشت وجه سفارش پروکسی #42') as $note) {
 eq(calc(array(event(11000000,1),event(10000000,0,'wallet_admin_debit',array('admin_note'=>$note))))['percent'], 30.0, 'Legacy service debit excluded');
}
eq(calc(array(event(6000000,1),event(2000000,0,'wallet_admin_debit')))['percent'], 5.0, 'Manual correction reduces a single charge tier');
eq(calc(array(event(6000000,1),event(1000000,0,'wallet_admin_debit')))['percent'], 10.0, '6m minus 1m retains 5m tier');
eq(calc(array(event(11000000,2),event(1000000,1),event(2000000,0,'wallet_admin_debit')))['percent'], 20.0, 'Correction applies newest-first without summing reseller deposits');
eq(calc(array(event(11000000,1),event(20000000,0,'wallet_admin_debit')))['total'], 0, 'Correction clamps at zero');
eq(calc(array(event(10000000,2,'wallet_admin_debit'),event(6000000,1)))['percent'], 10.0, 'Excess correction does not penalize a later deposit');
$history=array(event(10000000,31),event(1000000,21),event(5000000,11,'wallet_admin_debit'));
eq(calc($history)['largest'], 0, 'Expired deposits do not reallocate past corrections');
eq(calc(array(event(6000000,31),event(1000000,1),event(2000000,0,'wallet_admin_debit')))['total'], 0, 'Expired deposits cannot absorb a new correction');
eq(calc(array(event(6000000,-1)))['percent'], 5.0, 'Future approval excluded');
eq(calc(array(event(6000000,0,'wallet',array('created_at'=>'2026-01-01 00:00:00'))))['percent'], 10.0, 'Age starts at approval, not upload');
eq(calc(array(event(6000000,0,'wallet',array('reviewed_at'=>null))))['percent'], 10.0, 'Legacy approved receipt uses creation date');
$valid=IPSVP_Loyalty::validate_settings($settings);eq(is_wp_error($valid),false,'Defaults validate');
foreach (array(null,array(),'bad') as $bad) { eq(is_wp_error(IPSVP_Loyalty::validate_settings($bad)),true,'Malformed settings rejected'); }
foreach (array('min'=>'-1','percent'=>'101','strict'=>'2') as $field=>$value) { $bad=$settings;$bad['reseller'][1][$field]=$value;eq(is_wp_error(IPSVP_Loyalty::validate_settings($bad)),true,'Invalid field rejected'); }
$bad=$settings;$bad['reseller'][1]['min']=0;eq(is_wp_error(IPSVP_Loyalty::validate_settings($bad)),true,'Non-ascending thresholds rejected');
$bad=$settings;$bad['reseller'][2]['percent']=1;eq(is_wp_error(IPSVP_Loyalty::validate_settings($bad)),true,'Decreasing percentages rejected');
$settings['reseller'][1]['min']=4000000;$settings['reseller'][1]['percent']=12.5;eq(calc(array(event(4500000)))['percent'],12.5,'Custom settings determine real level');
$settings=IPSVP_Loyalty::defaults();
foreach (array('30'=>4,'20'=>3,'17.5'=>2,'10'=>2,'0'=>1) as $rate=>$stars) { eq(calc(array(), true, (string)$rate)['stars'], $stars, 'Manual reseller stars '.$rate); }
foreach (array('20'=>4,'10'=>3,'5'=>2,'0'=>0) as $rate=>$stars) { eq(calc(array(), false, (string)$rate)['stars'], $stars, 'Manual customer stars '.$rate); }
eq(calc(array(event(11000000)),false,'0',true)['stars'],1,'Manual zero ignores high financial tier');
eq(calc(array(event(11000000)),false,'7.5')['percent'],7.5,'Manual customer percent overrides higher tier');
eq(calc(array(),false,'7.5')['expires_at'],null,'Manual customer rate never expires');
eq(calc(array(event(6000000)),false,'')['percent'],10.0,'Blank customer override restores tiers');
foreach (array('new','renewal','bot_renewal','extra_volume') as $type) {
    $r=event(2000000,0,$type,array('attachment_id'=>42,'remote_source'=>$type==='bot_renewal'?'bot':''));
    eq(calc(array($r),false)['percent'],5.0,'Approved direct receipt qualifies '.$type);
    eq(calc(array($r),true)['percent'],5.0,'Reseller still wallet-only '.$type);
    foreach(array('pending','rejected','failed') as $status){$bad=clone $r;$bad->status=$status;eq(calc(array($bad),false)['total'],0,'Unapproved direct excluded '.$type);}
    $r->remote_payload='{"payment_method":"wallet"}';eq(calc(array($r),false)['total'],0,'Wallet payment cannot count twice '.$type);
}
$direct=event(3000000,0,'new',array('attachment_id'=>42));
eq(calc(array(event(2000000,1),$direct),false)['percent'],10.0,'Direct payment and topup accumulate');
eq(calc(array(event(2000000,2),$direct,event(2000000,0,'wallet_admin_debit')),false)['total'],3000000,'Wallet correction never consumes direct purchase');
eq(calc(array(event(5000000,31,'renewal',array('attachment_id'=>42))),false)['total'],0,'Expired direct payment excluded');
eq(calc(array(event(5000000,0,'wallet_renewal')),false)['total'],0,'Wallet renewal excluded');
eq(calc(array($direct),false,'7.5')['percent'],7.5,'Fixed override retains priority');
echo "PASS: $n loyalty policy assertions.\n";

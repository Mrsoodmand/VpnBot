<?php
/** Run: php tests/reseller-test.php. Isolated WP/database/provider doubles; never calls a live service. */
if (PHP_SAPI !== 'cli' && !defined('IPSVP_TEST_RUN')) { exit; }
define('ABSPATH', '/');
define('DAY_IN_SECONDS', 86400);
define('IPSVP_PLUGIN_DIR', dirname(__DIR__) . '/');
define('IPSVP_PLUGIN_URL', 'https://example.test/plugin/');
set_error_handler(static function ($severity, $message, $file, $line) {
    if (!(error_reporting() & $severity)) { return false; }
    throw new ErrorException($message, 0, $severity, $file, $line);
});
class WP_Error {
    private $code; private $message; private $data;
    public function __construct($code, $message, $data = null) { $this->code = $code; $this->message = $message; $this->data = $data; }
    public function get_error_code() { return $this->code; }
    public function get_error_message() { return $this->message; }
    public function get_error_data() { return $this->data; }
}
class WP_REST_Response { public $data; public $status; public $headers = array(); public function __construct($data, $status = 200) { $this->data = $data; $this->status = $status; } public function header($k, $v) { $this->headers[$k] = $v; } }
class IPSabet_PasarGuard_Shop { const VERSION = 'test'; }
function is_wp_error($x) { return $x instanceof WP_Error; }
function wp_json_encode($x, $flags = 0) { return json_encode($x, $flags); }
function current_time($format) { return gmdate('Y-m-d H:i:s'); }
function wp_generate_password($n, $special = true, $extra = true) { return substr(bin2hex(random_bytes($n)), 0, $n); }
function wp_generate_uuid4() { return '12345678-1234-4321-8765-' . bin2hex(random_bytes(6)); }
function sanitize_text_field($s) { return trim(strip_tags($s)); }
function sanitize_textarea_field($s) { return sanitize_text_field($s); }
function sanitize_key($s) { return strtolower(preg_replace('/[^a-zA-Z0-9_-]/', '', $s)); }
function get_current_user_id() { return 99; }
function add_action(...$a) {} function add_filter(...$a) {} function add_shortcode(...$a) {}
function apply_filters($hook, $value, ...$args) { return isset($GLOBALS['test_filters'][$hook]) ? $GLOBALS['test_filters'][$hook]($value, ...$args) : $value; }
function register_rest_route(...$a) { $GLOBALS['routes'][] = $a; }
function is_ssl() { return $GLOBALS['ssl'] ?? true; }
function is_admin() { return false; }
function esc_url_raw($s, $protocols = null) { return $s; }
function wp_unslash($s) { return $s; }
function esc_html($s) { return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8'); }
function esc_attr($s) { return esc_html($s); }
function esc_textarea($s) { return esc_html($s); }
function esc_url($s) { return esc_html($s); }
function wp_kses_post($s) { return $s; }
function rest_url($s) { return 'https://example.test/wp-json/' . $s; }
function home_url($s) { return 'https://example.test' . $s; }
function untrailingslashit($s) { return rtrim($s, '/'); }
function add_query_arg($key, $value = null, $url = null) { if (is_array($key)) { return $value . '&' . http_build_query($key); } return $url . '?' . urlencode($key) . '=' . urlencode($value); }
function number_format_i18n($n, $decimals = 0) { return number_format((float) $n, $decimals); }
function disabled($value) { if ($value) { echo 'disabled="disabled"'; } }
function selected($a, $b, $echo = true) { $s = $a === $b ? 'selected' : ''; if ($echo) { echo $s; } return $s; }
function wp_nonce_field(...$args) {} function wp_verify_nonce($nonce, $action) { return $nonce === hash('sha256', $action); }
function nocache_headers() {} function paginate_links($a) { return ''; }
class IPSVP_Session { public static function cookie_name() { return 'test_session'; } public static function get_phone($db) { return $GLOBALS['session_phone'] ?? ''; } }
class IPSVP_Settings { public static function get() { return ($GLOBALS['test_settings'] ?? array()) + array('dashboard_url' => 'https://example.test/dashboard', 'all_countries_price_percent' => '30', 'extra_volume_price_per_gb' => '10000'); } }

class FakeWpdb {
    public $prefix = 'test_'; public $insert_id = 0; public $rows = array(); public $ids = array(); public $fail_insert = ''; public $fail_update = ''; public $storage = 'InnoDB'; public $lock_ok = true; private $snapshot;
    public function prepare($sql, ...$args) { return array($sql, $args); }
    public function get_row($q) {
        list($sql, $args) = $q;
        if (strpos($sql, 'reseller_accounts') !== false) {
            foreach ($this->rows['test_ipsvp_reseller_accounts'] ?? array() as $r) {
                if (strpos($sql, 'key_hash=%s') !== false ? ($r['key_hash'] ?? '') === $args[0] : (int) $r['user_id'] === (int) $args[0]) { return (object) $r; }
            }
        } elseif (strpos($sql, 'reseller_operations') !== false) {
            if (strpos($sql, 'SUM(action=') !== false) {
                $summary = array('sales' => 0, 'spent' => 0, 'savings' => 0, 'renewals' => 0, 'operations' => 0, 'api_count' => 0, 'panel_count' => 0);
                foreach ($this->rows['test_ipsvp_reseller_operations'] ?? array() as $r) { if ((int) $r['user_id'] === (int) $args[0] && $r['state'] === 'succeeded') { $summary['operations']++; $summary[$r['channel'] . '_count']++; $summary['sales'] += $r['action'] === 'purchase' ? 1 : 0; $summary['spent'] += $r['amount']; $summary['savings'] += $r['base_amount'] - $r['amount']; } }
                return (object) $summary;
            }
            foreach ($this->rows['test_ipsvp_reseller_operations'] ?? array() as $r) {
                if (strpos($sql, 'idempotency_hash') !== false) { $match = (int) $r['user_id'] === (int) $args[0] && $r['idempotency_hash'] === $args[1]; }
                else { $match = (int) $r['id'] === (int) $args[0] && (count($args) < 2 || (int) $r['user_id'] === (int) $args[1]); }
                if ($match) { return (object) $r; }
            }
        }
        return null;
    }
    public function get_var($q) {
        list($sql, $args) = $q;
        if (strpos($sql, 'GET_LOCK') !== false) { return $this->lock_ok ? '1' : '0'; }
        if (strpos($sql, 'RELEASE_LOCK') !== false) { return '1'; }
        if (strpos($sql, 'information_schema') !== false) { return $this->storage; }
        if (strpos($sql, 'COUNT(*)') !== false && strpos($sql, 'state IN') === false) { return count($this->get_results($q)); }
        if (strpos($sql, 'reseller_operations') !== false && strpos($sql, 'state IN') !== false) {
            foreach ($this->rows['test_ipsvp_reseller_operations'] ?? array() as $r) {
                if ((int) $r['user_id'] === (int) $args[0] && in_array($r['state'], array('reserved', 'processing', 'manual_review', 'refund_review'), true)) { return $r['id']; }
            }
            return null;
        }
        throw new RuntimeException('Unhandled get_var: ' . $sql);
    }
    public function get_results($q) {
        list($sql, $args) = $q;
        if (strpos($sql, 'GROUP BY DATE') !== false) { return array(); }
        $table = strpos($sql, 'reseller_operations') !== false ? 'test_ipsvp_reseller_operations' : 'test_ipsvp_orders';
        $rows = array_filter($this->rows[$table] ?? array(), static function ($r) use ($args) { return (int) $r['user_id'] === (int) $args[0]; });
        return array_map(static function ($r) { return (object) $r; }, array_reverse(array_values($rows)));
    }
    public function insert($table, $data) {
        if ($table === $this->fail_insert) { return false; }
        if (substr($table, -8) === 'accounts') {
            $id = $data['user_id'];
            $data += array('discount_percent' => 0, 'key_hash' => null, 'key_hint' => null, 'key_expires_at' => null, 'key_created_at' => null, 'last_used_at' => null, 'allowed_ips' => '', 'rate_window' => 0, 'rate_count' => 0, 'review_note' => null, 'website' => '', 'application_note' => '');
        } else {
            $id = ($this->ids[$table] ?? 0) + 1; $this->ids[$table] = $id; $data['id'] = $id;
            if (substr($table, -10) === 'operations') { $data += array('receipt_id' => 0, 'provider_result' => null, 'error_code' => null); }
            if (substr($table, -6) === 'orders') { $data += array('pg_user_id' => '', 'pg_username' => '', 'pg_subscription_url' => '', 'pg_links' => '[]', 'pg_response' => '', 'pg_status' => '', 'service_ended_at' => null); }
        }
        $this->rows[$table][$id] = $data; $this->insert_id = $id; return 1;
    }
    public function update($table, $data, $where) {
        if ($this->fail_update === $table) { return false; }
        $count = 0;
        foreach ($this->rows[$table] ?? array() as $id => $row) {
            $match = true;
            foreach ($where as $key => $value) { if ((string) ($row[$key] ?? '') !== (string) $value) { $match = false; } }
            if ($match) { $this->rows[$table][$id] = array_merge($row, $data); $count++; }
        }
        return $count;
    }
    public function query($q) {
        if (is_string($q)) {
            if ($q === 'START TRANSACTION') { $this->snapshot = $this->rows; }
            elseif ($q === 'ROLLBACK') { $this->rows = $this->snapshot; }
            elseif ($q === 'COMMIT') { $this->snapshot = null; }
            else { throw new RuntimeException('Unhandled query: ' . $q); }
            return 1;
        }
        list($sql, $args) = $q;
        if (strpos($sql, 'rate_count=IF') !== false) {
            $a = &$this->rows['test_ipsvp_reseller_accounts'][$args[3]];
            if ($a['rate_window'] === $args[0] && $a['rate_count'] >= 60) { return 0; }
            $a['rate_count'] = $a['rate_window'] === $args[0] ? $a['rate_count'] + 1 : 1; $a['rate_window'] = $args[0];
            return 1;
        }
        throw new RuntimeException('Unhandled query');
    }
}
class ShopDouble {
    public $users = array(); public $credit = 2000000; public $sales = true; public $all_enabled = true; public $plan_active = true; public $plan_type = 'shared'; public $country_active = true; public $country_type = 'shared'; public $audit = array();
    public function tables() { return array('orders' => 'test_ipsvp_orders', 'receipts' => 'test_ipsvp_receipts'); }
    public function now() { return current_time('mysql'); }
    public function get_user_by_id($id) { return $this->users[$id] ?? null; }
    public function get_user_by_phone($phone) { foreach ($this->users as $u) { if ($u->phone === $phone) { return $u; } } return null; }
    public function get_local_wallet_balance($id) {
        $n = $this->credit;
        foreach ($GLOBALS['wpdb']->rows['test_ipsvp_receipts'] ?? array() as $r) { if ((int) $r['user_id'] === (int) $id && $r['status'] === 'approved' && $r['wallet_effect'] === 'local') { $n -= $r['amount']; } }
        return $n;
    }
    public function get_plan($id) { return (int) $id === 1 ? (object) array('id' => 1, 'status' => (int) $this->plan_active, 'service_type' => $this->plan_type, 'price' => 120000, 'sale_price' => 100000, 'title' => 'Plan', 'gb' => 1, 'days' => 30) : null; }
    public function get_country($id) { return (int) $id === 1 ? (object) array('id' => 1, 'status' => (int) $this->country_active, 'service_type' => $this->country_type, 'pg_group_id' => 5, 'name' => 'Test', 'flag' => 'flag') : null; }
    public function normalize_service_type($x) { return $x === 'dedicated' ? 'dedicated' : 'shared'; }
    public function order_service_type($o) { return $this->normalize_service_type($o->service_type); }
    public function service_sales_enabled($type) { return $this->sales; }
    public function final_price($p, $retail = false) { return $p->sale_price; }
    public function all_countries_enabled() { return $this->all_enabled; }
    public function all_countries_group_ready() { return $this->all_enabled; }
    public function all_countries_price_percent_value() { return 30; }
    public function is_all_countries_order($o) { return (int) $o->country_id === 0; }
    public function calculate_extra_volume_price($o, $gb, $retail = false) { return array('total_amount' => 10000 * $gb * ((int) $o->country_id === 0 ? 1.3 : 1)); }
    public function order_can_renew($o) { return in_array($o->status, array('active', 'on_hold', 'disabled'), true); }
    public function ready_countries($type = 'shared') { return array($this->get_country(1)); }
    public function active_plans($type = 'shared') { return array($this->get_plan(1)); }
    public function get_order($id) {
        $o = $GLOBALS['wpdb']->rows['test_ipsvp_orders'][$id] ?? null;
        return $o ? (object) ($o + array('gb' => 1, 'days' => 30, 'pg_group_id' => 5, 'pg_group_name' => 'Test')) : null;
    }
    public function update_order($id, $data) { return $GLOBALS['wpdb']->update('test_ipsvp_orders', $data, array('id' => $id)); }
    public function get_receipt($id) { $r = $GLOBALS['wpdb']->rows['test_ipsvp_receipts'][$id] ?? null; return $r ? (object) $r : null; }
    public function add_log(...$args) { $this->audit[] = $args; }
    public function create_user_notification(...$args) {}
    public function status_label($s) { return $s; }
}
class ProviderDouble {
    public $calls = 0; public $failure = false; public $expired = false; public $limit = 1000000; public $result_hook;
    private function result() { $this->calls++; if ($this->result_hook) { ($this->result_hook)(); } return $this->failure ? new WP_Error('timeout', 'Uncertain upstream timeout') : array('user_id' => '321', 'username' => 'ips-test', 'status' => 'active', 'subscription_url' => 'https://example.test/sub/secret', 'links' => array('vless://private'), 'raw' => array('data_limit' => 1000000)); }
    public function create_user_for_order($o) { return $this->result(); }
    public function create_users_for_all_countries_order($o, $c) { return $this->result(); }
    public function extend_user_for_order($o, $p) { return $this->result(); }
    public function add_extra_volume_for_order($o, $gb) { return $this->result(); }
    public function update_user_status_for_order($o, $status) { return $this->result(); }
    public function user_snapshot(...$a) { return array('live' => array('id' => 321), 'user_id' => '321', 'username' => 'ips-test', 'status' => 'active', 'used' => 10, 'limit' => $this->limit, 'expire' => time() + ($this->expired ? -10 : 1000), 'subscription_url' => 'https://example.test/sub/secret', 'links' => array('vless://private')); }
}
class IPSVP_Bot_API {
    public static $debits = 0; public static $refunds = 0; public static $uncertain = false; public static $refund_uncertain = false; public static $wallet_down = false;
    public static function unified_wallet($u, $db, $sync) { return self::$wallet_down ? new WP_Error('wallet_down', 'down') : array('ok' => true, 'balance' => 2000000); }
    public static function debit_wallet(...$a) { self::$debits++; return self::$uncertain ? new WP_Error('timeout', 'timeout') : array('ok' => true); }
    public static function credit_wallet(...$a) { self::$refunds++; return self::$refund_uncertain ? new WP_Error('timeout', 'timeout') : array('ok' => true); }
}
foreach (array('store', 'service', 'api', 'docs', 'reports') as $file) { require __DIR__ . '/../includes/class-ipsvp-reseller-' . $file . '.php'; }
require __DIR__ . '/../includes/class-ipsvp-reseller.php';
$checks = 0;
function check($value, $message) { global $checks; $checks++; if (!$value) { throw new RuntimeException($message); } }
function same($got, $want, $message) { check($got === $want, $message . ': ' . json_encode($got)); }
function error_is($value, $code) { check(is_wp_error($value) && $value->get_error_code() === 'ipsr_' . $code, 'Expected ' . $code . ', got ' . (is_wp_error($value) ? $value->get_error_code() : json_encode($value))); }
function fixture($approved = true) {
    $GLOBALS['wpdb'] = new FakeWpdb(); $GLOBALS['ssl'] = true; $GLOBALS['session_phone'] = ''; $GLOBALS['test_settings'] = array();
    $db = new ShopDouble(); $user = (object) array('id' => 1, 'phone' => '+989123456789', 'is_blocked' => 0, 'bot_tel_id' => ''); $db->users[1] = $user;
    $api = new ProviderDouble(); $service = new IPSVP_Reseller_Service($db, $api); $ui = new IPSVP_Reseller($db, $api);
    if ($approved) { $GLOBALS['wpdb']->insert(IPSVP_Reseller_Store::table('accounts'), array('user_id' => 1, 'status' => 'approved', 'discount_percent' => '10.00', 'business_name' => 'Test shop', 'requested_at' => $db->now())); }
    IPSVP_Bot_API::$debits = IPSVP_Bot_API::$refunds = 0; IPSVP_Bot_API::$uncertain = IPSVP_Bot_API::$refund_uncertain = IPSVP_Bot_API::$wallet_down = false;
    $_POST = $_GET = array(); return array($db, $user, $api, $service, $ui);
}
function private_call($object, $method, ...$args) { $r = new ReflectionMethod($object, $method); $r->setAccessible(true); return $r->invokeArgs($object, $args); }
function buy($service, $user, $key = '12345678-1234-1234-1234-123456789012', $extra = array()) { return $service->execute($user, 'purchase', $extra + array('plan_id' => 1, 'country_id' => 1), $key); }

same(IPSVP_Reseller_Store::discount(100001, '12.50'), 87501, 'Discount rounds upward');
same(IPSVP_Reseller_Store::discount(100000, 100), 0, '100 percent');
foreach (array(-1, '1.5', '1e3', true, array(1), '01', '999999999999999999999') as $bad) { same(IPSVP_Reseller_Service::integer($bad), false, 'Reject malformed integer'); }
same(IPSVP_Reseller_Service::integer('0', 0), 0, 'All countries zero');
check(IPSVP_Reseller_API::ip_allowed('2001:db8::1', '2001:0db8:0000::1'), 'Canonical IPv6 equality');
check(!IPSVP_Reseller_API::ip_allowed('203.0.113.10', '203.0.113.11'), 'IP allowlist');

list($db, $u, $api, $s, $ui) = fixture();
$quote = $s->quote($u, 'purchase', array('plan_id' => 1, 'country_id' => 0));
same($quote['base_amount'], 130000, 'All countries surcharge first'); same($quote['amount'], 117000, 'Discount after surcharge');
same($db->get_local_wallet_balance(1), 2000000, 'Quote never debits');
$db->plan_active = false; error_is(buy($s, $u), 'invalid_plan'); $db->plan_active = true;
$db->country_active = false; error_is(buy($s, $u), 'invalid_country'); $db->country_active = true;
$db->plan_type = 'dedicated'; error_is(buy($s, $u), 'invalid_plan'); $db->plan_type = 'shared';
$db->country_type = 'dedicated'; error_is(buy($s, $u), 'invalid_country'); $db->country_type = 'shared';
$db->sales = false; error_is(buy($s, $u), 'sales_disabled'); $db->sales = true;
$db->credit = 89999; error_is(buy($s, $u), 'insufficient_balance'); same($api->calls, 0, 'No delivery without funds'); $db->credit = 2000000;
error_is(buy($s, $u, 'short'), 'idempotency_required');
error_is(buy($s, $u, '12345678-1234-1234-1234-123456789012', array('max_amount' => 89999)), 'price_changed');
$op = buy($s, $u); same($op->state, 'succeeded', 'Purchase succeeded'); same((int) $op->amount, 90000, 'Discounted debit');
same($db->get_local_wallet_balance(1), 1910000, 'Exactly one local debit'); same($api->calls, 1, 'Exactly one provision');
$GLOBALS['wpdb']->rows['test_ipsvp_reseller_accounts'][1]['discount_percent'] = '50.00'; $db->plan_active = false;
$replay = buy($s, $u); same($replay->id, $op->id, 'Replay after catalog/discount change'); same($api->calls, 1, 'Replay no delivery'); same((int) $replay->amount, 90000, 'Historical price preserved');
error_is(buy($s, $u, '12345678-1234-1234-1234-123456789012', array('country_id' => 0)), 'idempotency_conflict');
$db->plan_active = true;
$u2 = clone $u; $u2->id = 2; error_is($s->owned_order($u2, $op->order_id), 'order_not_found');
$renew = $s->execute($u, 'renew', array('order_id' => $op->order_id, 'plan_id' => 1), 'renew-1234567890123456'); same($renew->state, 'succeeded', 'Renewal'); same((int) $renew->amount, 50000, 'Current discount on renewal');
$volume = $s->execute($u, 'extra-volume', array('order_id' => $op->order_id, 'gb' => 2), 'volume-1234567890123456'); same($volume->state, 'succeeded', 'Extra volume'); same((int) $volume->amount, 10000, 'Discount on extra volume');
same($db->get_local_wallet_balance(1), 1850000, 'Journal debits purchase/renew/volume once');
$pause = $s->execute($u, 'disable', array('order_id' => $op->order_id), 'disable-1234567890123456'); same($pause->state, 'succeeded', 'Pause'); same($db->get_local_wallet_balance(1), 1850000, 'Pause free');
$api->expired = true; error_is($s->execute($u, 'enable', array('order_id' => $op->order_id), 'enable-1234567890123456'), 'renewal_required'); $api->expired = false;
same($s->execute($u, 'enable', array('order_id' => $op->order_id), 'enable-1234567890123456')->state, 'succeeded', 'Resume valid service');
$api->limit = 0; error_is($s->execute($u, 'extra-volume', array('order_id' => $op->order_id, 'gb' => 1), 'volume-2222222222222222'), 'unlimited_service');

list($db, $u, $api, $s, $ui) = fixture(); $GLOBALS['wpdb']->fail_insert = 'test_ipsvp_receipts';
error_is(buy($s, $u), 'storage_failed'); same($api->calls, 0, 'No delivery after failed reserve'); same($db->get_local_wallet_balance(1), 2000000, 'Transaction rollback'); same(count($GLOBALS['wpdb']->rows['test_ipsvp_orders'] ?? array()), 0, 'No orphan order');
list($db, $u, $api, $s, $ui) = fixture(); $GLOBALS['wpdb']->storage = 'MyISAM'; error_is(buy($s, $u), 'storage_unavailable'); same($api->calls, 0, 'Reject nontransactional storage');
list($db, $u, $api, $s, $ui) = fixture(); $api->failure = true; $op = buy($s, $u);
same($op->state, 'manual_review', 'Timeout held for reconciliation'); same($db->get_local_wallet_balance(1), 1910000, 'Timeout keeps reservation');
same(buy($s, $u)->id, $op->id, 'Timeout replay'); same($api->calls, 1, 'No retry of uncertain provider mutation');
error_is(buy($s, $u, 'different-12345678901234'), 'operation_unresolved');
$_POST = array('operation_id' => $op->id, 'outcome' => 'refund', 'resolution_note' => 'Verified no delivery', 'verified' => 1);
check(!is_wp_error(private_call($ui, 'resolve', $u)), 'Local refund resolution'); same($db->get_local_wallet_balance(1), 2000000, 'Reservation released');
error_is(private_call($ui, 'resolve', $u), 'resolved'); same($db->get_local_wallet_balance(1), 2000000, 'Refund once');

list($db, $u, $api, $s, $ui) = fixture();
$api->result_hook = static function () { $GLOBALS['wpdb']->fail_update = 'test_ipsvp_orders'; };
$op = buy($s, $u); same($op->state, 'manual_review', 'Persistence failure after provider success'); same($op->stage, 'provider_completed', 'Provider result journaled');
$GLOBALS['wpdb']->fail_update = ''; $api->result_hook = null;
$_POST = array('operation_id' => $op->id, 'outcome' => 'complete', 'resolution_note' => 'Delivery and debit verified', 'verified' => 1);
check(!is_wp_error(private_call($ui, 'resolve', $u)), 'Finalize stored provider result'); same($api->calls, 1, 'No re-provision on reconciliation');

list($db, $u, $api, $s, $ui) = fixture(); $u->bot_tel_id = '123'; IPSVP_Bot_API::$uncertain = true;
$op = buy($s, $u); same($op->state, 'manual_review', 'Uncertain remote debit'); same($op->stage, 'debit_pending', 'Debit uncertainty stage'); same($api->calls, 0, 'Do not provision after ambiguous debit');
buy($s, $u); same(IPSVP_Bot_API::$debits, 1, 'No second remote debit'); same($db->get_local_wallet_balance(1), 2000000, 'Remote debit not counted locally');
$_POST = array('operation_id' => $op->id, 'outcome' => 'no_debit', 'resolution_note' => 'Remote statement confirms no debit', 'verified' => 1);
check(!is_wp_error(private_call($ui, 'resolve', $u)), 'Resolve proven absent debit'); same(IPSVP_Bot_API::$refunds, 0, 'Never credit money that was not debited');
list($db, $u, $api, $s, $ui) = fixture(); $u->bot_tel_id = '123'; $api->failure = true;
$op = buy($s, $u); same(IPSVP_Bot_API::$debits, 1, 'One successful remote debit'); same($op->stage, 'provider_pending', 'Provider uncertainty after debit');
IPSVP_Bot_API::$refund_uncertain = true;
$_POST = array('operation_id' => $op->id, 'outcome' => 'refund', 'resolution_note' => 'Delivery absent, debit verified', 'verified' => 1);
error_is(private_call($ui, 'resolve', $u), 'refund_uncertain'); error_is(private_call($ui, 'resolve', $u), 'refund_unresolved'); same(IPSVP_Bot_API::$refunds, 1, 'Uncertain refund never sent twice');
$_POST['outcome'] = 'refund_confirmed'; check(!is_wp_error(private_call($ui, 'resolve', $u)), 'Confirm externally verified refund');

list($db, $u, $api, $s, $ui) = fixture(false); $db->credit = 1999999;
$_POST = array('business_name' => 'Test shop', 'website' => '', 'application_note' => 'Hello');
error_is(private_call($ui, 'front_action', $u, 'apply'), 'balance_low');
$db->credit = 2000000; check(!is_wp_error(private_call($ui, 'front_action', $u, 'apply')), 'Exact threshold permits application'); same(IPSVP_Reseller_Store::account(1)->status, 'pending', 'Approval not automatic'); same($db->get_local_wallet_balance(1), 2000000, 'Application free');
error_is(private_call($ui, 'front_action', $u, 'apply'), 'already_applied'); error_is(buy($s, $u), 'not_approved');
$_POST = array('status' => 'approved', 'discount_percent' => '12.50', 'review_note' => 'Welcome');
$db->credit = 1999999; error_is(private_call($ui, 'admin_action', $u, 'review'), 'balance_low'); $db->credit = 2000000;
check(!is_wp_error(private_call($ui, 'admin_action', $u, 'review')), 'Admin approval'); same((float) IPSVP_Reseller_Store::account(1)->discount_percent, 12.5, 'Per-user percentage');
$_POST['discount_percent'] = '100.01'; error_is(private_call($ui, 'admin_action', $u, 'review'), 'invalid_review');
$_POST = array('key_version' => '', 'key_days' => 90); check(!is_wp_error(private_call($ui, 'front_action', $u, 'rotate_key')), 'Issue key');
$secret_property = new ReflectionProperty($ui, 'secret'); $secret_property->setAccessible(true); $key = $secret_property->getValue($ui); $account = IPSVP_Reseller_Store::account(1);
same($account->key_hash, hash('sha256', $key), 'Only key hash persisted'); check(strpos(json_encode($GLOBALS['wpdb']->rows), $key) === false, 'No plaintext credential in database');
private_call($ui, 'front_action', $u, 'rotate_key'); same(IPSVP_Reseller_Store::account(1)->key_hash, $account->key_hash, 'POST replay does not rotate again');
$_POST = array('allowed_ips' => "203.0.113.10\ninvalid"); error_is(private_call($ui, 'front_action', $u, 'settings'), 'invalid_ips');

class RequestDouble {
    public $headers = array(); public $body = array(); public $method = 'GET'; public $path = '/account'; public $url = array(); public $json = true; public $raw = null;
    public function get_header($key) { return $this->headers[$key] ?? ''; }
    public function get_route() { return '/' . IPSVP_Reseller_API::NS . $this->path; }
    public function get_method() { return $this->method; }
    public function get_url_params() { return $this->url; }
    public function is_json_content_type() { return $this->json; }
    public function get_body() { return $this->raw ?? json_encode((object) $this->body); }
    public function get_json_params() { return $this->body; }
    public function get_param($key) { return $this->body[$key] ?? null; }
}
$rest = new IPSVP_Reseller_API($db, $s); $req = new RequestDouble(); $req->headers['authorization'] = 'Bearer ' . $key;
same($rest->authorize($req), true, 'Bearer accepted'); same($rest->dispatch($req)->data['data']['user_id'], 1, 'Identity from key');
$forged = new RequestDouble(); $forged->body['user_id'] = 1; error_is($rest->dispatch($forged), 'unauthorized');
$GLOBALS['ssl'] = false; error_is($rest->authorize($req), 'https_required'); $GLOBALS['ssl'] = true;
$GLOBALS['wpdb']->rows['test_ipsvp_reseller_accounts'][1]['allowed_ips'] = '203.0.113.10'; $_SERVER['REMOTE_ADDR'] = '203.0.113.11'; $_SERVER['HTTP_X_FORWARDED_FOR'] = '203.0.113.10'; error_is($rest->authorize($req), 'ip_forbidden');
$_SERVER['REMOTE_ADDR'] = '203.0.113.10'; same($rest->authorize($req), true, 'Allowed IP');
$GLOBALS['wpdb']->rows['test_ipsvp_reseller_accounts'][1]['rate_window'] = (int) floor(time() / 60); $GLOBALS['wpdb']->rows['test_ipsvp_reseller_accounts'][1]['rate_count'] = 60; error_is($rest->authorize($req), 'rate_limited');
error_is($rest->dispatch($req), 'unauthorized'); // Failed reauthorization erases earlier identity.
$GLOBALS['wpdb']->rows['test_ipsvp_reseller_accounts'][1]['rate_count'] = 0;
same($rest->authorize($req), true, 'Reauthorize before new work');
$req->path = '/orders'; $req->method = 'POST'; $req->headers['idempotency-key'] = 'rest-1234567890123456'; $req->body = array('plan_id' => 1, 'country_id' => 1, 'amount' => 1); error_is($rest->dispatch($req), 'unknown_fields');
unset($req->body['amount']); $response = $rest->dispatch($req); same($response->status, 200, 'REST purchase'); same($response->data['data']['operation']['amount'], 87500, 'REST discounted payment');
// Mutation inputs, routes and identities cannot be supplied by a client.
$order_id = $response->data['data']['operation']['order_id'];
$req->path = '/orders/' . $order_id; $req->method = 'GET'; $req->body = array('id'=>999,'user_id'=>2); $req->url = array('id'=>999);
same($rest->dispatch($req)->status, 200, 'Matched URL ID wins over query and URL-param override');
$req->path = '/orders/' . $order_id . '/renew'; $req->method = 'POST'; $req->body = array('plan_id'=>1,'order_id'=>999);
error_is($rest->dispatch($req), 'unknown_fields');
$req->path = '/wallet'; error_is($rest->dispatch($req), 'method_not_allowed');
$req->path = '/wallet/credit'; error_is($rest->dispatch($req), 'route_not_found');
$req->path = '/orders'; $req->body = array('plan_id'=>1,'country_id'=>1,'user_id'=>2); error_is($rest->dispatch($req), 'unknown_fields');
$req->body = array('plan_id'=>1,'country_id'=>1); $req->raw = '[]'; error_is($rest->dispatch($req), 'invalid_json');
$req->raw = '{invalid'; error_is($rest->dispatch($req), 'invalid_json');
$req->raw = str_repeat('x', 8193); error_is($rest->dispatch($req), 'body_too_large'); $req->raw = null;
$req->json = false; error_is($rest->dispatch($req), 'json_required'); $req->json = true;
$req->path = '/quote'; $req->body = array('action'=>'purchase','plan_id'=>1,'country_id'=>1,'discount_percent'=>100); error_is($rest->dispatch($req), 'unknown_fields');
$req->body = array('action'=>'purchase','plan_id'=>1,'country_id'=>1); same($rest->dispatch($req)->status, 200, 'Read-only quote accepted');
$req->path = '/orders/' . $order_id; $req->method = 'GET'; $req->body = array();
$GLOBALS['wpdb']->rows['test_ipsvp_orders'][$order_id]['user_id'] = 2; error_is($rest->dispatch($req), 'order_not_found');
$GLOBALS['wpdb']->rows['test_ipsvp_orders'][$order_id]['user_id'] = 1;
$original_hash = IPSVP_Reseller_Store::account(1)->key_hash;
$GLOBALS['wpdb']->rows['test_ipsvp_reseller_accounts'][1]['key_hash'] = hash('sha256','rotated'); error_is($rest->dispatch($req), 'unauthorized');
$GLOBALS['wpdb']->rows['test_ipsvp_reseller_accounts'][1]['key_hash'] = $original_hash;
same($rest->authorize($req), true, 'Current key reauthorized');
$GLOBALS['wpdb']->rows['test_ipsvp_reseller_accounts'][1]['allowed_ips'] = '192.0.2.10'; error_is($rest->dispatch($req), 'unauthorized');
$GLOBALS['wpdb']->rows['test_ipsvp_reseller_accounts'][1]['allowed_ips'] = ''; same($rest->authorize($req), true, 'IP change reauthorized');
$u->is_blocked = 1; error_is($rest->dispatch($req), 'unauthorized'); $u->is_blocked = 0;
same($api->calls, 1, 'Rejected requests never provision extra configurations');
same($db->get_local_wallet_balance(1), 1912500, 'Rejected requests neither credit nor debit wallet');
$rest->no_cache($response, null, $req); same($response->headers['Cache-Control'], 'private, no-store, max-age=0', 'No cache on private API');
$_POST = array('status' => 'suspended', 'discount_percent' => '12.50', 'review_note' => 'Suspended');
check(!is_wp_error(private_call($ui, 'admin_action', $u, 'review')), 'Suspend representative'); error_is($rest->authorize($req), 'unauthorized'); same(IPSVP_Reseller_Store::account(1)->key_hash, null, 'Suspension revokes key');
$db->credit = 100000; $_POST = array('status' => 'approved', 'discount_percent' => '12.50', 'review_note' => 'Restored');
check(!is_wp_error(private_call($ui, 'admin_action', $u, 'review')), 'Restoring a previously approved representative does not charge a new entry threshold');
same(IPSVP_Reseller_Store::account(1)->key_hash, null, 'Restoring does not resurrect a revoked API key');
$before_balance=$db->get_local_wallet_balance(1);
$_POST=array('status'=>'customer','discount_percent'=>'30','review_note'=>'');
check(!is_wp_error(private_call($ui,'admin_action',$u,'review')),'Admin can switch representative to ordinary customer');
same(IPSVP_Reseller_Store::account(1)->status,'customer','Customer status persists');
same(IPSVP_Reseller_Store::approved(1),false,'Customer has no approved reseller privileges');
error_is($rest->authorize($req),'unauthorized');
same(IPSVP_Reseller_Store::account(1)->key_hash,null,'Customer conversion revokes API key');
same($ui->hero('ordinary header',$u->phone,0,''),'ordinary header','Ordinary header restored');
$ordinary_tabs=$ui->navigation(array('dashboard'=>'Dashboard','referral'=>'Referral'),'', $u->phone);
check(isset($ordinary_tabs['referral'])&&!isset($ordinary_tabs['reseller-api']),'Ordinary navigation and referral restored');
check(!in_array('reseller-create',$ui->allowed_tabs(array(),$u->phone),true),'Direct quick-create tab inaccessible');
same($ui->panel('ordinary','reseller-api',$u->phone),'ordinary','Direct API panel inaccessible');
same($db->get_local_wallet_balance(1),$before_balance,'Conversion preserves wallet balance');
$_POST=array('status'=>'approved','discount_percent'=>'12.50','review_note'=>'Restored');
check(!is_wp_error(private_call($ui,'admin_action',$u,'review')),'Admin can restore representative after conversion');
same(IPSVP_Reseller_Store::account(1)->key_hash,null,'Restoration never revives old credentials');


$spec = IPSVP_Reseller_Docs::openapi(); same($spec['openapi'], '3.0.3', 'OpenAPI version');
foreach (IPSVP_Reseller_API::endpoints() as $e) { check(isset($spec['paths'][$e[1]][strtolower($e[0])]), 'Endpoint documented'); }
same($spec['paths']['/orders/{id}/extra-volume']['post']['requestBody']['content']['application/json']['schema']['required'], array('gb'), 'Volume schema');
$docs = IPSVP_Reseller_Docs::shortcode(); check(strpos($docs, 'Idempotency-Key') !== false && strpos($docs, 'max_amount') !== false && strpos($docs, '/operations/lookup') !== false, 'Docs render'); check(strpos($docs, $key) === false, 'No real secret in public docs');

// Check real shop pricing, session isolation, UI output and rollback during reconciliation.
require __DIR__ . '/../includes/class-ipsvp-db.php';
list($db, $u, $api, $s, $ui) = fixture(); $GLOBALS['session_phone'] = $u->phone; $real_db = new IPSVP_DB();
same($real_db->final_price($db->get_plan(1)), 90000, 'Existing storefront applies representative price');
same($real_db->final_price($db->get_plan(1), true), 100000, 'Service can always read retail price');
same($real_db->all_countries_price($db->get_plan(1)), 117000, 'Existing checkout and API all-country prices agree');
$existing_order = (object) array('country_id' => 0, 'service_type' => 'shared');
same($real_db->calculate_renewal_plan_price($db->get_plan(1), $existing_order), 117000, 'Existing renewal price agrees');
same($real_db->calculate_extra_volume_price($existing_order, 2)['total_amount'], 23400, 'Existing volume price agrees');
$db->plan_type = 'dedicated'; same($real_db->final_price($db->get_plan(1)), 100000, 'Dedicated plan unaffected'); $db->plan_type = 'shared';
$GLOBALS['session_phone'] = ''; same($real_db->final_price($db->get_plan(1)), 100000, 'Guest retail price unaffected');
$GLOBALS['test_settings']['payment_wallet_enabled'] = '0'; error_is(buy($s, $u), 'wallet_disabled'); $GLOBALS['test_settings'] = array();
$op = buy($s, $u);
$approved_html = $ui->panel('', 'reseller', $u->phone);
$create_html = $ui->panel('', 'reseller-create', $u->phone);
$api_html = $ui->panel('', 'reseller-api', $u->phone);
check(strpos($approved_html, 'data-ipsr-chart') !== false, 'Approved dashboard has sales chart');
check(strpos($create_html, 'name="operation" value="purchase"') !== false, 'Quick create has purchase form');
check(strpos($api_html, 'name="key_version"') !== false, 'API tab has key controls');
check(strpos($approved_html, 'name="key_version"') === false, 'Dashboard separated from credentials');
$tabs = $ui->navigation(array('dashboard'=>'x','referral'=>'x','proxyline'=>'x'), '', $u->phone);
check(!isset($tabs['referral']) && isset($tabs['reseller-create'], $tabs['reseller-api'], $tabs['reseller-docs'], $tabs['orders'], $tabs['proxyline']), 'Approved navigation separates tasks and preserves add-ons');
check(strpos($ui->hero('old', $u->phone, 1910000, ''), 'پنل نمایندگی') !== false, 'Representative header');
same($ui->current_tab('reseller', $u->phone), 'dashboard', 'Legacy reseller link opens new dashboard');
check(!in_array('referral', $ui->allowed_tabs(array('referral'), $u->phone), true), 'Direct referral tab excluded');
$GLOBALS['wpdb']->rows['test_ipsvp_reseller_accounts'][1]['status'] = 'pending';
check(isset($ui->navigation(array('referral'=>'x'), '', $u->phone)['referral']), 'Ordinary user keeps referral');
same($ui->panel('keep', 'dashboard', $u->phone), 'keep', 'Ordinary dashboard preserved');
$GLOBALS['wpdb']->rows['test_ipsvp_reseller_accounts'][1]['status'] = 'approved';
$u->is_blocked = 1; same($ui->panel('keep', 'reseller-api', $u->phone), 'keep', 'Blocked user cannot see API settings'); $u->is_blocked = 0;

same($ui->panel('keep', 'profile', $u->phone), 'keep', 'Other dashboard tabs unaffected');
$GLOBALS['wpdb']->rows['test_ipsvp_reseller_accounts'][1]['business_name'] = '<script>alert(1)</script>';
$_POST = array('business_name' => 'Safe');
$db->credit = 0; $GLOBALS['wpdb']->rows['test_ipsvp_reseller_accounts'][1]['status'] = 'rejected';
$low_html = $ui->panel('', 'reseller', $u->phone); check(strpos($low_html, 'disabled="disabled"') !== false, 'Low-balance application button disabled'); check(strpos($low_html, '<script>alert(1)</script>') === false, 'Business name HTML escaped');

list($db, $u, $api, $s, $ui) = fixture(false); $_SERVER['REQUEST_METHOD'] = 'POST'; $GLOBALS['session_phone'] = $u->phone;
$_COOKIE['test_session'] = 'signed-session-1'; $_POST = array('ipsr_action' => 'apply', 'business_name' => 'Shop', 'ipsr_nonce' => 'invalid');
$ui->handle_front(); same(IPSVP_Reseller_Store::account(1), null, 'Invalid CSRF token cannot apply');
$nonce = hash('sha256', private_call($ui, 'nonce_action', $u)); $_COOKIE['test_session'] = 'signed-session-2'; $_POST['ipsr_nonce'] = $nonce;
$ui->handle_front(); same(IPSVP_Reseller_Store::account(1), null, 'CSRF token bound to signed customer session');
$_POST['ipsr_nonce'] = hash('sha256', private_call($ui, 'nonce_action', $u)); $ui->handle_front(); same(IPSVP_Reseller_Store::account(1)->status, 'pending', 'Valid bound form works');
$_SERVER['REQUEST_METHOD'] = 'GET';

list($db, $u, $api, $s, $ui) = fixture(); $api->failure = true; $op = buy($s, $u);
$_POST = array('operation_id' => $op->id, 'outcome' => 'refund', 'resolution_note' => 'Verified no delivery', 'verified' => 1);
$GLOBALS['wpdb']->fail_update = 'test_ipsvp_orders';
try { private_call($ui, 'resolve', $u); check(false, 'Refund should fail'); } catch (RuntimeException $e) { check(true, 'Refund storage failure caught'); }
same($db->get_local_wallet_balance(1), 1910000, 'Failed refund rolls back release'); same(IPSVP_Reseller_Store::operation($op->id)->state, 'manual_review', 'Failed refund remains reviewable');
$GLOBALS['wpdb']->fail_update = ''; check(!is_wp_error(private_call($ui, 'resolve', $u)), 'Refund can finalize after storage restored');
list($db, $u, $api, $s, $ui) = fixture(); $u->bot_tel_id = '123'; $op = buy($s, $u);
same($op->state, 'succeeded', 'Remote-wallet happy path'); same(IPSVP_Bot_API::$debits, 1, 'Remote charged once'); same($db->get_local_wallet_balance(1), 2000000, 'Remote payment has no second local charge');
list($db, $u, $api, $s, $ui) = fixture(); $GLOBALS['wpdb']->rows['test_ipsvp_reseller_accounts'][1]['discount_percent'] = '100'; $db->credit = 0; $op = buy($s, $u);
same($op->state, 'succeeded', 'Intentional free price works'); same((int) $op->receipt_id, 0, 'No false zero debit');
require __DIR__ . '/../includes/class-ipsvp-receipt-manager.php';
list($db, $u, $api, $s, $ui) = fixture(); $op = buy($s, $u);
same(IPSVP_Receipt_Manager::approve($op->receipt_id, $db, $api)['ok'], false, 'Generic approval cannot alter journal-managed receipts');
same(IPSVP_Receipt_Manager::reject($op->receipt_id, $db)['ok'], false, 'Generic rejection cannot release a reseller reservation');
same($db->get_local_wallet_balance(1), 1910000, 'Generic receipt actions leave accounting unchanged');
$GLOBALS['wpdb']->insert('test_ipsvp_receipts', array('user_id' => 1, 'order_id' => $op->order_id, 'status' => 'pending', 'type' => 'wallet_renewal', 'wallet_effect' => 'local', 'amount' => 2000000));
$legacy_receipt_id = $GLOBALS['wpdb']->insert_id;
same(IPSVP_Receipt_Manager::approve($legacy_receipt_id, $db, $api)['ok'], false, 'Legacy wallet receipt rechecks available funds under the shared lock');
same($api->calls, 1, 'Insufficient legacy receipt never mutates provider');
same($real_db->payment_method_from_receipt((object) array('remote_source' => 'reseller')), 'wallet', 'Reseller receipt displays wallet payment');
if (getenv('IPSR_RENDER_DIR')) {
    $dir = rtrim(getenv('IPSR_RENDER_DIR'), '/');
    $plugin = dirname(__DIR__);
    $theme = dirname($plugin, 2) . '/themes/ip-sabet';
    $style = file_get_contents($theme . '/dist/output.css') . file_get_contents($theme . '/src/styles.css');
    $style .= file_get_contents($plugin . '/assets/css/palette.css') . file_get_contents($plugin . '/assets/css/frontend.css') . file_get_contents($plugin . '/assets/css/commerce.css') . file_get_contents($plugin . '/assets/css/reseller.css');
    $style .= file_get_contents(dirname($plugin) . '/ip-sabet-referral-addon/assets/css/frontend.css');
    ob_start(); include __DIR__ . '/ui-components.php'; $components_html = ob_get_clean();
    $style .= '@font-face{font-family:Peyda;src:url(data:font/woff2;base64,' . base64_encode(file_get_contents($theme . '/public/fonts/peyda/PeydaFaNumWeb-Regular.woff2')) . ') format("woff2");font-weight:100 900}body{font-family:Peyda,Tahoma,sans-serif;margin:0;background:var(--ipsr-bg);color:var(--ipsr-ink)}main{max-width:1320px;margin:0 auto;padding:28px 24px}.preview-toolbar{display:flex;justify-content:space-between;align-items:center;gap:16px;padding:14px 24px;border-bottom:1px solid var(--ipsr-border);background:var(--ipsr-surface);color:var(--ipsr-ink)}.preview-toolbar button{padding:8px 16px;border:1px solid var(--ipsr-border);border-radius:9px}';
    $nav = '<nav class="ipsvp-panel-nav"><a href="#">داشبورد</a><a href="#">اطلاعات کاربری</a><a href="#">کیف پول</a><a href="#">سفارشات</a><a class="is-active" href="#">نمایندگی و وب‌سرویس</a><a href="#">دعوت دوستان</a></nav>';
    foreach (array('components' => $components_html, 'approved' => $approved_html, 'create' => $create_html, 'api' => $api_html, 'application' => $low_html, 'docs' => $docs, 'docs-standalone' => $docs, 'multiple-docs' => $docs . IPSVP_Reseller_Docs::shortcode()) as $name => $html) {
        $content = strpos($name, 'docs') !== false ? $html : '<div class="ipsvp ipsvp-panel">' . $nav . $html . '</div>';
        $page_style = $name === 'docs-standalone' ? str_replace(file_get_contents($plugin . '/assets/css/frontend.css'), '', $style) : $style;
        file_put_contents($dir . '/' . $name . '.html', '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><style>' . $page_style . '</style></head><body class="light" data-theme="light"><div class="navbar"></div><button id="mobile-menu-open-btn" hidden></button><button id="mobile-menu-close-btn" hidden></button><div id="mobile-mega-menu" hidden></div><header class="preview-toolbar"><strong>آی پی ثابت · پیش‌نمایش آزمایشی</strong><button onclick="ToggleTheme()">تغییر تم</button></header><main>' . $content . '</main><script>' . file_get_contents($theme . '/public/js/index.js') . '</script><script>' . file_get_contents($plugin . '/assets/js/commerce-ui.js') . '</script><script>' . file_get_contents($plugin . '/assets/js/reseller-docs.js') . '</script><script>' . file_get_contents($plugin . '/assets/js/reseller-workspace.js') . '</script></body></html>');
    }
}
$GLOBALS['wpdb']->lock_ok = false; error_is(IPSVP_Reseller_Store::lock(98765), 'wallet_busy');
echo "OK: $checks reseller assertions passed.\n";

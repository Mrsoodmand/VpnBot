<?php
/** Offline contract tests for the actual shared WordPress authority. */
if (PHP_SAPI !== 'cli') exit;
define('ABSPATH', '/');
// Test the default-enabled bridge without a wp-config constant.
class WP_Error { public function __construct(public $code, public $message, public $data = []) {} }
function is_wp_error($v) { return $v instanceof WP_Error; }
function add_action(...$args) {}
function add_filter(...$args) {}
function wp_timezone() { return new DateTimeZone('Asia/Tehran'); }
function wp_date($format, $at, $tz = null) { return (new DateTimeImmutable('@'.$at))->setTimezone($tz ?: wp_timezone())->format($format); }
function get_option($key, $default = false) { return $GLOBALS['options'][$key] ?? $default; }
function update_option($key, $value, $autoload = false) { $GLOBALS['options'][$key] = $value; }
function delete_option($key) { unset($GLOBALS['options'][$key]); }
class IPSVP_Settings { static function get() { return ['wp_sync_secret' => 'test-secret']; } }
class IPSVP_Reseller_Store {
    static function approved($id) { return false; }
    static function account($id) { return false; }
    static function lock($id) { return true; }
    static function audit(...$args) {}
}
class IPSVP_DB {
    function tables() { return ['users'=>'users','receipts'=>'receipts','orders'=>'orders']; }
    function get_user_by_id($id) { return $GLOBALS['wpdb']->user; }
}
class FakeSql {
    public $user = null; public array $receipts = []; public bool $first = false;
    function prepare($sql, ...$params) { return $sql; }
    function get_row($sql) { return $this->user; }
    function get_results($sql) { return $this->receipts; }
    function get_var($sql) { return $this->first ? 1 : 0; }
    function update($table, $data, $where) { foreach ($data as $k=>$v) $this->user->$k = $v; return 1; }
}
class IPSVP_Bot_API {
    public static int $calls = 0;
    static function request(...$args) { self::$calls++; return new WP_Error('offline','offline'); }
}
class Request {
    function __construct(public array $data = [], public string $secret = 'test-secret') {}
    function has_param($key) { return array_key_exists($key,$this->data); }
    function get_param($key) { return $this->data[$key] ?? null; }
    function get_header($key) { return $this->secret; }
}
require __DIR__.'/../includes/class-ipsvp-loyalty.php';
require __DIR__.'/../includes/class-ipsvp-customer-loyalty-sync.php';
IPSVP_Loyalty::init(new IPSVP_DB());
$GLOBALS['wpdb'] = new FakeSql(); $GLOBALS['options'] = [];
$n = 0;
function check($actual, $expected, $label) { global $n; $n++; if ($actual !== $expected) throw new RuntimeException($label.': '.json_encode([$actual,$expected])); }
function endpoint($action, $data) { return IPSVP_Customer_Loyalty_Sync::dispatch($action,new Request($data)); }
$now = time();
function bot_event($id,$amount,$age=0,$type='wallet') { global $now; return ['id'=>$id,'amount'=>$amount,'approved_at'=>$now-$age*86400,'type'=>$type,'key'=>'bot:'.$id]; }
function event_payload($rows,$first=false) { return ['rows'=>$rows,'first_purchase'=>$first,'currency'=>'IRT']; }
function bot_profile($rows,$tel='1001',$first=false) { return endpoint('profile',['tel_id'=>$tel,'events'=>event_payload($rows,$first)])['profile']; }
check(is_wp_error(IPSVP_Customer_Loyalty_Sync::authorize(new Request([], 'wrong'))),true,'Unauthorized rejected');
check(IPSVP_Customer_Loyalty_Sync::authorize(new Request()),true,'Same shared key');
check(IPSVP_Customer_Loyalty_Sync::enabled(),true,'Bridge enabled by default');
$next = bot_profile([bot_event(1,2000000)]);
check($next['next_amount'],3000000,'Next amount from policy');
check($next['next_percent'],10.0,'Next discount from policy');
check($next['next_stars'],3,'Next stars from policy');
foreach ([0=>0,1999999=>0,2000000=>5,3000000=>5,4999999=>5,5000000=>10,6000000=>10,9999999=>10,10000000=>20,12000000=>20] as $amount=>$rate) {
    check(bot_profile($amount ? [bot_event(1,$amount)] : [])['percent'],(float)$rate,'Exact customer boundary '.$amount);
}
check(bot_profile([bot_event(1,1000000),bot_event(2,1000000)])['percent'],5.0,'Small payments sum');
check(bot_profile([bot_event(1,2000000),bot_event(1,2000000)])['total'],2000000,'Repeated event deduplicated');
$mix = [bot_event(1,500000),bot_event(2,500000,0,'new'),bot_event(3,500000,0,'renewal'),bot_event(4,500000,0,'extra_volume')];
check(bot_profile($mix)['total'],2000000,'Topup purchase renewal extra combined');
check(bot_profile([bot_event(1,5000000,30)])['total'],0,'Exact 30 day expiration');
check(bot_profile([bot_event(1,5000000,29),bot_event(2,1000)])['expires_at'],$now+86400,'New deposit cannot extend old tier');
check(bot_profile([bot_event(1,3000000,25),bot_event(2,3000000,5),bot_event(3,2000000,1,'wallet_admin_debit')])['expires_at'],$now+5*86400,'Correction consumes newest first');
check(bot_profile([bot_event(1,5000000,31),bot_event(2,6000000,0,'wallet_admin_debit'),bot_event(3,2000000)])['total'],2000000,'Expired credits cannot consume correction; excess cannot carry forward');
check(bot_profile([bot_event(1,2000000,2),bot_event(2,3000000,1,'new'),bot_event(3,9000000,0,'wallet_admin_debit')])['total'],3000000,'Direct receipt cannot be corrected');
check(bot_profile([])['stars'],0,'No purchase zero stars');
check(bot_profile([],'1001',true)['stars'],1,'First successful purchase one star');
foreach (['15'=>[15.0,3],'0'=>[0.0,0],''=>[20.0,4]] as $value=>$expect) {
    endpoint('override',['tel_id'=>'1001','value'=>(string)$value]);
    $p = bot_profile([bot_event(1,10000000)]);
    check([$p['percent'],$p['stars']],$expect,'Override zero versus empty '.$value);
    if ($value !== '') check($p['expires_at'],null,'Manual never expires');
}
check(endpoint('override',['tel_id'=>'1001','value'=>'101'])->code,'invalid_loyalty_input','Bad fixed rate');
$original=IPSVP_Loyalty::defaults();$original['reseller'][0]['percent']=3;
$GLOBALS['options'][IPSVP_Loyalty::OPTION]=$original;
$custom=$original['customer'];$custom[1]['min']=3000000;$custom[1]['percent']=7;
$r=endpoint('settings',['customer'=>$custom]);check($r['ok'],true,'Custom settings saved');
check(get_option(IPSVP_Loyalty::OPTION)['reseller'],$original['reseller'],'Reseller settings preserved byte for byte');
check(bot_profile([bot_event(1,3000000)])['percent'],7.0,'Custom threshold shared');
foreach ([['min',-1],['percent',101],['min',5000000],['percent',11],['strict',1]] as [$field,$value]) {
    $bad=$custom;$bad[1][$field]=$value;
    check(is_wp_error(endpoint('settings',['customer'=>$bad])),true,'Invalid threshold/rate rejected');
}
$GLOBALS['options'][IPSVP_Loyalty::OPTION]=IPSVP_Loyalty::defaults();
// Linked site original + bot original, with a mirror and balance sync present.
$GLOBALS['wpdb']->user=(object)['id'=>1,'bot_tel_id'=>'2002','manual_discount_percent'=>null];
$site=(object)['id'=>1,'type'=>'wallet','status'=>'approved','amount'=>3000000,'reviewed_at'=>wp_date('Y-m-d H:i:s',$now),'remote_source'=>''];
$mirror=clone $site;$mirror->id=2;$mirror->remote_source='bot_wallet_mirror';
$sync=clone $site;$sync->id=3;$sync->remote_source='bot_wallet_sync';
$GLOBALS['wpdb']->receipts=[$site,$mirror,$sync];
IPSVP_Loyalty::clear_cache();
$bot=bot_profile([bot_event(9,2000000)],'2002');
$web=IPSVP_Loyalty::profile(1);
check($bot['total'],5000000,'Linked union counts each original once');
check($bot['percent'],$web['percent'],'Site and bot same percentage');
check($bot['total'],$web['total'],'Site and bot same total');
check($bot['stars'],$web['stars'],'Site and bot same stars');
check(IPSVP_Bot_API::$calls,0,'Bot profile supplies events; no recursive HTTP request');
endpoint('override',['tel_id'=>'2002','value'=>'0']);
check($GLOBALS['wpdb']->user->manual_discount_percent,'0','Shared SQL override stores explicit zero');
check(bot_profile([bot_event(9,10000000)],'2002')['percent'],0.0,'Shared zero has priority');
endpoint('override',['tel_id'=>'2002','value'=>'']);
check($GLOBALS['wpdb']->user->manual_discount_percent,null,'Clear stores null');
// No guessing of approval dates for old customer receipts.
$unknown=clone $site;$unknown->reviewed_at=null;$unknown->created_at=wp_date('Y-m-d H:i:s',$now);
check(IPSVP_Loyalty::calculate([$unknown],false,null,false,IPSVP_Loyalty::defaults(),$now)['total'],0,'Upload date not approval');
// An unlinked fixed override is adopted exactly once on linking.
$GLOBALS['options']['ipsvp_bot_customer_discount_2002']='15';
IPSVP_Customer_Loyalty_Sync::adopt_override($GLOBALS['wpdb']->user);
check($GLOBALS['wpdb']->user->manual_discount_percent,'15','Override survives link');
check(get_option('ipsvp_bot_customer_discount_2002',null),null,'No second authority after linking');
// Custom zero-percent tiers use the highest configured percentage not above the manual rate.
$custom = IPSVP_Loyalty::defaults();
$custom['customer'][1]['percent'] = 0;
check(IPSVP_Loyalty::calculate([], false, '0', false, $custom, $now)['stars'], 2, 'Manual stars follow customized percentages');
// Crypto/referral/refund/ordinary wallet spend are excluded by the real customer calculator.
foreach (['ramzino','bot_wallet_sync','service_refund','service_payment','referral'] as $source) {
    $excluded = clone $site; $excluded->remote_source = $source;
    check(IPSVP_Loyalty::calculate([$excluded], false, null, false, IPSVP_Loyalty::defaults(), $now)['total'], 0, 'Excluded financial source '.$source);
}
echo "PASS: $n customer synchronization assertions.\n";

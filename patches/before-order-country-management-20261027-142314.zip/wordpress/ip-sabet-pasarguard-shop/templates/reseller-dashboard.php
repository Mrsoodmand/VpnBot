<?php defined('ABSPATH') || exit;
$totals = $report['totals'];
$max_sales = max(1, ...array_column($report['days'], 'sales'));
$max_spent = max(1, ...array_column($report['days'], 'spent'));
?>
<div class="ipsr-heading"><div><span class="ipsr-eyebrow">نمای کلی کسب‌وکار</span><h2>داشبورد فروش</h2></div><a class="ipsr-button ipsr-button-primary" href="<?php echo esc_url(self::dashboard_url('reseller-create')); ?>">＋ ساخت کانفیگ</a></div>
<?php if ($report['unresolved']) : ?><p class="ipsr-note"><a href="<?php echo esc_url(self::dashboard_url('reseller-operations')); ?>"><?php echo esc_html(number_format_i18n($report['unresolved'])); ?> عملیات در انتظار تعیین تکلیف ←</a></p><?php endif; ?>
<form class="ipsr-period" method="get" action="<?php echo esc_url(self::dashboard_url('dashboard')); ?>"><input type="hidden" name="ipsvp_tab" value="dashboard"><label>بازه گزارش<select name="rs_period"><?php foreach (array(7,30,90) as $days) : ?><option value="<?php echo $days; ?>" <?php selected($report['period'], $days); ?>><?php echo esc_html(number_format_i18n($days)); ?> روز اخیر</option><?php endforeach; ?></select></label><button type="submit">نمایش</button></form>
<div class="ipsr-stats ipsr-stats-four">
    <div><span>کانفیگ فروخته‌شده</span><strong><?php echo esc_html(number_format_i18n($totals['sales'] ?? 0)); ?></strong><small>خرید موفق</small></div>
    <div><span>تمدید موفق</span><strong><?php echo esc_html(number_format_i18n($totals['renewals'] ?? 0)); ?></strong><small><?php echo esc_html(number_format_i18n($report['active'])); ?> سرویس فعال در حساب</small></div>
    <div><span>هزینه خرید و تمدید و حجم</span><strong><?php echo esc_html(number_format_i18n($totals['spent'] ?? 0)); ?></strong><small>تومان</small></div>
    <div><span>تخفیف دریافت‌شده</span><strong><?php echo esc_html(number_format_i18n($totals['savings'] ?? 0)); ?></strong><small>تومان صرفه‌جویی</small></div>
</div>
<div class="ipsr-dashboard-grid">
    <section class="ipsr-card ipsr-chart-card" data-ipsr-chart><div class="ipsr-card-heading"><h3>روند فروش</h3><div class="ipsr-chart-switch" role="group" aria-label="نوع نمودار"><button type="button" data-chart-metric="sales" aria-pressed="true">تعداد فروش</button><button type="button" data-chart-metric="spent" aria-pressed="false">مبلغ عملیات</button></div></div>
        <div class="ipsr-chart" role="group" aria-label="روند فروش روزانه؛ مقادیر دقیق در جدول زیر نمودار" dir="ltr">
            <?php foreach ($report['days'] as $point) : ?><div class="ipsr-chart-column" tabindex="0" data-sales="<?php echo (int) $point['sales']; ?>" data-spent="<?php echo (int) $point['spent']; ?>" data-height-sales="<?php echo esc_attr(round($point['sales'] / $max_sales * 100, 2)); ?>" data-height-spent="<?php echo esc_attr(round($point['spent'] / $max_spent * 100, 2)); ?>" style="--bar-height:<?php echo esc_attr(round($point['sales'] / $max_sales * 100, 2)); ?>%"><i aria-hidden="true"></i><span class="ipsr-chart-tip"><?php echo esc_html($point['day']); ?><br><?php echo esc_html(number_format_i18n($point['sales'])); ?> فروش<br><?php echo esc_html(number_format_i18n($point['spent'])); ?> تومان</span></div><?php endforeach; ?>
        </div><div class="ipsr-chart-axis" dir="ltr"><span><?php echo esc_html($report['days'][0]['day']); ?></span><span><?php echo esc_html(end($report['days'])['day']); ?></span></div>
        <?php if (empty($totals['operations'])) : ?><p class="ipsr-empty">در این بازه هنوز عملیاتی ثبت نشده است.</p><?php endif; ?>
        <details class="ipsr-chart-data"><summary>جدول روزانه</summary><div class="ipsr-table"><table><thead><tr><th>تاریخ</th><th>فروش موفق</th><th>هزینه (تومان)</th></tr></thead><tbody><?php foreach ($report['days'] as $point) : ?><tr><td><?php echo esc_html($point['day']); ?></td><td><?php echo esc_html(number_format_i18n($point['sales'])); ?></td><td><?php echo esc_html(number_format_i18n($point['spent'])); ?></td></tr><?php endforeach; ?></tbody></table></div></details>
    </section>
    <aside class="ipsr-card ipsr-channel-card"><span class="ipsr-eyebrow">کانال ثبت عملیات موفق</span><h3>دستی و وب‌سرویس</h3>
        <?php $count = max(1, (int) ($totals['operations'] ?? 0)); $api_percent = min(100, round(($totals['api_count'] ?? 0) / $count * 100)); ?>
        <div class="ipsr-donut" style="--api-share:<?php echo (int) $api_percent; ?>%" aria-hidden="true"><div><strong><?php echo esc_html(number_format_i18n($totals['operations'] ?? 0)); ?></strong><small>عملیات</small></div></div>
        <dl class="ipsr-channel-legend"><div><dt><i class="ipsr-dot-api"></i>وب‌سرویس</dt><dd><?php echo esc_html(number_format_i18n($totals['api_count'] ?? 0)); ?></dd></div><div><dt><i class="ipsr-dot-panel"></i>پنل نمایندگی</dt><dd><?php echo esc_html(number_format_i18n($totals['panel_count'] ?? 0)); ?></dd></div></dl>
        <a href="<?php echo esc_url(self::dashboard_url('reseller-api')); ?>">تنظیمات وب‌سرویس ←</a>
    </aside>
</div>
<?php $compact_operations = true; include __DIR__ . '/reseller-operations.php'; ?>

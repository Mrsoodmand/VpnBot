<?php defined('ABSPATH') || exit;
$compact_operations = !empty($compact_operations);
?>
<section class="ipsr-card"><div class="ipsr-card-heading"><h3><?php echo $compact_operations ? 'آخرین عملیات' : 'گردش عملیات'; ?></h3><?php if ($compact_operations) : ?><a href="<?php echo esc_url(self::dashboard_url('reseller-operations')); ?>">مشاهده همه ←</a><?php endif; ?></div>
<div class="ipsr-table"><table><thead><tr><th>پیگیری / سفارش</th><th>عملیات</th><th>منبع / مشتری</th><th>مبلغ (تومان)</th><th>وضعیت</th><th>زمان</th></tr></thead><tbody>
<?php foreach ($operations['items'] as $op) : ?><tr><td><strong>#<?php echo (int) $op->id; ?></strong><?php if ($op->order_id) : ?><br><a href="<?php echo esc_url(add_query_arg('ipsvp_order_id', (int) $op->order_id, self::dashboard_url('detail'))); ?>">سفارش #<?php echo (int) $op->order_id; ?></a><?php endif; ?></td><td><?php echo esc_html(self::label($op->action)); ?></td><td><?php echo ($op->channel ?? '') === 'api' ? 'وب‌سرویس' : 'دستی'; ?><small><?php echo esc_html($op->customer_reference); ?></small></td><td><?php echo esc_html(number_format_i18n($op->amount)); ?><small><?php echo esc_html($op->discount_percent); ?>٪ تخفیف</small></td><td><span class="ipsr-state ipsr-state-<?php echo esc_attr($op->state); ?>"><?php echo esc_html(self::label($op->state)); ?></span></td><td dir="ltr"><?php echo esc_html($op->created_at); ?></td></tr><?php endforeach; ?>
<?php if (!$operations['items']) : ?><tr><td colspan="6" class="ipsr-empty">هنوز عملیاتی ثبت نشده است.</td></tr><?php endif; ?>
</tbody></table></div>
<?php if (!$compact_operations && $operations['pages'] > 1) : ?><nav class="ipsr-pagination" aria-label="صفحه‌های عملیات"><?php echo wp_kses_post(paginate_links(array('base' => add_query_arg('rs_page', '%#%', self::dashboard_url('reseller-operations')), 'format' => '', 'current' => $operations['page'], 'total' => $operations['pages']))); ?></nav><?php endif; ?>
</section>

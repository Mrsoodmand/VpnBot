<?php defined('ABSPATH') || exit;
$ready = !$unresolved && $plans && $countries && !is_wp_error($balance) && $this->db->service_sales_enabled('shared');
?>
<div class="ipsr-heading"><div><span class="ipsr-eyebrow">ثبت دستی سفارش</span><h2>ساخت سریع کانفیگ</h2></div><span class="ipsr-state"><?php echo esc_html(number_format_i18n($account->discount_percent, 2)); ?>٪ تخفیف</span></div>
<?php if ($unresolved) : ?><p class="ipsr-note"><a href="<?php echo esc_url(self::dashboard_url('reseller-operations')); ?>">ابتدا عملیات در انتظار بررسی را تعیین تکلیف کنید ←</a></p><?php endif; ?>
<?php if (is_wp_error($balance)) : ?><p class="ipsvp-alert"><?php echo esc_html($balance->get_error_message()); ?></p><?php endif; ?>
<?php if ($this->last_operation && $this->last_operation->state === 'succeeded' && $this->last_operation->order_id) : ?><div class="ipsr-note"><a class="ipsr-button ipsr-button-primary" href="<?php echo esc_url(add_query_arg('ipsvp_order_id', (int) $this->last_operation->order_id, self::dashboard_url('detail'))); ?>">مشاهده سفارش و دریافت کانفیگ ←</a></div><?php endif; ?>
<div class="ipsr-create-grid" data-ipsr-create data-balance="<?php echo esc_attr(is_wp_error($balance) ? 0 : $balance); ?>">
    <div class="ipsr-card"><h3>مشخصات سرویس</h3>
        <?php $this->form_start($user, 'operation'); ?>
        <input type="hidden" name="operation" value="purchase"><input type="hidden" name="idempotency_key" value="<?php echo esc_attr(wp_generate_uuid4()); ?>">
        <label class="ipsr-full">پلن<select name="plan_id" required data-ipsr-plan><?php foreach ($plans as $p) : ?><option value="<?php echo (int) $p['id']; ?>" data-amount="<?php echo (int) $p['amount']; ?>" data-all-amount="<?php echo esc_attr($p['all_countries_amount'] ?? ''); ?>"><?php echo esc_html($p['title'] . ' — ' . number_format_i18n($p['amount']) . ' تومان'); ?></option><?php endforeach; ?></select></label>
        <label class="ipsr-full">کشور<select name="country_id" required data-ipsr-country><?php foreach ($countries as $c) : ?><option value="<?php echo (int) $c['id']; ?>"><?php echo esc_html($c['flag'] . ' ' . $c['name']); ?></option><?php endforeach; ?></select></label>
        <label>شناسه مشتری<input name="customer_reference" maxlength="100" placeholder="customer-123" dir="ltr"></label>
        <label>سقف پرداخت (تومان)<input type="number" name="max_amount" min="0" step="1" placeholder="اختیاری" data-ipsr-max></label>
        <div class="ipsr-full"><button class="ipsvp-btn" data-ipsr-buy data-ready="<?php echo $ready ? '1' : '0'; ?>" <?php disabled(!$ready); ?>>ساخت و پرداخت از کیف پول</button></div>
        </form>
    </div>
    <aside class="ipsr-card ipsr-quote-preview"><span class="ipsr-eyebrow">خلاصه سفارش</span><h3>مبلغ نهایی</h3><strong data-ipsr-amount>—</strong><span>تومان</span><dl><div><dt>تخفیف نمایندگی</dt><dd><?php echo esc_html(number_format_i18n($account->discount_percent, 2)); ?>٪</dd></div><div><dt>موجودی کیف پول</dt><dd><?php echo esc_html(is_wp_error($balance) ? '—' : number_format_i18n($balance)); ?></dd></div><div><dt>موجودی پس از خرید</dt><dd data-ipsr-after>—</dd></div></dl><p class="ipsr-note" data-ipsr-insufficient hidden>موجودی کافی نیست. <a href="<?php echo esc_url(self::dashboard_url('wallet')); ?>">شارژ کیف پول</a></p></aside>
</div>

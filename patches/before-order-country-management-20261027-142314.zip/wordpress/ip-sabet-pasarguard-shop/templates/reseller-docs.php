<?php defined('ABSPATH') || exit; ?>
<article class="ipsr ipsr-docs" dir="rtl" data-ipsr-docs id="<?php echo esc_attr($uid); ?>">
    <header class="ipsr-docs-hero">
        <div class="ipsr-docs-hero-inner">
            <div class="ipsr-docs-kicker"><span dir="ltr">API v1</span> مرکز توسعه‌دهندگان آی پی ثابت</div>
            <h2>فروشگاه شما،<br>متصل به وب‌سرویس آی پی ثابت</h2>
            <p>از اولین استعلام تا خرید و تمدید؛ سرویس‌های اشتراکی را با تعرفه نمایندگی و پرداخت مستقیم از کیف پول مدیریت کنید.</p>
            <div class="ipsr-docs-actions"><a class="ipsr-button ipsr-button-primary" href="#<?php echo esc_attr($uid); ?>-start">شروع اتصال <span aria-hidden="true">←</span></a><a class="ipsr-button" href="<?php echo esc_url($base . '/openapi'); ?>">دریافت OpenAPI <span aria-hidden="true">↗</span></a></div>
            <div class="ipsr-docs-facts"><span>REST / JSON</span><span>اتصال امن HTTPS</span><span>پرداخت به تومان</span><span>۶۰ درخواست در دقیقه</span></div>
        </div>
    </header>
    <div class="ipsr-docs-layout">
        <details class="ipsr-docs-sidebar" open>
            <summary>فهرست مستندات</summary>
            <nav aria-label="فهرست مستندات وب‌سرویس">
                <p class="ipsr-docs-nav-title">راهنمای اتصال</p>
                <?php foreach ($sections as $id => $title) : ?><a href="#<?php echo esc_attr($uid . '-' . $id); ?>"><?php echo esc_html($title); ?></a><?php endforeach; ?>
                <p class="ipsr-docs-nav-title">حساب و تعرفه‌ها</p>
                <?php foreach ($endpoints as $index => $e) : ?>
                    <?php if ($index === 5) : ?><p class="ipsr-docs-nav-title">خرید و مدیریت سرویس</p><?php elseif ($index === 13) : ?><p class="ipsr-docs-nav-title">گردش و پیگیری عملیات</p><?php endif; ?>
                    <a href="#<?php echo esc_attr($uid . '-' . self::endpoint_id($e)); ?>" title="<?php echo esc_attr($e[2]); ?>" dir="ltr"><span class="ipsr-method ipsr-method-<?php echo strtolower($e[0]); ?>"><?php echo esc_html($e[0]); ?></span><span><?php echo esc_html($e[1]); ?></span></a>
                <?php endforeach; ?>
            </nav>
        </details>
        <div class="ipsr-docs-content">
            <section class="ipsr-docs-section" id="<?php echo esc_attr($uid); ?>-start">
                <span class="ipsr-section-label">QUICK START</span><h3>در سه قدم، آماده اتصال شوید</h3>
                <ol class="ipsr-quicksteps"><li><strong>درخواست نمایندگی</strong><p>کیف پول را حداقل ۲ میلیون تومان شارژ و از پنل درخواست ثبت کنید.</p></li><li><strong>دریافت کلید دسترسی</strong><p>پس از تأیید مدیریت، تخفیف خود را ببینید و کلید API بسازید.</p></li><li><strong>اولین درخواست</strong><p>از سرور خود، موجودی کیف پول را با نمونه زیر بخوانید.</p></li></ol>
                <p class="ipsr-note">درخواست عضویت رایگان است و مبلغی کسر نمی‌شود. پس از تأیید، برای هر عملیات فقط موجودی کافی برای هزینه همان عملیات لازم است.</p>
                <?php self::code_block($base, 'BASE URL'); ?>
                <?php self::code_block(self::curl_example($base, array('GET', '/wallet', '', array())), 'اولین درخواست · cURL'); ?>
            </section>
            <section class="ipsr-docs-section" id="<?php echo esc_attr($uid); ?>-auth"><span class="ipsr-section-label">AUTHENTICATION</span><h3>احراز هویت و امنیت اتصال</h3>
            <p>تمام درخواست‌ها باید از سرور شما و با HTTPS ارسال شوند. کلید فقط در هدر <code>Authorization: Bearer YOUR_API_KEY</code> قرار می‌گیرد. ارسال کلید در URL یا بدنه معتبر نیست. برای درخواست POST هدر <code>Content-Type: application/json</code> لازم است. کلید فقط یک‌بار در پنل نمایش داده می‌شود؛ با ساخت کلید تازه، کلید قبلی فوراً لغو می‌شود. تعلیق نمایندگی یا مسدودی حساب نیز دسترسی را قطع می‌کند.</p>
            <p>در پنل می‌توانید کلید را لغو و حداکثر ۲۰ IP سرور را مجاز کنید. همه پاسخ‌های خصوصی بدون کش هستند. سقف استفاده ۶۰ درخواست در هر دقیقه تقویمی برای هر نماینده است. پس از پاسخ 429 تا دقیقه بعد صبر کنید. شناسه کاربران و سفارش‌ها فقط در محدوده حساب خودتان قابل دسترسی است.</p>
            </section>
<section class="ipsr-docs-section" id="<?php echo esc_attr($uid); ?>-pricing"><span class="ipsr-section-label">PRICING</span><h3>واحد پول، تخفیف و قیمت</h3>
            <p>تمام مبالغ عدد صحیح <strong>تومان (IRT)</strong> هستند، نه ریال. مبنا قیمت فروش جاری سایت است (اگر قیمت فروش ویژه فعال باشد، همان قیمت). ابتدا هزینه همه کشورها اضافه می‌شود و سپس تخفیف نمایندگی اعمال و مبلغ نهایی رو به بالا به تومان گرد می‌شود. برای مثال قیمت ۱۰۰٬۰۰۰ با تخفیف ۱۰٪ برابر ۹۰٬۰۰۰ تومان است. خرید، تمدید و حجم اضافه هزینه دارند؛ استعلام‌ها و توقف/فعال‌سازی رایگان هستند.</p>
            <p>برای نمایش قیمت ابتدا <code>/plans</code> یا <code>/quote</code> را بخوانید. استعلام، مبلغ را رزرو نمی‌کند. فیلد اختیاری <code>max_amount</code> سقف مجاز کسر است؛ اگر قیمت جدید بالاتر باشد، پاسخ 409 می‌گیرید و خرید انجام نمی‌شود. ارسال قیمت یا درصد تخفیف دلخواه پذیرفته نیست.</p>
            </section>
<section class="ipsr-docs-section" id="<?php echo esc_attr($uid); ?>-idempotency"><span class="ipsr-section-label">IDEMPOTENCY</span><h3>جلوگیری از خرید و کسر تکراری</h3>
            <p>در همه POSTهای تغییردهنده (به‌جز <code>/quote</code>) هدر <code>Idempotency-Key</code> الزامی است: ۱۶ تا ۱۰۰ کاراکتر انگلیسی، عدد یا <code>._:-</code>؛ UUID پیشنهاد می‌شود. یک کلید را پیش از ارسال در دیتابیس خود ذخیره کنید. تکرار همان کلید و همان ورودی، همان عملیات را برمی‌گرداند و دوباره مبلغی کسر یا سرویسی ایجاد نمی‌کند. استفاده از همان کلید برای ورودی متفاوت، خطای 409 است. کلیدها منقضی یا با تغییر کلید API پاک نمی‌شوند.</p>
            <p>اگر اتصال قطع شد، از <code>GET /operations/lookup</code> با همان هدر <code>Idempotency-Key</code> استفاده کنید یا دقیقاً همان درخواست را با همان شناسه تکرار کنید. هرگز صرفاً به دلیل timeout شناسه تازه نسازید. پاسخ 202 به معنای موفقیت نهایی نیست: عملیات در حال پردازش یا نیازمند بررسی است. با فاصله حداقل ۵ ثانیه پیگیری کنید؛ برای <code>manual_review</code> با پشتیبانی و شماره عملیات تماس بگیرید. در این وضعیت عملیات تازه تا تعیین تکلیف مسدود است.</p>
            </section>
<section class="ipsr-docs-section" id="<?php echo esc_attr($uid); ?>-endpoints"><span class="ipsr-section-label">API REFERENCE</span><h3>فهرست کامل endpointها</h3>
            <label class="ipsr-search"><span>جست‌وجو در مسیرها و توضیحات</span><input type="search" data-ipsr-search placeholder="مثلاً تمدید، wallet یا POST" autocomplete="off" aria-controls="<?php echo esc_attr($uid); ?>-endpoint-list"></label>
            <p class="ipsr-search-status" data-ipsr-search-status role="status" aria-live="polite"><?php echo count($endpoints); ?> مسیر در دسترس</p>
            <div id="<?php echo esc_attr($uid); ?>-endpoint-list">
            <?php foreach ($endpoints as $e) : $schema = self::body_schema($e[1]); ?>
                <details class="ipsr-endpoint-card" id="<?php echo esc_attr($uid . '-' . self::endpoint_id($e)); ?>" data-ipsr-endpoint data-search="<?php echo esc_attr(implode(' ', array_slice($e, 0, 3))); ?>">
                    <summary><span class="ipsr-route"><span class="ipsr-method ipsr-method-<?php echo strtolower($e[0]); ?>"><?php echo esc_html($e[0]); ?></span><code><?php echo esc_html($e[1]); ?></code></span><span class="ipsr-endpoint-title"><?php echo esc_html($e[2]); ?></span></summary>
                    <div class="ipsr-endpoint-body">
                    <p><?php echo $e[1] === '/quote' ? 'استعلام رایگان؛ Idempotency-Key لازم نیست.' : ($e[0] === 'POST' ? 'هدر Idempotency-Key الزامی است. پاسخ شامل operation و در صورت وجود order است.' : 'درخواست خواندن؛ بدنه ارسال نکنید.'); ?></p>
                    <?php if (strpos($e[1], '{id}') !== false) : ?><p>پارامتر مسیر <code>id</code> عدد صحیح مثبت است؛ شناسه عملیات با شناسه سفارش متفاوت است و باید متعلق به حساب شما باشد.</p><?php endif; ?>
                    <?php if ($e[1] === '/operations/lookup') : ?><p class="ipsr-note">هدر <code>Idempotency-Key</code> همان درخواست اولیه الزامی است؛ کلید جدید نسازید.</p><?php endif; ?>
                    <?php if ($e[0] === 'POST' && !empty($schema['properties'])) : ?>
                        <h4>پارامترهای بدنه JSON</h4><dl class="ipsr-fields"><?php foreach ($schema['properties'] as $name => $field) : $required = in_array($name, $schema['required'] ?? array(), true); ?>
                            <dt><code><?php echo esc_html($name); ?></code><span class="ipsr-type"><?php echo esc_html($field['type']); ?></span><span class="<?php echo $required ? 'ipsr-required' : 'ipsr-optional'; ?>"><?php echo $required ? 'الزامی' : 'اختیاری / وابسته به عملیات'; ?></span></dt><dd><?php echo esc_html($field['description'] ?? ''); ?></dd>
                        <?php endforeach; ?></dl>
                    <?php endif; ?>
                    <?php if (in_array($e[1], array('/orders', '/operations'), true) && $e[0] === 'GET') : ?><p>پارامترهای صفحه‌بندی: <code>page=1&amp;per_page=20</code>؛ حداکثر ۵۰ رکورد در صفحه، از جدید به قدیم و فقط برای همین حساب.</p><?php endif; ?>
                    <?php if ($e[1] === '/quote') : ?><p>خرید: action=purchase و plan_id و country_id؛ تمدید: action=renew و order_id و plan_id؛ حجم اضافه: action=extra-volume و order_id و gb؛ توقف/فعال‌سازی: action=disable یا enable و order_id.</p><?php endif; ?>
                    <?php if ($e[1] === '/orders/{id}/usage') : ?><p>فیلد <code>live_available</code> دریافت داده زنده را مشخص می‌کند. <code>usage.used</code> و <code>usage.limit</code> به بایت هستند. <code>usage.expire</code> زمان Unix به ثانیه یا تاریخ ISO پنل است؛ صفر/خالی می‌تواند به معنی شروع‌نشده یا بدون انقضا باشد.</p><?php endif; ?>
                    <?php self::code_block(self::curl_example($base, $e), 'cURL · ' . $e[0] . ' ' . $e[1]); ?>
                    <p><a href="#<?php echo esc_attr($uid); ?>-responses">ساختار پاسخ و وضعیت عملیات</a> · <a href="#<?php echo esc_attr($uid); ?>-errors">راهنمای خطاها</a></p>
                    </div>
                </details>
            <?php endforeach; ?>
            </div>
            <p data-ipsr-empty hidden class="ipsr-note">مسیری پیدا نشد. عبارت کوتاه‌تر یا نام انگلیسی مسیر را جست‌وجو کنید.</p>
            </section>
<section class="ipsr-docs-section" id="<?php echo esc_attr($uid); ?>-examples"><span class="ipsr-section-label">EXAMPLES</span><h3>نمونه خرید و پیگیری با cURL</h3>
            <div class="ipsr-code"><div class="ipsr-code-bar"><span>نمونه درخواست / پاسخ</span><button type="button" class="ipsr-copy" data-ipsr-copy hidden>کپی کد</button></div><pre><code><?php echo esc_html(implode(' ' . chr(92) . PHP_EOL, array(
                'curl -X POST "' . $base . '/orders"',
                '  -H "Authorization: Bearer YOUR_API_KEY"',
                '  -H "Content-Type: application/json"',
                '  -H "Idempotency-Key: 4f2e5b76-4c13-4be1-9a73-71497c8c41c9"',
                '  --data ' . chr(39) . '{"plan_id":1,"country_id":1,"customer_reference":"customer-123","max_amount":500000}' . chr(39)
            ))); ?></code></pre></div>
            <div class="ipsr-code"><div class="ipsr-code-bar"><span>نمونه درخواست / پاسخ</span><button type="button" class="ipsr-copy" data-ipsr-copy hidden>کپی کد</button></div><pre><code><?php echo esc_html(implode(' ' . chr(92) . PHP_EOL, array(
                'curl "' . $base . '/operations/lookup"',
                '  -H "Authorization: Bearer YOUR_API_KEY"',
                '  -H "Idempotency-Key: 4f2e5b76-4c13-4be1-9a73-71497c8c41c9"'
            ))); ?></code></pre></div>
            </section>
<section class="ipsr-docs-section" id="<?php echo esc_attr($uid); ?>-responses"><span class="ipsr-section-label">RESPONSES</span><h3>ساختار پاسخ‌ها</h3>
            <p>پاسخ موفق با <code>data</code> شروع می‌شود. پاسخ عملیات شامل قیمت ثبت‌شده، درصد تخفیف و شناسه پیگیری است. نمونه زیر صرفاً آموزشی است:</p>
            <div class="ipsr-code"><div class="ipsr-code-bar"><span>نمونه درخواست / پاسخ</span><button type="button" class="ipsr-copy" data-ipsr-copy hidden>کپی کد</button></div><pre><code><?php echo esc_html(wp_json_encode(array('data' => array('operation' => array('id' => 42, 'action' => 'purchase', 'state' => 'succeeded', 'order_id' => 105, 'base_amount' => 100000, 'discount_percent' => 10, 'amount' => 90000, 'currency' => 'IRT', 'customer_reference' => 'customer-123', 'error_code' => null, 'created_at' => '2026-09-24 12:00:00', 'updated_at' => '2026-09-24 12:00:02'), 'order' => array('id' => 105, 'code' => 'RS-42-EXAMPLE', 'plan_id' => 1, 'country_id' => 1, 'status' => 'on_hold', 'amount' => 90000, 'currency' => 'IRT', 'subscription_url' => 'https://example.com/sub/PRIVATE', 'links' => array(), 'created_at' => '2026-09-24 12:00:00'))), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)); ?></code></pre></div>
            <p>در پاسخ <code>/account</code>، مقدار <code>discount_percent</code> تخفیف فعال است. <code>discount_source</code> منبع دستی یا خودکار، <code>discount_expires_at</code> پایان اعتبار تخفیف به UTC و <code>stars</code> سطح حساب را نشان می‌دهد. اعتبار تهی یعنی تخفیف پایه یا دستی بدون انقضای زمانی. استعلام قیمت را پیش از هر خرید تازه بگیرید.</p>
            <p>فهرست‌ها به صورت <code>data: {items: [], page: 1, per_page: 20, total: 0, total_pages: 0}</code> هستند. پاسخ استعلام شامل <code>request</code>، <code>base_amount</code>، <code>discount_percent</code>، <code>amount</code> و <code>currency</code> است. تاریخ‌های عملیات به منطقه زمانی سایت و تاریخ اعتبار/آخرین استفاده کلید به UTC هستند.</p>
            <dl><dt>reserved / processing</dt><dd>ثبت یا پردازش؛ نتیجه قطعی نیست و رزرو مالی ممکن است انجام شده باشد.</dd><dt>succeeded</dt><dd>عملیات با موفقیت ثبت و تحویل شده است.</dd><dt>manual_review / refund_review</dt><dd>نتیجه سرویس یا کیف پول نامشخص است؛ مدیریت باید بررسی کند. خرید یا بازپرداخت خودکار تکرار نمی‌شود.</dd><dt>failed / refunded</dt><dd>عملیات بدون تحویل تعیین تکلیف شده؛ کسر تأیید نشده یا وجه آزاد/بازپرداخت شده است. با همان شناسه تکرار نخواهد شد.</dd></dl>
            </section>
<section class="ipsr-docs-section" id="<?php echo esc_attr($uid); ?>-errors"><span class="ipsr-section-label">ERRORS</span><h3>خطاها و محدودیت‌ها</h3>
            <div class="ipsr-code"><div class="ipsr-code-bar"><span>نمونه درخواست / پاسخ</span><button type="button" class="ipsr-copy" data-ipsr-copy hidden>کپی کد</button></div><pre><code>{"code":"ipsr_insufficient_balance","message":"موجودی کیف پول کافی نیست.","data":{"status":402}}</code></pre></div>
            <div class="ipsr-table"><table><thead><tr><th>HTTP</th><th>معنا</th></tr></thead><tbody>
            <?php foreach (array(400 => 'ورودی، پلن، کشور، شناسه یکتا یا حجم نامعتبر؛ gb عدد صحیح ۱ تا ۱۰۰۰۰ است.', 401 => 'کلید نامعتبر، لغوشده یا منقضی.', 402 => 'موجودی کافی نیست؛ از پنل سایت شارژ کنید.', 403 => 'حساب تأیید نشده/مسدود، IP غیرمجاز یا اتصال بدون HTTPS.', 404 => 'سفارش/عملیات وجود ندارد یا متعلق به شما نیست.', 409 => 'تداخل شناسه یکتا، تغییر قیمت، قفل حساب، وضعیت سرویس نامعتبر، فروش متوقف یا عملیات تعیین‌تکلیف‌نشده.', 413 => 'بدنه بیش از ۸ کیلوبایت.', 415 => 'Content-Type نامعتبر.', 429 => 'بیش از ۶۰ درخواست در دقیقه.', 503 => 'کیف پول، پنل یا ذخیره‌سازی موقتاً در دسترس نیست؛ وضعیت را با همان شناسه پیگیری کنید.') as $status => $text) : ?><tr><td><?php echo (int) $status; ?></td><td><?php echo esc_html($text); ?></td></tr><?php endforeach; ?>
            </tbody></table></div>
            <p>تمدید و حجم اضافه طبق مهلت و وضعیت‌های مجاز فروشگاه انجام می‌شود. توقف فقط برای سرویس active و فعال‌سازی فقط برای disabled دارای زمان و حجم معتبر است؛ سرویس on_hold قبل از اولین اتصال از این مسیر فعال نمی‌شود. کشور صفر فقط زمانی معتبر است که فروش همه کشورها فعال باشد. حذف سرویس، انتقال مالکیت، تغییر گروه پنل، شارژ مستقیم کیف پول و ساخت کاربر به نام شخص دیگر از API مجاز نیست. برای شارژ از پنل سایت استفاده کنید.</p>
            <p>این نسخه وب‌هوک خروجی ندارد؛ نتیجه‌ها از endpointهای عملیات پیگیری می‌شوند. هیچ کلید پنل، رمز، شماره تلفن مشتری دیگر یا پاسخ داخلی سرویس‌دهنده در API منتشر نمی‌شود.</p>
</section>
            <footer class="ipsr-docs-footer"><span>همه مبالغ به تومان (IRT) هستند.</span><a href="#<?php echo esc_attr($uid); ?>">بازگشت به ابتدای راهنما ↑</a></footer>
        </div>
    </div>
    <span class="ipsr-copy-feedback" role="status" aria-live="polite"></span>
</article>

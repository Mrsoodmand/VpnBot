<?php
defined('ABSPATH') || exit;
global $wpdb;
$op_table = IPSVP_Reseller_Store::table('operations');
$order_table = $this->db->tables()['orders'];
$approved = $account && $account->status === 'approved';
$can_apply = !is_wp_error($balance) && $balance >= IPSVP_Reseller_Store::MIN_BALANCE && (!$account || in_array($account->status, array('rejected', 'customer'), true));
?>
<section class="ipsr" dir="rtl">
    <div class="ipsr-heading"><div><span class="ipsr-eyebrow">پنل همکاری آی پی ثابت</span><h2>نمایندگی و وب‌سرویس</h2><p>فروش کانفیگ، مدیریت سرویس‌ها و اتصال فروشگاه شما به کیف پول سایت.</p></div><a class="ipsvp-secondary" href="<?php echo esc_url(self::dashboard_url('wallet')); ?>">شارژ کیف پول</a></div>
    <?php echo wp_kses_post($this->notice); ?>
    <div class="ipsr-stats">
        <div><span>وضعیت نمایندگی</span><strong><?php echo esc_html($account ? self::label($account->status) : 'ثبت‌نام نشده'); ?></strong></div>
        <div><span>موجودی قابل مصرف</span><strong><?php echo esc_html(is_wp_error($balance) ? 'موقتاً در دسترس نیست' : number_format_i18n($balance) . ' تومان'); ?></strong></div>
        <div><span>تخفیف اختصاصی شما</span><strong><?php echo esc_html($approved ? number_format_i18n((float) $account->discount_percent, 2) . '٪' : 'پس از تأیید مدیریت'); ?></strong></div>
    </div>
    <?php if (is_wp_error($balance)) : ?><p class="ipsvp-alert"><?php echo esc_html($balance->get_error_message()); ?></p><?php endif; ?>
    <?php if ($account && $account->review_note) : ?><p class="ipsr-note">پیام مدیریت: <?php echo esc_html($account->review_note); ?></p><?php endif; ?>
    <?php if (!$approved) : ?>
        <div class="ipsr-card"><h3>درخواست نمایندگی و دسترسی وب‌سرویس</h3><p>برای ثبت درخواست و تأیید اولیه، حداقل <strong>۲٬۰۰۰٬۰۰۰ تومان</strong> موجودی لازم است. این مبلغ هزینه عضویت نیست و هنگام درخواست از حساب کم نمی‌شود. پس از تأیید، هزینه هر خرید، تمدید و حجم اضافه با تخفیف اختصاصی از کیف پول کسر می‌شود.</p>
        <?php if (!$account || in_array($account->status, array('rejected', 'customer'), true)) : ?>
            <?php $this->form_start($user, 'apply'); ?>
                <label>نام کسب‌وکار<input name="business_name" maxlength="100" required value="<?php echo esc_attr($account->business_name ?? ''); ?>"></label>
                <label>وب‌سایت (اختیاری)<input type="url" name="website" dir="ltr" maxlength="255" placeholder="https://example.com" value="<?php echo esc_attr($account->website ?? ''); ?>"></label>
                <label class="ipsr-full">توضیح همکاری<textarea name="application_note" rows="3" maxlength="1000"><?php echo esc_textarea($account->application_note ?? ''); ?></textarea></label>
                <div class="ipsr-full"><button class="ipsvp-btn" <?php disabled(!$can_apply); ?>>ثبت درخواست نمایندگی</button></div>
            </form>
            <?php if (!$can_apply) : ?><p class="ipsr-note">با رسیدن موجودی به ۲ میلیون تومان، دکمه ثبت درخواست فعال می‌شود. <?php if (!is_wp_error($balance)) { echo esc_html('مبلغ مورد نیاز برای شارژ: ' . number_format_i18n(max(0, IPSVP_Reseller_Store::MIN_BALANCE - $balance)) . ' تومان'); } ?></p><?php endif; ?>
        <?php else : ?><p class="ipsr-note"><?php echo $account->status === 'pending' ? 'درخواست شما ثبت شده است. نتیجه پس از بررسی مدیریت در همین بخش نمایش داده می‌شود.' : 'دسترسی نمایندگی تعلیق شده است؛ برای بررسی با پشتیبانی تماس بگیرید.'; ?></p><?php endif; ?>
        </div>
    <?php endif; ?>

</section>

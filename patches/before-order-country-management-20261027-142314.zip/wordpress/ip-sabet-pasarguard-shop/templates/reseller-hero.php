<?php defined('ABSPATH') || exit; ?>
<header class="ipsr ipsr-workspace-hero" dir="rtl">
    <div class="ipsr-workspace-identity"><span class="ipsr-eyebrow">همکار فروش آی پی ثابت من</span><h2>پنل نمایندگی</h2><div class="ipsr-hero-tags"><strong><?php echo esc_html($account->business_name); ?></strong><span class="ipsr-state">نمایندگی فعال</span><?php if (!class_exists('IPSVP_Loyalty')) : ?><span><?php echo esc_html(number_format_i18n((float) $account->discount_percent, 2)); ?>٪ تخفیف</span><?php endif; ?></div></div>
    <div class="ipsr-hero-wallet"><span>موجودی کیف پول</span><strong><?php echo esc_html(number_format_i18n((int) $balance)); ?><small>تومان</small></strong><a class="ipsr-button" href="<?php echo esc_url(self::dashboard_url('wallet')); ?>">افزایش موجودی <span aria-hidden="true">↗</span></a></div>
</header>

<?php

use App\Services\OrderLifecycleService;
use App\Services\OrderLifecycleNotificationService;
use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;
use Illuminate\Support\Facades\Cache;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

Artisan::command('orders:sync-lifecycle', function () {
    // Also covers direct cron/manual invocations, not only schedule:run.
    $lock = Cache::lock('orders:lifecycle:runner', 900);
    if (!$lock->get()) {
        $this->info('Lifecycle worker is already running.');
        return;
    }
    try {
        $result = [
            'at' => now()->toDateTimeString(),
            'synchronization' => app(OrderLifecycleService::class)->synchronizeAll(),
            'notifications' => app(OrderLifecycleNotificationService::class)->sendDueNotifications(),
        ];
        Cache::put('orders:lifecycle:last-run', $result, now()->addDays(7));
        $this->info(json_encode($result, JSON_UNESCAPED_UNICODE));
    } finally {
        $lock->release();
    }
})->purpose('Synchronize order lifecycle and send due renewal/volume notifications');

Schedule::command('orders:sync-lifecycle')
    ->everyMinute()
    ->withoutOverlapping(30);

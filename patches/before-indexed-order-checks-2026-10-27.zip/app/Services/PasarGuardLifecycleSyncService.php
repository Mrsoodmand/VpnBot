<?php

namespace App\Services;

use App\Lib\PasarGuard;
use App\Models\Orders;
use App\Models\Panels;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use RuntimeException;
use Throwable;

/** Bounded, resumable scans of only the bot's users, with no config downloads. */
class PasarGuardLifecycleSyncService
{
    public const BATCH_SIZE = 200;

    public const MAX_REQUESTS = 5;

    public function synchronize(OrderLifecycleService $lifecycle): array
    {
        $interval = OrderNotificationSettings::load()['interval'];
        $result = ['checked' => 0, 'failed' => 0, 'requests' => 0];
        $deadline = microtime(true) + 40;
        $panels = Panels::where('system_type', 'pasarguard')
            ->whereIn('id', Orders::botManaged()->whereNotNull('uid')->select('panel_id'))
            ->get()->sortBy(fn ($panel) => Cache::get($this->key($panel->id), [])['attempted_at'] ?? 0);

        // One batch per panel per round prevents a large panel starving smaller ones.
        for ($round = 0; $round < self::MAX_REQUESTS; $round++) {
            $progress = false;
            foreach ($panels as $panel) {
                if ($result['requests'] >= self::MAX_REQUESTS || microtime(true) >= $deadline) {
                    break 2;
                }
                $key = $this->key($panel->id);
                $state = Cache::get($key, []);
                if (($state['retry_at'] ?? 0) > now()->timestamp ||
                    (! isset($state['cursor']) && ($state['completed_at'] ?? 0) > now()->subMinutes($interval)->timestamp)) {
                    continue;
                }
                $base = Orders::botManaged()->where('panel_id', $panel->id)->whereNotNull('uid')
                    ->whereIn('status', ['active', 'data_exhausted', 'suspended', 'inactive', '1', '0', '2', 'created', 'limited', 'expired', 'on_hold'])
                    ->where(fn ($q) => $q->whereNull('expire_at')->orWhere('expire_at', '>', now()->subDays(OrderLifecycleService::RENEWAL_GRACE_DAYS)));
                $state['ceiling'] ??= (int) (clone $base)->max('id');
                $orders = (clone $base)->where('id', '>', $state['cursor'] ?? 0)->where('id', '<=', $state['ceiling'])
                    ->orderBy('id')->limit(self::BATCH_SIZE)->get();
                if ($orders->isEmpty()) {
                    Cache::put($key, ['completed_at' => now()->timestamp, 'attempted_at' => now()->timestamp], now()->addDays(7));

                    continue;
                }
                $eligible = $orders->reject(fn ($order) => $lifecycle->shouldSkipProviderRefresh($order));
                $ids = $eligible->pluck('uid')->map(fn ($id) => (string) $id)->filter(fn ($id) => ctype_digit($id) && (int) $id > 0)->unique()->values()->all();
                $result['failed'] += $eligible->filter(fn ($o) => ! ctype_digit((string) $o->uid) || (int) $o->uid < 1)->count();
                $state['attempted_at'] = now()->timestamp;
                try {
                    if ($ids) {
                        $result['requests']++;
                        $progress = true;
                        $response = $this->fetch($panel, $ids);
                        if (! is_array($response) || ($response['status'] ?? null) === false || ! is_array($response['users'] ?? null)
                            || ! array_is_list($response['users']) || ! is_numeric($response['total'] ?? null)
                            || (int) $response['total'] !== count($response['users']) || count($response['users']) > count($ids)) {
                            throw new RuntimeException('Invalid or incomplete user batch');
                        }
                        $byId = [];
                        foreach ($response['users'] as $user) {
                            if (! is_array($user) || ! in_array((string) ($user['id'] ?? ''), $ids, true)
                                || isset($byId[(string) $user['id']]) || ! isset($user['status'])
                                || ! array_key_exists('data_limit', $user) || ! is_numeric($user['used_traffic'] ?? null)) {
                                throw new RuntimeException('Unexpected user in batch response');
                            }
                            $byId[(string) $user['id']] = $user;
                        }
                        foreach ($eligible as $order) {
                            $user = $byId[(string) $order->uid] ?? null;
                            if ($user === null) {
                                $result['failed']++;

                                continue; // A missing user must not be marked as deleted or zero traffic.
                            }
                            $lifecycle->applyPasarguardSnapshot($order, $user);
                            $result['checked']++;
                        }
                    }
                    $state['cursor'] = (int) $orders->last()->id;
                    unset($state['retry_at'], $state['failures']);
                    if ($orders->count() < self::BATCH_SIZE || $state['cursor'] >= $state['ceiling']) {
                        $state = ['completed_at' => now()->timestamp, 'attempted_at' => now()->timestamp];
                    }
                } catch (Throwable $exception) {
                    $state['cursor'] ??= 0;
                    $state['failures'] = min(6, ($state['failures'] ?? 0) + 1);
                    $state['retry_at'] = now()->addMinutes(min(60, 2 ** $state['failures']))->timestamp;
                    $result['failed'] += $eligible->count();
                    Log::warning('PasarGuard lifecycle batch failed', ['panel_id' => $panel->id, 'error' => $exception->getMessage()]);
                }
                Cache::put($key, $state, now()->addDays(7));
            }
            if (! $progress) {
                break;
            }
        }

        return $result;
    }

    private function key(int $panelId): string
    {
        return 'orders:lifecycle:panel:'.$panelId;
    }

    protected function fetch(Panels $panel, array $ids): mixed
    {
        return (new PasarGuard(['url' => $panel->url, 'username' => $panel->username, 'password' => $panel->password, 'id' => $panel->id]))->getUsersByIds($ids);
    }
}
